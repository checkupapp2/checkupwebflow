import '../../profile/domain/profile_entity.dart';
import '../domain/models/user_profile_model.dart';

/// Map ProfileEntity -> UserProfileModel (used by Menu only)
/// Note: isLookingToHoop will be set by the BLoC based on existing state
UserProfileModel toMenuUser(ProfileEntity e, {bool? preserveToggleState}) {
  return UserProfileModel(
    username: e.username,
    fullName: e.fullName,
    profileImageUrl: e.profileImageUrl,
    // Sensible defaults for now; wire to real fields later if you add them
    isStar: true,
    isLookingToHoop:
        preserveToggleState ?? false, // Use preserved state or default to false
    version: 'V 2.0.0.11',
  );
}
