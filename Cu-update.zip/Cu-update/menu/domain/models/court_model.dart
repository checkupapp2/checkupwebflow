/// Model class for basketball courts
class CourtModel {
  /// Unique identifier for the court
  final String id;
  
  /// Name of the court
  final String name;
  
  /// Address of the court
  final String address;
  
  /// Distance from user's current location in miles
  final double distance;
  
  /// Number of people currently checked in at this court
  final int peopleCount;
  
  /// URL for the court image
  final String? imageUrl;
  
  /// Whether the user is currently checked in at this court
  bool isCheckedIn;
  
  /// Constructor
  CourtModel({
    required this.id,
    required this.name,
    required this.address,
    required this.distance,
    required this.peopleCount,
    this.imageUrl,
    this.isCheckedIn = false,
  });
}
