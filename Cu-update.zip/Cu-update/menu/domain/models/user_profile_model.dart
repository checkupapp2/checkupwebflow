import 'package:equatable/equatable.dart';

class UserProfileModel extends Equatable {
  final String username;
  final String fullName;
  final String? profileImageUrl;
  final bool isStar;
  final bool isLookingToHoop;
  final String version;
  final String verificationStatus;

  const UserProfileModel({
    required this.username,
    required this.fullName,
    this.profileImageUrl,
    required this.isStar,
    required this.isLookingToHoop,
    required this.version,
    this.verificationStatus = 'unverified',
  });

  UserProfileModel copyWith({
    String? username,
    String? fullName,
    String? profileImageUrl,
    bool? isStar,
    bool? isLookingToHoop,
    String? version,
    String? verificationStatus,
  }) {
    return UserProfileModel(
      username: username ?? this.username,
      fullName: fullName ?? this.fullName,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      isStar: isStar ?? this.isStar,
      isLookingToHoop: isLookingToHoop ?? this.isLookingToHoop,
      version: version ?? this.version,
      verificationStatus: verificationStatus ?? this.verificationStatus,
    );
  }

  @override
  List<Object?> get props => [
        username,
        fullName,
        profileImageUrl,
        isStar,
        isLookingToHoop,
        version,
        verificationStatus
      ];
}
