import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../events/bloc/my_events/my_events_cubit.dart';
import '../../events/data/events_repository.dart';
import '../../events/presentation/pages/my_events_page.dart';
import '../../profile/data/firebase_profile_repository.dart';
import '../bloc/menu_bloc.dart';
import '../bloc/menu_event.dart';
import '../bloc/menu_state.dart';
import '../data/menu_data_provider.dart';
import '../domain/models/court_model.dart';
import 'package:check_up_app/core/mixins/resettable_screen_mixin.dart';
import 'widgets/profile_card.dart';
import '../../trophies/trophies.dart';
import 'widgets/courts_bottom_sheet.dart';
import 'widgets/check_in_confirmation_dialog.dart';
import 'widgets/check_in_success_notification.dart';
import '../../qr_code/presentation/qr_code_screen.dart';
import '../../settings/presentation/pages/contact_us_page.dart';

/// Menu screen implementation with modern UI design
class MenuScreen extends StatefulWidget {
  /// Constructor
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen>
    with ResettableScreenMixin<MenuScreen>
    implements ResettableScreen {
  // Menu data provider
  final MenuDataProvider _menuDataProvider = MenuDataProvider();

  // Nearby courts
  late List<CourtModel> _nearbyCourts;

  // Currently checked in court
  CourtModel? _checkedInCourt;

  @override
  void initState() {
    super.initState();
    _nearbyCourts = _menuDataProvider.getNearbyCourts();
  }

  @override
  String get screenKey => 'menu_screen';

  @override
  void resetToDefaultView() {
    if (mounted) {
      // Reset any expanded sections or active dialogs
      // For menu screen, we might just need to reset scroll position
      // or close any open bottom sheets

      // If there are any open bottom sheets, close them
      Navigator.of(context).popUntil((route) => route.isFirst);

      // Refresh data if needed
      setState(() {
        _nearbyCourts = _menuDataProvider.getNearbyCourts();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // final toolCards = _menuDataProvider.getToolCards();
    // final navigationShortcuts = _menuDataProvider.getNavigationShortcuts();

    return BlocProvider(
      create: (_) => MenuBloc(
        profileRepo: FirebaseProfileRepository(),
        dataProvider: MenuDataProvider(),
      )..add(MenuStarted()),
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: _buildAppBar(),
        body: BlocBuilder<MenuBloc, MenuState>(
          builder: (context, state) {
            print(
                '🏗️ BlocBuilder rebuilding with user.isLookingToHoop: ${state.user?.isLookingToHoop}');
            if (state.status != MenuStatus.success || state.user == null) {
              return const Center(child: CircularProgressIndicator());
            }
            final user = state.user!; // <-- safe now
            final toolCards =
                context.read<MenuBloc>().dataProvider.getToolCards();
            final navigationShortcuts =
                context.read<MenuBloc>().dataProvider.getNavigationShortcuts();

            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Profile card - more compact
                  ProfileCard(
                    user: user,
                    onProfileTap: _handleProfileTap,
                    onCheckInTap: _handleCheckInTap,
                    isCheckedIn: _checkedInCourt != null,
                  ),

                  const SizedBox(height: 20),

                  // 🎯 QUICK ACTIONS Section
                  _buildSectionHeader('🎯 QUICK ACTIONS'),
                  const SizedBox(height: 12),
                  _buildQuickActionsRow(),

                  const SizedBox(height: 24),

                  // 📅 MY ACTIVITIES Section
                  _buildSectionHeader('📅 MY ACTIVITIES'),
                  const SizedBox(height: 12),
                  _buildMyActivitiesRow(navigationShortcuts),

                  const SizedBox(height: 24),

                  // 🏀 GAME TOOLS Section
                  _buildSectionHeader('🏀 GAME TOOLS'),
                  const SizedBox(height: 12),
                  _buildGameToolsRow(toolCards),

                  const SizedBox(height: 24),

                  // ⚙️ MANAGEMENT Section
                  _buildSectionHeader('⚙️ MANAGEMENT'),
                  const SizedBox(height: 12),
                  _buildManagementGrid(navigationShortcuts),

                  const SizedBox(height: 24),

                  const SizedBox(height: 50),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.black,
      elevation: 0,
      toolbarHeight: 60, // Reduced from 80 to 60 to match smaller logo
      title: Row(
        children: [
          Container(
            width: 44, // Reduced from 64 to 44 for smaller logo
            height: 44, // Reduced from 64 to 44 for smaller logo
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withOpacity(0.3),
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/main_btn.png',
                width: 44, // Reduced from 64 to 44 for smaller logo
                height: 44, // Reduced from 64 to 44 for smaller logo
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => const Icon(
                  Icons.sports_basketball,
                  color: Colors.white,
                  size: 32, // Reduced from 42 to 32 for smaller logo
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          const Text(
            'MENU',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.0,
            ),
          ),
        ],
      ),
      actions: [
        // Trophy/Experience badge - tappable to navigate to trophies page
        GestureDetector(
          onTap: () {
            HapticFeedback.mediumImpact();
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => const TrophiesScreen(),
              ),
            );
          },
          child: Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.star,
                  color: Colors.white,
                  size: 16,
                ),
                const SizedBox(width: 6),
                const Text(
                  'Superstar',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Montserrat',
                  ),
                ),
                const SizedBox(width: 4),
                Container(
                  width: 1,
                  height: 12,
                  color: Colors.white.withOpacity(0.3),
                ),
                const SizedBox(width: 4),
                const Text(
                  '87XP',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Montserrat',
                  ),
                ),
              ],
            ),
          ),
        ),
        // QR Code button with larger icon
        IconButton(
          icon: const Icon(
            Icons.qr_code_scanner,
            color: Colors.white,
            size: 30, // Increased size from default
          ),
          iconSize: 30, // Ensure the touch target is also larger
          onPressed: _handleQrCodeTap,
          padding: const EdgeInsets.all(8.0),
        ),
      ],
    );
  }

  // Handler methods
  void _handleProfileTap() {
    HapticFeedback.mediumImpact();
    // Navigate to the profile page
    Navigator.pushNamed(context, '/profile');
  }

  void _handleCheckInTap() {
    HapticFeedback.mediumImpact();

    // Show bottom sheet with nearby courts - simplified scrolling
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      enableDrag: true,
      isDismissible: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.85,
        child: CourtsBottomSheet(
          courts: _nearbyCourts,
          onCourtSelected: _handleCourtSelected,
        ),
      ),
    );
  }

  // Handle when a court is selected for check-in
  void _handleCourtSelected(CourtModel court) {
    // Close the bottom sheet
    Navigator.of(context).pop();

    // Show confirmation dialog
    showDialog(
      context: context,
      builder: (context) => CheckInConfirmationDialog(
        court: court,
        onConfirm: () => _handleCheckInConfirmed(court),
        onCancel: () => Navigator.of(context).pop(),
      ),
    );
  }

  // Handle when check-in is confirmed
  void _handleCheckInConfirmed(CourtModel court) {
    // Close the dialog
    Navigator.of(context).pop();

    // Update the checked-in court
    setState(() {
      // If there was a previous check-in, reset it
      if (_checkedInCourt != null) {
        _checkedInCourt!.isCheckedIn = false;
      }

      // Set the new check-in
      court.isCheckedIn = true;
      _checkedInCourt = court;
    });

    // Show success notification
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: CheckInSuccessNotification(court: court),
        backgroundColor: Colors.transparent,
        elevation: 0,
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        padding: EdgeInsets.zero,
      ),
    );
  }

  // Handle tool tap navigation
  void _handleToolTap(ToolCardModel tool) {
    HapticFeedback.mediumImpact();

    if (tool.route == '/camera' &&
        tool.extraData != null &&
        tool.extraData!.containsKey('tab')) {
      // Navigate to camera page with specific tab
      final int tabIndex = tool.extraData!['tab'];
      Navigator.pushNamed(
        context,
        tool.route,
        arguments: {'initialTabIndex': tabIndex},
      );
    } else {
      // Regular navigation
      Navigator.pushNamed(context, tool.route);
    }
  }

  void _openRoute(String route) {
    if (route == '/events') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BlocProvider<MyEventsCubit>(
            create: (_) => MyEventsCubit(
              repo: EventsRepository(),
              auth: FirebaseAuth.instance,
            )..init(),
            child: const MyEventsPage(),
          ),
        ),
      );
    } else if (route == '/contact') {
      // Navigate directly to contact us page using MaterialPageRoute
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const ContactUsPage(),
        ),
      );
    } else if (route == '/trophies') {
      // Navigate directly to trophies page using MaterialPageRoute
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const TrophiesScreen(),
        ),
      );
    } else {
      Navigator.pushNamed(context, route);
    }
  }

  void _handleNotificationsTap() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const TrophiesScreen(),
      ),
    );
  }

  void _handleQrCodeTap() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const QrCodeScreen(),
      ),
    );
  }

  void _handleAddButtonTap() {
    HapticFeedback.mediumImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Add button tapped')),
    );
  }

  // Section header builder
  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Text(
        title,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  // Quick Actions Row (My Courts, My Banks, Premium)
  Widget _buildQuickActionsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          // My Courts Action
          Expanded(
            child: _buildQuickActionCard(
              title: 'My Courts',
              icon: Icons.sports_basketball,
              onTap: () {
                HapticFeedback.mediumImpact();
                _openRoute('/courts');
              },
            ),
          ),
          const SizedBox(width: 12),
          // My Banks Action
          Expanded(
            child: _buildQuickActionCard(
              title: 'My Banks',
              icon: Icons.account_balance,
              onTap: () {
                HapticFeedback.mediumImpact();
                _openRoute('/banks');
              },
            ),
          ),
          const SizedBox(width: 12),
          // Premium Action - special styling
          Expanded(
            child: _buildPremiumActionCard(
              title: 'Premium',
              icon: Icons.workspace_premium,
              onTap: () {
                HapticFeedback.mediumImpact();
                Navigator.of(context).pushNamed('/membership');
              },
            ),
          ),
        ],
      ),
    );
  }

  // Quick Action Card Builder
  Widget _buildQuickActionCard({
    required String title,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 80,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFFF9800),
              Color(0xFFFF5722),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF9800).withOpacity(0.3),
              blurRadius: 8,
              spreadRadius: 1,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: 24,
            ),
            const SizedBox(height: 6),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // My Activities Row (Schedule, Bookings)
  Widget _buildMyActivitiesRow(List<NavigationShortcutModel> shortcuts) {
    final scheduleShortcut = shortcuts.firstWhere((s) => s.route == '/events');
    final bookingsShortcut =
        shortcuts.firstWhere((s) => s.route == '/bookings');

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Expanded(
            child: _buildActivityCard(scheduleShortcut),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildActivityCard(bookingsShortcut),
          ),
        ],
      ),
    );
  }

  // Premium Action Card Builder - special black gradient with gold icon
  Widget _buildPremiumActionCard({
    required String title,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 80,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2C2C2C),
              Color(0xFF1A1A1A),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: const Color(0xFFFFD700),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFFD700).withOpacity(0.3),
              blurRadius: 12,
              spreadRadius: 1,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFFFFD700),
                    Color(0xFFFFA500),
                  ],
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                color: Colors.black,
                size: 20,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              title,
              style: const TextStyle(
                color: Color(0xFFFFD700),
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // Activity Card Builder
  Widget _buildActivityCard(NavigationShortcutModel shortcut) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        _openRoute(shortcut.route);
      },
      child: Container(
        height: 100,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.grey[800]!,
              Colors.grey[900]!,
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.grey[700]!,
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 8,
              spreadRadius: 1,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    shortcut.icon,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                const Spacer(),
                if (shortcut.badgeCount != null && shortcut.badgeCount! > 0)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${shortcut.badgeCount}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              shortcut.title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Game Tools Row (Scoreboard, ScoreCam, Brackets)
  Widget _buildGameToolsRow(List<ToolCardModel> toolCards) {
    return SizedBox(
      height: 80,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: toolCards.length,
        itemBuilder: (context, index) {
          final tool = toolCards[index];
          return Container(
            width: 120,
            margin:
                EdgeInsets.only(right: index < toolCards.length - 1 ? 12 : 0),
            child: _buildGameToolCard(tool),
          );
        },
      ),
    );
  }

  // Game Tool Card Builder
  Widget _buildGameToolCard(ToolCardModel tool) {
    return GestureDetector(
      onTap: () => _handleToolTap(tool),
      child: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFFF9800),
              Color(0xFFFF5722),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF9800).withOpacity(0.3),
              blurRadius: 8,
              spreadRadius: 1,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              tool.icon,
              color: Colors.white,
              size: 24,
            ),
            const SizedBox(height: 6),
            Text(
              tool.title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  // Management Row (Support, Settings) - using same layout as My Activities
  Widget _buildManagementGrid(List<NavigationShortcutModel> shortcuts) {
    final supportShortcut = shortcuts.firstWhere((s) => s.route == '/contact');
    final settingsShortcut =
        shortcuts.firstWhere((s) => s.route == '/settings');

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Expanded(
            child: _buildManagementCard(supportShortcut),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildManagementCard(settingsShortcut),
          ),
        ],
      ),
    );
  }

  // Management Card Builder - using same style as My Activities
  Widget _buildManagementCard(NavigationShortcutModel shortcut) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        _openRoute(shortcut.route);
      },
      child: Container(
        height: 100,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.grey[800]!,
              Colors.grey[900]!,
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.grey[700]!,
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 8,
              spreadRadius: 1,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    shortcut.icon,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                const Spacer(),
                if (shortcut.badgeCount != null && shortcut.badgeCount! > 0)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${shortcut.badgeCount}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              shortcut.title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
