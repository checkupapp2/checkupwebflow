import 'package:shared_preferences/shared_preferences.dart';

/// Service for managing guest mode state and restrictions
class GuestModeService {
  static const String _isGuestModeKey = 'is_guest_mode';

  /// Check if the user is currently in guest mode
  static Future<bool> isGuestMode() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_isGuestModeKey) ?? false;
    } catch (e) {
      // If SharedPreferences fails, default to false (not guest mode)
      print('Error accessing SharedPreferences in isGuestMode: $e');
      return false;
    }
  }

  /// Set guest mode status
  static Future<void> setGuestMode(bool isGuest) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_isGuestModeKey, isGuest);
    } catch (e) {
      // Log error but don't crash the app
      print('Error setting guest mode in SharedPreferences: $e');
    }
  }

  /// Clear guest mode (when user signs up/logs in)
  static Future<void> clearGuestMode() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_isGuestModeKey);
    } catch (e) {
      // Log error but don't crash the app
      print('Error clearing guest mode in SharedPreferences: $e');
    }
  }

  /// List of restricted features for guest users
  static const List<String> restrictedFeatures = [
    'inbox',
    'menu',
    'create_event',
    'join_league',
    'book_court',
    'messaging',
    'profile_settings',
    'payment_methods',
    'hosting_features',
  ];

  /// Check if a feature is restricted for guest users
  static bool isFeatureRestricted(String feature) {
    return restrictedFeatures.contains(feature);
  }
}
