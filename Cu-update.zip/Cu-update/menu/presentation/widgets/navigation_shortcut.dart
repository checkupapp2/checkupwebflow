import 'package:flutter/material.dart';
import '../../data/menu_data_provider.dart';

/// Widget for displaying a navigation shortcut in the menu screen
class NavigationShortcut extends StatefulWidget {
  /// The navigation shortcut data
  final NavigationShortcutModel shortcut;
  
  /// Callback when the shortcut is tapped
  final VoidCallback? onTap;
  
  /// Constructor
  const NavigationShortcut({
    super.key,
    required this.shortcut,
    this.onTap,
  });

  @override
  State<NavigationShortcut> createState() => _NavigationShortcutState();
}

class _NavigationShortcutState extends State<NavigationShortcut> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  bool _isPressed = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.9).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTapDown(TapDownDetails details) {
    _controller.forward();
    setState(() => _isPressed = true);
  }

  void _handleTapUp(TapUpDetails details) {
    _controller.reverse();
    setState(() => _isPressed = false);
  }

  void _handleTapCancel() {
    _controller.reverse();
    setState(() => _isPressed = false);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _handleTapDown,
      onTapUp: _handleTapUp,
      onTapCancel: _handleTapCancel,
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _scaleAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: child,
          );
        },
        child: Container(
          width: 90, // Increased width for better visibility
          margin: const EdgeInsets.symmetric(horizontal: 6), // Adjusted margin for spacing
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon with badge
              Stack(
                clipBehavior: Clip.none,
                children: [
                  // Icon container with gradient background
                  Container(
                    width: 70, // Increased width for better visibility
                    height: 70, // Increased height for better visibility
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.grey[700]!,
                          Colors.grey[800]!,
                          Colors.grey[900]!,
                        ],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: _isPressed 
                            ? const Color(0xFFFF9800).withOpacity(0.7)
                            : Colors.grey[800]!,
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _isPressed 
                              ? Colors.transparent 
                              : Colors.black.withOpacity(0.4),
                          blurRadius: 10,
                          spreadRadius: 2,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Icon(
                      widget.shortcut.icon,
                      color: const Color(0xFFFF9800),
                      size: 34, // Increased icon size for better visibility
                    ),
                  ),
                  
                  // Badge if there are unread items
                  if (widget.shortcut.badgeCount != null && widget.shortcut.badgeCount! > 0)
                    Positioned(
                      top: -5,
                      right: -5,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Colors.red, Colors.redAccent],
                          ),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.red.withOpacity(0.5),
                              blurRadius: 6,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 20,
                          minHeight: 20,
                        ),
                        child: Center(
                          child: Text(
                            '${widget.shortcut.badgeCount}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              
              // Title
              Text(
                widget.shortcut.title,
                style: TextStyle(
                  color: _isPressed ? const Color(0xFFFF9800) : Colors.white,
                  fontSize: 12.5, // Increased font size for better readability
                  fontWeight: FontWeight.w700, // Bolder text for better visibility
                  letterSpacing: 0.2,
                ),
                textAlign: TextAlign.center,
                maxLines: 2, // Allow two lines for longer text
                overflow: TextOverflow.ellipsis, // Handle overflow gracefully
              ),
            ],
          ),
        ),
      ),
    );
  }
}
