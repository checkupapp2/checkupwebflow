import 'package:flutter/material.dart';
import 'dart:math';
import '../../../profile/presentation/pages/owner_profile_page.dart';
import '../../domain/models/user_profile_model.dart';

/// Widget for displaying the user profile card in the menu screen
class ProfileCard extends StatelessWidget {
  /// The user profile data
  final UserProfileModel user;

  /// Callback when the profile is tapped
  final VoidCallback? onProfileTap;

  /// Callback when the check-in button is tapped
  final VoidCallback? onCheckInTap;

  /// Whether the user is currently checked in to a court
  final bool isCheckedIn;

  /// Constructor
  const ProfileCard({
    super.key,
    required this.user,
    this.onProfileTap,
    this.onCheckInTap,
    this.isCheckedIn = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Profile section - more compact
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                // Profile image - smaller
                _buildProfileImage(),
                const SizedBox(width: 12),

                // Username and full name
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user.username,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        user.fullName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        softWrap: false,
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),

                // View profile button - smaller
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const OwnerProfilePage(),
                      ),
                    );
                  },
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Text(
                      'view profile',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Check-in button - more compact
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: GestureDetector(
              onTap: onCheckInTap,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Text(
                    'CHECK-IN',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Version number - more compact
          Center(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                user.version,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 11,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileImage() {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Status-based moving ring animation
        SizedBox(
          width: 60, // Smaller than profile page but larger than original
          height: 60,
          child: _buildStatusRing(),
        ),

        // Profile image container - smaller
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF9800).withOpacity(0.3),
                blurRadius: 6,
                spreadRadius: 1,
              ),
            ],
          ),
          child: ClipOval(
            child: user.profileImageUrl != null
                ? Image.network(
                    user.profileImageUrl!,
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.person, color: Colors.white, size: 30),
                  )
                : const Icon(Icons.person, color: Colors.white, size: 30),
          ),
        ),

        // Looking to hoop indicator - smaller
        Positioned(
          bottom: 0,
          right: 0,
          child: Container(
            width: 16,
            height: 16,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: user.isLookingToHoop ? Colors.green : Colors.grey,
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: Icon(
              user.isLookingToHoop ? Icons.sports_basketball : Icons.close,
              color: Colors.white,
              size: 10,
            ),
          ),
        ),

        // Verification badge
        Positioned(
          bottom: 0,
          right: 0,
          child: Container(
            width: 16,
            height: 16,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF9800), // Orange
                  Color(0xFFFF5722), // Deep Orange
                ],
              ),
              border: Border.all(
                color: Colors.black,
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withValues(alpha: 0.7),
                  blurRadius: 6,
                  spreadRadius: 1,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: const Center(
              child: Icon(
                Icons.verified,
                color: Colors.white,
                size: 16,
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Builds the status-based moving ring animation
  Widget _buildStatusRing() {
    // Determine ring colors based on user status priority:
    // 1. Checked-in (orange gradient) - highest priority
    // 2. Looking to hoop (green) - medium priority
    // 3. Inactive (gray) - default state
    List<Color> ringColors;

    print(
        '🎨 Ring color logic - isCheckedIn: $isCheckedIn, isLookingToHoop: ${user.isLookingToHoop}');

    if (isCheckedIn) {
      // Orange gradient ring for "checked-in" status
      print('🟠 Setting ORANGE ring (checked-in)');
      ringColors = [
        const Color(0xFFFF9800), // Orange
        const Color(0xFFFF5722), // Deep Orange
        const Color(0xFFFFFFFF), // White for contrast
        const Color(0xFFFF9800), // Orange
      ];
    } else if (user.isLookingToHoop) {
      // Green ring for "looking to hoop"
      print('🟢 Setting GREEN ring (looking to hoop)');
      ringColors = [
        const Color(0xFF4CAF50), // Green
        const Color(0xFF66BB6A), // Light Green
        const Color(0xFFFFFFFF), // White for contrast
        const Color(0xFF4CAF50), // Green
      ];
    } else {
      // Gray ring for inactive
      print('⚪ Setting GRAY ring (inactive)');
      ringColors = [
        const Color(0xFF757575), // Gray
        const Color(0xFF9E9E9E), // Light Gray
        const Color(0xFFBDBDBD), // Lighter Gray
        const Color(0xFF757575), // Gray
      ];
    }

    return AnimatedStatusRing(colors: ringColors);
  }
}

/// Animated status ring widget with customizable colors
class AnimatedStatusRing extends StatefulWidget {
  final List<Color> colors;

  const AnimatedStatusRing({super.key, required this.colors});

  @override
  State<AnimatedStatusRing> createState() => _AnimatedStatusRingState();
}

class _AnimatedStatusRingState extends State<AnimatedStatusRing>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );
    _controller.repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(AnimatedStatusRing oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Force rebuild when colors change
    if (oldWidget.colors != widget.colors) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          painter: _StatusRingPainter(_controller.value, widget.colors),
          child: Container(),
        );
      },
    );
  }
}

/// Custom painter for the status ring with customizable colors
class _StatusRingPainter extends CustomPainter {
  final double animationValue;
  final List<Color> colors;

  _StatusRingPainter(this.animationValue, this.colors);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // Create gradient for the ring with custom colors
    final rect = Rect.fromCircle(center: center, radius: radius);

    // Create gradient with the provided colors
    final gradient = SweepGradient(
      startAngle: 0,
      endAngle: 6.28, // 2*pi
      colors: colors,
      stops: const [0.0, 0.3, 0.6, 1.0], // Control color distribution
      transform: GradientRotation(6.28 * animationValue), // 2*pi
    );

    // Glow effect (outer ring)
    final glowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3.0)
      ..shader = gradient.createShader(rect);

    // Main ring
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.0 // Increased width for more visibility
      ..shader = gradient.createShader(rect);

    // Draw both rings
    canvas.drawCircle(center, radius - glowPaint.strokeWidth / 2, glowPaint);
    canvas.drawCircle(center, radius - paint.strokeWidth / 2, paint);

    // Add small dots along the ring for more visual movement
    final dotRadius = 2.0;
    final dotPaint = Paint()..color = Colors.white;

    // Draw 3 dots at different positions based on animation value
    for (int i = 0; i < 3; i++) {
      final angle = 6.28 * ((animationValue + (i / 3)) % 1.0); // 2*pi
      final dotX = center.dx + (radius - 3) * cos(angle);
      final dotY = center.dy + (radius - 3) * sin(angle);
      canvas.drawCircle(Offset(dotX, dotY), dotRadius, dotPaint);
    }
  }

  @override
  bool shouldRepaint(_StatusRingPainter oldDelegate) =>
      oldDelegate.animationValue != animationValue ||
      oldDelegate.colors != colors;
}
