// menu_state.dart
import 'package:equatable/equatable.dart';
import '../../profile/domain/profile_entity.dart';
import '../domain/models/court_model.dart';
import '../domain/models/user_profile_model.dart';
// import '../domain/models/user_profile_model.dart'; // whatever your ProfileCard uses

enum MenuStatus { initial, loading, success, failure }

class MenuState extends Equatable {
  final MenuStatus status;
  final UserProfileModel? user; // mapped for UI
  final List<CourtModel> nearbyCourts;
  final CourtModel? checkedInCourt;
  final String? error;

  const MenuState({
    this.status = MenuStatus.initial,
    this.user,
    this.nearbyCourts = const [],
    this.checkedInCourt,
    this.error,
  });

  MenuState copyWith({
    MenuStatus? status,
    UserProfileModel? user,
    List<CourtModel>? nearbyCourts,
    CourtModel? checkedInCourt,
    String? error,
  }) {
    return MenuState(
      status: status ?? this.status,
      user: user ?? this.user,
      nearbyCourts: nearbyCourts ?? this.nearbyCourts,
      checkedInCourt: checkedInCourt ?? this.checkedInCourt,
      error: error,
    );
  }

  @override
  List<Object?> get props =>
      [status, user, nearbyCourts, checkedInCourt, error];
}
