import 'package:bloc/bloc.dart';
import 'menu_event.dart';
import 'menu_state.dart';
import '../../profile/data/profile_repository.dart';
import '../domain/menu_user_mapper.dart' as menu_mapper; // <-- change
import '../data/menu_data_provider.dart';

class MenuBloc extends Bloc<MenuEvent, MenuState> {
  final ProfileRepository profileRepo;
  final MenuDataProvider dataProvider;

  MenuBloc({
    required this.profileRepo,
    required this.dataProvider,
  }) : super(const MenuState()) {
    on<MenuStarted>(_onLoad);
    on<MenuRefreshed>(_onLoad);
    on<LookingToHoopToggled>(_onLookingToHoopToggled);
    on<CourtSelected>(_onCourtSelected);
  }

  Future<void> _onLoad(MenuEvent event, Emitter<MenuState> emit) async {
    emit(state.copyWith(status: MenuStatus.loading, error: null));
    try {
      final entity = await profileRepo.getCurrent();

      // Preserve existing toggle state if user already exists
      final currentToggleState = state.user?.isLookingToHoop;
      final user = menu_mapper.toMenuUser(entity,
          preserveToggleState: currentToggleState);

      final courts = dataProvider.getNearbyCourts();
      emit(state.copyWith(
        status: MenuStatus.success,
        user: user,
        nearbyCourts: courts,
      ));
    } catch (e) {
      emit(state.copyWith(status: MenuStatus.failure, error: e.toString()));
    }
  }

  void _onLookingToHoopToggled(
      LookingToHoopToggled e, Emitter<MenuState> emit) {
    print('🔄 BLoC _onLookingToHoopToggled called with value: ${e.value}');
    final u = state.user;
    if (u == null) {
      print('❌ User is null, cannot toggle');
      return;
    }
    print(
        '📊 Current user isLookingToHoop: ${u.isLookingToHoop}, new value: ${e.value}');
    final updatedUser = u.copyWith(isLookingToHoop: e.value);
    print('✅ Updated user isLookingToHoop: ${updatedUser.isLookingToHoop}');

    final newState = state.copyWith(user: updatedUser);
    print(
        '🚀 About to emit new state with user.isLookingToHoop: ${newState.user?.isLookingToHoop}');
    emit(newState);
    print('✨ State emitted successfully');
  }

  void _onCourtSelected(CourtSelected e, Emitter<MenuState> emit) {
    for (final c in state.nearbyCourts) {
      c.isCheckedIn = false;
    }
    e.court.isCheckedIn = true;
    emit(state.copyWith(checkedInCourt: e.court));
  }
}
