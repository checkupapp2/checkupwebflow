// menu_event.dart
import 'package:equatable/equatable.dart';
import '../../profile/domain/profile_entity.dart';
import '../domain/models/court_model.dart';

abstract class MenuEvent extends Equatable {
  const MenuEvent();
  @override
  List<Object?> get props => [];
}

class MenuStarted extends MenuEvent {}

class MenuRefreshed extends MenuEvent {}

class LookingToHoopToggled extends MenuEvent {
  final bool value;
  const LookingToHoopToggled(this.value);
  @override
  List<Object?> get props => [value];
}

class CourtSelected extends MenuEvent {
  final CourtModel court;
  const CourtSelected(this.court);
  @override
  List<Object?> get props => [court];
}
