import 'package:flutter/material.dart';
import '../domain/models/court_model.dart';
import '../domain/models/user_profile_model.dart';

/// Provider class for menu data
class MenuDataProvider {
  /// Get the current user data
  UserProfileModel getCurrentUser() {
    // Mock data for the current user
    return const UserProfileModel(
      username: '33username',
      fullName: 'full name',
      profileImageUrl: null,
      isStar: true,
      isLookingToHoop: false,
      version: 'V 2.0.0.11',
    );
  }

  /// Get tools cards
  List<ToolCardModel> getToolCards() {
    return [
      ToolCardModel(
        title: 'Scoreboard',
        description: 'Track scores and game stats',
        icon: Icons.scoreboard,
        color: const Color(0xFFFF9800),
        route: '/scoreboard',
      ),
      ToolCardModel(
        title: 'ScoreCam',
        description: 'Record and analyze your shooting form',
        icon: Icons.videocam,
        color: const Color(0xFFFF9800),
        route: '/camera',
        extraData: {'tab': 2}, // Index 2 for Score-cam tab
      ),
      ToolCardModel(
        title: 'Brackets',
        description: 'Tournament brackets and standings',
        icon: Icons.emoji_events,
        color: const Color(0xFFFF9800),
        route: '/brackets',
      ),
    ];
  }

  /// Get navigation shortcuts - Revenue ready version
  List<NavigationShortcutModel> getNavigationShortcuts() {
    return [
      // First row - core features
      NavigationShortcutModel(
        title: 'MY SCHEDULE',
        icon: Icons.calendar_today,
        route: '/events',
        badgeCount: 2,
        row: 1,
      ),
      NavigationShortcutModel(
        title: 'MY BOOKINGS',
        icon: Icons.book_online,
        route: '/bookings',
        badgeCount: 5,
        row: 1,
      ),
      NavigationShortcutModel(
        title: 'MY COURTS',
        icon: Icons.sports_basketball,
        route: '/courts',
        row: 1,
      ),
      NavigationShortcutModel(
        title: 'MY BANKS',
        icon: Icons.account_balance_wallet,
        route: '/banks',
        row: 1,
      ),

      // Second row - additional features
      NavigationShortcutModel(
        title: 'MY BRACKETS',
        icon: Icons.emoji_events,
        route: '/brackets',
        row: 2,
      ),
      NavigationShortcutModel(
        title: 'SUPPORT',
        icon: Icons.help_center,
        route: '/contact',
        row: 2,
      ),
      NavigationShortcutModel(
        title: 'TROPHIES',
        icon: Icons.emoji_events,
        route: '/trophies',
        row: 2,
      ),
      NavigationShortcutModel(
        title: 'SETTINGS',
        icon: Icons.settings,
        route: '/settings',
        row: 2,
      ),
    ];
  }

  /// Get nearby courts within 5-mile radius
  List<CourtModel> getNearbyCourts() {
    // Mock data for nearby courts - only showing courts within 5 miles
    final allCourts = [
      CourtModel(
        id: '1',
        name: 'Venice Beach Courts',
        address: '1800 Ocean Front Walk, Venice, CA',
        distance: 0.3,
        peopleCount: 24,
        imageUrl: 'assets/images/courts/venice_beach.jpg',
      ),
      CourtModel(
        id: '2',
        name: 'Rucker Park',
        address: '155th St & Frederick Douglass Blvd, NY',
        distance: 0.8,
        peopleCount: 18,
        imageUrl: 'assets/images/courts/rucker_park.jpg',
      ),
      CourtModel(
        id: '3',
        name: 'The Cage',
        address: 'West 4th Street, New York, NY',
        distance: 1.2,
        peopleCount: 12,
        imageUrl: 'assets/images/courts/the_cage.jpg',
      ),
      CourtModel(
        id: '4',
        name: 'Mosswood Park',
        address: '3612 Webster St, Oakland, CA',
        distance: 1.5,
        peopleCount: 8,
        imageUrl: 'assets/images/courts/mosswood.jpg',
      ),
      CourtModel(
        id: '5',
        name: 'Dyckman Courts',
        address: 'Dyckman St & Nagle Ave, New York, NY',
        distance: 2.1,
        peopleCount: 15,
        imageUrl: 'assets/images/courts/dyckman.jpg',
      ),
      CourtModel(
        id: '6',
        name: 'Holcombe Rucker Park',
        address: 'W 155th St, New York, NY',
        distance: 3.2,
        peopleCount: 32,
        imageUrl: 'assets/images/courts/holcombe.jpg',
      ),
      CourtModel(
        id: '7',
        name: 'Marcus Garvey Park',
        address: 'E 124th St, New York, NY',
        distance: 4.1,
        peopleCount: 19,
        imageUrl: 'assets/images/courts/marcus_garvey.jpg',
      ),
      CourtModel(
        id: '8',
        name: 'Sunset Park Courts',
        address: '4th Ave & 41st St, Brooklyn, NY',
        distance: 4.8,
        peopleCount: 14,
        imageUrl: 'assets/images/courts/sunset_park.jpg',
      ),
      // Courts beyond 5 miles - should be filtered out
      CourtModel(
        id: '9',
        name: 'Far Court',
        address: 'Far Away Street, Distant City',
        distance: 6.2,
        peopleCount: 5,
        imageUrl: 'assets/images/courts/far_court.jpg',
      ),
    ];

    // Filter courts within 5-mile radius and sort by distance
    return allCourts.where((court) => court.distance <= 5.0).toList()
      ..sort((a, b) => a.distance.compareTo(b.distance));
  }
}

/// Model class for user profile
// class UserProfileModel {
//   /// Username
//   final String username;

//   /// Full name
//   final String fullName;

//   /// Profile image URL
//   final String? profileImageUrl;

//   /// Whether the user is a star
//   final bool isStar;

//   /// Whether the user is looking to hoop
//   final bool isLookingToHoop;

//   /// App version
//   final String version;

//   /// Constructor
//   const UserProfileModel({
//     required this.username,
//     required this.fullName,
//     this.profileImageUrl,
//     required this.isStar,
//     required this.isLookingToHoop,
//     required this.version,
//   });

//   /// Create a copy of this model with given fields replaced
//   UserProfileModel copyWith({
//     String? username,
//     String? fullName,
//     String? profileImageUrl,
//     bool? isStar,
//     bool? isLookingToHoop,
//     String? version,
//   }) {
//     return UserProfileModel(
//       username: username ?? this.username,
//       fullName: fullName ?? this.fullName,
//       profileImageUrl: profileImageUrl ?? this.profileImageUrl,
//       isStar: isStar ?? this.isStar,
//       isLookingToHoop: isLookingToHoop ?? this.isLookingToHoop,
//       version: version ?? this.version,
//     );
//   }
// }

/// Model class for tool cards
class ToolCardModel {
  /// Title of the tool
  final String title;

  /// Description of the tool
  final String description;

  /// Icon for the tool
  final IconData icon;

  /// Background color
  final Color color;

  /// Route to navigate to when tapped
  final String route;

  /// Extra data to pass to the route
  final Map<String, dynamic>? extraData;

  /// Constructor
  const ToolCardModel({
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
    required this.route,
    this.extraData,
  });
}

/// Model class for navigation shortcuts
class NavigationShortcutModel {
  /// Title of the shortcut
  final String title;

  /// Icon for the shortcut
  final IconData icon;

  /// Route to navigate to when tapped
  final String route;

  /// Badge count (optional)
  final int? badgeCount;

  /// Row number (for organizing shortcuts in multiple rows)
  final int row;

  /// Constructor
  const NavigationShortcutModel({
    required this.title,
    required this.icon,
    required this.route,
    this.badgeCount,
    required this.row,
  });
}
