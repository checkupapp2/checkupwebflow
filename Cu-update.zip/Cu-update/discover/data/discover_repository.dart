// lib/features/discover/data/discover_repository.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:check_up_app/features/events/domain/models/court_model.dart'
    show CourtModel, CourtModelFirestore;
import 'package:check_up_app/features/events/domain/models/event_model.dart';
import 'package:check_up_app/features/events/domain/models/event_model_firestore.dart';

class DiscoverRepository {
  final _db = FirebaseFirestore.instance;

  Stream<List<EventModel>> upcomingEvents({DateTime? from}) {
    final q = _db
        .collection('events')
        .orderBy('dateTime')
        .where('dateTime', isGreaterThanOrEqualTo: (from ?? DateTime.now()));

    return q.snapshots().map((s) => s.docs.map(eventFromDoc).toList());
  }

  Stream<List<CourtModel>> activeCourts() {
    final q = _db.collection('courts').where('isActive', isEqualTo: true);
    return q
        .snapshots()
        .map((s) => s.docs.map(CourtModelFirestore.fromDoc).toList());
  }
}
