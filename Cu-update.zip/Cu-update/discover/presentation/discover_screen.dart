import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:check_up_app/core/mixins/resettable_screen_mixin.dart';
import 'package:check_up_app/core/routes/app_router.dart';
import 'package:check_up_app/features/search/presentation/search_screen.dart';
import 'package:check_up_app/features/brackets/presentation/pages/brackets_page.dart';
import 'package:check_up_app/features/events/presentation/pages/event_detail_page.dart';
import 'package:check_up_app/features/search/presentation/widgets/event_filter_row.dart';
import 'package:check_up_app/features/search/data/search_repository.dart';
import 'package:check_up_app/features/search/domain/models/search_event_model.dart'
    as search;
import 'package:check_up_app/features/events/data/events_repository.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:check_up_app/features/search/bloc/search_cubit.dart';

import '../../events/data/seed_events.dart';

/// Discover screen implementation with search functionality
class DiscoverScreen extends StatefulWidget {
  /// Constructor
  const DiscoverScreen({super.key});

  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen>
    with TickerProviderStateMixin, ResettableScreenMixin<DiscoverScreen>
    implements ResettableScreen {
  final TextEditingController _searchController = TextEditingController();
  bool _isSearching = false;
  String _searchQuery = '';

  // Events section state
  String _selectedPrimaryFilter = 'Popular';
  String? _selectedSecondaryFilter;
  late final SearchCubit _eventsCubit;

  Future<void> runSeed() async {
    await seedMockEventsToFirestore(hostId: 'demo_host_001');
  }

  @override
  void initState() {
    super.initState();
    // Initialize events cubit with same setup as search page
    final eventsRepo = EventsRepository();
    final searchRepo = SearchRepository(eventsRepository: eventsRepo);
    _eventsCubit = SearchCubit(searchRepo)
      ..init(query: '', selectedFilter: _selectedPrimaryFilter);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _eventsCubit.close();
    super.dispose();
  }

  void _clearSearch() {
    setState(() {
      _searchController.clear();
      _searchQuery = '';
      _isSearching = false;
    });
    // TODO: Reset search results
  }

  @override
  String get screenKey => 'discover_screen';

  @override
  void resetToDefaultView() {
    if (mounted) {
      // Clear any search and return to main discover view
      _clearSearch();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Removed AppBar to give more room for search bar
      body: SafeArea(
        child: Column(
          children: [
            _buildSearchBar(),
            Expanded(
              child: _isSearching
                  ? _buildSearchResults()
                  : _buildDiscoverContent(),
            ),
          ],
        ),
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  void _showCreateOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFF1E1E1E),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 20),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Create',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            _buildCreateOption(
              icon: Icons.event,
              title: 'Create Event',
              subtitle: 'Organize a new basketball event',
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(
                  context,
                  AppRouter.createEventRoute,
                );
              },
            ),
            _buildCreateOption(
              icon: Icons.scoreboard,
              title: 'Scoreboard',
              subtitle: 'Access live game scoreboard',
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/scoreboard');
              },
            ),
            _buildCreateOption(
              icon: Icons.account_tree,
              title: 'Brackets',
              subtitle: 'View tournament brackets',
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/brackets');
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // Build create option item for the popup menu
  Widget _buildCreateOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.orange.shade300,
              Colors.deepOrange.shade700,
            ],
          ),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withValues(alpha: 0.3),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 28),
      ),
      title: Text(title,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle, style: TextStyle(color: Colors.grey[400])),
      trailing: const Icon(Icons.chevron_right, color: Colors.grey),
      onTap: onTap,
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 8.0),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A), // Dark theme background
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 6.0,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 4.0, bottom: 8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Image.asset(
                  'assets/images/main_btn.png',
                  width: 48, // Increased from 36 to 48
                  height: 48, // Increased from 36 to 48
                ),
                const SizedBox(width: 10),
                const Text(
                  'Discover',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            // Search button with gradient
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF333333),
                    Color(0xFF222222),
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    spreadRadius: 1,
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    // Navigate to search page
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const SearchScreen(),
                      ),
                    );
                  },
                  borderRadius: BorderRadius.circular(20),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.search, color: Colors.white, size: 18),
                        SizedBox(width: 4),
                        Text(
                          'Search',
                          style: TextStyle(
                              color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchResults() {
    // TODO: Replace with actual search results
    return Center(
      child: _searchQuery.isEmpty
          ? const Text('Enter a search term')
          : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Search results for: $_searchQuery',
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                const Text('No results found. Try a different search term.'),
              ],
            ),
    );
  }

  Widget _buildDiscoverContent() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTopButtonCards(),
            const SizedBox(height: 24),
            _buildEventsSection(),
            const SizedBox(height: 20)
          ],
        ),
      ),
    );
  }

  Widget _buildTopButtonCards() {
    return Row(
      children: [
        Expanded(
          child: _buildButtonCard(
            title: 'Book Now',
            icon: Icons.location_on,
            color: const Color(0xFFFF9800),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SearchScreen(initialTabIndex: 4),
                ),
              );
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildButtonCard(
            title: 'Scores',
            icon: Icons.scoreboard,
            color: const Color(0xFF00C853),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SearchScreen(initialTabIndex: 6),
                ),
              );
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildButtonCard(
            title: 'Brackets',
            icon: Icons.account_tree,
            color: const Color(0xFFFF6D00),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const BracketsPage(),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildButtonCard({
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        onTap();
      },
      child: Container(
        height: 120,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              color.withValues(alpha: 0.9),
              HSLColor.fromColor(color)
                  .withLightness((HSLColor.fromColor(color).lightness - 0.2)
                      .clamp(0.0, 1.0))
                  .toColor(),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.4),
              blurRadius: 15,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.2),
              ),
              child: Icon(
                icon,
                color: Colors.white,
                size: 28,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEventsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BlocBuilder<SearchCubit, SearchState>(
          bloc: _eventsCubit,
          builder: (context, state) {
            final eventCount = state.items.length;
            return Row(
              children: [
                const Text(
                  'Events',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.grey.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '$eventCount events',
                    style: TextStyle(
                      color: Colors.grey[300],
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 16),
        EventFilterRow(
          selectedPrimaryFilter: _selectedPrimaryFilter,
          onFilterSelected: _handleFilterSelected,
        ),
        const SizedBox(height: 16),
        _buildEventsList(),
      ],
    );
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _eventsCubit.setFilter(_selectedSecondaryFilter ?? filter);
        }
      } else {
        if (_selectedSecondaryFilter == filter) {
          _selectedSecondaryFilter = null;
          _eventsCubit.setFilter(_selectedPrimaryFilter);
        } else {
          _selectedSecondaryFilter = filter;
          _eventsCubit.setFilter(filter);
        }
      }
    });
  }

  Widget _buildEventsList() {
    return BlocBuilder<SearchCubit, SearchState>(
      bloc: _eventsCubit,
      builder: (context, state) {
        if (state.loading) {
          return const Center(
            child: CircularProgressIndicator(
              color: Colors.orange,
            ),
          );
        }

        if (state.error != null) {
          return Center(
            child: Column(
              children: [
                Icon(
                  Icons.error_outline,
                  size: 48,
                  color: Colors.grey[600],
                ),
                const SizedBox(height: 16),
                Text(
                  'Error loading events',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          );
        }

        final events = state.items;

        if (events.isEmpty) {
          return Center(
            child: Column(
              children: [
                Icon(
                  Icons.event_busy,
                  size: 64,
                  color: Colors.grey[700],
                ),
                const SizedBox(height: 16),
                Text(
                  'No events found',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Check back later for new events',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: events.length > 10 ? 10 : events.length,
          itemBuilder: (context, index) {
            final event = events[index];
            return _buildTicketStyleEventCard(event, index);
          },
        );
      },
    );
  }

  Widget _buildTicketStyleEventCard(search.SearchEventModel event, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      height: 130,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => EventDetailPage(
                  eventId: event.id,
                  title: event.title,
                ),
              ),
            );
          },
          borderRadius: BorderRadius.circular(16),
          splashColor: Colors.orange.withValues(alpha: 0.1),
          highlightColor: Colors.orange.withValues(alpha: 0.05),
          child: Stack(
            children: [
              // Main ticket container
              Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF2A2A2A), // Dark gray
                      Color(0xFF1A1A1A), // Black
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.3),
                      blurRadius: 15,
                      spreadRadius: 2,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    children: [
                      // Ticket perforations pattern
                      Positioned(
                        right: -8,
                        top: 0,
                        bottom: 0,
                        child: Container(
                          width: 16,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.05),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: List.generate(
                              7,
                              (index) => Container(
                                width: 6,
                                height: 6,
                                decoration: const BoxDecoration(
                                  color: Colors.black,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      // Ticket stub separator line
                      Positioned(
                        right: 12,
                        top: 0,
                        bottom: 0,
                        child: Container(
                          width: 1,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.8),
                          ),
                        ),
                      ),
                      // Main content
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 16, 30, 16),
                        child: Row(
                          children: [
                            // Event image/icon (larger)
                            Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(14),
                                color: Colors.white.withValues(alpha: 0.1),
                                border: Border.all(
                                  color: const Color(0xFFFF9800)
                                      .withValues(alpha: 0.4),
                                  width: 2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFFFF9800)
                                        .withValues(alpha: 0.2),
                                    blurRadius: 8,
                                    spreadRadius: 1,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: event.thumbnailUrl.isNotEmpty
                                  ? ClipRRect(
                                      borderRadius: BorderRadius.circular(12),
                                      child: Image.network(
                                        event.thumbnailUrl,
                                        fit: BoxFit.cover,
                                        errorBuilder:
                                            (context, error, stackTrace) {
                                          return _buildTicketEventIcon(event);
                                        },
                                      ),
                                    )
                                  : _buildTicketEventIcon(event),
                            ),
                            const SizedBox(width: 16),
                            // Event details
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  // Event title
                                  Text(
                                    event.title,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 17,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.3,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 8),
                                  // Date and location
                                  Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(4),
                                        decoration: BoxDecoration(
                                          color: Colors.white
                                              .withValues(alpha: 0.15),
                                          borderRadius:
                                              BorderRadius.circular(6),
                                        ),
                                        child: Icon(
                                          Icons.access_time_rounded,
                                          size: 14,
                                          color: Colors.grey[300],
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        event.date,
                                        style: TextStyle(
                                          color: Colors.grey[300],
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Row(
                                    children: [
                                      Container(
                                        width: 20,
                                        height: 20,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: Colors.orange
                                                .withValues(alpha: 0.6),
                                            width: 1.5,
                                          ),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: Image.network(
                                            'https://i.pravatar.cc/150?u=${event.hostName}',
                                            fit: BoxFit.cover,
                                            errorBuilder:
                                                (context, error, stackTrace) {
                                              return Container(
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  gradient: LinearGradient(
                                                    colors: [
                                                      Colors.orange.shade300,
                                                      Colors
                                                          .deepOrange.shade700,
                                                    ],
                                                  ),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    event.hostName.isNotEmpty
                                                        ? event.hostName[0]
                                                            .toUpperCase()
                                                        : '?',
                                                    style: const TextStyle(
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 10,
                                                    ),
                                                  ),
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          event.hostName,
                                          style: TextStyle(
                                            color: Colors.grey[300],
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            // Price badge (prominent)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: event.price.toLowerCase() == 'free'
                                      ? [
                                          const Color(0xFF22C55E),
                                          const Color(0xFF16A34A),
                                        ]
                                      : [
                                          const Color(0xFFFF9800),
                                          const Color(0xFFFF5722),
                                        ],
                                ),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [
                                  BoxShadow(
                                    color: (event.price.toLowerCase() == 'free'
                                            ? const Color(0xFF22C55E)
                                            : const Color(0xFFFF9800))
                                        .withValues(alpha: 0.3),
                                    blurRadius: 8,
                                    spreadRadius: 1,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Text(
                                event.price,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Event type badge (positioned over image bottom-left)
                      Positioned(
                        left: 20,
                        bottom: 20,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFFFF9800),
                                Color(0xFFFF5722),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.4),
                                blurRadius: 6,
                                spreadRadius: 1,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Text(
                            _getEventType(event.gameType),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTicketEventIcon(search.SearchEventModel event) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: Colors.white.withValues(alpha: 0.1),
      ),
      child: const Center(
        child: Icon(
          Icons.account_tree,
          size: 40,
          color: Colors.white,
        ),
      ),
    );
  }

  String _getEventType(String gameType) {
    // Map to only valid event types: runs, 1v1, tournament, training, camp, fundraiser, special events
    final lowerType = gameType.toLowerCase();

    // Handle common patterns from search repository
    if (lowerType.contains('open play') ||
        lowerType.contains('pickup') ||
        lowerType.contains('basketball') ||
        lowerType.contains('3v3') ||
        lowerType.contains('5v5') ||
        lowerType.contains('opengym') ||
        lowerType.contains('open gym')) {
      return 'Runs';
    }

    if (lowerType.contains('1v1') || lowerType.contains('onevsone')) {
      return '1v1';
    }

    if (lowerType.contains('tournament') ||
        lowerType.contains('elimination') ||
        lowerType.contains('bracket')) {
      return 'Tournament';
    }

    if (lowerType.contains('training') || lowerType.contains('skill')) {
      return 'Training';
    }

    if (lowerType.contains('camp')) {
      return 'Camp';
    }

    if (lowerType.contains('donation') ||
        lowerType.contains('charity') ||
        lowerType.contains('fundraiser')) {
      return 'Fundraiser';
    }

    if (lowerType.contains('special') ||
        lowerType.contains('showcase') ||
        lowerType.contains('oneoff') ||
        lowerType.contains('one-off')) {
      return 'Special Events';
    }

    // Default to 'Runs' for any unrecognized type
    return 'Runs';
  }

  Widget _buildFloatingActionButton() {
    return SizedBox(
      height: 56,
      width: 120,
      child: FloatingActionButton.extended(
        backgroundColor: Colors.transparent,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
        ),
        onPressed: () => _showCreateOptions(context),
        tooltip: 'Create options',
        icon: Container(
          height: 56,
          width: 120,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFFFF9800), // Orange
                Color(0xFFFF5722), // Deep Orange
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.withValues(alpha: 0.5),
                spreadRadius: 2,
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.add,
                color: Colors.white,
                size: 20,
              ),
              SizedBox(width: 8),
              Text(
                'Create',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        label: const SizedBox.shrink(),
      ),
    );
  }
}
