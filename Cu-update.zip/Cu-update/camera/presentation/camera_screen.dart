import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'pages/story_page.dart';
import 'pages/score_cam_page.dart';

/// Camera screen with tabs for different camera modes
class CameraScreen extends StatefulWidget {
  /// Initial tab index to show
  final int? initialTabIndex;

  /// Constructor
  const CameraScreen({super.key, this.initialTabIndex});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);

    // Set initial tab if provided
    if (widget.initialTabIndex != null) {
      _tabController.animateTo(widget.initialTabIndex!);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0), // Zero height
        child: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          systemOverlayStyle: const SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            statusBarIconBrightness: Brightness.light,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Tab content
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: const [
                  StoryPage(),
                  ScoreCamPage(),
                ],
              ),
            ),

            // Custom tab bar at bottom - Mobile optimized
            SafeArea(
              top: false,
              child: Container(
                height: 50, // Slightly increased for better visibility
                decoration: BoxDecoration(
                  color: Colors.black,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(
                        20), // Smaller radius for compact look
                  ),
                  dividerColor: Colors.transparent,
                  indicatorSize: TabBarIndicatorSize.tab,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.grey.shade400,
                  labelStyle: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13, // Slightly smaller font for mobile
                  ),
                  unselectedLabelStyle: const TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 12,
                  ),
                  labelPadding: const EdgeInsets.symmetric(horizontal: 4),
                  indicatorPadding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  tabAlignment: TabAlignment.fill,
                  splashFactory:
                      NoSplash.splashFactory, // Remove splash for cleaner look
                  overlayColor: MaterialStateProperty.all(Colors.transparent),
                  tabs: const [
                    Tab(
                      text: 'Story',
                      height: 36, // Slightly increased for better visibility
                    ),
                    Tab(
                      text: 'Score-cam',
                      height: 36,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
