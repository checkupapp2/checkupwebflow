import 'package:flutter/material.dart';
import 'dart:async';
import 'scoreboard_settings_page.dart';
import 'clips_page.dart';
import '../../domain/models/clip_model.dart';
import '../../domain/services/clip_service.dart';

/// Tour step data class for interactive walkthrough
class TourStep {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String description;
  final Rect? spotlightRect;
  final double borderRadius;

  const TourStep({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.description,
    this.spotlightRect,
    this.borderRadius = 8.0,
  });
}

/// Custom painter for creating spotlight cutout effect
class SpotlightPainter extends CustomPainter {
  final Rect? spotlightRect;
  final double borderRadius;

  SpotlightPainter({
    required this.spotlightRect,
    required this.borderRadius,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black.withOpacity(0.85)
      ..style = PaintingStyle.fill;

    // Create path for the entire screen
    final screenPath = Path()
      ..addRect(Rect.fromLTWH(0, 0, size.width, size.height));

    // Create path for the spotlight cutout
    if (spotlightRect != null) {
      final spotlightPath = Path()
        ..addRRect(RRect.fromRectAndRadius(
          spotlightRect!,
          Radius.circular(borderRadius),
        ));

      // Subtract spotlight from screen to create cutout
      final cutoutPath = Path.combine(
        PathOperation.difference,
        screenPath,
        spotlightPath,
      );

      canvas.drawPath(cutoutPath, paint);
    } else {
      canvas.drawPath(screenPath, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return oldDelegate != this;
  }
}

/// Score-cam mode page for recording basketball games with scoring
class ScoreCamPage extends StatefulWidget {
  /// Constructor
  const ScoreCamPage({super.key});

  @override
  State<ScoreCamPage> createState() => _ScoreCamPageState();
}

class _ScoreCamPageState extends State<ScoreCamPage> {
  // Game clock variables (counts down like real basketball)
  String _gameClockDisplay = '12:00';
  String _currentPeriod = '1ST';
  bool _isGameClockRunning = false;

  // Recording timer variables (counts up)
  String _recordingTimeDisplay = '00:00';
  bool _isRecordingTimerRunning = false;

  // Other variables
  String _homeTeam = 'Home';
  String _awayTeam = 'Away';
  String _selectedSpeed = '1x';
  int _homeScore = 0;
  int _awayScore = 0;
  bool _showClock = true;

  // Shot clock settings
  bool _showShotClock = true;
  int _shotClockTime = 24;
  int _currentShotClockTime = 24;
  bool _isShotClockRunning = false;
  Timer? _shotClockTimer;

  // Logo settings
  bool _showLogo = true;
  String _selectedLogo = 'basketball';

  // Scoreboard visibility
  bool _showScoreboard = true;

  // Recording state
  bool _isRecording = false;

  // Clip service
  final ClipService _clipService = ClipService();

  // Team name variables for editing dialog
  String _teamAName = 'Home';
  String _teamBName = 'Away';

  // Score history for undo functionality
  List<Map<String, dynamic>> _scoreHistory = [];

  // Timer controllers
  Timer? _gameClockTimer;
  Timer? _recordingTimer;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _gameClockTimer?.cancel();
    _recordingTimer?.cancel();
    _shotClockTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Stack(
        children: [
          // Modern gradient background
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF0A0A0A),
                  Color(0xFF1A1A1A),
                  Color(0xFF2A2A2A),
                ],
                stops: [0.0, 0.5, 1.0],
              ),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Modern basketball icon with gradient
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF9800).withOpacity(0.3),
                          blurRadius: 20,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.sports_basketball,
                      color: Colors.white,
                      size: 60,
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Modern title with gradient text effect
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    ).createShader(bounds),
                    child: const Text(
                      'Score-cam',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Record basketball games and track scores',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Top navigation bar
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: _buildTopNavigationBar(),
          ),

          // Speed controls
          Positioned(
            top: 60,
            left: 0,
            right: 0,
            child: _buildSpeedControls(),
          ),

          // Modern side camera controls
          Positioned(
            right: 20,
            top: MediaQuery.of(context).size.height * 0.25,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.8),
                    Colors.black.withOpacity(0.6),
                  ],
                ),
                borderRadius: BorderRadius.circular(25),
                border: Border.all(
                  color: const Color(0xFFFF9800).withOpacity(0.3),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  _buildCameraControl(
                    Icons.camera_alt_rounded,
                    const Color(0xFF4CAF50),
                    onTap: _captureClip,
                  ),
                  const SizedBox(height: 16),
                  _buildRecordButton(),
                  const SizedBox(height: 16),
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF9800).withOpacity(0.4),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: _undoLastScoreAction,
                        customBorder: const CircleBorder(),
                        child: const Center(
                          child: Icon(
                            Icons.undo_rounded,
                            color: Colors.white,
                            size: 26,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Bottom scoreboard (conditional)
          if (_showScoreboard)
            Positioned(
              bottom: 5, // Reduced spacing for better mobile UX
              left: 0,
              right: 0,
              child: _buildBottomScoreboard(),
            ),
        ],
      ),
    );
  }

  // Build record button with recording state
  Widget _buildRecordButton() {
    return GestureDetector(
      onTap: _toggleRecording,
      child: Container(
        width: 75,
        height: 75,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: _isRecording
                ? [const Color(0xFFFF1744), const Color(0xFFD50000)]
                : [const Color(0xFFFF9800), const Color(0xFFFF5722)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: _isRecording
                  ? const Color(0xFFFF1744).withOpacity(0.4)
                  : const Color(0xFFFF9800).withOpacity(0.4),
              blurRadius: 15,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(
            color: Colors.white.withOpacity(0.9),
            width: 3,
          ),
        ),
        child: Icon(
          _isRecording ? Icons.stop_rounded : Icons.fiber_manual_record_rounded,
          color: Colors.white,
          size: 32,
        ),
      ),
    );
  }

  // Toggle recording state and recording timer
  void _toggleRecording() {
    setState(() {
      _isRecording = !_isRecording;
      if (_isRecording) {
        // Start recording timer and game clock
        _startRecordingTimer();
        _startGameClock();
      } else {
        // Stop recording timer and game clock
        _stopRecordingTimer();
        _pauseGameClock();
        // Save the recorded clip
        _saveRecordedClip();
      }
    });
  }

  // Start recording timer (counts up)
  void _startRecordingTimer() {
    if (!_isRecordingTimerRunning) {
      _isRecordingTimerRunning = true;
      _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        setState(() {
          _updateRecordingTime();
        });
      });
    }
  }

  // Stop recording timer
  void _stopRecordingTimer() {
    _isRecordingTimerRunning = false;
    _recordingTimer?.cancel();
  }

  // Save recorded clip when recording stops
  void _saveRecordedClip() {
    // Get the recording duration from the recording timer display
    final recordingDuration = _recordingTimeDisplay;

    // Create score info for the clip
    final scoreInfo = ScoreInfo(
      homeTeam: _homeTeam,
      awayTeam: _awayTeam,
      homeScore: _homeScore,
      awayScore: _awayScore,
      period: _currentPeriod,
      timerDisplay: _gameClockDisplay,
    );

    // Save clip using clip service
    final now = DateTime.now();
    _clipService.createClip(
      videoPath: 'clips/${now.millisecondsSinceEpoch}.mp4',
      title: 'Game Clip - $recordingDuration',
      startTimeMs: 0,
      endTimeMs: _parseTimeToMs(recordingDuration),
      thumbnailPath: 'thumbnails/${now.millisecondsSinceEpoch}.jpg',
      scoreInfo: scoreInfo,
    );

    // Show success notification
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(
              Icons.check_circle,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'Clip saved successfully ($recordingDuration)',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
        duration: const Duration(seconds: 2),
        backgroundColor: const Color(0xFF4CAF50),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );

    // Reset recording timer display for next recording
    setState(() {
      _recordingTimeDisplay = '00:00';
    });
  }

  // Helper method to parse time string to milliseconds
  int _parseTimeToMs(String timeString) {
    final parts = timeString.split(':');
    if (parts.length == 2) {
      final minutes = int.tryParse(parts[0]) ?? 0;
      final seconds = int.tryParse(parts[1]) ?? 0;
      return (minutes * 60 + seconds) * 1000;
    }
    return 0;
  }

  // Start game clock (counts down) - independent of recording
  void _startGameClock() {
    if (!_isGameClockRunning) {
      _isGameClockRunning = true;
      _gameClockTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        setState(() {
          _updateGameClock();
        });
      });
    }

    // Start shot clock with game clock
    if (!_isShotClockRunning && _showShotClock) {
      _isShotClockRunning = true;
      _shotClockTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        setState(() {
          if (_currentShotClockTime > 0) {
            _currentShotClockTime--;
          } else {
            // Shot clock expired - reset to configured time
            _currentShotClockTime = _shotClockTime;
          }
        });
      });
    }
  }

  // Pause game clock (independent of recording)
  void _pauseGameClock() {
    _isGameClockRunning = false;
    _gameClockTimer?.cancel();

    _isShotClockRunning = false;
    _shotClockTimer?.cancel();
  }

  // Toggle game clock (tap to pause/resume game)
  void _toggleGameClock() {
    setState(() {
      if (_isGameClockRunning) {
        _pauseGameClock();
      } else {
        _startGameClock();
      }
    });
  }

  // Reset shot clock to configured time
  void _resetShotClock() {
    setState(() {
      _currentShotClockTime = _shotClockTime;
    });
  }

  // Update game clock (counts DOWN like real basketball)
  void _updateGameClock() {
    // Parse current game time
    List<String> parts = _gameClockDisplay.split(':');
    int minutes = int.parse(parts[0]);
    int seconds = int.parse(parts[1]);

    // Decrement game time (counting down)
    if (seconds > 0) {
      seconds--;
    } else if (minutes > 0) {
      minutes--;
      seconds = 59;
    } else {
      // Game clock reached 0:00 - stop the clock
      _pauseGameClock();
      return;
    }

    // Update display
    _gameClockDisplay =
        '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  // Update recording time (counts UP)
  void _updateRecordingTime() {
    // Parse current recording time
    List<String> parts = _recordingTimeDisplay.split(':');
    int minutes = int.parse(parts[0]);
    int seconds = int.parse(parts[1]);

    // Increment recording time (counting up)
    seconds++;
    if (seconds >= 60) {
      seconds = 0;
      minutes++;
    }

    // Update display
    _recordingTimeDisplay =
        '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  // Build modern camera control button
  Widget _buildCameraControl(IconData icon, Color? color,
      {bool isGradient = false, bool isLarge = false, VoidCallback? onTap}) {
    final double size = isLarge ? 75 : 50;

    return GestureDetector(
      onTap: onTap ??
          () {
            // Handle camera control tap
          },
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: (!isGradient) ? color : null,
          gradient: isGradient
              ? const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: isGradient
                  ? const Color(0xFFFF9800).withOpacity(0.4)
                  : Colors.black.withOpacity(0.3),
              blurRadius: isLarge ? 15 : 10,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(
            color: Colors.white.withOpacity(0.9),
            width: isLarge ? 3 : 2,
          ),
        ),
        child: Icon(
          icon,
          color: Colors.white,
          size: isLarge ? 32 : 24,
        ),
      ),
    );
  }

  // Build bottom scoreboard with tappable scores
  // Build the Classic vertical scoreboard (only style available)
  Widget _buildBottomScoreboard() {
    return _buildVerticalScoreboard();
  }

  // Modern Sharp Scoreboard Design
  Widget _buildVerticalScoreboard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF1A1A1A),
            Color(0xFF0F0F0F),
            Color(0xFF000000),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: [0.0, 0.5, 1.0],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 20,
            spreadRadius: 2,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // Left side - Ultra-modern sponsor logo
          if (_showLogo)
            Container(
              width: 80,
              height: 80,
              margin: const EdgeInsets.only(right: 20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF2A2A2A),
                    Color(0xFF1A1A1A),
                    Color(0xFF0F0F0F),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  stops: [0.0, 0.5, 1.0],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 10,
                    spreadRadius: 1,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFFFF9800).withOpacity(0.1),
                      Colors.transparent,
                    ],
                    stops: const [0.3, 1.0],
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.asset(
                    'assets/images/main_btn.png',
                    width: 42,
                    height: 42,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),

          // Right side - Scoreboard content
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Top row - Ultra-modern Timer/Period and Shot Clock
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Game clock (tappable to pause/resume) - Sharp modern design
                    if (_showClock)
                      Expanded(
                        child: GestureDetector(
                          onTap: _toggleGameClock,
                          child: Container(
                            margin: const EdgeInsets.only(right: 12),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: _isGameClockRunning
                                    ? [
                                        const Color(0xFFFF9800),
                                        const Color(0xFFFF6F00),
                                        const Color(0xFFE65100),
                                      ]
                                    : [
                                        const Color(0xFF757575),
                                        const Color(0xFF616161),
                                        const Color(0xFF424242),
                                      ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: _isGameClockRunning
                                    ? const Color(0xFFFFB74D)
                                    : Colors.grey.shade400,
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _isGameClockRunning
                                      ? const Color(0xFFFF9800).withOpacity(0.5)
                                      : Colors.grey.withOpacity(0.3),
                                  blurRadius: 12,
                                  spreadRadius: 1,
                                  offset: const Offset(0, 2),
                                ),
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.6),
                                  blurRadius: 8,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.3),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    _currentPeriod,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 10,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  _gameClockDisplay,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 14,
                                    letterSpacing: 1.0,
                                    shadows: [
                                      Shadow(
                                        blurRadius: 2,
                                        color: Colors.black54,
                                        offset: Offset(0, 1),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                    // Shot clock (conditional) - Ultra-modern design
                    if (_showShotClock)
                      GestureDetector(
                        onTap: _resetShotClock,
                        child: Container(
                          width: 44,
                          height: 32,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFFFF1744),
                                Color(0xFFD50000),
                                Color(0xFFB71C1C),
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: const Color(0xFFFF5252),
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFFF1744).withOpacity(0.6),
                                blurRadius: 10,
                                spreadRadius: 1,
                                offset: const Offset(0, 0),
                              ),
                              BoxShadow(
                                color: Colors.black.withOpacity(0.7),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              '$_currentShotClockTime',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                                letterSpacing: 0.5,
                                shadows: [
                                  Shadow(
                                    blurRadius: 2,
                                    color: Colors.black87,
                                    offset: Offset(0, 1),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),

                const SizedBox(height: 12),

                // Teams and scores
                Column(
                  children: [
                    // Home team row
                    _buildVerticalTeamRow(_homeTeam, _homeScore, true, 'HOME'),

                    const SizedBox(height: 8),

                    // Ultra-modern divider
                    Container(
                      height: 2,
                      margin: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [
                            Colors.transparent,
                            Color(0xFFFF9800),
                            Color(0xFFFFB74D),
                            Color(0xFFFF9800),
                            Colors.transparent,
                          ],
                          stops: [0.0, 0.3, 0.5, 0.7, 1.0],
                        ),
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFFF9800).withOpacity(0.4),
                            blurRadius: 4,
                            offset: const Offset(0, 0),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    // Away team row
                    _buildVerticalTeamRow(_awayTeam, _awayScore, false, 'AWAY'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Interactive tour state
  int _currentTourStep = 0;
  bool _isTourActive = false;
  OverlayEntry? _tourOverlay;

  // Show modern help overlay
  void _showScoreCamWalkthrough() {
    _showModernHelpOverlay();
  }

  // Modern contextual help overlay
  void _showModernHelpOverlay() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return _buildModernHelpDialog();
      },
    );
  }

  // Build modern help dialog with interactive cards
  Widget _buildModernHelpDialog() {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(16),
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.8,
        ),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [
              Color(0xFF1A1A1A),
              Color(0xFF0A0A0A),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: const Color(0xFFFF9800).withOpacity(0.3),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF9800).withOpacity(0.2),
              blurRadius: 30,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFFFF9800).withOpacity(0.1),
                    Colors.transparent,
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(22),
                  topRight: Radius.circular(22),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.sports_basketball,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 16),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'ScoreCam Guide',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Learn the key features',
                          style: TextStyle(
                            color: Color(0xFFFF9800),
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(
                      Icons.close,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                ],
              ),
            ),

            // Content
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    _buildHelpFeatureCard(
                      icon: Icons.fiber_manual_record,
                      iconColor: const Color(0xFFFF9800),
                      title: 'Record Games',
                      description:
                          'Tap the large orange record button to start/stop recording your basketball game.',
                      tips: [
                        'Button turns red when recording',
                        'Records any duration you need'
                      ],
                    ),
                    const SizedBox(height: 16),
                    _buildHelpFeatureCard(
                      icon: Icons.video_library,
                      iconColor: const Color(0xFF4CAF50),
                      title: 'Instant Clips',
                      description:
                          'Use the green clip button to save highlight moments during gameplay.',
                      tips: [
                        'Saves clips automatically',
                        'Access via clips library'
                      ],
                    ),
                    const SizedBox(height: 16),
                    _buildHelpFeatureCard(
                      icon: Icons.scoreboard,
                      iconColor: const Color(0xFF2196F3),
                      title: 'Live Scoreboard',
                      description:
                          'Track scores, game time, and periods in real-time during recording.',
                      tips: [
                        'Tap scores to update',
                        'Game clock runs independently',
                        'Toggle visibility in settings'
                      ],
                    ),
                    const SizedBox(height: 16),
                    _buildHelpFeatureCard(
                      icon: Icons.undo,
                      iconColor: const Color(0xFFFF5722),
                      title: 'Undo Actions',
                      description:
                          'Quickly reverse the last score change with the undo button.',
                      tips: [
                        'No confirmation needed',
                        'Works for recent changes'
                      ],
                    ),
                    const SizedBox(height: 16),
                    _buildHelpFeatureCard(
                      icon: Icons.settings,
                      iconColor: const Color(0xFF9C27B0),
                      title: 'Customize Settings',
                      description:
                          'Configure team names, game controls, and display options.',
                      tips: [
                        'Edit team names',
                        'Adjust game clock',
                        'Upload team logos'
                      ],
                    ),
                  ],
                ),
              ),
            ),

            // Footer
            Container(
              padding: const EdgeInsets.all(24),
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF9800),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  minimumSize: const Size(double.infinity, 0),
                ),
                child: const Text(
                  'Got it!',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Build individual feature help card
  Widget _buildHelpFeatureCard({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String description,
    required List<String> tips,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: iconColor.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: iconColor.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Icon(
                  icon,
                  color: iconColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Description
          Text(
            description,
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 14,
              height: 1.4,
            ),
          ),

          const SizedBox(height: 12),

          // Tips
          ...tips
              .map((tip) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 4,
                          height: 4,
                          margin: const EdgeInsets.only(top: 8, right: 8),
                          decoration: BoxDecoration(
                            color: iconColor,
                            shape: BoxShape.circle,
                          ),
                        ),
                        Expanded(
                          child: Text(
                            tip,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.7),
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ))
              .toList(),
        ],
      ),
    );
  }

  // Show current tour step with spotlight effect
  void _showTourStep() {
    _tourOverlay?.remove();

    _tourOverlay = OverlayEntry(
      builder: (context) => _buildTourOverlay(),
    );

    Overlay.of(context).insert(_tourOverlay!);
  }

  // Build tour overlay with proper spotlight cutout
  Widget _buildTourOverlay() {
    final steps = _getTourSteps();
    if (_currentTourStep >= steps.length) {
      _endTour();
      return const SizedBox.shrink();
    }

    final currentStep = steps[_currentTourStep];

    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          // Custom painter for spotlight cutout effect
          CustomPaint(
            painter: SpotlightPainter(
              spotlightRect: currentStep.spotlightRect,
              borderRadius: currentStep.borderRadius,
            ),
            size: Size.infinite,
          ),

          // Animated pulse ring around spotlight
          if (currentStep.spotlightRect != null)
            Positioned(
              left: currentStep.spotlightRect!.left - 8,
              top: currentStep.spotlightRect!.top - 8,
              child: Container(
                width: currentStep.spotlightRect!.width + 16,
                height: currentStep.spotlightRect!.height + 16,
                decoration: BoxDecoration(
                  borderRadius:
                      BorderRadius.circular(currentStep.borderRadius + 8),
                  border: Border.all(
                    color: const Color(0xFFFF9800),
                    width: 3,
                  ),
                ),
              ),
            ),

          // Instruction card - positioned higher to not block spotlight
          Positioned(
            left: 20,
            right: 20,
            bottom: 200,
            child: _buildTourInstructionCard(currentStep),
          ),
        ],
      ),
    );
  }

  // Build instruction card for current step
  Widget _buildTourInstructionCard(TourStep step) {
    final steps = _getTourSteps();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF1A1A1A),
            Color(0xFF0A0A0A),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: const Color(0xFFFF9800).withOpacity(0.3),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF9800).withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Step header
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: step.iconColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: step.iconColor.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Icon(
                  step.icon,
                  color: step.iconColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      step.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      'Step ${_currentTourStep + 1} of ${steps.length}',
                      style: TextStyle(
                        color: const Color(0xFFFF9800).withOpacity(0.8),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: _endTour,
                icon: const Icon(
                  Icons.close,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Description
          Text(
            step.description,
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 14,
              height: 1.4,
            ),
          ),

          const SizedBox(height: 20),

          // Navigation buttons
          Row(
            children: [
              if (_currentTourStep > 0)
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _previousStep,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey.withOpacity(0.3),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    icon: const Icon(Icons.arrow_back, size: 16),
                    label: const Text('Previous'),
                  ),
                ),
              if (_currentTourStep > 0) const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _currentTourStep < steps.length - 1
                      ? _nextStep
                      : _endTour,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF9800),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  icon: Icon(
                    _currentTourStep < steps.length - 1
                        ? Icons.arrow_forward
                        : Icons.check,
                    size: 16,
                  ),
                  label: Text(
                      _currentTourStep < steps.length - 1 ? 'Next' : 'Finish'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Tour navigation methods
  void _nextStep() {
    if (_currentTourStep < _getTourSteps().length - 1) {
      setState(() {
        _currentTourStep++;
      });
      _showTourStep();
    }
  }

  void _previousStep() {
    if (_currentTourStep > 0) {
      setState(() {
        _currentTourStep--;
      });
      _showTourStep();
    }
  }

  void _endTour() {
    _tourOverlay?.remove();
    setState(() {
      _isTourActive = false;
      _currentTourStep = 0;
    });
  }

  // Get tour steps with precise UI element positions based on red circles in screenshot
  List<TourStep> _getTourSteps() {
    // Get screen dimensions for accurate positioning
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return [
      TourStep(
        icon: Icons.fiber_manual_record,
        iconColor: const Color(0xFFFF9800),
        title: 'Start Recording',
        description:
            'Tap the large orange record button to start recording your basketball game. The button will turn red when actively recording.',
        spotlightRect: Rect.fromLTWH(
            screenWidth - 90, // Centered on the actual orange record button
            screenHeight * 0.56, // Lower to match the actual button position
            75,
            75),
        borderRadius: 37.5,
      ),
      TourStep(
        icon: Icons.video_library,
        iconColor: const Color(0xFF4CAF50),
        title: 'Capture Clip',
        description:
            'Tap the green clip button to instantly save a highlight clip of the current action.',
        spotlightRect: Rect.fromLTWH(
            screenWidth - 70, // Green clip button position
            screenHeight * 0.42, // Upper right control area
            55,
            55),
        borderRadius: 27.5,
      ),
      TourStep(
        icon: Icons.undo,
        iconColor: const Color(0xFFFF9800),
        title: 'Undo Last Action',
        description:
            'Tap the smaller orange undo button to reverse the last score change or action.',
        spotlightRect: Rect.fromLTWH(
            screenWidth - 75, // Smaller orange undo button - adjusted position
            screenHeight * 0.72, // Much lower to match actual button position
            50,
            50),
        borderRadius: 25,
      ),
      TourStep(
        icon: Icons.scoreboard,
        iconColor: const Color(0xFFFF9800),
        title: 'Game Scoreboard',
        description:
            'This scoreboard displays live game information including team scores, game time, period, and shot clock. Tap elements to interact.',
        spotlightRect: Rect.fromLTWH(
            20, // Full scoreboard widget
            screenHeight - 260, // Higher to avoid card overlap
            screenWidth - 40,
            220),
        borderRadius: 16,
      ),
      TourStep(
        icon: Icons.video_library,
        iconColor: const Color(0xFF9C27B0),
        title: 'View All Clips',
        description:
            'Access your clips library to view, edit, and manage all recorded game highlights.',
        spotlightRect: Rect.fromLTWH(
            screenWidth - 75, // Clips button in header - corrected position
            110, // Top header area
            40,
            40),
        borderRadius: 20,
      ),
      TourStep(
        icon: Icons.settings,
        iconColor: const Color(0xFF9C27B0),
        title: 'Game Settings',
        description:
            'Configure team names, game controls, scoreboard options, and other settings for your recording session.',
        spotlightRect: Rect.fromLTWH(
            screenWidth - 35, // Settings button in header - corrected position
            110, // Top header area
            40,
            40),
        borderRadius: 20,
      ),
    ];
  }

  // Build walkthrough step widget
  Widget _buildWalkthroughStep({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String description,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Icon
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: iconColor.withOpacity(0.2),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: iconColor.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Icon(
            icon,
            color: iconColor,
            size: 20,
          ),
        ),

        const SizedBox(width: 12),

        // Content
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                description,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.8),
                  fontSize: 12,
                  height: 1.3,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // Build ultra-modern team row
  Widget _buildVerticalTeamRow(
      String teamName, int score, bool isHome, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.black.withOpacity(0.3),
            Colors.black.withOpacity(0.1),
          ],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isHome
              ? const Color(0xFFFF9800).withOpacity(0.3)
              : Colors.grey.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          // Ultra-modern team logo
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isHome
                    ? [
                        const Color(0xFFFF9800),
                        const Color(0xFFFF6F00),
                        const Color(0xFFE65100),
                      ]
                    : [
                        const Color(0xFF616161),
                        const Color(0xFF424242),
                        const Color(0xFF212121),
                      ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              border: Border.all(
                color: isHome ? const Color(0xFFFFB74D) : Colors.grey.shade400,
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: isHome
                      ? const Color(0xFFFF9800).withOpacity(0.4)
                      : Colors.grey.withOpacity(0.3),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Icon(
              Icons.sports_basketball,
              color: Colors.white,
              size: 18,
            ),
          ),

          const SizedBox(width: 12),

          // Ultra-modern team info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  teamName,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                    letterSpacing: 0.5,
                    shadows: [
                      Shadow(
                        blurRadius: 2,
                        color: Colors.black.withOpacity(0.8),
                        offset: const Offset(0, 1),
                      ),
                    ],
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(
                    color: isHome
                        ? const Color(0xFFFF9800).withOpacity(0.2)
                        : Colors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    label,
                    style: TextStyle(
                      color: isHome
                          ? const Color(0xFFFFB74D)
                          : Colors.grey.shade300,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.8,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Ultra-modern score display
          GestureDetector(
            onTap: () => _updateScore(isHome, true),
            onVerticalDragEnd: (details) {
              if (details.primaryVelocity != null) {
                if (details.primaryVelocity! < 0) {
                  _updateScore(isHome, true);
                } else if (details.primaryVelocity! > 0) {
                  _updateScore(isHome, false);
                }
              }
            },
            child: Container(
              width: 56,
              height: 36,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF1A1A1A),
                    Color(0xFF0A0A0A),
                    Color(0xFF000000),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: const Color(0xFFFF9800),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFF9800).withOpacity(0.5),
                    blurRadius: 8,
                    spreadRadius: 1,
                    offset: const Offset(0, 0),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.8),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  '$score',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 18,
                    letterSpacing: 1.0,
                    shadows: [
                      Shadow(
                        blurRadius: 3,
                        color: Color(0xFFFF9800),
                        offset: Offset(0, 0),
                      ),
                      Shadow(
                        blurRadius: 6,
                        color: Colors.black87,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Update score based on team and direction
  void _updateScore(bool isHome, bool increment) {
    setState(() {
      if (isHome) {
        if (increment) {
          _homeScore++;
          _scoreHistory.add({
            'team': 'A',
            'action': 'increment',
            'previousScore': _homeScore - 1,
          });
        } else if (_homeScore > 0) {
          _homeScore--;
          _scoreHistory.add({
            'team': 'A',
            'action': 'decrement',
            'previousScore': _homeScore + 1,
          });
        }
      } else {
        if (increment) {
          _awayScore++;
          _scoreHistory.add({
            'team': 'B',
            'action': 'increment',
            'previousScore': _awayScore - 1,
          });
        } else if (_awayScore > 0) {
          _awayScore--;
          _scoreHistory.add({
            'team': 'B',
            'action': 'decrement',
            'previousScore': _awayScore + 1,
          });
        }
      }
    });
  }

  // Undo last score action
  void _undoLastScoreAction() {
    if (_scoreHistory.isNotEmpty) {
      final Map<String, dynamic> lastAction = _scoreHistory.removeLast();
      final String team = lastAction['team'];
      final int previousScore = lastAction['previousScore'];

      setState(() {
        if (team == 'A') {
          _homeScore = previousScore;
        } else if (team == 'B') {
          _awayScore = previousScore;
        }
      });
    }
  }

  // Capture a 15-second clip
  void _captureClip() {
    // Create score info for the clip
    final scoreInfo = ScoreInfo(
      homeTeam: _homeTeam,
      awayTeam: _awayTeam,
      homeScore: _homeScore,
      awayScore: _awayScore,
      period: _currentPeriod,
      timerDisplay: _gameClockDisplay,
    );

    // Generate a timestamp-based title
    final now = DateTime.now();
    final timeString =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final title = '$timeString - $_homeTeam vs $_awayTeam';

    // Show immediate feedback popup
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFF4CAF50),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.videocam_rounded,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                '📹 Clipped the last 15 seconds!',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF2A2A2A),
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: const EdgeInsets.all(16),
        action: SnackBarAction(
          label: 'View Clips',
          textColor: const Color(0xFFFF9800),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const ClipsPage(),
              ),
            );
          },
        ),
      ),
    );

    // Create the clip
    _clipService.createClip(
      videoPath: 'assets/videos/clip_${now.millisecondsSinceEpoch}.mp4',
      title: title,
      startTimeMs: 0,
      endTimeMs: 15000, // 15 seconds
      thumbnailPath:
          'assets/images/clip_thumbnail_${now.millisecondsSinceEpoch}.jpg',
      scoreInfo: scoreInfo,
    );
  }

  // Save the last 15 seconds as a clip
  void _saveClip() {
    // In a real implementation, this would capture the last 15 seconds of video
    // For now, we'll create a mock clip

    // Create score info for the clip
    final scoreInfo = ScoreInfo(
      homeTeam: _homeTeam,
      awayTeam: _awayTeam,
      homeScore: _homeScore,
      awayScore: _awayScore,
      period: _currentPeriod,
      timerDisplay: _gameClockDisplay,
    );

    // Show a dialog to name the clip
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Save Clip'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Enter a name for this clip:'),
            const SizedBox(height: 16),
            TextField(
              autofocus: true,
              decoration: const InputDecoration(
                hintText: 'Awesome play',
                border: OutlineInputBorder(),
              ),
              onSubmitted: (value) {
                _createClip(value, scoreInfo);
                Navigator.pop(context);
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              // Get the text from the TextField
              final title =
                  'Basketball Clip ${DateTime.now().toString().substring(0, 16)}';
              _createClip(title, scoreInfo);
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  // Create a new clip with the given title and score info
  void _createClip(String title, ScoreInfo scoreInfo) {
    _clipService
        .createClip(
      videoPath: 'assets/videos/sample_clip.mp4', // Placeholder path
      title: title,
      startTimeMs: 0,
      endTimeMs: 15000, // 15 seconds
      thumbnailPath:
          'assets/images/placeholder_thumbnail.jpg', // Placeholder path
      scoreInfo: scoreInfo,
    )
        .then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Clip saved successfully!'),
          action: SnackBarAction(
            label: 'View Clips',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ClipsPage(),
                ),
              );
            },
          ),
        ),
      );
    });
  }

  // CheckUp logo removed as requested

  // Build modern top navigation bar with timer and controls
  Widget _buildTopNavigationBar() {
    return Container(
      height: 70,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF1A1A1A).withOpacity(0.95),
            const Color(0xFF0A0A0A).withOpacity(0.9),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Back button with modern design
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Colors.white.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios,
                  color: Colors.white, size: 18),
              padding: EdgeInsets.zero,
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ),

          // Center section with timer and info
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Info button
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.info_outline,
                        color: Colors.white, size: 18),
                    padding: EdgeInsets.zero,
                    onPressed: () {
                      _showScoreCamWalkthrough();
                    },
                  ),
                ),

                const SizedBox(width: 16),

                // Recording timer display
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFFFF6B35).withOpacity(0.2),
                        const Color(0xFFFF8A50).withOpacity(0.1),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFFFF6B35).withOpacity(0.3),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF6B35).withOpacity(0.2),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          gradient: _isRecordingTimerRunning
                              ? const LinearGradient(
                                  colors: [
                                    Color(0xFFFF6B35),
                                    Color(0xFFFF8A50)
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                )
                              : null,
                          color: _isRecordingTimerRunning
                              ? null
                              : const Color(0xFFFF6B35).withOpacity(0.6),
                          shape: BoxShape.circle,
                          boxShadow: _isRecordingTimerRunning
                              ? [
                                  BoxShadow(
                                    color: const Color(0xFFFF6B35)
                                        .withOpacity(0.5),
                                    blurRadius: 4,
                                    spreadRadius: 1,
                                  ),
                                ]
                              : null,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _recordingTimeDisplay,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Right section with action buttons
          Row(
            children: [
              // Clips button with modern design
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.2),
                    width: 1,
                  ),
                ),
                child: IconButton(
                  icon: const Icon(Icons.video_library_outlined,
                      color: Colors.white, size: 20),
                  padding: EdgeInsets.zero,
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ClipsPage(),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(width: 12),

              // Settings button with modern design
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.2),
                    width: 1,
                  ),
                ),
                child: IconButton(
                  icon: const Icon(Icons.settings_outlined,
                      color: Colors.white, size: 20),
                  padding: EdgeInsets.zero,
                  onPressed: () async {
                    // Open settings page
                    final result = await Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => ScoreboardSettingsPage(
                          homeTeam: _homeTeam,
                          awayTeam: _awayTeam,
                          initialGameClockDisplay: _gameClockDisplay,
                          initialCurrentPeriod:
                              int.tryParse(_currentPeriod) ?? 1,
                          initialShotClockTime: _shotClockTime,
                          initialCurrentShotClockTime: _currentShotClockTime,
                          initialIsGameClockRunning: _isGameClockRunning,
                          initialIsShotClockRunning: _isShotClockRunning,
                          initialShowScoreboard: _showScoreboard,
                          initialShowClock: _showClock,
                          initialShowShotClock: _showShotClock,
                          initialShowLogo: _showLogo,
                          initialSelectedLogo: _selectedLogo,
                        ),
                      ),
                    );

                    // Update settings if returned
                    if (result != null) {
                      setState(() {
                        _homeTeam = result['homeTeam'];
                        _awayTeam = result['awayTeam'];
                        // Update the clock display setting
                        if (result['showClock'] != null) {
                          _showClock = result['showClock'];
                        }
                        // Update shot clock settings
                        if (result['showShotClock'] != null) {
                          _showShotClock = result['showShotClock'];
                        }
                        if (result['shotClockTime'] != null) {
                          _shotClockTime = result['shotClockTime'];
                          _currentShotClockTime = result['shotClockTime'];
                        }
                        // Update logo settings
                        if (result['showLogo'] != null) {
                          _showLogo = result['showLogo'];
                        }
                        if (result['selectedLogo'] != null) {
                          _selectedLogo = result['selectedLogo'];
                        }
                        // Update scoreboard visibility
                        if (result['showScoreboard'] != null) {
                          _showScoreboard = result['showScoreboard'];
                        }
                        // Update game controls
                        if (result['gameClockDisplay'] != null) {
                          _gameClockDisplay = result['gameClockDisplay'];
                        }
                        if (result['currentPeriod'] != null) {
                          _currentPeriod = result['currentPeriod'].toString();
                        }
                        if (result['isGameClockRunning'] != null) {
                          _isGameClockRunning = result['isGameClockRunning'];
                        }
                        if (result['isShotClockRunning'] != null) {
                          _isShotClockRunning = result['isShotClockRunning'];
                        }
                      });
                    }
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Build speed control buttons (0.5x, 1x, 2x)
  Widget _buildSpeedControls() {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.4),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildSpeedButton('0.5', _selectedSpeed == '0.5x'),
            const SizedBox(width: 4),
            _buildSpeedButton('1x', _selectedSpeed == '1x'),
            const SizedBox(width: 4),
            _buildSpeedButton('2', _selectedSpeed == '2x'),
          ],
        ),
      ),
    );
  }

  // Individual speed button
  Widget _buildSpeedButton(String speed, bool isSelected) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedSpeed = speed + (speed.endsWith('x') ? '' : 'x');
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          gradient: isSelected
              ? const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: isSelected ? null : Colors.black45,
          shape: BoxShape.circle,
          border: isSelected ? Border.all(color: Colors.white, width: 1) : null,
        ),
        child: Center(
          child: Text(
            speed,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.white.withOpacity(0.7),
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }

  void _showTeamNameDialog() {
    final teamAController = TextEditingController(text: _teamAName);
    final teamBController = TextEditingController(text: _teamBName);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF0A1E3D),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        titlePadding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
        contentPadding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        title: const Row(
          children: [
            Icon(Icons.edit, color: Colors.orange, size: 20),
            SizedBox(width: 8),
            Text(
              'Edit Team Names',
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: teamAController,
              decoration: const InputDecoration(
                labelText: 'Home Team',
                labelStyle: TextStyle(color: Colors.grey),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.orange, width: 2),
                ),
              ),
              style: const TextStyle(color: Colors.white),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: teamBController,
              decoration: const InputDecoration(
                labelText: 'Away Team',
                labelStyle: TextStyle(color: Colors.grey),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.orange, width: 2),
                ),
              ),
              style: const TextStyle(color: Colors.white),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              foregroundColor: Colors.grey,
            ),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _teamAName = teamAController.text.isNotEmpty
                    ? teamAController.text
                    : 'Home';
                _teamBName = teamBController.text.isNotEmpty
                    ? teamBController.text
                    : 'Away';
              });
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Save'),
          ),
          const SizedBox(width: 8),
        ],
      ),
    );
  }
}
