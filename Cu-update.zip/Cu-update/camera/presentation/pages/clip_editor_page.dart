import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/clip_model.dart';
import '../../domain/services/clip_service.dart';

/// Page for editing a clip (trimming, adding title, etc.)
class ClipEditorPage extends StatefulWidget {
  /// The clip to edit
  final ClipModel clip;

  /// Constructor
  const ClipEditorPage({super.key, required this.clip});

  @override
  State<ClipEditorPage> createState() => _ClipEditorPageState();
}

class _ClipEditorPageState extends State<ClipEditorPage> {
  late TextEditingController _titleController;
  late ClipModel _clip;
  final ClipService _clipService = ClipService();
  bool _isHighlight = false;

  // Trim slider values (0.0 to 1.0 representing percentage of video)
  double _startTrimPosition = 0.0;
  double _endTrimPosition = 1.0;

  // For video player
  bool _isPlaying = false;
  bool _isFullscreen = false;

  @override
  void initState() {
    super.initState();
    _clip = widget.clip;
    _titleController = TextEditingController(text: _clip.title);
    _isHighlight = _clip.isHighlight;

    // Initialize trim positions based on clip duration
    final clipDuration = _clip.durationMs;
    _startTrimPosition = _clip.startTimeMs / clipDuration;
    _endTrimPosition = _clip.endTimeMs / clipDuration;
  }

  void _saveChanges() {
    // Calculate new start and end times based on trim positions
    final originalDuration = _clip.endTimeMs - _clip.startTimeMs;
    final newStartTime =
        _clip.startTimeMs + (_startTrimPosition * originalDuration).toInt();
    final newEndTime =
        _clip.startTimeMs + (_endTrimPosition * originalDuration).toInt();

    final updatedClip = ClipModel(
      id: _clip.id,
      title: _titleController.text.trim(),
      clipUrl: _clip.clipUrl,
      thumbnailUrl: _clip.thumbnailUrl,
      startTimeMs: newStartTime,
      endTimeMs: newEndTime,
      scoreInfo: _clip.scoreInfo,
      createdAt: _clip.createdAt,
      tags: _clip.tags,
      isHighlight: _isHighlight,
      displayOrder: _clip.displayOrder,
    );

    _clipService.updateClip(updatedClip);
    Navigator.pop(context, true); // Return true to indicate changes were made
  }

  void _togglePlayback() {
    setState(() {
      _isPlaying = !_isPlaying;
    });
    // In a real implementation, this would control video playback
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          'Edit Clip',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          TextButton(
            onPressed: _saveChanges,
            child: const Text(
              'Save',
              style: TextStyle(
                color: Color(0xFFFF9800),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Video preview
            AspectRatio(
              aspectRatio: 16 / 9,
              child: GestureDetector(
                onTap: _togglePlayback,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Video placeholder (would be actual video player in implementation)
                    Container(
                      color: const Color(0xFF0A1E3D),
                      child: Center(
                        child: Icon(
                          Icons.sports_basketball,
                          color: Colors.orange.withOpacity(0.8),
                          size: 64,
                        ),
                      ),
                    ),

                    // Play/pause button overlay
                    if (!_isPlaying)
                      Container(
                        width: 64,
                        height: 64,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.play_arrow,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                  ],
                ),
              ),
            ),

            // Trim controls
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Trim Clip',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Drag handles to trim the clip (max 15 seconds)',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildTrimSlider(),
                  const SizedBox(height: 32),

                  // Title input
                  TextField(
                    controller: _titleController,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      labelText: 'Title',
                      labelStyle: TextStyle(color: Colors.grey[400]),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey[800]!),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Color(0xFFFF9800)),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Highlight toggle
                  SwitchListTile(
                    title: const Text(
                      'Mark as Highlight',
                      style: TextStyle(color: Colors.white),
                    ),
                    subtitle: Text(
                      'Highlights will be used for generating reels',
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                    ),
                    value: _isHighlight,
                    onChanged: (value) {
                      setState(() {
                        _isHighlight = value;
                      });
                    },
                    activeColor: const Color(0xFFFF9800),
                    contentPadding: EdgeInsets.zero,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTrimSlider() {
    return Container(
      height: 70,
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          // Thumbnail strip (would be actual video thumbnails in implementation)
          Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF0A1E3D), Color(0xFF0D2B4D)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),

          // Range slider
          SliderTheme(
            data: SliderThemeData(
              trackHeight: 4,
              activeTrackColor: const Color(0xFFFF9800),
              inactiveTrackColor: Colors.grey[800],
              thumbColor: Colors.white,
              overlayColor: const Color(0xFFFF9800).withOpacity(0.2),
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
              rangeThumbShape:
                  const RoundRangeSliderThumbShape(enabledThumbRadius: 8),
              rangeTrackShape: const RoundedRectRangeSliderTrackShape(),
              rangeValueIndicatorShape:
                  const PaddleRangeSliderValueIndicatorShape(),
              valueIndicatorColor: const Color(0xFFFF9800),
              valueIndicatorTextStyle: const TextStyle(color: Colors.white),
            ),
            child: RangeSlider(
              values: RangeValues(_startTrimPosition, _endTrimPosition),
              min: 0.0,
              max: 1.0,
              divisions: 100,
              labels: RangeLabels(
                '${(_startTrimPosition * 15).toStringAsFixed(1)}s',
                '${(_endTrimPosition * 15).toStringAsFixed(1)}s',
              ),
              onChanged: (RangeValues values) {
                // Ensure minimum clip length (e.g., 3 seconds)
                final minLength = 3.0 / 15.0; // 3 seconds out of 15

                if (values.end - values.start >= minLength) {
                  setState(() {
                    _startTrimPosition = values.start;
                    _endTrimPosition = values.end;
                  });
                } else if (_startTrimPosition != values.start) {
                  // User is moving the start thumb
                  setState(() {
                    _startTrimPosition = values.start;
                    _endTrimPosition = values.start + minLength;
                  });
                } else {
                  // User is moving the end thumb
                  setState(() {
                    _endTrimPosition = values.end;
                    _startTrimPosition = values.end - minLength;
                  });
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}
