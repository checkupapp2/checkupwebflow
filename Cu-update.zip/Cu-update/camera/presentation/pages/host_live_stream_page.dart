import 'dart:async';
import 'package:flutter/material.dart';

class ChatMessage {
  final String username;
  final String message;
  final DateTime timestamp;
  final Color color;

  ChatMessage({
    required this.username,
    required this.message,
    required this.timestamp,
    required this.color,
  });
}

class HostLiveStreamPage extends StatefulWidget {
  const HostLiveStreamPage({super.key});

  @override
  State<HostLiveStreamPage> createState() => _HostLiveStreamPageState();
}

class _HostLiveStreamPageState extends State<HostLiveStreamPage>
    with TickerProviderStateMixin {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessage> _messages = [];
  
  late AnimationController _liveAnimationController;
  late AnimationController _recordingAnimationController;
  
  int _viewerCount = 0;
  Timer? _viewerTimer;
  bool _showScoreboard = false;
  bool _showChat = true;
  
  // Scoreboard state
  int _team1Score = 0;
  int _team2Score = 0;
  String _team1Name = 'Team 1';
  String _team2Name = 'Team 2';
  
  // Draggable scoreboard position
  double _scoreboardX = 16.0;
  double _scoreboardY = 140.0;
  
  // Stream duration
  DateTime _streamStartTime = DateTime.now();
  Timer? _durationTimer;
  String _streamDuration = '00:00';

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startViewerSimulation();
    _startDurationTimer();
    _addWelcomeMessage();
  }

  void _initializeAnimations() {
    _liveAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
    
    _recordingAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..repeat();
  }

  void _startViewerSimulation() {
    _viewerTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (mounted) {
        setState(() {
          _viewerCount = (_viewerCount + (DateTime.now().millisecond % 3)).clamp(0, 999);
        });
      }
    });
  }

  void _startDurationTimer() {
    _durationTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        final duration = DateTime.now().difference(_streamStartTime);
        setState(() {
          _streamDuration = '${duration.inMinutes.toString().padLeft(2, '0')}:${(duration.inSeconds % 60).toString().padLeft(2, '0')}';
        });
      }
    });
  }

  void _addWelcomeMessage() {
    // Add system message
    _messages.add(ChatMessage(
      username: 'System',
      message: 'Your live stream has started!',
      timestamp: DateTime.now(),
      color: Colors.orange,
    ));
    
    // Add mock viewer messages for realism
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(
            username: 'SportsFan23',
            message: 'Hey! Great to see you live! 🔥',
            timestamp: DateTime.now(),
            color: Colors.blue,
          ));
        });
        _scrollToBottom();
      }
    });
    
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(
            username: 'GameWatcher',
            message: 'What game are we watching today?',
            timestamp: DateTime.now(),
            color: Colors.green,
          ));
        });
        _scrollToBottom();
      }
    });
    
    Future.delayed(const Duration(seconds: 8), () {
      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(
            username: 'LiveViewer',
            message: 'This stream quality is amazing! 👍',
            timestamp: DateTime.now(),
            color: Colors.purple,
          ));
        });
        _scrollToBottom();
      }
    });
    
    // Continue adding periodic mock messages
    Timer.periodic(const Duration(seconds: 12), (timer) {
      if (mounted && _messages.length < 20) {
        final mockMessages = [
          'Nice setup!',
          'Can you show the scoreboard?',
          'Great stream! 🎉',
          'Who\'s winning?',
          'Love the commentary!',
          'Keep it up! 💪',
          'This is so cool!',
          'Best stream ever!',
        ];
        final usernames = ['Fan1', 'Viewer99', 'SportsLover', 'GameFan', 'StreamWatcher'];
        final colors = [Colors.blue, Colors.green, Colors.purple, Colors.teal, Colors.pink];
        
        final randomMessage = mockMessages[DateTime.now().millisecond % mockMessages.length];
        final randomUsername = usernames[DateTime.now().millisecond % usernames.length];
        final randomColor = colors[DateTime.now().millisecond % colors.length];
        
        setState(() {
          _messages.add(ChatMessage(
            username: randomUsername,
            message: randomMessage,
            timestamp: DateTime.now(),
            color: randomColor,
          ));
        });
        _scrollToBottom();
      } else {
        timer.cancel();
      }
    });
  }

  void _sendMessage() {
    if (_messageController.text.trim().isNotEmpty) {
      setState(() {
        _messages.add(ChatMessage(
          username: 'Host',
          message: _messageController.text.trim(),
          timestamp: DateTime.now(),
          color: Colors.orange,
        ));
      });
      _messageController.clear();
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _toggleScoreboard() {
    setState(() {
      _showScoreboard = !_showScoreboard;
    });
  }

  void _toggleChat() {
    setState(() {
      _showChat = !_showChat;
    });
  }

  void _incrementScore(int team) {
    setState(() {
      if (team == 1) {
        _team1Score++;
      } else {
        _team2Score++;
      }
    });
  }
  
  void _decrementScore(int team) {
    setState(() {
      if (team == 1) {
        _team1Score = (_team1Score - 1).clamp(0, 999); // Prevent negative scores
      } else {
        _team2Score = (_team2Score - 1).clamp(0, 999); // Prevent negative scores
      }
    });
  }

  void _resetScores() {
    setState(() {
      _team1Score = 0;
      _team2Score = 0;
    });
  }

  void _endStream() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('End Live Stream', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Are you sure you want to end your live stream?',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context); // Close dialog
              Navigator.pop(context); // Go back to live page
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('End Stream', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _liveAnimationController.dispose();
    _recordingAnimationController.dispose();
    _viewerTimer?.cancel();
    _durationTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Camera preview background (simulated)
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.grey[800]!,
                  Colors.black,
                ],
              ),
            ),
            child: const Center(
              child: Icon(
                Icons.videocam,
                size: 120,
                color: Colors.white24,
              ),
            ),
          ),

          // Top status bar
          Positioned(
            top: 50,
            left: 16,
            right: 16,
            child: Row(
              children: [
                // Live indicator
                AnimatedBuilder(
                  animation: _liveAnimationController,
                  builder: (context, child) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.8 + 0.2 * _liveAnimationController.value),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.red.withOpacity(0.3),
                            blurRadius: 8,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 6),
                          const Text(
                            'LIVE',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                const SizedBox(width: 12),
                // Duration
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    _streamDuration,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                ),
                const Spacer(),
                // Viewer count
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.visibility, color: Colors.white, size: 16),
                      const SizedBox(width: 4),
                      Text(
                        '$_viewerCount',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Simplified host controls on the right
          Positioned(
            top: 140,
            right: 16,
            child: Column(
              children: [
                _buildHostControl(Icons.scoreboard_outlined, 'Score', _toggleScoreboard),
                const SizedBox(height: 20),
                _buildHostControl(
                  _showChat ? Icons.chat_bubble : Icons.chat_bubble_outline,
                  'Chat',
                  _toggleChat,
                ),
                const SizedBox(height: 20),
                _buildHostControl(Icons.flip_camera_ios_outlined, 'Flip', () {}),
              ],
            ),
          ),

          // Draggable modern scoreboard overlay
          if (_showScoreboard)
            Positioned(
              top: _scoreboardY,
              left: _scoreboardX,
              child: Draggable(
                feedback: Material(
                  color: Colors.transparent,
                  child: _buildScoreboard(),
                ),
                childWhenDragging: Container(),
                onDragEnd: (details) {
                  setState(() {
                    // Keep scoreboard within screen bounds
                    _scoreboardX = details.offset.dx.clamp(0.0, MediaQuery.of(context).size.width - 200);
                    _scoreboardY = details.offset.dy.clamp(50.0, MediaQuery.of(context).size.height - 200);
                  });
                },
                child: _buildScoreboard(),
              ),
            ),

          // Simplified bottom controls
          Positioned(
            bottom: _showChat ? screenHeight * 0.3 + 20 : 50,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildBottomControl(Icons.stop_circle, 'End Stream', _endStream),
              ],
            ),
          ),

          // Clean chat area
          if (_showChat)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              height: screenHeight * 0.3, // Reduced height for cleaner look
              child: _buildChatArea(),
            ),
        ],
      ),
    );
  }

  Widget _buildHostControl(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.black.withOpacity(0.8), Colors.black.withOpacity(0.6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.orange.withOpacity(0.3), width: 1),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 12,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Icon(icon, color: Colors.white, size: 26),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomControl(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: label == 'End' 
                ? [Colors.red.withOpacity(0.8), Colors.red.withOpacity(0.6)]
                : [Colors.black.withOpacity(0.8), Colors.black.withOpacity(0.6)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: label == 'End' 
                ? Colors.red.withOpacity(0.3)
                : Colors.orange.withOpacity(0.3),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 12,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreboard() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.black.withOpacity(0.95), Colors.grey[900]!.withOpacity(0.95)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.orange.withOpacity(0.4), width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.orange.withOpacity(0.2),
            blurRadius: 15,
            spreadRadius: 3,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 25,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Modern scoreboard header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text(
              'LIVE SCORE',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.0,
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Teams and scores
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildCompactTeamScore(_team1Name, _team1Score, 1),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'VS',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              _buildCompactTeamScore(_team2Name, _team2Score, 2),
            ],
          ),
          const SizedBox(height: 10),
          // Compact reset button
          GestureDetector(
            onTap: _resetScores,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.red.withOpacity(0.5), width: 1),
              ),
              child: const Text(
                'Reset',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactTeamScore(String teamName, int score, int team) {
    return GestureDetector(
      onTap: () => _incrementScore(team),
      onPanUpdate: (details) {
        // Swipe up to increment, swipe down to decrement
        if (details.delta.dy < -5) {
          _incrementScore(team);
        } else if (details.delta.dy > 5) {
          _decrementScore(team);
        }
      },
      child: Column(
        children: [
          Text(
            teamName,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.2), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.3),
                  blurRadius: 8,
                  spreadRadius: 2,
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 6,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Center(
              child: Text(
                '$score',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Tap/Swipe',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 8,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatArea() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.grey[900]!.withOpacity(0.95),
            Colors.black.withOpacity(0.98),
          ],
        ),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      child: Column(
        children: [
          // Drag handle
          Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          // Chat header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.chat, color: Colors.orange, size: 20),
                const SizedBox(width: 8),
                const Text(
                  'Live Chat',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const Spacer(),
                Text(
                  '${_messages.length}',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Chat messages
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return _buildChatMessage(_messages[index]);
              },
            ),
          ),
          // Message input
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[800],
                      borderRadius: BorderRadius.circular(25),
                    ),
                    child: TextField(
                      controller: _messageController,
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                      decoration: const InputDecoration(
                        hintText: 'Message your viewers...',
                        hintStyle: TextStyle(color: Colors.grey, fontSize: 16),
                        contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                        border: InputBorder.none,
                      ),
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 20),
                    onPressed: _sendMessage,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatMessage(ChatMessage message) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [message.color, message.color.withOpacity(0.7)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                message.username[0].toUpperCase(),
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  message.username,
                  style: TextStyle(
                    color: message.color,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  message.message,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
