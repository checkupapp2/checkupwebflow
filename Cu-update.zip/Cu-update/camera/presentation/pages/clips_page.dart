import 'package:flutter/material.dart';
import '../../domain/models/clip_model.dart';
import '../../domain/services/clip_service.dart';
import 'dart:ui';

/// Page for managing ScoreCam clips
class ClipsPage extends StatefulWidget {
  /// Constructor
  const ClipsPage({super.key});

  @override
  State<ClipsPage> createState() => _ClipsPageState();
}

class _ClipsPageState extends State<ClipsPage>
    with SingleTickerProviderStateMixin {
  final ClipService _clipService = ClipService();
  List<ClipModel> _clips = [];
  List<String> _selectedClipIds = [];
  bool _isEditMode = false;
  bool _isGeneratingHighlight = false;

  // Tab controller for managing tabs
  late TabController _tabController;
  int _currentTabIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _currentTabIndex = _tabController.index;
        // Clear selections when switching tabs
        _selectedClipIds.clear();
        _isEditMode = false;
      });
    });
    _loadClips();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Reload clips when page becomes visible again
    _loadClips();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _loadClips() {
    setState(() {
      _clips = _clipService.clips;
    });
  }

  // Get active/recent clips (clips from today or yesterday, but NOT highlighted)
  List<ClipModel> get _activeClips {
    final now = DateTime.now();
    final yesterday = now.subtract(const Duration(days: 1));

    return _clips.where((clip) {
      return clip.createdAt.isAfter(yesterday) && !clip.isHighlight;
    }).toList();
  }

  // Get highlighted/favorited clips only
  List<ClipModel> get _savedClips {
    return _clips.where((clip) => clip.isHighlight).toList();
  }

  // Get current tab's clips
  List<ClipModel> get _currentClips {
    return _currentTabIndex == 0 ? _activeClips : _savedClips;
  }

  void _toggleClipSelection(String clipId) {
    setState(() {
      if (_selectedClipIds.contains(clipId)) {
        _selectedClipIds.remove(clipId);
      } else {
        _selectedClipIds.add(clipId);
      }
    });
  }

  void _toggleClipHighlight(ClipModel clip) {
    final updatedClip = ClipModel(
      id: clip.id,
      title: clip.title,
      clipUrl: clip.clipUrl,
      thumbnailUrl: clip.thumbnailUrl,
      startTimeMs: clip.startTimeMs,
      endTimeMs: clip.endTimeMs,
      scoreInfo: clip.scoreInfo,
      createdAt: clip.createdAt,
      tags: clip.tags,
      isHighlight: !clip.isHighlight, // Toggle highlight status
      displayOrder: clip.displayOrder,
    );

    _clipService.updateClip(updatedClip);
    _loadClips();

    // Show feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          updatedClip.isHighlight
              ? '⭐ Added to highlights!'
              : '⭐ Removed from highlights',
        ),
        backgroundColor: updatedClip.isHighlight
            ? const Color(0xFFFF9800)
            : const Color(0xFF666666),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _toggleEditMode() {
    setState(() {
      _isEditMode = !_isEditMode;
      if (!_isEditMode) {
        _selectedClipIds.clear();
      }
    });
  }

  Future<void> _generateHighlight() async {
    if (_selectedClipIds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select clips to generate a highlight')),
      );
      return;
    }

    setState(() {
      _isGeneratingHighlight = true;
    });

    try {
      // Get selected clips
      final selectedClips =
          _clips.where((clip) => _selectedClipIds.contains(clip.id)).toList();

      if (selectedClips.isEmpty) {
        throw Exception('No clips found for highlight generation');
      }

      // Create highlight reel clip
      final now = DateTime.now();
      final timeString =
          '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
      final highlightTitle = 'Highlight Reel - $timeString';

      // Calculate total duration
      final totalDuration = selectedClips.fold<int>(
        0,
        (sum, clip) => sum + (clip.endTimeMs - clip.startTimeMs),
      );

      // Get team names from the first clip with score info
      final firstClipWithScore = selectedClips.firstWhere(
        (clip) => clip.scoreInfo != null,
        orElse: () => selectedClips.first,
      );

      // Create the highlight reel clip
      final highlightClip = await _clipService.createClip(
        videoPath: 'assets/videos/highlight_${now.millisecondsSinceEpoch}.mp4',
        title: highlightTitle,
        startTimeMs: 0,
        endTimeMs: totalDuration,
        thumbnailPath:
            'assets/images/highlight_thumbnail_${now.millisecondsSinceEpoch}.jpg',
        scoreInfo: firstClipWithScore.scoreInfo,
      );

      // Mark it as a highlight automatically
      final updatedHighlightClip = ClipModel(
        id: highlightClip.id,
        title: highlightClip.title,
        clipUrl: highlightClip.clipUrl,
        thumbnailUrl: highlightClip.thumbnailUrl,
        startTimeMs: highlightClip.startTimeMs,
        endTimeMs: highlightClip.endTimeMs,
        scoreInfo: highlightClip.scoreInfo,
        createdAt: highlightClip.createdAt,
        tags: [...highlightClip.tags, 'highlight_reel'],
        isHighlight: true, // Mark as highlight
        displayOrder: highlightClip.displayOrder,
      );

      _clipService.updateClip(updatedHighlightClip);
      _loadClips();

      // Clear selections and exit edit mode
      setState(() {
        _selectedClipIds.clear();
        _isEditMode = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFF9800),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Icon(
                    Icons.movie_creation_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        '🎬 Highlight reel created!',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        'Combined ${selectedClips.length} clips',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            backgroundColor: const Color(0xFF2A2A2A),
            duration: const Duration(seconds: 4),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            margin: const EdgeInsets.all(16),
            action: SnackBarAction(
              label: 'View Highlights',
              textColor: const Color(0xFFFF9800),
              onPressed: () {
                // Switch to Highlights tab
                _tabController.animateTo(1);
              },
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error creating highlight: ${e.toString()}'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isGeneratingHighlight = false;
        });
      }
    }
  }

  void _showClipPreview(ClipModel clip) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildClipPreviewSheet(clip),
    );
  }

  Widget _buildClipPreviewSheet(ClipModel clip) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: const BoxDecoration(
        color: Color(0xFF1A1A1A),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        clip.title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      if (clip.scoreInfo != null)
                        Text(
                          '${clip.scoreInfo!.homeTeam} ${clip.scoreInfo!.homeScore} - ${clip.scoreInfo!.awayScore} ${clip.scoreInfo!.awayTeam}',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.7),
                            fontSize: 16,
                          ),
                        ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close, color: Colors.white),
                ),
              ],
            ),
          ),

          // Video preview area
          Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A2A),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.9),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.play_arrow_rounded,
                            color: Colors.black,
                            size: 40,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Tap to play clip',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.7),
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Action buttons
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(
                  child: _buildPreviewActionButton(
                    icon: Icons.edit_rounded,
                    label: 'Edit',
                    onTap: () {
                      Navigator.pop(context);
                      _showClipEditDialog(clip);
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildPreviewActionButton(
                    icon: Icons.content_cut_rounded,
                    label: 'Trim',
                    onTap: () {
                      Navigator.pop(context);
                      _showTrimDialog(clip);
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildPreviewActionButton(
                    icon: Icons.share_rounded,
                    label: 'Share',
                    onTap: () {
                      // Implement share functionality
                      Navigator.pop(context);
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildPreviewActionButton(
                    icon: Icons.delete_outline_rounded,
                    label: 'Delete',
                    isDestructive: true,
                    onTap: () {
                      Navigator.pop(context);
                      _showDeleteConfirmationDialog(clip);
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    final Color iconColor =
        isDestructive ? Colors.redAccent : const Color(0xFFFF9800);
    final Color borderColor = isDestructive
        ? Colors.redAccent.withOpacity(0.3)
        : const Color(0xFFFF9800).withOpacity(0.3);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: const Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: borderColor,
            width: 1,
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: iconColor,
              size: 24,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showTrimDialog(ClipModel clip) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Text(
          'Trim Clip',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Adjust the start and end times for your clip',
              style: TextStyle(color: Colors.white.withOpacity(0.8)),
            ),
            const SizedBox(height: 20),
            // Placeholder for trim controls - would implement actual video trimmer
            Container(
              height: 60,
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A2A),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: Text(
                  'Trim controls would go here',
                  style: TextStyle(color: Colors.white.withOpacity(0.6)),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(foregroundColor: Colors.white70),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              // Implement trim functionality
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text('Trim functionality coming soon!')),
              );
            },
            style:
                TextButton.styleFrom(foregroundColor: const Color(0xFFFF9800)),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmationDialog(ClipModel clip) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Text(
          'Delete Clip',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.delete_outline_rounded,
              color: Colors.redAccent,
              size: 48,
            ),
            const SizedBox(height: 16),
            Text(
              'Are you sure you want to delete "${clip.title}"?',
              style: TextStyle(color: Colors.white.withOpacity(0.8)),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              'This action cannot be undone.',
              style: TextStyle(
                color: Colors.redAccent.withOpacity(0.8),
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(foregroundColor: Colors.white70),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              // Delete the clip
              _clipService.deleteClip(clip.id);
              _loadClips();
              Navigator.pop(context);

              // Show success message
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Clip "${clip.title}" deleted'),
                  backgroundColor: Colors.redAccent,
                  duration: const Duration(seconds: 2),
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  margin: const EdgeInsets.all(16),
                ),
              );
            },
            style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  // Create highlight from all visible clips
  void _createHighlightFromAllClips() async {
    final clipsToHighlight = _currentClips;
    if (clipsToHighlight.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No clips available to create highlight')),
      );
      return;
    }

    // Show confirmation dialog
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Text(
          'Create Highlight Reel',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.movie_creation_rounded,
              color: const Color(0xFFFF9800),
              size: 48,
            ),
            const SizedBox(height: 16),
            Text(
              'Create a highlight reel from ${clipsToHighlight.length} ${_currentTabIndex == 0 ? 'active' : 'highlight'} clips?',
              style: TextStyle(color: Colors.white.withOpacity(0.8)),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              'This will combine all visible clips into one highlight video.',
              style: TextStyle(
                color: Colors.white.withOpacity(0.6),
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            style: TextButton.styleFrom(foregroundColor: Colors.white70),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style:
                TextButton.styleFrom(foregroundColor: const Color(0xFFFF9800)),
            child: const Text('Create Highlight'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() {
        _isGeneratingHighlight = true;
      });

      try {
        // Create highlight reel clip
        final now = DateTime.now();
        final timeString =
            '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
        final highlightTitle = 'Highlight Reel - $timeString';

        // Calculate total duration
        final totalDuration = clipsToHighlight.fold<int>(
          0,
          (sum, clip) => sum + (clip.endTimeMs - clip.startTimeMs),
        );

        // Get team names from the first clip with score info
        final firstClipWithScore = clipsToHighlight.firstWhere(
          (clip) => clip.scoreInfo != null,
          orElse: () => clipsToHighlight.first,
        );

        // Create the highlight reel clip
        final highlightClip = await _clipService.createClip(
          videoPath:
              'assets/videos/highlight_${now.millisecondsSinceEpoch}.mp4',
          title: highlightTitle,
          startTimeMs: 0,
          endTimeMs: totalDuration,
          thumbnailPath:
              'assets/images/highlight_thumbnail_${now.millisecondsSinceEpoch}.jpg',
          scoreInfo: firstClipWithScore.scoreInfo,
        );

        // Mark it as a highlight automatically
        final updatedHighlightClip = ClipModel(
          id: highlightClip.id,
          title: highlightClip.title,
          clipUrl: highlightClip.clipUrl,
          thumbnailUrl: highlightClip.thumbnailUrl,
          startTimeMs: highlightClip.startTimeMs,
          endTimeMs: highlightClip.endTimeMs,
          scoreInfo: highlightClip.scoreInfo,
          createdAt: highlightClip.createdAt,
          tags: [...highlightClip.tags, 'highlight_reel'],
          isHighlight: true, // Mark as highlight
          displayOrder: highlightClip.displayOrder,
        );

        _clipService.updateClip(updatedHighlightClip);
        _loadClips();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF9800),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(
                      Icons.movie_creation_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          '🎬 Highlight reel created!',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          'Combined ${clipsToHighlight.length} clips',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.8),
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              backgroundColor: const Color(0xFF2A2A2A),
              duration: const Duration(seconds: 4),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              margin: const EdgeInsets.all(16),
              action: SnackBarAction(
                label: 'View Highlights',
                textColor: const Color(0xFFFF9800),
                onPressed: () {
                  // Switch to Highlights tab
                  _tabController.animateTo(1);
                },
              ),
            ),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error creating highlight: ${e.toString()}'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            _isGeneratingHighlight = false;
          });
        }
      }
    }
  }

  // Build modern tab bar
  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 10, 20, 20),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.8),
        borderRadius: BorderRadius.circular(25),
        border: Border.all(
          color: const Color(0xFFFF9800).withOpacity(0.3),
          width: 1,
        ),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(25),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.white.withOpacity(0.6),
        labelStyle: const TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 16,
        ),
        unselectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.w400,
          fontSize: 16,
        ),
        tabs: [
          Tab(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.access_time_rounded, size: 18),
                const SizedBox(width: 8),
                const Text('Active'),
                if (_activeClips.isNotEmpty)
                  Container(
                    margin: const EdgeInsets.only(left: 8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${_activeClips.length}',
                      style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ),
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.star_rounded, size: 18),
                const SizedBox(width: 8),
                const Text('Highlights'),
                if (_savedClips.isNotEmpty)
                  Container(
                    margin: const EdgeInsets.only(left: 8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${_savedClips.length}',
                      style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Build tab bar view with highlight button
  Widget _buildTabBarView() {
    return Column(
      children: [
        // Create Highlight Reel Button
        if (!_isEditMode && _currentClips.isNotEmpty)
          _buildHighlightReelButton(),

        // Tab Content
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              // Active Clips Tab
              _activeClips.isEmpty
                  ? _buildEmptyState('No clips yet',
                      'Tap the green camera button on ScoreCam to create your first clip')
                  : _buildClipsList(_activeClips),
              // Saved Clips Tab
              _savedClips.isEmpty
                  ? _buildEmptyState('No highlights yet',
                      'Mark clips as highlights to see them here')
                  : _buildClipsList(_savedClips),
            ],
          ),
        ),
      ],
    );
  }

  // Build Create Highlight Reel button
  Widget _buildHighlightReelButton() {
    final clipCount = _currentClips.length;
    final tabName = _currentTabIndex == 0 ? 'active' : 'highlight';

    return Container(
      margin: const EdgeInsets.fromLTRB(20, 10, 20, 10),
      child: GestureDetector(
        onTap: _createHighlightFromAllClips,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(25),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF9800).withOpacity(0.4),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.movie_creation_rounded,
                color: Colors.white,
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Create Highlight Reel',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$clipCount ${tabName}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showClipEditDialog(ClipModel clip) {
    final TextEditingController titleController =
        TextEditingController(text: clip.title);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Text(
          'Edit Clip',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Title',
                labelStyle: const TextStyle(color: Colors.white70),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Colors.grey.shade700),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide:
                      const BorderSide(color: Color(0xFFFF9800), width: 2),
                ),
                filled: true,
                fillColor: Colors.black45,
              ),
            ),
            const SizedBox(height: 16),
            // Highlight toggle
            Row(
              children: [
                const Text(
                  'Mark as highlight',
                  style: TextStyle(color: Colors.white70),
                ),
                const Spacer(),
                Switch(
                  value: clip.isHighlight,
                  activeColor: const Color(0xFFFF9800),
                  onChanged: (value) {
                    setState(() {
                      clip.isHighlight = value;
                    });
                  },
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              foregroundColor: Colors.white70,
            ),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              final updatedClip = ClipModel(
                id: clip.id,
                title: titleController.text,
                clipUrl: clip.clipUrl,
                thumbnailUrl: clip.thumbnailUrl,
                startTimeMs: clip.startTimeMs,
                endTimeMs: clip.endTimeMs,
                scoreInfo: clip.scoreInfo,
                createdAt: clip.createdAt,
                tags: clip.tags,
                isHighlight: clip.isHighlight,
                displayOrder: clip.displayOrder,
              );

              _clipService.updateClip(updatedClip);
              _loadClips();
              Navigator.pop(context);
            },
            style: TextButton.styleFrom(
              foregroundColor: const Color(0xFFFF9800),
            ),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: false,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          'My Clips',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: _buildTabBar(),
        ),
      ),
      body: _buildTabBarView(),
      bottomNavigationBar: _isEditMode ? _buildEditModeBottomBar() : null,
    );
  }

  Widget _buildEmptyState(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 40, 32, 32),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A2A),
                shape: BoxShape.circle,
              ),
              child: Icon(
                _currentTabIndex == 0
                    ? Icons.access_time_rounded
                    : Icons.star_outline_rounded,
                size: 60,
                color: Colors.white.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 32),
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w600,
                height: 1.2,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Text(
              subtitle,
              style: TextStyle(
                color: Colors.white.withOpacity(0.7),
                fontSize: 16,
                fontWeight: FontWeight.w400,
                height: 1.4,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFFF9800).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: const Color(0xFFFF9800).withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.info_outline_rounded,
                    color: const Color(0xFFFF9800),
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Tap and hold to edit clips',
                    style: TextStyle(
                      color: const Color(0xFFFF9800),
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildClipsList(List<ClipModel> clips) {
    return ReorderableListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
      itemCount: clips.length,
      onReorder: (oldIndex, newIndex) {
        if (oldIndex < newIndex) {
          newIndex -= 1;
        }
        setState(() {
          final clip = clips.removeAt(oldIndex);
          clips.insert(newIndex, clip);
          // Update display order
          for (int i = 0; i < clips.length; i++) {
            clips[i].displayOrder = i;
          }
        });
        // Save the new order
        _clipService.reorderClips(clips.map((c) => c.id).toList());
      },
      itemBuilder: (context, index) {
        final clip = clips[index];
        final isSelected = _selectedClipIds.contains(clip.id);

        return Container(
          key: ValueKey(clip.id),
          margin: const EdgeInsets.only(bottom: 24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF2A2A2A),
                Color(0xFF1A1A1A),
                Color(0xFF0A0A0A),
              ],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: const Color(0xFFFF9800).withOpacity(0.15),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 20,
                offset: const Offset(0, 8),
                spreadRadius: 2,
              ),
              BoxShadow(
                color: const Color(0xFFFF9800).withOpacity(0.1),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: GestureDetector(
              onTap: _isEditMode
                  ? () => _toggleClipSelection(clip.id)
                  : () => _showClipPreview(clip),
              onLongPress: !_isEditMode ? _toggleEditMode : null,
              child: Container(
                height: 120,
                child: Stack(
                  children: [
                    // Main content row
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          // Thumbnail container
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Color(0xFF3A3A3A),
                                  Color(0xFF2A2A2A),
                                ],
                              ),
                              border: Border.all(
                                color: const Color(0xFFFF9800).withOpacity(0.2),
                                width: 1,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.4),
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Stack(
                              children: [
                                // Play button
                                Center(
                                  child: Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                        colors: [
                                          Color(0xFFFF9800),
                                          Color(0xFFFF5722)
                                        ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: const Color(0xFFFF9800)
                                              .withOpacity(0.4),
                                          blurRadius: 6,
                                          offset: const Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    child: const Icon(
                                      Icons.play_arrow_rounded,
                                      color: Colors.white,
                                      size: 20,
                                    ),
                                  ),
                                ),
                                // Duration badge
                                Positioned(
                                  bottom: 6,
                                  right: 6,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.9),
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(
                                        color: const Color(0xFFFF9800)
                                            .withOpacity(0.3),
                                        width: 0.5,
                                      ),
                                    ),
                                    child: Text(
                                      _formatDuration(
                                          clip.endTimeMs - clip.startTimeMs),
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(width: 16),

                          // Clip details
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                // Title
                                Text(
                                  clip.title,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    height: 1.2,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),

                                const SizedBox(height: 6),

                                // Score info
                                if (clip.scoreInfo != null)
                                  Text(
                                    '${clip.scoreInfo!.homeTeam} ${clip.scoreInfo!.homeScore} - ${clip.scoreInfo!.awayScore} ${clip.scoreInfo!.awayTeam}',
                                    style: const TextStyle(
                                      color: Color(0xFFFF9800),
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500,
                                      height: 1.2,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),

                                const SizedBox(height: 4),

                                // Created date with icon
                                Row(
                                  children: [
                                    Icon(
                                      Icons.access_time_rounded,
                                      color: Colors.white.withOpacity(0.5),
                                      size: 12,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      _formatDate(clip.createdAt),
                                      style: TextStyle(
                                        color: Colors.white.withOpacity(0.6),
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),

                          // Action area
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              // Edit mode selection or menu
                              if (_isEditMode)
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: 32,
                                      height: 32,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: isSelected
                                            ? const Color(0xFFFF9800)
                                            : Colors.transparent,
                                        border: Border.all(
                                          color: isSelected
                                              ? const Color(0xFFFF9800)
                                              : Colors.white.withOpacity(0.5),
                                          width: 2,
                                        ),
                                      ),
                                      child: isSelected
                                          ? const Icon(
                                              Icons.check_rounded,
                                              color: Colors.white,
                                              size: 20,
                                            )
                                          : null,
                                    ),
                                    const SizedBox(width: 8),
                                    Icon(
                                      Icons.drag_handle_rounded,
                                      color: Colors.white.withOpacity(0.6),
                                      size: 24,
                                    ),
                                  ],
                                )
                              else
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    // Favorite/Star button
                                    GestureDetector(
                                      onTap: () => _toggleClipHighlight(clip),
                                      child: Container(
                                        width: 36,
                                        height: 36,
                                        decoration: BoxDecoration(
                                          color: clip.isHighlight
                                              ? const Color(0xFFFF9800)
                                              : Colors.white.withOpacity(0.1),
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: clip.isHighlight
                                                ? const Color(0xFFFF9800)
                                                : Colors.white.withOpacity(0.3),
                                            width: 1,
                                          ),
                                        ),
                                        child: Icon(
                                          clip.isHighlight
                                              ? Icons.star_rounded
                                              : Icons.star_outline_rounded,
                                          color: clip.isHighlight
                                              ? Colors.white
                                              : Colors.white.withOpacity(0.7),
                                          size: 20,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Icon(
                                      Icons.chevron_right_rounded,
                                      color: Colors.white.withOpacity(0.6),
                                      size: 28,
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Highlight badge
                    if (clip.isHighlight)
                      Positioned(
                        top: 12,
                        left: 12,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF9800),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.star_rounded,
                                color: Colors.white,
                                size: 12,
                              ),
                              SizedBox(width: 4),
                              Text(
                                'HIGHLIGHT',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                    // Selection overlay
                    if (_isEditMode && isSelected)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF9800).withOpacity(0.1),
                            border: Border.all(
                              color: const Color(0xFFFF9800),
                              width: 2,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  String _formatDuration(int milliseconds) {
    final seconds = (milliseconds / 1000).round();
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.month}/${date.day}/${date.year}';
    }
  }

  Widget _buildEditModeBottomBar() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.black,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildActionButton(
              icon: Icons.delete_outline_rounded,
              label: 'Delete',
              onTap: _selectedClipIds.isEmpty
                  ? null
                  : () {
                      // Show delete confirmation dialog
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          backgroundColor: const Color(0xFF1E1E1E),
                          title: const Text(
                            'Delete Clips',
                            style: TextStyle(color: Colors.white),
                          ),
                          content: Text(
                            'Are you sure you want to delete ${_selectedClipIds.length} clip${_selectedClipIds.length > 1 ? 's' : ''}?',
                            style: const TextStyle(color: Colors.white70),
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              style: TextButton.styleFrom(
                                foregroundColor: Colors.white70,
                              ),
                              child: const Text('Cancel'),
                            ),
                            TextButton(
                              onPressed: () {
                                for (final clipId in _selectedClipIds) {
                                  _clipService.deleteClip(clipId);
                                }
                                _loadClips();
                                _selectedClipIds.clear();
                                Navigator.pop(context);
                              },
                              style: TextButton.styleFrom(
                                foregroundColor: Colors.redAccent,
                              ),
                              child: const Text('Delete'),
                            ),
                          ],
                        ),
                      );
                    },
            ),
            _buildActionButton(
              icon: Icons.edit_rounded,
              label: 'Edit',
              onTap: _selectedClipIds.length != 1
                  ? null
                  : () {
                      final clip =
                          _clipService.getClipById(_selectedClipIds.first);
                      if (clip != null) {
                        _showClipEditDialog(clip);
                      }
                    },
            ),
            _buildActionButton(
              icon: Icons.movie_rounded,
              label: 'Highlight',
              onTap: _selectedClipIds.isEmpty || _isGeneratingHighlight
                  ? null
                  : _generateHighlight,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
  }) {
    final isDisabled = onTap == null;
    final Color activeColor = const Color(0xFFFF9800);
    final Color disabledColor = Colors.grey.shade600;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: BoxDecoration(
          color: isDisabled ? Colors.grey.shade900 : Colors.black,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isDisabled ? disabledColor : activeColor,
            width: 1.5,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isDisabled ? disabledColor : activeColor,
              size: 26,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: isDisabled ? disabledColor : Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
