import 'package:uuid/uuid.dart';
import '../models/clip_model.dart';

/// Service for managing ScoreCam clips
class ClipService {
  /// Singleton instance
  static final ClipService _instance = ClipService._internal();
  
  /// Factory constructor
  factory ClipService() => _instance;
  
  /// Internal constructor
  ClipService._internal() {
    // Start with empty clips list for realistic experience
    // _initializeSampleClips(); // Commented out to start with no clips
  }
  
  /// List of all clips
  final List<ClipModel> _clips = [];
  
  /// Get all clips
  List<ClipModel> get clips => List.unmodifiable(_clips);
  
  /// Create a new clip
  Future<ClipModel> createClip({
    required String videoPath,
    required String title,
    required int startTimeMs,
    required int endTimeMs,
    required String thumbnailPath,
    ScoreInfo? scoreInfo,
  }) async {
    final uuid = const Uuid().v4();
    
    final clip = ClipModel(
      id: uuid,
      title: title,
      clipUrl: videoPath,
      thumbnailUrl: thumbnailPath,
      startTimeMs: startTimeMs,
      endTimeMs: endTimeMs,
      scoreInfo: scoreInfo,
      createdAt: DateTime.now(),
      displayOrder: _clips.length,
    );
    
    _clips.add(clip);
    return clip;
  }
  
  /// Update a clip
  void updateClip(ClipModel updatedClip) {
    final index = _clips.indexWhere((clip) => clip.id == updatedClip.id);
    if (index != -1) {
      _clips[index] = updatedClip;
    }
  }
  
  /// Delete a clip
  void deleteClip(String clipId) {
    _clips.removeWhere((clip) => clip.id == clipId);
  }
  
  /// Get a clip by ID
  ClipModel? getClipById(String id) {
    try {
      return _clips.firstWhere((clip) => clip.id == id);
    } catch (e) {
      return null;
    }
  }
  
  /// Reorder clips
  void reorderClips(List<String> clipIds) {
    for (int i = 0; i < clipIds.length; i++) {
      final clip = getClipById(clipIds[i]);
      if (clip != null) {
        final updatedClip = ClipModel(
          id: clip.id,
          title: clip.title,
          clipUrl: clip.clipUrl,
          thumbnailUrl: clip.thumbnailUrl,
          startTimeMs: clip.startTimeMs,
          endTimeMs: clip.endTimeMs,
          scoreInfo: clip.scoreInfo,
          createdAt: clip.createdAt,
          tags: clip.tags,
          isHighlight: clip.isHighlight,
          displayOrder: i,
        );
        updateClip(updatedClip);
      }
    }
  }
  
  /// Generate a highlight reel from selected clips
  Future<String?> generateHighlight(List<String> selectedClipIds) async {
    // This would involve actual video processing
    // For now, this is a placeholder for the implementation
    // In a real implementation, this would:
    // 1. Get all selected clips
    // 2. Concatenate them in order
    // 3. Return the path to the new video
    
    return 'path/to/highlight/video.mp4';
  }
  
}
