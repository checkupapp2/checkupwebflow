// Clip model for ScoreCam clips feature

/// Model class representing a video clip from ScoreCam
class ClipModel {
  /// Unique identifier for the clip
  final String id;
  
  /// Title or name of the clip
  String title;
  
  /// URL or file path to the clip
  final String clipUrl;
  
  /// URL or file path to the clip thumbnail
  final String thumbnailUrl;
  
  /// Start time of the clip in the original video (in milliseconds)
  int startTimeMs;
  
  /// End time of the clip in the original video (in milliseconds)
  int endTimeMs;
  
  /// Duration of the clip in milliseconds
  int get durationMs => endTimeMs - startTimeMs;
  
  /// Score information at the time of the clip
  final ScoreInfo? scoreInfo;
  
  /// Time when the clip was created
  final DateTime createdAt;
  
  /// Tags or labels associated with the clip
  List<String> tags;
  
  /// Whether this clip is marked as a highlight
  bool isHighlight;
  
  /// Display order for arranging clips
  int displayOrder;

  /// Constructor
  ClipModel({
    required this.id,
    required this.title,
    required this.clipUrl,
    required this.thumbnailUrl,
    required this.startTimeMs,
    required this.endTimeMs,
    this.scoreInfo,
    required this.createdAt,
    this.tags = const [],
    this.isHighlight = false,
    this.displayOrder = 0,
  });
}

/// Model class representing score information for a clip
class ScoreInfo {
  /// Home team name
  final String homeTeam;
  
  /// Away team name
  final String awayTeam;
  
  /// Home team score
  final int homeScore;
  
  /// Away team score
  final int awayScore;
  
  /// Current period (1ST, 2ND, etc.)
  final String period;
  
  /// Timer display at the time of the clip
  final String timerDisplay;

  /// Constructor
  const ScoreInfo({
    required this.homeTeam,
    required this.awayTeam,
    required this.homeScore,
    required this.awayScore,
    required this.period,
    required this.timerDisplay,
  });
}
