import 'package:check_up_app/features/courts/domain/models/court_model.dart'
    as core;
import 'package:check_up_app/features/search/domain/models/court_model.dart'
    as search;

/// Map the rich core model to the lightweight search model.
search.CourtModel toSearch(core.CourtModel c) {
  return search.CourtModel(
    id: c.id ?? '',
    name: c.name,
    city: c.city,
    state: c.state,
    followers: (c.followersCount ?? 0),
    imageUrl: (c.images.isNotEmpty
        ? c.images.first
        : 'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=1200&q=80'),
    isVerified: c.isVerified,
    isFollowing: c.isFollowing,
  );
}
