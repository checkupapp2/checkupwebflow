import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:check_up_app/features/events/data/events_repository.dart';
import 'package:check_up_app/features/search/domain/models/search_event_model.dart';

class SearchRepository {
  SearchRepository({
    FirebaseFirestore? firestore,
    required EventsRepository eventsRepository,
  })  : _db = firestore ?? FirebaseFirestore.instance,
        _eventsRepo = eventsRepository;

  final FirebaseFirestore _db;
  final EventsRepository _eventsRepo;

  Stream<List<SearchEventModel>> stream({
    required String query,
    required String selectedFilter,
    int limit = 100,
  }) {
    final base = _db
        .collection('events')
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots();

    return base.asyncMap((snap) async {
      print('📥 [SearchEvents] snapshot docs: ${snap.docs.length}');

      final results = <SearchEventModel>[];
      for (final d in snap.docs) {
        final m = await _toModel(d.id, d.data());
        if (m != null) results.add(m);
      }

      print('🛠️ [SearchEvents] built models: ${results.length}');

      final filtered = _applyFilters(results, query, selectedFilter);

      print(
        '🔎 [SearchEvents] filtered: ${filtered.length} '
        '(query="$query", filter="$selectedFilter")',
      );

      return filtered;
    });
  }

  Future<SearchEventModel?> _toModel(
    String id,
    Map<String, dynamic> data,
  ) async {
    try {
      // Safe field extraction
      final title = (data['title'] as String?) ?? 'Untitled Event';

      // Location may be missing OR nested inside extra
      final extra = (data['extra'] as Map<String, dynamic>?) ?? const {};
      final location = (data['location'] as String?) ??
          (extra['locationMeta']?['name'] as String?) ??
          'Unknown Location';

      final banner = (data['bannerImageUrl'] as String?) ?? '';
      final eventType = (data['eventType'] as String?) ?? 'pickupRun';

      // Safe date
      final ts = data['dateTime'];
      DateTime dateTime;
      if (ts is Timestamp) {
        dateTime = ts.toDate();
      } else if (ts is String) {
        dateTime = DateTime.tryParse(ts) ?? DateTime.now();
      } else {
        dateTime = DateTime.now();
      }

      final isFreeField = (data['isFree'] as bool?) ?? false;
      final priceField = (data['price'] as num?)?.toDouble();
      final hostName = (data['hostUsername'] as String?)?.trim();

      // Tickets (safe)
      List tickets = [];
      try {
        tickets = await _eventsRepo.fetchTicketsOnce(id);
      } catch (e) {
        print('⚠️ fetchTicketsOnce failed for event $id → $e');
        tickets = [];
      }

      final prices = tickets.map((t) => t.price).whereType<double>().toList();
      final hasFree = prices.any((p) => p == 0);
      final minPaid = prices
          .where((p) => p > 0)
          .fold<double?>(null, (m, p) => m == null || p < m ? p : m);

      final priceLabel = _priceLabel(
        hasTickets: tickets.isNotEmpty,
        hasFreeTicket: hasFree,
        minPaid: minPaid,
        eventIsFree: isFreeField,
        eventPrice: priceField,
      );

      return SearchEventModel(
        id: id,
        title: title,
        location: location,
        gameType: _displayGameType(eventType, extra),
        date: _displayDate(dateTime),
        price: priceLabel,
        rating: 4.8,
        reviews: _approxReviews(eventType, extra),
        hostName: hostName ?? 'Hosted Event',
        thumbnailUrl: banner.isNotEmpty
            ? banner
            : 'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=1000&auto=format&fit=crop',
        imageUrls: [if (banner.isNotEmpty) banner],
      );
    } catch (e, st) {
      print('❌ _toModel FAILED for event $id — $e');
      print(st);
      return null;
    }
  }

  String _priceLabel({
    required bool hasTickets,
    required bool hasFreeTicket,
    required double? minPaid,
    required bool eventIsFree,
    required double? eventPrice,
  }) {
    if (hasTickets) {
      if (hasFreeTicket) return 'Free';
      if (minPaid != null) return _fmt(minPaid);
      return 'From tickets';
    }
    if (eventIsFree) return 'Free';
    if (eventPrice != null && eventPrice > 0) return _fmt(eventPrice);
    return 'From tickets';
  }

  String _fmt(double p) => p == p.truncateToDouble()
      ? '\$${p.toStringAsFixed(0)}'
      : '\$${p.toStringAsFixed(2)}';

  // filters identical to your widget version
  List<SearchEventModel> _applyFilters(
      List<SearchEventModel> all, String query, String selectedFilter) {
    var filtered = all;
    if (query.isNotEmpty) {
      final q = query.toLowerCase();
      filtered = filtered
          .where((e) =>
              e.title.toLowerCase().contains(q) ||
              e.location.toLowerCase().contains(q) ||
              e.gameType.toLowerCase().contains(q))
          .toList();
    }
    switch (selectedFilter) {
      case 'Popular':
        filtered.sort((a, b) => b.reviews.compareTo(a.reviews));
        break;
      case 'Nearby':
        filtered.sort((a, b) => a.location.compareTo(b.location));
        break;
      case 'Today':
        filtered = filtered
            .where((e) => e.date.toLowerCase().contains('today'))
            .toList();
        break;
      case 'This Week':
        filtered = filtered
            .where((e) =>
                e.date.toLowerCase().contains('this week') ||
                e.date.toLowerCase().contains('today'))
            .toList();
        break;
      case 'Free':
        filtered =
            filtered.where((e) => e.price.toLowerCase() == 'free').toList();
        break;
      case 'Runs':
        filtered = filtered
            .where((e) =>
                e.gameType.toLowerCase().contains('run') ||
                e.gameType.toLowerCase().contains('pickup') ||
                e.gameType.toLowerCase().contains('pick up') ||
                e.gameType.toLowerCase().contains('open play') ||
                e.gameType.toLowerCase().contains('open gym'))
            .toList();
        break;
      case 'Tournaments':
        filtered = filtered
            .where((e) => e.gameType.toLowerCase().contains('tournament'))
            .toList();
        break;
      case 'Leagues':
        filtered = filtered
            .where((e) => e.gameType.toLowerCase().contains('league'))
            .toList();
        break;
      case 'Camp':
        filtered = filtered
            .where((e) => e.gameType.toLowerCase().contains('camp'))
            .toList();
        break;
      case 'Training':
        filtered = filtered
            .where((e) =>
                e.gameType.toLowerCase().contains('training') ||
                e.gameType.toLowerCase().contains('workshop'))
            .toList();
        break;
      case 'Special':
        filtered = filtered
            .where((e) =>
                e.gameType.toLowerCase().contains('special') ||
                e.gameType.toLowerCase().contains('exhibition'))
            .toList();
        break;
      default:
        break;
    }
    return filtered;
  }

  // view helpers
  String _displayGameType(String raw, Map<String, dynamic> extra) {
    switch (raw) {
      case 'tournament':
        return (extra['format'] as String?) ?? 'Tournament';
      case 'donationBased':
        return 'Donation Event';
      case 'pickupRun':
      default:
        final max = (extra['maxPlayers'] as num?)?.toInt();
        final skill = (extra['skillLevel'] as String?) ?? 'Open Play';
        return max != null ? '$skill • ${max}p cap' : skill;
    }
  }

  String _displayDate(DateTime dt) {
    final now = DateTime.now();
    final isToday =
        dt.year == now.year && dt.month == now.month && dt.day == now.day;
    final isThisWeek = dt.difference(now).inDays <= 7 && dt.isAfter(now);
    final hh = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final mm = dt.minute.toString().padLeft(2, '0');
    final ampm = dt.hour >= 12 ? 'PM' : 'AM';
    if (isToday) return 'Today • $hh:$mm $ampm';
    if (isThisWeek) {
      const w = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      final wd = w[dt.weekday - 1];
      return 'This Week • $wd $hh:$mm $ampm';
    }
    const m = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return '${m[dt.month - 1]} ${dt.day} • $hh:$mm $ampm';
  }

  int _approxReviews(String raw, Map<String, dynamic> extra) {
    switch (raw) {
      case 'pickupRun':
        return (extra['currentPlayers'] as num?)?.toInt() ?? 0;
      case 'tournament':
        return ((extra['numberOfTeams'] as num?)?.toInt() ?? 8) * 5;
      case 'donationBased':
        final amt = (extra['currentAmount'] as num?)?.toDouble() ?? 0;
        return amt > 0 ? (amt / 20).round() : 0;
      default:
        return 0;
    }
  }
}
