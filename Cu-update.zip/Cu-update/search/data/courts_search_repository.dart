import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:check_up_app/features/search/domain/models/court_model.dart';

/// Lightweight repo for streaming court search cards from Firestore
class CourtsSearchRepository {
  CourtsSearchRepository({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  // Simple logger
  void _log(String msg) {
    if (kDebugMode) debugPrint('[CourtsSearchRepo] $msg');
  }

  Stream<List<CourtModel>> stream({
    required String query,
    required String selectedFilter,
    int limit = 200,
  }) {
    final base = _db
        .collection('courts')
        // .orderBy('followersCount', descending: true) // ❌ remove this
        .limit(limit)
        .snapshots();

    return base.map((snap) {
      // Debug logs
      // ignore: avoid_print
      print('📥 [CourtsSearch] snapshot docs: ${snap.docs.length}');

      final all = <CourtModel>[];
      for (final d in snap.docs) {
        final m = _toModelSafe(d.id, d.data());
        if (m != null) all.add(m);
      }

      // ignore: avoid_print
      print('🧱 [CourtsSearch] mapped models: ${all.length}');

      final filtered = _applyFilters(all, query, selectedFilter);

      // ignore: avoid_print
      print('🔎 [CourtsSearch] filtered=${filtered.length} '
          '(q="$query", filter="$selectedFilter")');

      return filtered;
    });
  }

  CourtModel? _toModelSafe(String id, Map<String, dynamic> data) {
    try {
      final name = (data['name'] as String?)?.trim() ?? 'Unnamed Court';
      final city = (data['city'] as String?)?.trim() ?? '';
      final state = (data['state'] as String?)?.trim() ?? '';
      final followers = (data['followersCount'] as num?)?.toInt() ?? 0;
      final isVerified = (data['isVerified'] as bool?) ?? false;

      final images = (data['images'] as List?)
              ?.whereType<String>()
              .where((e) => e.isNotEmpty)
              .toList() ??
          const <String>[];
      final imageUrl = images.isNotEmpty
          ? images.first
          : 'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=1200&q=80';

      // Optional per-user denormalized flag for listing UI
      final isFollowing = (data['isFollowing'] as bool?) ?? false;

      return CourtModel(
        id: id,
        name: name,
        city: city,
        state: state,
        followers: followers,
        imageUrl: imageUrl,
        isVerified: isVerified,
        isFollowing: isFollowing,
      );
    } catch (e, st) {
      _log('_toModelSafe failed for $id: $e');
      _log(st.toString());
      return null;
    }
  }

  List<CourtModel> _applyFilters(
    List<CourtModel> all,
    String query,
    String selectedFilter,
  ) {
    var filtered = all;

    if (query.isNotEmpty) {
      final q = query.toLowerCase();
      filtered = filtered.where((c) {
        final hit = c.name.toLowerCase().contains(q) ||
            c.city.toLowerCase().contains(q) ||
            c.state.toLowerCase().contains(q);
        if (!hit) _log('search miss id=${c.id} name="${c.name}"');
        return hit;
      }).toList();
    }

    switch (selectedFilter) {
      case 'Popular':
        filtered.sort((a, b) => b.followers.compareTo(a.followers));
        break;
      case 'Nearby':
        // Placeholder sort for now
        filtered.sort((a, b) => a.name.compareTo(b.name));
        break;
      case 'My Courts':
        filtered =
            filtered.where((c) => c.isVerified && c.isFollowing).toList();
        break;
      case 'Rentals':
        filtered = filtered.where((c) => c.isVerified).toList();
        break;
      case 'Following':
        filtered = filtered.where((c) => c.isFollowing).toList();
        break;
      case 'Friends':
        filtered = filtered.where((c) => c.id.hashCode % 3 == 0).toList();
        break;
      default:
        break;
    }

    _log('applyFilters done -> ${filtered.length} items');
    return filtered;
  }
}
