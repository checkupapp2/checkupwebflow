/// Group model for representing group data in the search results
class GroupModel {
  /// Group ID
  final String id;
  
  /// Group name
  final String name;
  
  /// URL to group's image
  final String? imageUrl;
  
  /// Group's description
  final String? description;
  
  /// Number of members in the group
  final int memberCount;
  
  /// Whether the current user is a member of this group
  final bool isMember;

  /// Constructor
  GroupModel({
    required this.id,
    required this.name,
    this.imageUrl,
    this.description,
    this.memberCount = 0,
    this.isMember = false,
  });
}
