

/// Model representing a game score/session
class ScoreModel {
  /// Unique identifier for the score
  final String id;
  
  /// Home team name
  final String homeTeamName;
  
  /// Away team name
  final String awayTeamName;
  
  /// Home team score
  final int homeScore;
  
  /// Away team score
  final int awayScore;
  
  /// Home team logo URL
  final String? homeTeamLogoUrl;
  
  /// Away team logo URL
  final String? awayTeamLogoUrl;
  
  /// Game date and time
  final DateTime gameDateTime;
  
  /// Game status (e.g., "Final", "In Progress", "Upcoming")
  final String gameStatus;
  
  /// Court name where the game was played
  final String courtName;
  
  /// Court location
  final String courtLocation;
  
  /// Host name
  final String hostName;
  
  /// Host profile image URL
  final String? hostImageUrl;
  
  /// Game type (e.g., "5v5", "3v3", "Tournament")
  final String gameType;
  
  /// League name if applicable
  final String? leagueName;

  /// Constructor
  const ScoreModel({
    required this.id,
    required this.homeTeamName,
    required this.awayTeamName,
    required this.homeScore,
    required this.awayScore,
    this.homeTeamLogoUrl,
    this.awayTeamLogoUrl,
    required this.gameDateTime,
    required this.gameStatus,
    required this.courtName,
    required this.courtLocation,
    required this.hostName,
    this.hostImageUrl,
    required this.gameType,
    this.leagueName,
  });

  /// Generate a list of mock scores for testing
  static List<ScoreModel> getMockScores() {
    return [
      ScoreModel(
        id: '1',
        homeTeamName: 'Lakers',
        awayTeamName: 'Celtics',
        homeScore: 108,
        awayScore: 102,
        homeTeamLogoUrl: 'https://picsum.photos/100/100?random=1',
        awayTeamLogoUrl: 'https://picsum.photos/100/100?random=2',
        gameDateTime: DateTime(2025, 6, 10, 19, 30),
        gameStatus: 'Final',
        courtName: 'Downtown Arena',
        courtLocation: 'Los Angeles, CA',
        hostName: 'John Smith',
        hostImageUrl: 'https://picsum.photos/100/100?random=3',
        gameType: '5v5',
        leagueName: 'Summer League',
      ),
      ScoreModel(
        id: '2',
        homeTeamName: 'Warriors',
        awayTeamName: 'Nets',
        homeScore: 95,
        awayScore: 112,
        homeTeamLogoUrl: 'https://picsum.photos/100/100?random=4',
        awayTeamLogoUrl: 'https://picsum.photos/100/100?random=5',
        gameDateTime: DateTime(2025, 6, 9, 18, 0),
        gameStatus: 'Final',
        courtName: 'Bay Area Court',
        courtLocation: 'San Francisco, CA',
        hostName: 'Mike Johnson',
        hostImageUrl: 'https://picsum.photos/100/100?random=6',
        gameType: '5v5',
      ),
      ScoreModel(
        id: '3',
        homeTeamName: 'Street Ballers',
        awayTeamName: 'Hoop Dreams',
        homeScore: 21,
        awayScore: 15,
        gameDateTime: DateTime(2025, 6, 11, 16, 0),
        gameStatus: 'Final',
        courtName: 'Venice Beach Courts',
        courtLocation: 'Venice, CA',
        hostName: 'Sarah Williams',
        gameType: '3v3',
        leagueName: 'Street League',
      ),
      ScoreModel(
        id: '4',
        homeTeamName: 'Phoenix',
        awayTeamName: 'Dallas',
        homeScore: 88,
        awayScore: 92,
        homeTeamLogoUrl: 'https://picsum.photos/100/100?random=7',
        awayTeamLogoUrl: 'https://picsum.photos/100/100?random=8',
        gameDateTime: DateTime(2025, 6, 12, 20, 0),
        gameStatus: 'In Progress',
        courtName: 'Desert Arena',
        courtLocation: 'Phoenix, AZ',
        hostName: 'Robert Garcia',
        hostImageUrl: 'https://picsum.photos/100/100?random=9',
        gameType: '5v5',
      ),
      ScoreModel(
        id: '5',
        homeTeamName: 'Chicago',
        awayTeamName: 'Miami',
        homeScore: 0,
        awayScore: 0,
        homeTeamLogoUrl: 'https://picsum.photos/100/100?random=10',
        awayTeamLogoUrl: 'https://picsum.photos/100/100?random=11',
        gameDateTime: DateTime(2025, 6, 15, 19, 0),
        gameStatus: 'Upcoming',
        courtName: 'Windy City Center',
        courtLocation: 'Chicago, IL',
        hostName: 'Lisa Thompson',
        hostImageUrl: 'https://picsum.photos/100/100?random=12',
        gameType: '5v5',
        leagueName: 'Pro-Am League',
      ),
      ScoreModel(
        id: '6',
        homeTeamName: 'Rookies',
        awayTeamName: 'Veterans',
        homeScore: 45,
        awayScore: 62,
        gameDateTime: DateTime(2025, 6, 8, 14, 0),
        gameStatus: 'Final',
        courtName: 'Community Center',
        courtLocation: 'Portland, OR',
        hostName: 'David Wilson',
        gameType: '3v3',
      ),
      ScoreModel(
        id: '7',
        homeTeamName: 'East All-Stars',
        awayTeamName: 'West All-Stars',
        homeScore: 115,
        awayScore: 118,
        homeTeamLogoUrl: 'https://picsum.photos/100/100?random=13',
        awayTeamLogoUrl: 'https://picsum.photos/100/100?random=14',
        gameDateTime: DateTime(2025, 6, 7, 20, 0),
        gameStatus: 'Final',
        courtName: 'Central Arena',
        courtLocation: 'Atlanta, GA',
        hostName: 'Michael Brown',
        hostImageUrl: 'https://picsum.photos/100/100?random=15',
        gameType: '5v5',
        leagueName: 'All-Star Game',
      ),
    ];
  }
}
