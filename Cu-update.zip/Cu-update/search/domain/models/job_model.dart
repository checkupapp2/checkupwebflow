/// Job model for representing job data in the search results
class JobModel {
  /// Job ID
  final String id;
  
  /// Job title
  final String title;
  
  /// Job type (e.g., Referee, Videographer, Scorekeeper)
  final String type;
  
  /// Job description
  final String? description;
  
  /// Job location
  final String? location;
  
  /// Pay rate (can be hourly or fixed)
  final String? payRate;
  
  /// Date of the job
  final DateTime? date;
  
  /// URL to job poster's image or organization logo
  final String? imageUrl;
  
  /// Name of the person or organization posting the job
  final String posterName;
  
  /// Whether the current user has applied for this job
  final bool hasApplied;
  
  /// Whether the job is featured/highlighted
  final bool isFeatured;

  /// Constructor
  JobModel({
    required this.id,
    required this.title,
    required this.type,
    required this.posterName,
    this.description,
    this.location,
    this.payRate,
    this.date,
    this.imageUrl,
    this.hasApplied = false,
    this.isFeatured = false,
  });
}
