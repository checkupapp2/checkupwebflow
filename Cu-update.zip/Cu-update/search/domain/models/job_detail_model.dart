import 'job_model.dart';

/// Enhanced job model with additional details for the job detail page
class JobDetailModel {
  /// Basic job information
  final JobModel job;
  
  /// Full job description (may be longer than the preview in JobModel)
  final String fullDescription;
  
  /// Requirements for the job
  final List<String> requirements;
  
  /// Responsibilities for the job
  final List<String> responsibilities;
  
  /// Qualifications needed
  final List<String> qualifications;
  
  /// Contact information
  final String? contactEmail;
  
  /// Contact phone
  final String? contactPhone;
  
  /// Application deadline
  final DateTime? applicationDeadline;
  
  /// Number of positions available
  final int positionsAvailable;
  
  /// Number of applicants so far
  final int applicantCount;
  
  /// Constructor
  JobDetailModel({
    required this.job,
    required this.fullDescription,
    required this.requirements,
    required this.responsibilities,
    required this.qualifications,
    this.contactEmail,
    this.contactPhone,
    this.applicationDeadline,
    this.positionsAvailable = 1,
    this.applicantCount = 0,
  });
  
  /// Factory method to create a JobDetailModel from a JobModel with mock additional data
  factory JobDetailModel.fromJobModel(JobModel job) {
    return JobDetailModel(
      job: job,
      fullDescription: job.description ?? 'No description available.',
      requirements: [
        'Must be at least 18 years old',
        'Previous experience in ${job.type.toLowerCase()} role preferred',
        'Ability to work in a fast-paced environment',
        'Excellent communication skills',
        'Reliable transportation to the venue',
      ],
      responsibilities: [
        'Perform all duties related to ${job.type.toLowerCase()} role',
        'Arrive 30 minutes before scheduled time',
        'Follow all guidelines and protocols',
        'Report to supervisor upon arrival',
        'Complete all required documentation',
      ],
      qualifications: [
        'High school diploma or equivalent',
        'Previous experience in sports events',
        'Knowledge of sports rules and regulations',
        'Ability to stand for extended periods',
      ],
      contactEmail: 'jobs@checkup.com',
      contactPhone: '(555) 123-4567',
      applicationDeadline: job.date?.add(const Duration(days: -3)),
      positionsAvailable: 2,
      applicantCount: 8,
    );
  }
}
