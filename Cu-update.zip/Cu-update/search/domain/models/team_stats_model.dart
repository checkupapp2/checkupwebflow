/// Model representing team statistics for a game
class TeamStatsModel {
  /// Game ID this stats are related to
  final String gameId;
  
  /// Team ID
  final String teamId;
  
  /// Field goals made
  final int fieldGoalsMade;
  
  /// Field goals attempted
  final int fieldGoalsAttempted;
  
  /// Three pointers made
  final int threePointersMade;
  
  /// Three pointers attempted
  final int threePointersAttempted;
  
  /// Free throws made
  final int freeThrowsMade;
  
  /// Free throws attempted
  final int freeThrowsAttempted;
  
  /// Total rebounds
  final int rebounds;
  
  /// Total assists
  final int assists;
  
  /// Total steals
  final int steals;
  
  /// Total blocks
  final int blocks;
  
  /// Total turnovers
  final int turnovers;
  
  /// Total fouls
  final int fouls;
  
  /// Points scored in each quarter
  final List<int> quarterPoints;
  
  /// Name of the top performer
  final String topPerformerName;
  
  /// Stat line of the top performer
  final String topPerformerStatLine;

  /// Constructor
  const TeamStatsModel({
    required this.gameId,
    required this.teamId,
    required this.fieldGoalsMade,
    required this.fieldGoalsAttempted,
    required this.threePointersMade,
    required this.threePointersAttempted,
    required this.freeThrowsMade,
    required this.freeThrowsAttempted,
    required this.rebounds,
    required this.assists,
    required this.steals,
    required this.blocks,
    required this.turnovers,
    required this.fouls,
    required this.quarterPoints,
    required this.topPerformerName,
    required this.topPerformerStatLine,
  });

  /// Generate mock team stats for a game
  static Map<String, TeamStatsModel> getMockTeamStats(String gameId) {
    return {
      'home': TeamStatsModel(
        gameId: gameId,
        teamId: 'home',
        fieldGoalsMade: 32,
        fieldGoalsAttempted: 68,
        threePointersMade: 10,
        threePointersAttempted: 26,
        freeThrowsMade: 11,
        freeThrowsAttempted: 14,
        rebounds: 38,
        assists: 22,
        steals: 8,
        blocks: 5,
        turnovers: 12,
        fouls: 18,
        quarterPoints: [24, 21, 18, 22],
        topPerformerName: 'James Johnson',
        topPerformerStatLine: '28 PTS, 7 REB, 6 AST, 3 STL',
      ),
      'away': TeamStatsModel(
        gameId: gameId,
        teamId: 'away',
        fieldGoalsMade: 29,
        fieldGoalsAttempted: 72,
        threePointersMade: 8,
        threePointersAttempted: 24,
        freeThrowsMade: 14,
        freeThrowsAttempted: 18,
        rebounds: 42,
        assists: 18,
        steals: 6,
        blocks: 3,
        turnovers: 15,
        fouls: 16,
        quarterPoints: [22, 26, 16, 16],
        topPerformerName: 'Michael Smith',
        topPerformerStatLine: '24 PTS, 10 REB, 5 AST, 2 BLK',
      ),
    };
  }
}
