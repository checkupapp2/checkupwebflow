/// Model class representing a basketball court
class CourtModel {
  /// Unique identifier for the court
  final String id;
  
  /// Name of the court
  final String name;
  
  /// City where the court is located
  final String city;
  
  /// State where the court is located
  final String state;
  
  /// Number of followers for this court
  final int followers;
  
  /// URL for the court image
  final String imageUrl;
  
  /// Whether the court is verified
  final bool isVerified;
  
  /// Whether the current user is following this court
  bool isFollowing;

  /// Constructor
  CourtModel({
    required this.id,
    required this.name,
    required this.city,
    required this.state,
    required this.followers,
    required this.imageUrl,
    this.isVerified = false,
    this.isFollowing = false,
  });
}
