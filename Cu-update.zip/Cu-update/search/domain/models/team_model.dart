/// Team model for representing team data in the search results
class TeamModel {
  /// Team ID
  final String id;
  
  /// Team name
  final String name;
  
  /// Team handle/username
  final String handle;
  
  /// URL to team's logo image
  final String? logoUrl;
  
  /// Team's description or short bio
  final String? description;
  
  /// Number of members in the team
  final int membersCount;
  
  /// Number of followers
  final int followers;
  
  /// Primary sport of the team
  final String? sport;
  
  /// Team's location
  final String? location;
  
  /// Whether the current user is following this team
  final bool isFollowing;

  /// Constructor
  TeamModel({
    required this.id,
    required this.name,
    required this.handle,
    this.logoUrl,
    this.description,
    this.membersCount = 0,
    this.followers = 0,
    this.sport,
    this.location,
    this.isFollowing = false,
  });
}
