/// User model for representing user data in the search results
class UserModel {
  /// User ID
  final String id;
  
  /// User's full name
  final String name;
  
  /// User's username
  final String username;
  
  /// URL to user's profile image
  final String? profileImageUrl;
  
  /// User's bio or short description
  final String? bio;
  
  /// Number of followers
  final int followers;
  
  /// Number of following
  final int following;
  
  /// Whether the current user is following this user
  final bool isFollowing;
  
  /// Whether the user is currently active/online
  final bool isActive;
  
  /// User's profile type (player, host, trainer, etc.)
  final String? profileType;
  
  /// User's city
  final String? city;
  
  /// User's state
  final String? state;

  /// Constructor
  UserModel({
    required this.id,
    required this.name,
    required this.username,
    this.profileImageUrl,
    this.bio,
    this.followers = 0,
    this.following = 0,
    this.isFollowing = false,
    this.isActive = false,
    this.profileType,
    this.city,
    this.state,
  });
}
