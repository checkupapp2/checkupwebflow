/// League model for representing league data in the search results
class LeagueModel {
  /// League ID
  final String id;
  
  /// League name
  final String name;
  
  /// League handle/username
  final String handle;
  
  /// URL to league's logo image
  final String? logoUrl;
  
  /// League's description or short bio
  final String? description;
  
  /// Number of teams in the league
  final int teamsCount;
  
  /// Number of players in the league
  final int playersCount;
  
  /// Number of followers
  final int followers;
  
  /// Primary sport of the league
  final String sport;
  
  /// League's location
  final String? location;
  
  /// League season status (e.g., "In Season", "Off Season", "Playoffs")
  final String status;
  
  /// Whether the current user is following this league
  final bool isFollowing;
  
  /// Type of league (e.g., "Recreational", "Competitive", "Professional")
  final String? leagueType;

  /// Constructor
  LeagueModel({
    required this.id,
    required this.name,
    required this.handle,
    this.logoUrl,
    this.description,
    this.teamsCount = 0,
    this.playersCount = 0,
    this.followers = 0,
    required this.sport,
    this.location,
    required this.status,
    this.isFollowing = false,
    this.leagueType,
  });
  
  /// Generate a list of mock leagues for testing
  static List<LeagueModel> getMockLeagues() {
    return [
      LeagueModel(
        id: '1',
        name: 'Downtown Basketball League',
        handle: '@downtownleague',
        logoUrl: 'https://picsum.photos/200?random=1',
        description: 'Premier adult basketball league in the downtown area with competitive divisions for all skill levels.',
        teamsCount: 24,
        playersCount: 288,
        followers: 3450,
        sport: 'Basketball',
        location: 'Downtown, Los Angeles',
        status: 'In Season',
        isFollowing: true,
        leagueType: 'Competitive',
      ),
      LeagueModel(
        id: '2',
        name: 'College Hoops Conference',
        handle: '@collegehoops',
        logoUrl: 'https://picsum.photos/200?random=2',
        description: 'Collegiate basketball conference featuring top university teams from across the state.',
        teamsCount: 16,
        playersCount: 192,
        followers: 8720,
        sport: 'Basketball',
        location: 'Multiple Campuses',
        status: 'Registration Open',
        isFollowing: false,
        leagueType: 'School',
      ),
      LeagueModel(
        id: '3',
        name: 'Streetball Championship',
        handle: '@streetballchamps',
        logoUrl: 'https://picsum.photos/200?random=3',
        description: 'Urban streetball competition showcasing the best playground talent in the city.',
        teamsCount: 32,
        playersCount: 128,
        followers: 12500,
        sport: 'Basketball',
        location: 'City Parks',
        status: 'Playoffs',
        isFollowing: true,
        leagueType: 'Recreational',
      ),
      LeagueModel(
        id: '4',
        name: 'Pro Basketball Association',
        handle: '@probasketball',
        logoUrl: 'https://picsum.photos/200?random=4',
        description: 'Professional basketball league with the highest level of competition.',
        teamsCount: 30,
        playersCount: 450,
        followers: 25000,
        sport: 'Basketball',
        location: 'National',
        status: 'In Season',
        isFollowing: false,
        leagueType: 'Professional',
      ),
      LeagueModel(
        id: '5',
        name: 'Youth Basketball League',
        handle: '@youthhoops',
        logoUrl: 'https://picsum.photos/200?random=5',
        description: 'Development league for young players aged 8-14.',
        teamsCount: 48,
        playersCount: 576,
        followers: 2800,
        sport: 'Basketball',
        location: 'Regional',
        status: 'In Season',
        isFollowing: true,
        leagueType: 'Youth',
      ),
      LeagueModel(
        id: '6',
        name: 'Amateur Basketball Circuit',
        handle: '@amateurcircuit',
        logoUrl: 'https://picsum.photos/200?random=6',
        description: 'Weekend league for amateur adult players of all skill levels.',
        teamsCount: 20,
        playersCount: 240,
        followers: 1500,
        sport: 'Basketball',
        location: 'Metro Area',
        status: 'Upcoming',
        isFollowing: false,
        leagueType: 'Recreational',
      ),
      LeagueModel(
        id: '7',
        name: 'Corporate Basketball League',
        handle: '@corphoops',
        logoUrl: 'https://picsum.photos/200?random=7',
        description: 'Inter-company basketball competition for local businesses.',
        teamsCount: 12,
        playersCount: 144,
        followers: 950,
        sport: 'Basketball',
        location: 'Downtown Business District',
        status: 'In Season',
        isFollowing: false,
        leagueType: 'Corporate',
      ),
      LeagueModel(
        id: '8',
        name: 'Senior Basketball Association',
        handle: '@seniorhoops',
        logoUrl: 'https://picsum.photos/200?random=8',
        description: 'Basketball league for players over 40 years old.',
        teamsCount: 16,
        playersCount: 192,
        followers: 1200,
        sport: 'Basketball',
        location: 'Community Centers',
        status: 'Playoffs',
        isFollowing: true,
        leagueType: 'Senior',
      ),
      LeagueModel(
        id: '9',
        name: 'International Basketball Tour',
        handle: '@intlhoops',
        logoUrl: 'https://picsum.photos/200?random=9',
        description: 'Global basketball competition featuring teams from multiple countries.',
        teamsCount: 24,
        playersCount: 288,
        followers: 18500,
        sport: 'Basketball',
        location: 'International',
        status: 'Registration Closed',
        isFollowing: false,
        leagueType: 'Professional',
      ),
      LeagueModel(
        id: '10',
        name: 'Community Basketball League',
        handle: '@communityhoops',
        logoUrl: 'https://picsum.photos/200?random=10',
        description: 'Local basketball league focused on community engagement and development.',
        teamsCount: 18,
        playersCount: 216,
        followers: 2200,
        sport: 'Basketball',
        location: 'Community Centers',
        status: 'In Season',
        isFollowing: true,
        leagueType: 'Recreational',
      ),
      // Additional leagues with different statuses
      LeagueModel(
        id: '11',
        name: 'Spring Basketball League',
        handle: '@springhoops',
        logoUrl: 'https://picsum.photos/200?random=11',
        description: 'Seasonal basketball league starting in March with open registration.',
        teamsCount: 22,
        playersCount: 264,
        followers: 3200,
        sport: 'Basketball',
        location: 'City Parks',
        status: 'Upcoming',
        isFollowing: false,
        leagueType: 'Recreational',
      ),
      LeagueModel(
        id: '12',
        name: 'Elite Basketball Championship',
        handle: '@elitehoops',
        logoUrl: 'https://picsum.photos/200?random=12',
        description: 'High-level competitive league for elite players and teams.',
        teamsCount: 16,
        playersCount: 192,
        followers: 5600,
        sport: 'Basketball',
        location: 'Sports Complex',
        status: 'Registration Open',
        isFollowing: true,
        leagueType: 'Competitive',
      ),
      LeagueModel(
        id: '13',
        name: 'Winter Basketball Series',
        handle: '@winterhoops',
        logoUrl: 'https://picsum.photos/200?random=13',
        description: 'Indoor winter basketball league with heated facilities.',
        teamsCount: 20,
        playersCount: 240,
        followers: 2800,
        sport: 'Basketball',
        location: 'Indoor Facilities',
        status: 'Registration Closed',
        isFollowing: false,
        leagueType: 'Recreational',
      ),
    ];
  }
}
