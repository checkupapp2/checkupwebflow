/// Enum for different types of play-by-play events
enum PlayByPlayEventType {
  /// Score event (basket, free throw)
  score,
  
  /// Foul event
  foul,
  
  /// Turnover event
  turnover,
  
  /// Timeout event
  timeout,
  
  /// Substitution event
  substitution,
  
  /// Other events
  other,
}

/// Model representing a play-by-play event in a game
class PlayByPlayModel {
  /// Unique identifier for the event
  final String id;
  
  /// Game ID this event belongs to
  final String gameId;
  
  /// Quarter or period number
  final int quarter;
  
  /// Time remaining in the quarter/period
  final String timeRemaining;
  
  /// Player name who performed the action
  final String playerName;
  
  /// Description of the event
  final String description;
  
  /// Type of event
  final PlayByPlayEventType eventType;
  
  /// Whether this is a home team event
  final bool isHomeTeam;
  
  /// Score after this event (e.g., "54-48")
  final String score;
  
  /// Whether this is a quarter/period header
  final bool isQuarterHeader;

  /// Constructor
  const PlayByPlayModel({
    required this.id,
    required this.gameId,
    required this.quarter,
    required this.timeRemaining,
    required this.playerName,
    required this.description,
    required this.eventType,
    required this.isHomeTeam,
    this.score = '',
    this.isQuarterHeader = false,
  });

  /// Generate mock play-by-play events for a game
  static List<PlayByPlayModel> getMockPlayByPlayEvents(String gameId) {
    // For a real game, we'd have many more events
    return [
      // Quarter 1
      PlayByPlayModel(
        id: '1',
        gameId: gameId,
        quarter: 1,
        timeRemaining: '',
        playerName: '',
        description: '1st Quarter',
        eventType: PlayByPlayEventType.other,
        isHomeTeam: false,
        isQuarterHeader: true,
      ),
      PlayByPlayModel(
        id: '2',
        gameId: gameId,
        quarter: 1,
        timeRemaining: '12:00',
        playerName: 'Tip Off',
        description: 'Game starts with tip off',
        eventType: PlayByPlayEventType.other,
        isHomeTeam: true,
        score: '0-0',
      ),
      PlayByPlayModel(
        id: '3',
        gameId: gameId,
        quarter: 1,
        timeRemaining: '11:45',
        playerName: 'James Johnson',
        description: 'Made 3-point jump shot',
        eventType: PlayByPlayEventType.score,
        isHomeTeam: true,
        score: '3-0',
      ),
      PlayByPlayModel(
        id: '4',
        gameId: gameId,
        quarter: 1,
        timeRemaining: '11:20',
        playerName: 'Michael Smith',
        description: 'Made layup',
        eventType: PlayByPlayEventType.score,
        isHomeTeam: false,
        score: '3-2',
      ),
      PlayByPlayModel(
        id: '5',
        gameId: gameId,
        quarter: 1,
        timeRemaining: '10:58',
        playerName: 'David Williams',
        description: 'Personal foul',
        eventType: PlayByPlayEventType.foul,
        isHomeTeam: true,
        score: '3-2',
      ),
      
      // Quarter 2
      PlayByPlayModel(
        id: '6',
        gameId: gameId,
        quarter: 2,
        timeRemaining: '',
        playerName: '',
        description: '2nd Quarter',
        eventType: PlayByPlayEventType.other,
        isHomeTeam: false,
        isQuarterHeader: true,
      ),
      PlayByPlayModel(
        id: '7',
        gameId: gameId,
        quarter: 2,
        timeRemaining: '12:00',
        playerName: 'Robert Davis',
        description: 'Made jump shot',
        eventType: PlayByPlayEventType.score,
        isHomeTeam: false,
        score: '24-26',
      ),
      PlayByPlayModel(
        id: '8',
        gameId: gameId,
        quarter: 2,
        timeRemaining: '11:35',
        playerName: 'James Johnson',
        description: 'Turnover: bad pass',
        eventType: PlayByPlayEventType.turnover,
        isHomeTeam: true,
        score: '24-26',
      ),
      PlayByPlayModel(
        id: '9',
        gameId: gameId,
        quarter: 2,
        timeRemaining: '11:20',
        playerName: 'Team',
        description: 'Timeout',
        eventType: PlayByPlayEventType.timeout,
        isHomeTeam: false,
        score: '24-26',
      ),
      
      // Quarter 3
      PlayByPlayModel(
        id: '10',
        gameId: gameId,
        quarter: 3,
        timeRemaining: '',
        playerName: '',
        description: '3rd Quarter',
        eventType: PlayByPlayEventType.other,
        isHomeTeam: false,
        isQuarterHeader: true,
      ),
      PlayByPlayModel(
        id: '11',
        gameId: gameId,
        quarter: 3,
        timeRemaining: '12:00',
        playerName: 'Chris Thompson',
        description: 'Substitution: in for Michael Smith',
        eventType: PlayByPlayEventType.substitution,
        isHomeTeam: false,
        score: '45-48',
      ),
      PlayByPlayModel(
        id: '12',
        gameId: gameId,
        quarter: 3,
        timeRemaining: '11:42',
        playerName: 'James Johnson',
        description: 'Made 3-point jump shot',
        eventType: PlayByPlayEventType.score,
        isHomeTeam: true,
        score: '48-48',
      ),
      
      // Quarter 4
      PlayByPlayModel(
        id: '13',
        gameId: gameId,
        quarter: 4,
        timeRemaining: '',
        playerName: '',
        description: '4th Quarter',
        eventType: PlayByPlayEventType.other,
        isHomeTeam: false,
        isQuarterHeader: true,
      ),
      PlayByPlayModel(
        id: '14',
        gameId: gameId,
        quarter: 4,
        timeRemaining: '2:30',
        playerName: 'David Williams',
        description: 'Made free throw 1 of 2',
        eventType: PlayByPlayEventType.score,
        isHomeTeam: true,
        score: '78-74',
      ),
      PlayByPlayModel(
        id: '15',
        gameId: gameId,
        quarter: 4,
        timeRemaining: '2:30',
        playerName: 'David Williams',
        description: 'Made free throw 2 of 2',
        eventType: PlayByPlayEventType.score,
        isHomeTeam: true,
        score: '79-74',
      ),
      PlayByPlayModel(
        id: '16',
        gameId: gameId,
        quarter: 4,
        timeRemaining: '0:45',
        playerName: 'Robert Davis',
        description: 'Made 3-point jump shot',
        eventType: PlayByPlayEventType.score,
        isHomeTeam: false,
        score: '82-80',
      ),
      PlayByPlayModel(
        id: '17',
        gameId: gameId,
        quarter: 4,
        timeRemaining: '0:00',
        playerName: 'Game',
        description: 'End of game',
        eventType: PlayByPlayEventType.other,
        isHomeTeam: true,
        score: '85-80',
      ),
    ];
  }
}
