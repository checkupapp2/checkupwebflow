/// Model representing an event
class SearchEventModel {
  /// Unique identifier for the event
  final String id;

  /// Event title
  final String title;

  /// Event location
  final String location;

  /// Game type (e.g., '3v3 Tournament', 'Open Play')
  final String gameType;

  /// Event date and time in display format
  final String date;

  /// Price information (e.g., 'Free', '$15 entry fee')
  final String price;

  /// Rating out of 5
  final double rating;

  /// Number of reviews
  final int reviews;

  /// Host name
  final String hostName;

  /// Thumbnail image URL
  final String thumbnailUrl;

  /// List of image URLs for the event
  final List<String> imageUrls;

  /// Whether the user is registered for this event
  final bool isRegistered;

  /// Whether the event is private (only visible to invited users)
  final bool isPrivate;

  /// Constructor
  const SearchEventModel({
    required this.id,
    required this.title,
    required this.location,
    required this.gameType,
    required this.date,
    required this.price,
    required this.rating,
    required this.reviews,
    required this.hostName,
    required this.thumbnailUrl,
    required this.imageUrls,
    this.isRegistered = false,
    this.isPrivate = false,
  });
}
