/// Booking model class
class BookingModel {
  /// Booking ID
  final String id;
  
  /// Booking title
  final String title;
  
  /// Location
  final String location;
  
  /// Court type
  final String courtType;
  
  /// Availability
  final String availability;
  
  /// Price
  final String price;
  
  /// Rating
  final double rating;
  
  /// Number of reviews
  final int reviews;
  
  /// Thumbnail URL
  final String thumbnailUrl;
  
  /// Constructor
  const BookingModel({
    required this.id,
    required this.title,
    required this.location,
    required this.courtType,
    required this.availability,
    required this.price,
    required this.rating,
    required this.reviews,
    required this.thumbnailUrl,
  });
}
