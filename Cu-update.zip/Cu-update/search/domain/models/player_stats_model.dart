/// Model representing player statistics for a game
class PlayerStatsModel {
  /// Player ID
  final String id;
  
  /// Player name
  final String name;
  
  /// Player jersey number
  final String jerseyNumber;
  
  /// Player position
  final String position;
  
  /// Player avatar URL (optional)
  final String? avatarUrl;
  
  /// Team ID this player belongs to
  final String teamId;
  
  /// Points scored
  final int points;
  
  /// Rebounds
  final int rebounds;
  
  /// Assists
  final int assists;
  
  /// Steals
  final int steals;
  
  /// Blocks
  final int blocks;
  
  /// Turnovers
  final int turnovers;
  
  /// Field goals made
  final int fieldGoalsMade;
  
  /// Field goals attempted
  final int fieldGoalsAttempted;
  
  /// Three pointers made
  final int threePointersMade;
  
  /// Three pointers attempted
  final int threePointersAttempted;
  
  /// Free throws made
  final int freeThrowsMade;
  
  /// Free throws attempted
  final int freeThrowsAttempted;
  
  /// Minutes played
  final String minutesPlayed;
  
  /// Plus/minus rating
  final int plusMinus;
  
  /// Whether this player is a starter
  final bool isStarter;

  /// Constructor
  const PlayerStatsModel({
    required this.id,
    required this.name,
    required this.jerseyNumber,
    required this.position,
    this.avatarUrl,
    required this.teamId,
    required this.points,
    required this.rebounds,
    required this.assists,
    required this.steals,
    required this.blocks,
    required this.turnovers,
    required this.fieldGoalsMade,
    required this.fieldGoalsAttempted,
    required this.threePointersMade,
    required this.threePointersAttempted,
    required this.freeThrowsMade,
    required this.freeThrowsAttempted,
    required this.minutesPlayed,
    required this.plusMinus,
    required this.isStarter,
  });

  /// Get field goal percentage
  String get fieldGoalPercentage {
    if (fieldGoalsAttempted == 0) return '0.0';
    return (fieldGoalsMade / fieldGoalsAttempted * 100).toStringAsFixed(1);
  }

  /// Get three point percentage
  String get threePointPercentage {
    if (threePointersAttempted == 0) return '0.0';
    return (threePointersMade / threePointersAttempted * 100).toStringAsFixed(1);
  }

  /// Get free throw percentage
  String get freeThrowPercentage {
    if (freeThrowsAttempted == 0) return '0.0';
    return (freeThrowsMade / freeThrowsAttempted * 100).toStringAsFixed(1);
  }

  /// Get formatted shooting stats
  String get shootingStats {
    return '$fieldGoalsMade-$fieldGoalsAttempted FG, $threePointersMade-$threePointersAttempted 3PT, $freeThrowsMade-$freeThrowsAttempted FT';
  }

  /// Get stat line summary
  String get statLine {
    return '$points PTS, $rebounds REB, $assists AST';
  }

  /// Get detailed stat line
  String get detailedStatLine {
    return '$points PTS, $rebounds REB, $assists AST, $steals STL, $blocks BLK';
  }

  /// Generate mock player stats for a game
  static Map<String, List<PlayerStatsModel>> getMockPlayerStats(String gameId) {
    return {
      'home': [
        // Starters
        PlayerStatsModel(
          id: 'h1',
          name: 'James Johnson',
          jerseyNumber: '23',
          position: 'PG',
          teamId: 'home',
          points: 28,
          rebounds: 7,
          assists: 6,
          steals: 3,
          blocks: 0,
          turnovers: 2,
          fieldGoalsMade: 10,
          fieldGoalsAttempted: 18,
          threePointersMade: 4,
          threePointersAttempted: 7,
          freeThrowsMade: 4,
          freeThrowsAttempted: 5,
          minutesPlayed: '36:24',
          plusMinus: 12,
          isStarter: true,
        ),
        PlayerStatsModel(
          id: 'h2',
          name: 'David Williams',
          jerseyNumber: '11',
          position: 'SG',
          teamId: 'home',
          points: 16,
          rebounds: 4,
          assists: 5,
          steals: 1,
          blocks: 0,
          turnovers: 3,
          fieldGoalsMade: 6,
          fieldGoalsAttempted: 14,
          threePointersMade: 2,
          threePointersAttempted: 6,
          freeThrowsMade: 2,
          freeThrowsAttempted: 2,
          minutesPlayed: '32:10',
          plusMinus: 8,
          isStarter: true,
        ),
        PlayerStatsModel(
          id: 'h3',
          name: 'Marcus Brown',
          jerseyNumber: '34',
          position: 'SF',
          teamId: 'home',
          points: 12,
          rebounds: 8,
          assists: 2,
          steals: 0,
          blocks: 2,
          turnovers: 1,
          fieldGoalsMade: 5,
          fieldGoalsAttempted: 10,
          threePointersMade: 2,
          threePointersAttempted: 4,
          freeThrowsMade: 0,
          freeThrowsAttempted: 0,
          minutesPlayed: '28:45',
          plusMinus: 5,
          isStarter: true,
        ),
        PlayerStatsModel(
          id: 'h4',
          name: 'Anthony Davis',
          jerseyNumber: '4',
          position: 'PF',
          teamId: 'home',
          points: 14,
          rebounds: 10,
          assists: 1,
          steals: 1,
          blocks: 3,
          turnovers: 2,
          fieldGoalsMade: 6,
          fieldGoalsAttempted: 12,
          threePointersMade: 0,
          threePointersAttempted: 1,
          freeThrowsMade: 2,
          freeThrowsAttempted: 4,
          minutesPlayed: '30:18',
          plusMinus: 6,
          isStarter: true,
        ),
        PlayerStatsModel(
          id: 'h5',
          name: 'Kevin Thompson',
          jerseyNumber: '0',
          position: 'C',
          teamId: 'home',
          points: 8,
          rebounds: 6,
          assists: 2,
          steals: 0,
          blocks: 0,
          turnovers: 1,
          fieldGoalsMade: 4,
          fieldGoalsAttempted: 8,
          threePointersMade: 0,
          threePointersAttempted: 0,
          freeThrowsMade: 0,
          freeThrowsAttempted: 0,
          minutesPlayed: '24:36',
          plusMinus: -2,
          isStarter: true,
        ),
        // Bench
        PlayerStatsModel(
          id: 'h6',
          name: 'Eric Gordon',
          jerseyNumber: '10',
          position: 'SG',
          teamId: 'home',
          points: 5,
          rebounds: 2,
          assists: 4,
          steals: 1,
          blocks: 0,
          turnovers: 1,
          fieldGoalsMade: 1,
          fieldGoalsAttempted: 3,
          threePointersMade: 1,
          threePointersAttempted: 3,
          freeThrowsMade: 2,
          freeThrowsAttempted: 2,
          minutesPlayed: '18:22',
          plusMinus: 3,
          isStarter: false,
        ),
        PlayerStatsModel(
          id: 'h7',
          name: 'Tyler Johnson',
          jerseyNumber: '8',
          position: 'PG',
          teamId: 'home',
          points: 2,
          rebounds: 1,
          assists: 2,
          steals: 0,
          blocks: 0,
          turnovers: 1,
          fieldGoalsMade: 0,
          fieldGoalsAttempted: 3,
          threePointersMade: 0,
          threePointersAttempted: 2,
          freeThrowsMade: 2,
          freeThrowsAttempted: 2,
          minutesPlayed: '12:05',
          plusMinus: -3,
          isStarter: false,
        ),
      ],
      'away': [
        // Starters
        PlayerStatsModel(
          id: 'a1',
          name: 'Michael Smith',
          jerseyNumber: '3',
          position: 'PG',
          teamId: 'away',
          points: 24,
          rebounds: 10,
          assists: 5,
          steals: 1,
          blocks: 2,
          turnovers: 3,
          fieldGoalsMade: 9,
          fieldGoalsAttempted: 20,
          threePointersMade: 3,
          threePointersAttempted: 8,
          freeThrowsMade: 3,
          freeThrowsAttempted: 4,
          minutesPlayed: '38:12',
          plusMinus: -5,
          isStarter: true,
        ),
        PlayerStatsModel(
          id: 'a2',
          name: 'Robert Davis',
          jerseyNumber: '1',
          position: 'SG',
          teamId: 'away',
          points: 18,
          rebounds: 3,
          assists: 4,
          steals: 2,
          blocks: 0,
          turnovers: 2,
          fieldGoalsMade: 7,
          fieldGoalsAttempted: 15,
          threePointersMade: 4,
          threePointersAttempted: 9,
          freeThrowsMade: 0,
          freeThrowsAttempted: 0,
          minutesPlayed: '34:45',
          plusMinus: -3,
          isStarter: true,
        ),
        PlayerStatsModel(
          id: 'a3',
          name: 'Chris Thompson',
          jerseyNumber: '21',
          position: 'SF',
          teamId: 'away',
          points: 14,
          rebounds: 5,
          assists: 2,
          steals: 1,
          blocks: 0,
          turnovers: 1,
          fieldGoalsMade: 5,
          fieldGoalsAttempted: 11,
          threePointersMade: 1,
          threePointersAttempted: 3,
          freeThrowsMade: 3,
          freeThrowsAttempted: 4,
          minutesPlayed: '30:18',
          plusMinus: -2,
          isStarter: true,
        ),
        PlayerStatsModel(
          id: 'a4',
          name: 'Andrew Wilson',
          jerseyNumber: '44',
          position: 'PF',
          teamId: 'away',
          points: 10,
          rebounds: 12,
          assists: 1,
          steals: 0,
          blocks: 1,
          turnovers: 2,
          fieldGoalsMade: 4,
          fieldGoalsAttempted: 9,
          threePointersMade: 0,
          threePointersAttempted: 0,
          freeThrowsMade: 2,
          freeThrowsAttempted: 4,
          minutesPlayed: '28:54',
          plusMinus: -8,
          isStarter: true,
        ),
        PlayerStatsModel(
          id: 'a5',
          name: 'James Carter',
          jerseyNumber: '33',
          position: 'C',
          teamId: 'away',
          points: 8,
          rebounds: 8,
          assists: 2,
          steals: 0,
          blocks: 0,
          turnovers: 3,
          fieldGoalsMade: 3,
          fieldGoalsAttempted: 8,
          threePointersMade: 0,
          threePointersAttempted: 0,
          freeThrowsMade: 2,
          freeThrowsAttempted: 2,
          minutesPlayed: '26:30',
          plusMinus: -4,
          isStarter: true,
        ),
        // Bench
        PlayerStatsModel(
          id: 'a6',
          name: 'Marcus White',
          jerseyNumber: '5',
          position: 'PG',
          teamId: 'away',
          points: 4,
          rebounds: 2,
          assists: 3,
          steals: 1,
          blocks: 0,
          turnovers: 2,
          fieldGoalsMade: 1,
          fieldGoalsAttempted: 5,
          threePointersMade: 0,
          threePointersAttempted: 2,
          freeThrowsMade: 2,
          freeThrowsAttempted: 2,
          minutesPlayed: '16:24',
          plusMinus: 2,
          isStarter: false,
        ),
        PlayerStatsModel(
          id: 'a7',
          name: 'David Lee',
          jerseyNumber: '42',
          position: 'PF',
          teamId: 'away',
          points: 2,
          rebounds: 2,
          assists: 1,
          steals: 1,
          blocks: 0,
          turnovers: 1,
          fieldGoalsMade: 0,
          fieldGoalsAttempted: 4,
          threePointersMade: 0,
          threePointersAttempted: 2,
          freeThrowsMade: 2,
          freeThrowsAttempted: 2,
          minutesPlayed: '14:47',
          plusMinus: 0,
          isStarter: false,
        ),
      ],
    };
  }
}
