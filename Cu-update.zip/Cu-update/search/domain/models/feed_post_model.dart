/// Model representing a feed post for a game
class FeedPostModel {
  /// Unique identifier for the post
  final String id;
  
  /// Game ID this post is related to
  final String gameId;
  
  /// User ID who created the post
  final String userId;
  
  /// User name who created the post
  final String userName;
  
  /// User avatar URL
  final String? userAvatarUrl;
  
  /// Post content
  final String content;
  
  /// Post image URL if any
  final String? imageUrl;
  
  /// Number of likes
  final int likes;
  
  /// Number of comments
  final int comments;
  
  /// Whether the current user has liked this post
  final bool isLiked;
  
  /// Time ago text (e.g., "2h ago")
  final String timeAgo;

  /// Constructor
  const FeedPostModel({
    required this.id,
    required this.gameId,
    required this.userId,
    required this.userName,
    this.userAvatarUrl,
    required this.content,
    this.imageUrl,
    required this.likes,
    required this.comments,
    this.isLiked = false,
    required this.timeAgo,
  });

  /// Generate mock feed posts for a game
  static List<FeedPostModel> getMockFeedPosts(String gameId) {
    return [
      FeedPostModel(
        id: '1',
        gameId: gameId,
        userId: 'user1',
        userName: 'John Smith',
        userAvatarUrl: 'https://picsum.photos/100/100?random=20',
        content: 'What a game! The home team is playing with so much energy tonight! 🔥🏀',
        likes: 24,
        comments: 5,
        isLiked: true,
        timeAgo: '35m ago',
      ),
      FeedPostModel(
        id: '2',
        gameId: gameId,
        userId: 'user2',
        userName: 'Sarah Johnson',
        userAvatarUrl: 'https://picsum.photos/100/100?random=21',
        content: 'That three-pointer at the buzzer was incredible! Did anyone get that on video?',
        imageUrl: 'https://picsum.photos/400/300?random=22',
        likes: 18,
        comments: 7,
        timeAgo: '1h ago',
      ),
      FeedPostModel(
        id: '3',
        gameId: gameId,
        userId: 'user3',
        userName: 'Mike Williams',
        content: 'The refs are making some questionable calls tonight... 🤔',
        likes: 32,
        comments: 12,
        isLiked: true,
        timeAgo: '1h ago',
      ),
      FeedPostModel(
        id: '4',
        gameId: gameId,
        userId: 'user4',
        userName: 'Basketball Fan',
        userAvatarUrl: 'https://picsum.photos/100/100?random=23',
        content: 'First time at this court and the atmosphere is amazing! Great facilities and the crowd is so into it.',
        imageUrl: 'https://picsum.photos/400/300?random=24',
        likes: 15,
        comments: 3,
        timeAgo: '2h ago',
      ),
      FeedPostModel(
        id: '5',
        gameId: gameId,
        userId: 'user5',
        userName: 'Coach Dave',
        userAvatarUrl: 'https://picsum.photos/100/100?random=25',
        content: 'Both teams showing great sportsmanship tonight. This is what basketball is all about! Proud of all the players.',
        likes: 41,
        comments: 8,
        isLiked: false,
        timeAgo: '3h ago',
      ),
    ];
  }
}
