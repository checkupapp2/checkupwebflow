// lib/features/search/presentation/bloc/courts_search_cubit.dart
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// Lightweight "search" model
import 'package:check_up_app/features/search/domain/models/court_model.dart'
    as search_models;

// Firestore-backed search repo (streams cards)
import 'package:check_up_app/features/search/data/courts_search_repository.dart';

// Core repo for user-specific lists (following/created/claimed)
import 'package:check_up_app/features/courts/data/courts_repository.dart'
    as core_repo;

// Adapter (core → search)
import 'package:check_up_app/features/search/data/court_adapters.dart';

class CourtsSearchState {
  const CourtsSearchState({
    required this.query,
    required this.selectedFilter,
    this.loading = true,
    this.items = const [],
    this.error,
  });

  final String query;
  final String selectedFilter;
  final bool loading;
  final List<search_models.CourtModel> items;
  final String? error;

  CourtsSearchState copyWith({
    String? query,
    String? selectedFilter,
    bool? loading,
    List<search_models.CourtModel>? items,
    String? error, // pass null to clear
  }) {
    return CourtsSearchState(
      query: query ?? this.query,
      selectedFilter: selectedFilter ?? this.selectedFilter,
      loading: loading ?? this.loading,
      items: items ?? this.items,
      error: error,
    );
  }
}

class CourtsSearchCubit extends Cubit<CourtsSearchState> {
  CourtsSearchCubit(
    this._searchRepo,
    this._courtsRepo,
  ) : super(const CourtsSearchState(query: '', selectedFilter: 'Popular'));

  final CourtsSearchRepository _searchRepo;
  final core_repo.CourtsRepository _courtsRepo;

  StreamSubscription<List<search_models.CourtModel>>? _searchSub;

  // ---- Public API -----------------------------------------------------------

  void init({required String query, required String selectedFilter}) {
    emit(state.copyWith(
      query: query,
      selectedFilter: selectedFilter,
      loading: true,
      error: null,
    ));
    _bindFor(state.query, state.selectedFilter);
  }

  void setFilter(String filter) {
    if (filter == state.selectedFilter) return;
    emit(state.copyWith(
      selectedFilter: filter,
      loading: true,
      error: null,
    ));
    _bindFor(state.query, filter);
  }

  void setQuery(String query) {
    if (query == state.query) return;
    emit(state.copyWith(
      query: query,
      loading: true,
      error: null,
    ));
    _bindFor(query, state.selectedFilter);
  }

  @override
  Future<void> close() {
    _searchSub?.cancel();
    return super.close();
  }

  // ---- Internals ------------------------------------------------------------

  void _bindFor(String query, String filter) {
    // Cancel any previous stream
    _searchSub?.cancel();
    _searchSub = null;

    // Filters that use the Firestore "search" stream:
    const streamFilters = {'Popular', 'Nearby', 'Rentals', 'Friends'};

    if (streamFilters.contains(filter)) {
      _attachSearchStream(query: query, selectedFilter: filter);
      return;
    }

    // Filters that use the core repo (one-shot fetch + map):
    switch (filter) {
      case 'Following':
        _loadFollowing(query);
        break;
      case 'My Courts':
        _loadMyCourts(query);
        break;
      default:
        // Fallback to stream if an unknown filter sneaks in
        _attachSearchStream(query: query, selectedFilter: filter);
    }
  }

  void _attachSearchStream({
    required String query,
    required String selectedFilter,
  }) {
    _searchSub = _searchRepo
        .stream(query: query, selectedFilter: selectedFilter)
        .listen((items) {
      emit(state.copyWith(items: items, loading: false, error: null));
    }, onError: (e, st) {
      if (kDebugMode) {
        debugPrint('[CourtsSearchCubit] stream error: $e');
        debugPrint(st.toString());
      }
      emit(state.copyWith(loading: false, error: e.toString()));
    });
  }

  Future<void> _loadFollowing(String query) async {
    try {
      emit(state.copyWith(loading: true, error: null));

      final coreList = await _courtsRepo.getFollowingCourts();
      final mapped = coreList.map(toSearch).toList();
      final filtered = _applyQuery(mapped, query);

      emit(state.copyWith(items: filtered, loading: false));
    } catch (e, st) {
      if (kDebugMode) {
        debugPrint('[CourtsSearchCubit] _loadFollowing error: $e');
        debugPrint(st.toString());
      }
      emit(
          state.copyWith(loading: false, error: e.toString(), items: const []));
    }
  }

  Future<void> _loadMyCourts(String query) async {
    try {
      emit(state.copyWith(loading: true, error: null));

      final created = await _courtsRepo.getCreatedCourts();
      final claimed = await _courtsRepo.getClaimedCourts();
      final following = await _courtsRepo.getFollowingCourts();

      // Map core → search
      final createdS = created.map(toSearch);
      final claimedS = claimed.map(toSearch);
      final followingS = following.map(toSearch);

      // Merge & de-dupe by id
      final merged = <String, search_models.CourtModel>{};
      for (final c in [...createdS, ...claimedS, ...followingS]) {
        merged[c.id] = c;
      }

      final list = merged.values.toList();
      final filtered = _applyQuery(list, query);

      emit(state.copyWith(items: filtered, loading: false));
    } catch (e, st) {
      if (kDebugMode) {
        debugPrint('[CourtsSearchCubit] _loadMyCourts error: $e');
        debugPrint(st.toString());
      }
      emit(
          state.copyWith(loading: false, error: e.toString(), items: const []));
    }
  }

  List<search_models.CourtModel> _applyQuery(
    List<search_models.CourtModel> src,
    String query,
  ) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return src;
    return src.where((c) {
      return c.name.toLowerCase().contains(q) ||
          c.city.toLowerCase().contains(q) ||
          c.state.toLowerCase().contains(q);
    }).toList();
  }
}
