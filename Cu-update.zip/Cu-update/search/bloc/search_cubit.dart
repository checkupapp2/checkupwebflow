import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:check_up_app/features/search/data/search_repository.dart';
import 'package:check_up_app/features/search/domain/models/search_event_model.dart';

class SearchState {
  const SearchState({
    required this.query,
    required this.selectedFilter,
    this.loading = true,
    this.items = const [],
    this.error,
  });

  final String query;
  final String selectedFilter;
  final bool loading;
  final List<SearchEventModel> items;
  final String? error;

  SearchState copyWith({
    String? query,
    String? selectedFilter,
    bool? loading,
    List<SearchEventModel>? items,
    String? error,
  }) =>
      SearchState(
        query: query ?? this.query,
        selectedFilter: selectedFilter ?? this.selectedFilter,
        loading: loading ?? this.loading,
        items: items ?? this.items,
        error: error,
      );
}

class SearchCubit extends Cubit<SearchState> {
  SearchCubit(this._repo)
      : super(const SearchState(query: '', selectedFilter: 'Popular'));

  final SearchRepository _repo;
  StreamSubscription<List<SearchEventModel>>? _sub;

  void init({required String query, required String selectedFilter}) {
    emit(state.copyWith(
        query: query,
        selectedFilter: selectedFilter,
        loading: true,
        error: null));
    _sub?.cancel();
    _sub = _repo.stream(query: query, selectedFilter: selectedFilter).listen(
          (items) =>
              emit(state.copyWith(items: items, loading: false, error: null)),
          onError: (e) =>
              emit(state.copyWith(loading: false, error: e.toString())),
        );
  }

  void setFilter(String filter) =>
      init(query: state.query, selectedFilter: filter);
  void setQuery(String query) =>
      init(query: query, selectedFilter: state.selectedFilter);

  @override
  Future<void> close() {
    _sub?.cancel();
    return super.close();
  }
}
