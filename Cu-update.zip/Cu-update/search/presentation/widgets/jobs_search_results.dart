import 'package:flutter/material.dart';
import '../../domain/models/job_model.dart';
import '../pages/job_detail_page.dart';
import '../pages/create_job_page.dart';
// import '../../../jobs/presentation/pages/job_application_page.dart';
import 'job_list_item.dart';
import 'jobs_filter_row.dart';

/// Widget for displaying jobs search results
class JobsSearchResults extends StatefulWidget {
  /// Search query
  final String searchQuery;

  /// Constructor
  const JobsSearchResults({
    super.key,
    required this.searchQuery,
  });

  @override
  State<JobsSearchResults> createState() => _JobsSearchResultsState();
}

class _JobsSearchResultsState extends State<JobsSearchResults> {
  // Currently selected primary filter (Popular, Nearby, Friends)
  String _selectedPrimaryFilter = 'Popular';
  // Currently selected secondary filter (Referees, Trainers, etc.)
  String? _selectedSecondaryFilter;
  // Filtered jobs
  List<JobModel> _filteredJobs = [];

  @override
  void initState() {
    super.initState();
    // Initialize filtered jobs
    _applyFilters();
  }

  // Mock data for demonstration
  final List<JobModel> _mockJobs = [
    JobModel(
      id: '1',
      title: 'Basketball Referee for Weekend Tournament',
      type: 'Referee',
      posterName: 'City Basketball League',
      description:
          'Looking for experienced basketball referees for our weekend tournament. Must have 2+ years of experience.',
      location: 'Downtown Sports Center',
      payRate: '\$30/hr',
      date: DateTime(2025, 6, 20),
      imageUrl: 'https://images.unsplash.com/photo-1519861531473-9200262188bf',
    ),
    JobModel(
      id: '2',
      title: 'Videographer for High School Basketball Games',
      type: 'Videographer',
      posterName: 'Lincoln High School',
      description:
          'Need a skilled videographer to record our varsity basketball games. Equipment provided.',
      location: 'Lincoln High School Gym',
      payRate: '\$150 per game',
      date: DateTime(2025, 6, 15),
      imageUrl: 'https://images.unsplash.com/photo-1576702438167-5341af8f0c1e',
    ),
    JobModel(
      id: '3',
      title: 'Scorekeeper for Youth Basketball League',
      type: 'Scorekeeper',
      posterName: 'Youth Basketball Association',
      description:
          'Seeking reliable scorekeepers for our youth basketball league. No experience necessary, training provided.',
      location: 'Community Basketball Center',
      payRate: '\$18/hr',
      date: DateTime(2025, 6, 18),
      imageUrl: 'https://images.unsplash.com/photo-1519861531473-9200262188bf',
    ),
    JobModel(
      id: '4',
      title: 'Personal Basketball Trainer',
      type: 'Trainer',
      posterName: 'Elite Training Center',
      description:
          'Looking for certified personal trainers specializing in basketball skills development.',
      location: 'Elite Training Center',
      payRate: '\$40-50/hr',
      date: DateTime(2025, 6, 25),
      imageUrl: 'https://images.unsplash.com/photo-1574680178050-55c6a6a96e0a',
    ),
    JobModel(
      id: '5',
      title: 'Youth Basketball Coach',
      type: 'Coach',
      posterName: 'Community Center',
      description:
          'Seeking passionate basketball coach for our youth program. Must love working with kids ages 8-12.',
      location: 'Community Recreation Center',
      payRate: '\$25/hr',
      date: DateTime(2025, 7, 1),
      imageUrl: 'https://images.unsplash.com/photo-1519861531473-9200262188bf',
    ),
    JobModel(
      id: '6',
      title: 'Event Staff for Basketball Tournament',
      type: 'Event Staff',
      posterName: 'Sports Events Inc.',
      description:
          'Hiring event staff for upcoming basketball tournament. Duties include ticket taking, crowd management, and general assistance.',
      location: 'City Arena',
      payRate: '\$18/hr',
      date: DateTime(2025, 6, 28),
      imageUrl: 'https://images.unsplash.com/photo-1587614382346-4ec70e388b28',
    ),
    JobModel(
      id: '7',
      title: 'Basketball Physical Therapist',
      type: 'Medical',
      posterName: 'Basketball Recovery Center',
      description:
          'Seeking licensed physical therapist specializing in basketball injuries. Experience with basketball players required.',
      location: 'Basketball Recovery Center',
      payRate: '\$45-60/hr',
      date: DateTime(2025, 7, 5),
      imageUrl: 'https://images.unsplash.com/photo-1519861531473-9200262188bf',
    ),
    JobModel(
      id: '8',
      title: 'Basketball Referee for Adult League',
      type: 'Referee',
      posterName: 'City Basketball Association',
      description:
          'Experienced basketball referees needed for adult league games on weeknights.',
      location: 'Indoor Basketball Complex',
      payRate: '\$28/hr',
      date: DateTime(2025, 6, 22),
      imageUrl: 'https://images.unsplash.com/photo-1519861531473-9200262188bf',
    ),
    JobModel(
      id: '9',
      title: 'Basketball Photographer',
      type: 'Videographer',
      posterName: 'Basketball Media Network',
      description:
          'Looking for talented photographers to capture action shots at basketball games and tournaments.',
      location: 'Various Basketball Venues',
      payRate: '\$200 per game',
      date: DateTime(2025, 6, 30),
      imageUrl: 'https://images.unsplash.com/photo-1519861531473-9200262188bf',
    ),
    JobModel(
      id: '10',
      title: 'Basketball Tournament Scorekeeper',
      type: 'Scorekeeper',
      posterName: 'Elite Basketball Club',
      description:
          'Need scorekeepers for weekend basketball tournament. Knowledge of basketball scoring preferred.',
      location: 'Elite Basketball Courts',
      payRate: '\$20/hr',
      date: DateTime(2025, 7, 8),
      imageUrl: 'https://images.unsplash.com/photo-1519861531473-9200262188bf',
    ),
  ];

  void _applyFilters() {
    // First filter by search query
    List<JobModel> filteredByQuery = _mockJobs;
    if (widget.searchQuery.isNotEmpty) {
      filteredByQuery = _mockJobs.where((job) {
        return job.title
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            job.type.toLowerCase().contains(widget.searchQuery.toLowerCase()) ||
            job.posterName
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            (job.description != null &&
                job.description!
                    .toLowerCase()
                    .contains(widget.searchQuery.toLowerCase())) ||
            (job.location != null &&
                job.location!
                    .toLowerCase()
                    .contains(widget.searchQuery.toLowerCase()));
      }).toList();
    }

    // Apply secondary filter first (job type)
    List<JobModel> filteredBySecondary = filteredByQuery;
    if (_selectedSecondaryFilter != null && _selectedSecondaryFilter != 'All') {
      // Remove 's' from the end of the filter if it exists (e.g., "Referees" -> "Referee")
      String filterSingular = _selectedSecondaryFilter!;
      if (filterSingular.endsWith('s')) {
        filterSingular = filterSingular.substring(0, filterSingular.length - 1);
      }

      filteredBySecondary = filteredByQuery
          .where(
              (job) => job.type.toLowerCase() == filterSingular.toLowerCase())
          .toList();
    }

    // Then apply primary filter (sorting)
    switch (_selectedPrimaryFilter) {
      case 'Popular':
        _filteredJobs = List.from(filteredBySecondary);
        // Sort featured jobs to the top, then by date
        _filteredJobs.sort((a, b) {
          if (a.isFeatured && !b.isFeatured) return -1;
          if (!a.isFeatured && b.isFeatured) return 1;
          return (b.date ?? DateTime.now()).compareTo(a.date ?? DateTime.now());
        });
        break;
      case 'Nearby':
        // Mock implementation - sort by location alphabetically
        _filteredJobs = List.from(filteredBySecondary)
          ..sort((a, b) => (a.location ?? '').compareTo(b.location ?? ''));
        break;
      case 'Friends':
        // Mock implementation - show featured jobs first
        _filteredJobs = List.from(filteredBySecondary)
          ..sort((a, b) => b.isFeatured ? 1 : -1);
        break;
      default:
        _filteredJobs = filteredBySecondary;
    }
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _applyFilters();
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        _applyFilters();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => const CreateJobPage()),
          );
        },
        backgroundColor: Colors.transparent,
        elevation: 5,
        child: Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.orange.shade300, Colors.deepOrange.shade700],
            ),
          ),
          child: const Icon(
            Icons.add,
            color: Colors.white,
            size: 30,
          ),
        ),
      ),
      body: Column(
        children: [
          // Header with filter row
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: JobsFilterRow(
              selectedPrimaryFilter: _selectedPrimaryFilter,
              selectedSecondaryFilter: _selectedSecondaryFilter,
              onFilterSelected: _handleFilterSelected,
            ),
          ),
          // Job list
          Expanded(
            child: _buildJobList(),
          ),
        ],
      ),
    );
  }

  // Post Job button removed

  Widget _buildJobList() {
    if (_filteredJobs.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      itemCount: _filteredJobs.length,
      itemBuilder: (context, index) {
        final job = _filteredJobs[index];
        return JobListItem(
          job: job,
          onTap: () {
            // Navigate to job details page
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => JobDetailPage(job: job),
              ),
            );
          },
          onApplyTap: (job) {
            if (job.hasApplied) {
              // If already applied, show withdraw option
              _showWithdrawDialog(job);
            } else {
              // Navigate to application form
              // Navigate to job application - placeholder
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Job application coming soon!'),
                  backgroundColor: Color(0xFFFF6B35),
                ),
              );
              Future.value(false).then((applied) {
                if (applied == true) {
                  // Update job status after successful application
                  setState(() {
                    final updatedJob = JobModel(
                      id: job.id,
                      title: job.title,
                      type: job.type,
                      posterName: job.posterName,
                      description: job.description,
                      location: job.location,
                      payRate: job.payRate,
                      date: job.date,
                      imageUrl: job.imageUrl,
                      hasApplied: true,
                      isFeatured: job.isFeatured,
                    );

                    final index = _mockJobs.indexWhere((j) => j.id == job.id);
                    if (index != -1) {
                      _mockJobs[index] = updatedJob;
                    }

                    _applyFilters();
                  });
                }
              });
            }
          },
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.work_off,
            size: 64,
            color: Colors.grey[700],
          ),
          const SizedBox(height: 16),
          Text(
            'No jobs found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.searchQuery.isEmpty
                ? 'Start typing to search for jobs'
                : 'Try a different search term or filter',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  void _showWithdrawDialog(JobModel job) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Withdraw Application',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Text(
          'Are you sure you want to withdraw your application for ${job.title}?',
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 16,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: Colors.grey[400],
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              // Update job status
              setState(() {
                final updatedJob = JobModel(
                  id: job.id,
                  title: job.title,
                  type: job.type,
                  posterName: job.posterName,
                  description: job.description,
                  location: job.location,
                  payRate: job.payRate,
                  date: job.date,
                  imageUrl: job.imageUrl,
                  hasApplied: false,
                  isFeatured: job.isFeatured,
                );

                final index = _mockJobs.indexWhere((j) => j.id == job.id);
                if (index != -1) {
                  _mockJobs[index] = updatedJob;
                }

                _applyFilters();
              });

              // Show confirmation
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Application withdrawn for ${job.title}'),
                  backgroundColor: Colors.red[700],
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red[700],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              'Withdraw',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
