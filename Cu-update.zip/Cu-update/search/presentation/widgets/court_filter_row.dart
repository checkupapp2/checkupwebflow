import 'package:flutter/material.dart';
import 'common_filter_row.dart';

/// Widget for displaying filter options in the courts search tab
class CourtFilterRow extends StatelessWidget {
  /// Callback when a filter is selected
  final Function(String) onFilterSelected;

  /// Currently selected primary filter (Popular, Nearby, Friends)
  final String selectedPrimaryFilter;

  /// Currently selected secondary filter (My Courts, Rentals, etc.)
  final String? selectedSecondaryFilter;

  /// Constructor
  const CourtFilterRow({
    super.key,
    required this.onFilterSelected,
    required this.selectedPrimaryFilter,
    this.selectedSecondaryFilter,
  });

  @override
  Widget build(BuildContext context) {
    // Dropdown options for the first filter button
    final List<String> dropdownOptions = [
      'Popular',
      'Nearby',
      'Friends',
    ];

    // Regular filter options
    final List<String> regularFilters = [
      'My Courts',
      'Rentals',
      'Following',
    ];

    return CommonFilterRow(
      selectedFilter: selectedPrimaryFilter,
      selectedSecondaryFilter: selectedSecondaryFilter,
      onFilterSelected: onFilterSelected,
      dropdownOptions: dropdownOptions,
      regularFilters: regularFilters,
    );
  }
}
