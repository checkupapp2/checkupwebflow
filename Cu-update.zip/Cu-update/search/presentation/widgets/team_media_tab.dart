import 'package:flutter/material.dart';

/// Team media tab that displays media content in an Instagram-style 3x3 grid
class TeamMediaTab extends StatefulWidget {
  final String teamId;
  final String teamName;

  const TeamMediaTab({
    super.key,
    required this.teamId,
    required this.teamName,
  });

  @override
  State<TeamMediaTab> createState() => _TeamMediaTabState();
}

class _TeamMediaTabState extends State<TeamMediaTab> {
  // Sample media items matching league design
  late final List<Map<String, dynamic>> _mediaItems;

  @override
  void initState() {
    super.initState();
    _initializeMediaItems();
  }

  void _initializeMediaItems() {
    _mediaItems = List.generate(
      15,
      (index) => {
        'type': index % 5 == 0 ? 'video' : 'image',
        'thumbnail': 'https://picsum.photos/500/500?random=${index + 100}',
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: _mediaItems.length,
            itemBuilder: (context, index) {
              final item = _mediaItems[index];
              final bool isVideo = item['type'] == 'video';

              return GestureDetector(
                onTap: () {},
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // Thumbnail
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.grey[800],
                        image: DecorationImage(
                          image: NetworkImage(item['thumbnail']),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),

                    // Video indicator
                    if (isVideo)
                      Positioned(
                        top: 8,
                        right: 8,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.7),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Icon(
                            Icons.play_arrow,
                            color: Colors.white,
                            size: 16,
                          ),
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Center(
            child: TextButton(
              onPressed: () {},
              child: Text(
                'View All Media',
                style: TextStyle(
                  color: Colors.orange[300],
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
