import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../domain/models/score_model.dart';

/// Widget for displaying a game score card
class ScoreCard extends StatelessWidget {
  /// The score model to display
  final ScoreModel score;
  
  /// Callback when view full score button is tapped
  final VoidCallback onViewFullScore;
  
  /// Callback when share button is tapped
  final VoidCallback onShare;

  /// Constructor
  const ScoreCard({
    super.key,
    required this.score,
    required this.onViewFullScore,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    // Determine border color based on game status
    Color borderColor;
    switch (score.gameStatus.toLowerCase()) {
      case 'in progress':
        borderColor = Colors.green.shade700;
        break;
      case 'upcoming':
        borderColor = Colors.orange.shade700;
        break;
      default:
        borderColor = Colors.transparent;
    }
    
    return GestureDetector(
      onTap: onViewFullScore,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2A2A2A),
              Color(0xFF1A1A1A),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: borderColor,
            width: borderColor != Colors.transparent ? 1.5 : 0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 10,
              spreadRadius: 0,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Game status and date
            _buildGameHeader(),
            
            // Teams and scores
            _buildScoreSection(),
            
            // Divider
            Divider(
              color: Colors.grey[700],
              thickness: 1,
              height: 1,
              indent: 12,
              endIndent: 12,
            ),
            
            // Game details (court, host)
            _buildGameDetails(),
            
            // Action buttons
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildGameHeader() {
    final dateFormat = DateFormat('MMM d • h:mm a');
    final formattedDate = dateFormat.format(score.gameDateTime);
    
    Color statusColor;
    Color textColor = Colors.white;
    String statusText = score.gameStatus;
    
    switch (score.gameStatus.toLowerCase()) {
      case 'final':
        statusColor = Colors.grey.shade700;
        break;
      case 'in progress':
        statusColor = Colors.green.shade600;
        statusText = 'LIVE';
        break;
      case 'upcoming':
        statusColor = Colors.orange.shade600;
        break;
      default:
        statusColor = Colors.grey.shade700;
    }
    
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF333333),
            const Color(0xFF2A2A2A).withValues(alpha: 0),
          ],
        ),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: statusColor.withValues(alpha: 0.4),
                      blurRadius: 4,
                      spreadRadius: 0,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
                child: Text(
                  statusText,
                  style: TextStyle(
                    color: textColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 10,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                score.gameType,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          Text(
            formattedDate,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScoreSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        children: [
          // Teams section (stacked vertically)
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Home team row
                Row(
                  children: [
                    _buildTeamLogo(score.homeTeamLogoUrl, size: 32),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        score.homeTeamName,
                        style: TextStyle(
                          color: score.homeScore > score.awayScore ? Colors.orange.shade300 : Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          letterSpacing: 0.2,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Away team row
                Row(
                  children: [
                    _buildTeamLogo(score.awayTeamLogoUrl, size: 32),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        score.awayTeamName,
                        style: TextStyle(
                          color: score.awayScore > score.homeScore ? Colors.orange.shade300 : Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          letterSpacing: 0.2,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          const SizedBox(width: 16),
          
          // Score display (vertical layout)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF3A3A3A),
                  Color(0xFF252525),
                ],
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 6,
                  spreadRadius: 0,
                  offset: const Offset(0, 3),
                ),
              ],
              border: Border.all(
                color: const Color(0xFF444444),
                width: 1,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Home team score
                Text(
                  score.homeScore.toString(),
                  style: TextStyle(
                    color: score.homeScore > score.awayScore ? Colors.orange.shade300 : Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 22,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                // Divider
                Container(
                  height: 1.5,
                  width: 24,
                  color: Colors.grey[600],
                ),
                const SizedBox(height: 4),
                // Away team score
                Text(
                  score.awayScore.toString(),
                  style: TextStyle(
                    color: score.awayScore > score.homeScore ? Colors.orange.shade300 : Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 22,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamLogo(String? logoUrl, {double size = 40}) {
    if (logoUrl == null || logoUrl.isEmpty) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: const Color(0xFF333333),
          borderRadius: BorderRadius.circular(size / 4),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 4,
              spreadRadius: 0,
              offset: const Offset(0, 2),
            ),
          ],
          border: Border.all(
            color: const Color(0xFF444444),
            width: 1,
          ),
        ),
        child: Icon(
          Icons.sports_basketball,
          color: Colors.orange,
          size: size / 2,
        ),
      );
    }
    
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size / 4),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 4,
            spreadRadius: 0,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: const Color(0xFF444444),
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size / 4),
        child: Image.network(
          logoUrl,
          width: size,
          height: size,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) {
            return Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                color: const Color(0xFF333333),
                borderRadius: BorderRadius.circular(size / 4),
              ),
              child: Icon(
                Icons.sports_basketball,
                color: Colors.orange,
                size: size / 2,
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildGameDetails() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Row(
        children: [
          // League info
          Flexible(
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF333333),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.2),
                        blurRadius: 3,
                        spreadRadius: 0,
                        offset: const Offset(0, 1),
                      ),
                    ],
                    border: Border.all(
                      color: const Color(0xFF444444),
                      width: 1,
                    ),
                  ),
                  child: const Icon(
                    Icons.sports_basketball,
                    color: Colors.orange,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        score.leagueName ?? 'League',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.2,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(width: 16),
          
          // Host info
          Flexible(
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF333333),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.2),
                        blurRadius: 3,
                        spreadRadius: 0,
                        offset: const Offset(0, 1),
                      ),
                    ],
                    border: Border.all(
                      color: const Color(0xFF444444),
                      width: 1,
                    ),
                  ),
                  child: const Icon(
                    Icons.person,
                    color: Colors.lightBlue,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        score.hostName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.2,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // View Full Score Button
          Expanded(
            child: ElevatedButton(
              onPressed: onViewFullScore,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF333333),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 10),
                minimumSize: const Size(0, 36),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
                elevation: 2,
                textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
              ),
              child: const Text('View Full Score'),
            ),
          ),
          
          const SizedBox(width: 10),
          
          // Share Button
          Container(
            height: 36,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF9800),
                  Color(0xFFFF5722),
                ],
              ),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withValues(alpha: 0.3),
                  blurRadius: 4,
                  spreadRadius: 0,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: onShare,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                minimumSize: const Size(0, 36),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
                elevation: 0,
                textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.share, size: 16),
                  SizedBox(width: 6),
                  Text('Share'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
