import 'package:flutter/material.dart';
import '../../domain/models/team_model.dart';
import '../pages/team_detail_page.dart' as RegularTeamDetail;
import '../pages/team_detail_page_host.dart' as HostTeamDetail;
import 'team_list_item.dart';
import 'teams_filter_row.dart';

/// Widget for displaying teams search results
class TeamsSearchResults extends StatefulWidget {
  /// Search query
  final String searchQuery;

  /// Constructor
  const TeamsSearchResults({
    super.key,
    required this.searchQuery,
  });

  @override
  State<TeamsSearchResults> createState() => _TeamsSearchResultsState();
}

class _TeamsSearchResultsState extends State<TeamsSearchResults> {
  // Currently selected primary filter (Popular, Nearby, Friends)
  String _selectedPrimaryFilter = 'Popular';
  // Currently selected secondary filter (Following, Recreational, etc.)
  String? _selectedSecondaryFilter;
  // Filtered teams
  List<TeamModel> _filteredTeams = [];

  @override
  void initState() {
    super.initState();
    // Initialize filtered teams
    _applyFilters();
  }

  // Mock data for basketball teams only
  final List<TeamModel> _mockTeams = [
    TeamModel(
      id: '2',
      name: 'LA Lakers',
      handle: 'lakers',
      logoUrl:
          'https://content.sportslogos.net/logos/6/237/thumbs/uig7aiht8jnpl1szbi57zzlsh.gif',
      description: '17-time NBA Champions - Showtime legacy',
      membersCount: 15,
      followers: 8700,
      sport: 'Professional',
      location: 'Los Angeles, CA',
      isFollowing: true,
    ),
    TeamModel(
      id: '1',
      name: 'Chicago Bulls',
      handle: 'chicagobulls',
      logoUrl:
          'https://content.sportslogos.net/logos/6/221/thumbs/hj3gmh82w9hffmeh3fjm5h874.gif',
      description: '6-time NBA Champions with legendary history',
      membersCount: 15,
      followers: 5200,
      sport: 'Professional',
      location: 'Chicago, IL',
      isFollowing: false,
    ),
    TeamModel(
      id: '3',
      name: 'Golden State Warriors',
      handle: 'warriors',
      logoUrl:
          'https://content.sportslogos.net/logos/6/235/thumbs/23531642019.gif',
      description: 'Modern dynasty with revolutionary play style',
      membersCount: 15,
      followers: 7500,
      sport: 'Professional',
      location: 'San Francisco, CA',
      isFollowing: false,
    ),
    TeamModel(
      id: '4',
      name: 'Duke Blue Devils',
      handle: 'dukebluedevils',
      logoUrl:
          'https://content.sportslogos.net/logos/120/2439/thumbs/8885__duke_blue_devils__secondary__2015.gif',
      description: 'Prestigious college basketball program',
      membersCount: 14,
      followers: 4200,
      sport: 'School',
      location: 'Durham, NC',
      isFollowing: true,
    ),
    TeamModel(
      id: '5',
      name: 'UConn Huskies',
      handle: 'uconnhuskies',
      logoUrl:
          'https://content.sportslogos.net/logos/31/700/thumbs/70073642013.gif',
      description: 'Dominant NCAA basketball champions',
      membersCount: 13,
      followers: 3800,
      sport: 'School',
      location: 'Storrs, CT',
      isFollowing: false,
    ),
    TeamModel(
      id: '6',
      name: 'NY Liberty',
      handle: 'nyliberty',
      logoUrl:
          'https://content.sportslogos.net/logos/16/323/thumbs/32387702019.gif',
      description: 'Premier WNBA franchise in New York',
      membersCount: 12,
      followers: 2500,
      sport: 'Professional',
      location: 'New York, NY',
      isFollowing: false,
    ),
    TeamModel(
      id: '7',
      name: 'Real Madrid Baloncesto',
      handle: 'rmbaloncesto',
      logoUrl:
          'https://content.sportslogos.net/logos/130/4231/thumbs/423143342020.gif',
      description: 'Elite European basketball powerhouse',
      membersCount: 14,
      followers: 3200,
      sport: 'Competitive',
      location: 'Madrid, Spain',
      isFollowing: true,
    ),
    TeamModel(
      id: '8',
      name: 'Rucker Park Legends',
      handle: 'ruckerlegends',
      logoUrl:
          'https://content.sportslogos.net/logos/6/235/thumbs/23531642019.gif',
      description: 'Historic streetball team from Harlem',
      membersCount: 10,
      followers: 2800,
      sport: 'Pickup',
      location: 'New York, NY',
      isFollowing: false,
    ),
    TeamModel(
      id: '9',
      name: 'Miami Heat',
      handle: 'miamiheat',
      logoUrl:
          'https://content.sportslogos.net/logos/6/214/thumbs/burm5gh2wvjti3xhei5h16k8e.gif',
      description: '3-time NBA Champions with Heat Culture',
      membersCount: 15,
      followers: 5600,
      sport: 'Professional',
      location: 'Miami, FL',
      isFollowing: false,
    ),
    TeamModel(
      id: '10',
      name: 'Brooklyn Nets',
      handle: 'brooklynnets',
      logoUrl:
          'https://content.sportslogos.net/logos/6/3786/thumbs/hsuff5m3dgiv20kovde422r1f.gif',
      description: 'Modern NBA franchise with global fanbase',
      membersCount: 15,
      followers: 4900,
      sport: 'Professional',
      location: 'Brooklyn, NY',
      isFollowing: true,
    ),
    TeamModel(
      id: '11',
      name: 'LA Sparks',
      handle: 'lasparks',
      logoUrl:
          'https://content.sportslogos.net/logos/16/264/thumbs/4328__los_angeles_sparks__primary__1998.gif',
      description: 'Legendary WNBA team with championship history',
      membersCount: 12,
      followers: 2300,
      sport: 'Professional',
      location: 'Los Angeles, CA',
      isFollowing: false,
    ),
    TeamModel(
      id: '12',
      name: 'Bronx Ballers',
      handle: 'bronxballers',
      logoUrl:
          'https://content.sportslogos.net/logos/6/214/thumbs/burm5gh2wvjti3xhei5h16k8e.gif',
      description: 'Rising youth basketball program',
      membersCount: 16,
      followers: 1200,
      sport: 'Youth',
      location: 'Bronx, NY',
      isFollowing: false,
    ),
    TeamModel(
      id: '13',
      name: 'Downtown Dribblers',
      handle: 'dtdribblers',
      logoUrl:
          'https://content.sportslogos.net/logos/6/235/thumbs/23531642019.gif',
      description: 'Casual weekend basketball group',
      membersCount: 12,
      followers: 850,
      sport: 'Recreational',
      location: 'Chicago, IL',
      isFollowing: false,
    ),
    TeamModel(
      id: '14',
      name: 'Eastside Crew',
      handle: 'eastsidecrew',
      logoUrl:
          'https://content.sportslogos.net/logos/6/214/thumbs/burm5gh2wvjti3xhei5h16k8e.gif',
      description: 'Neighborhood basketball crew',
      membersCount: 8,
      followers: 620,
      sport: 'Crew',
      location: 'Philadelphia, PA',
      isFollowing: false,
    ),
    TeamModel(
      id: '15',
      name: 'City League Champs',
      handle: 'cityleaguechamps',
      logoUrl:
          'https://content.sportslogos.net/logos/6/235/thumbs/23531642019.gif',
      description: 'Reigning city league champions',
      membersCount: 14,
      followers: 1100,
      sport: 'League Team',
      location: 'Boston, MA',
      isFollowing: false,
    ),
  ];

  void _applyFilters() {
    // First filter by search query
    List<TeamModel> filteredByQuery = _mockTeams;
    if (widget.searchQuery.isNotEmpty) {
      filteredByQuery = _mockTeams.where((team) {
        return team.name
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            team.handle
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            (team.description != null &&
                team.description!
                    .toLowerCase()
                    .contains(widget.searchQuery.toLowerCase()));
      }).toList();
    }

    // Apply secondary filter first (team type)
    List<TeamModel> filteredBySecondary = filteredByQuery;
    if (_selectedSecondaryFilter != null) {
      switch (_selectedSecondaryFilter) {
        case 'Following':
          filteredBySecondary =
              filteredByQuery.where((team) => team.isFollowing).toList();
          break;
        case 'Recreational':
          filteredBySecondary = filteredByQuery
              .where(
                  (team) => team.sport != null && team.sport == 'Recreational')
              .toList();
          break;
        case 'Competitive':
          filteredBySecondary = filteredByQuery
              .where(
                  (team) => team.sport != null && team.sport == 'Competitive')
              .toList();
          break;
        case 'Professional':
          filteredBySecondary = filteredByQuery
              .where(
                  (team) => team.sport != null && team.sport == 'Professional')
              .toList();
          break;
        case 'Youth':
          filteredBySecondary = filteredByQuery
              .where((team) => team.sport != null && team.sport == 'Youth')
              .toList();
          break;
        case 'Crew':
          filteredBySecondary = filteredByQuery
              .where((team) => team.sport != null && team.sport == 'Crew')
              .toList();
          break;
        case 'League Team':
          filteredBySecondary = filteredByQuery
              .where(
                  (team) => team.sport != null && team.sport == 'League Team')
              .toList();
          break;
        case 'School':
          filteredBySecondary = filteredByQuery
              .where((team) => team.sport != null && team.sport == 'School')
              .toList();
          break;
        case 'Pickup':
          filteredBySecondary = filteredByQuery
              .where((team) => team.sport != null && team.sport == 'Pickup')
              .toList();
          break;
      }
    }

    // Then apply primary filter (sorting)
    switch (_selectedPrimaryFilter) {
      case 'Popular':
        _filteredTeams = List.from(filteredBySecondary)
          ..sort((a, b) => b.followers.compareTo(a.followers));
        break;
      case 'Nearby':
        // Mock implementation - sort alphabetically by location
        _filteredTeams = List.from(filteredBySecondary)
          ..sort((a, b) => a.location?.compareTo(b.location ?? '') ?? 0);
        break;
      case 'Friends':
        // Mock implementation - show followed teams first
        _filteredTeams = List.from(filteredBySecondary)
          ..sort((a, b) => b.isFollowing ? 1 : -1);
        break;
      default:
        _filteredTeams = filteredBySecondary;
    }
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _applyFilters();
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        _applyFilters();
      }
    });
  }

  void _handleTeamTap(TeamModel team, int index) {
    if (index == 0) {
      // First team card navigates to host team detail page
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => HostTeamDetail.HostTeamDetailPage(team: team),
        ),
      );
    } else {
      // All other team cards navigate to regular team detail page
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => RegularTeamDetail.TeamDetailPage(team: team),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          // Filter row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: TeamsFilterRow(
              selectedPrimaryFilter: _selectedPrimaryFilter,
              selectedSecondaryFilter: _selectedSecondaryFilter,
              onFilterSelected: _handleFilterSelected,
            ),
          ),
          // Team list
          Expanded(
            child: _buildTeamList(),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamList() {
    if (_filteredTeams.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      itemCount: _filteredTeams.length,
      physics: const AlwaysScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        final team = _filteredTeams[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: TeamListItem(
            team: team,
            onTap: () => _handleTeamTap(team, index),
            onFollowTap: (team) {
              // Toggle follow status
              setState(() {
                final updatedTeam = TeamModel(
                  id: team.id,
                  name: team.name,
                  handle: team.handle,
                  logoUrl: team.logoUrl,
                  description: team.description,
                  membersCount: team.membersCount,
                  followers: team.isFollowing
                      ? team.followers - 1
                      : team.followers + 1,
                  sport: team.sport,
                  location: team.location,
                  isFollowing: !team.isFollowing,
                );

                final index = _mockTeams.indexWhere((t) => t.id == team.id);
                if (index != -1) {
                  _mockTeams[index] = updatedTeam;
                }

                _applyFilters(); // Reapply filters to update the list
              });
            },
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.groups,
            size: 64,
            color: Colors.grey[700],
          ),
          const SizedBox(height: 16),
          Text(
            'No teams found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.searchQuery.isEmpty
                ? 'Start typing to search for teams'
                : 'Try a different search term',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
