import 'package:flutter/material.dart';

/// Widget for displaying a team's schedule
class TeamScheduleTab extends StatefulWidget {
  /// Team ID
  final String teamId;
  
  /// Team name
  final String teamName;

  /// Constructor
  TeamScheduleTab({
    super.key,
    required this.teamId,
    required this.teamName,
  });

  @override
  State<TeamScheduleTab> createState() => _TeamScheduleTabState();
}

class _TeamScheduleTabState extends State<TeamScheduleTab> {
  // Mock data for upcoming games
  late final List<GameModel> _upcomingGames;
  
  // Mock data for past games
  late final List<GameModel> _pastGames;
  
  @override
  void initState() {
    super.initState();
    _initializeMockData();
  }
  
  void _initializeMockData() {
    _upcomingGames = [
      GameModel(
        id: '1',
        homeTeam: widget.teamName,
        awayTeam: 'Rockets',
        homeTeamLogo: 'https://via.placeholder.com/100',
        awayTeamLogo: 'https://via.placeholder.com/100',
        date: 'Fri, Nov 12',
        time: '7:30 PM',
        location: 'Home Arena',
        ticketsAvailable: true,
      ),
      GameModel(
        id: '2',
        homeTeam: 'Lakers',
        awayTeam: widget.teamName,
        homeTeamLogo: 'https://via.placeholder.com/100',
        awayTeamLogo: 'https://via.placeholder.com/100',
        date: 'Sun, Nov 21',
        time: '3:00 PM',
        location: 'Staples Center',
        ticketsAvailable: true,
      ),
      GameModel(
        id: '3',
        homeTeam: widget.teamName,
        awayTeam: 'Celtics',
        homeTeamLogo: 'https://via.placeholder.com/100',
        awayTeamLogo: 'https://via.placeholder.com/100',
        date: 'Wed, Nov 24',
        time: '8:00 PM',
        location: 'Home Arena',
        ticketsAvailable: false,
      ),
    ];
    
    _pastGames = [
      GameModel(
        id: '4',
        homeTeam: widget.teamName,
        awayTeam: 'Nets',
        homeTeamLogo: 'https://via.placeholder.com/100',
        awayTeamLogo: 'https://via.placeholder.com/100',
        date: 'Sat, Oct 30',
        time: '7:00 PM',
        location: 'Home Arena',
        homeScore: 105,
        awayScore: 98,
        isCompleted: true,
      ),
      GameModel(
        id: '5',
        homeTeam: 'Warriors',
        awayTeam: widget.teamName,
        homeTeamLogo: 'https://via.placeholder.com/100',
        awayTeamLogo: 'https://via.placeholder.com/100',
        date: 'Thu, Oct 28',
        time: '8:30 PM',
        location: 'Chase Center',
        homeScore: 114,
        awayScore: 109,
        isCompleted: true,
      ),
      GameModel(
        id: '6',
        homeTeam: 'Bucks',
        awayTeam: widget.teamName,
        homeTeamLogo: 'https://via.placeholder.com/100',
        awayTeamLogo: 'https://via.placeholder.com/100',
        date: 'Mon, Oct 25',
        time: '7:00 PM',
        location: 'Fiserv Forum',
        homeScore: 95,
        awayScore: 103,
        isCompleted: true,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Next game highlight
        _buildNextGameCard(),
        
        const SizedBox(height: 24),
        
        // Upcoming games section
        const Text(
          'Upcoming Games',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        const SizedBox(height: 12),
        ..._upcomingGames.skip(1).map((game) => _buildGameCard(game)).toList(),
        
        const SizedBox(height: 24),
        
        // Past games section
        const Text(
          'Past Games',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        const SizedBox(height: 12),
        ..._pastGames.map((game) => _buildGameCard(game)).toList(),
      ],
    );
  }
  
  Widget _buildNextGameCard() {
    if (_upcomingGames.isEmpty) {
      return const SizedBox.shrink();
    }
    
    final nextGame = _upcomingGames.first;
    
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF9800).withValues(alpha: 0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text(
                  'NEXT GAME',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildTeamColumn(
                      teamName: nextGame.homeTeam,
                      logoUrl: nextGame.homeTeamLogo,
                      isHome: true,
                    ),
                    Column(
                      children: [
                        const Text(
                          'VS',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          nextGame.date,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text(
                          nextGame.time,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                    _buildTeamColumn(
                      teamName: nextGame.awayTeam,
                      logoUrl: nextGame.awayTeamLogo,
                      isHome: false,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Icon(
                      Icons.location_on,
                      color: Colors.white,
                      size: 16,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      nextGame.location,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          InkWell(
            onTap: () {
              // Handle get tickets action
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                ),
              ),
              child: const Center(
                child: Text(
                  'GET TICKETS',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildGameCard(GameModel game) {
    final bool isHome = game.homeTeam == widget.teamName;
    final bool isWin = game.isCompleted && 
        ((isHome && game.homeScore! > game.awayScore!) || 
        (!isHome && game.awayScore! > game.homeScore!));
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[800]!, width: 1),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  game.date,
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 12,
                  ),
                ),
                if (game.isCompleted)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: isWin ? Colors.green[700] : Colors.red[700],
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      isWin ? 'WIN' : 'LOSS',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 10,
                      ),
                    ),
                  )
                else
                  Text(
                    game.time,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 12,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.network(
                          game.homeTeamLogo,
                          width: 40,
                          height: 40,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Container(
                            width: 40,
                            height: 40,
                            color: Colors.grey[800],
                            child: const Icon(Icons.sports_basketball, color: Colors.white),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          game.homeTeam,
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: game.homeTeam == widget.teamName ? FontWeight.bold : FontWeight.normal,
                            fontSize: 14,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                if (game.isCompleted)
                  Text(
                    '${game.homeScore}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  )
                else
                  const SizedBox(width: 20),
                const SizedBox(width: 20),
                if (game.isCompleted)
                  Text(
                    '${game.awayScore}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  )
                else
                  const SizedBox(width: 20),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Text(
                          game.awayTeam,
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: game.awayTeam == widget.teamName ? FontWeight.bold : FontWeight.normal,
                            fontSize: 14,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.network(
                          game.awayTeamLogo,
                          width: 40,
                          height: 40,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Container(
                            width: 40,
                            height: 40,
                            color: Colors.grey[800],
                            child: const Icon(Icons.sports_basketball, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.location_on,
                      color: Color(0xFFFF9800),
                      size: 14,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      game.location,
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
                if (!game.isCompleted && game.ticketsAvailable)
                  TextButton(
                    onPressed: () {
                      // Handle get tickets action
                    },
                    style: TextButton.styleFrom(
                      backgroundColor: const Color(0xFFFF9800),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: const Text(
                      'Get Tickets',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildTeamColumn({
    required String teamName,
    required String logoUrl,
    required bool isHome,
  }) {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: Image.network(
            logoUrl,
            width: 60,
            height: 60,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) => Container(
              width: 60,
              height: 60,
              color: Colors.grey[800],
              child: const Icon(Icons.sports_basketball, color: Colors.white, size: 30),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          teamName,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
        Text(
          isHome ? 'HOME' : 'AWAY',
          style: TextStyle(
            color: Colors.white.withValues(alpha: 0.7),
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}

/// Model class for game items
class GameModel {
  /// Unique ID
  final String id;
  
  /// Home team name
  final String homeTeam;
  
  /// Away team name
  final String awayTeam;
  
  /// URL to home team logo
  final String homeTeamLogo;
  
  /// URL to away team logo
  final String awayTeamLogo;
  
  /// Game date (e.g., "Fri, Nov 12")
  final String date;
  
  /// Game time (e.g., "7:30 PM")
  final String time;
  
  /// Game location
  final String location;
  
  /// Home team score (if game is completed)
  final int? homeScore;
  
  /// Away team score (if game is completed)
  final int? awayScore;
  
  /// Whether the game is completed
  final bool isCompleted;
  
  /// Whether tickets are available for purchase
  final bool ticketsAvailable;

  /// Constructor
  GameModel({
    required this.id,
    required this.homeTeam,
    required this.awayTeam,
    required this.homeTeamLogo,
    required this.awayTeamLogo,
    required this.date,
    required this.time,
    required this.location,
    this.homeScore,
    this.awayScore,
    this.isCompleted = false,
    this.ticketsAvailable = false,
  });
}
