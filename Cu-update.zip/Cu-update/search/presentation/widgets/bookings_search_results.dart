import 'package:flutter/material.dart';
import 'package:check_up_app/features/bookings/presentation/pages/booking_detail_page.dart';
import 'package:check_up_app/features/bookings/domain/models/booking_model.dart'
    as domain;
import 'bookings_filter_row.dart';

/// Widget for displaying bookings search results
class BookingsSearchResults extends StatefulWidget {
  /// Search query
  final String searchQuery;

  /// Constructor
  const BookingsSearchResults({
    super.key,
    required this.searchQuery,
  });

  @override
  State<BookingsSearchResults> createState() => _BookingsSearchResultsState();
}

class _BookingsSearchResultsState extends State<BookingsSearchResults> {
  // Currently selected primary filter (Popular, Nearby, Friends)
  String _selectedPrimaryFilter = 'Popular';
  // Currently selected secondary filter (This Week, Courts, etc.)
  String? _selectedSecondaryFilter;
  // Filtered bookings
  List<BookingModel> _filteredBookings = [];

  @override
  void initState() {
    super.initState();
    // Initialize filtered bookings
    _applyFilters();
  }

  // Mock data for demonstration
  final List<BookingModel> _mockBookings = [
    // Court Space Bookings
    BookingModel(
      id: 'rucker_park',
      title: 'Rucker Park',
      location: 'Harlem, New York',
      courtType: 'Outdoor Full Court',
      availability: 'Available Today',
      price: '\$25/hour',
      rating: 4.9,
      reviews: 124,
      thumbnailUrl:
          'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      category: 'court',
      hostName: 'NYC Parks & Recreation',
      hostRating: 4.7,
      features: [
        'Full-size court',
        'Bleachers',
        'Night lighting',
        'Historical landmark'
      ],
    ),
    BookingModel(
      id: 'brooklyn_bridge',
      title: 'Brooklyn Bridge Park Courts',
      location: 'Brooklyn, New York',
      courtType: 'Outdoor Half Court',
      availability: 'Available Tomorrow',
      price: '\$20/hour',
      rating: 4.8,
      reviews: 76,
      thumbnailUrl:
          'https://images.unsplash.com/photo-1505666287802-931dc83a5dc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      category: 'court',
      hostName: 'Brooklyn Bridge Park Conservancy',
      hostRating: 4.8,
      features: [
        'Waterfront view',
        'New backboards',
        'Multiple courts',
        'Public restrooms'
      ],
    ),
    // Equipment Bookings
    BookingModel(
      id: 'premium_basketball',
      title: 'Dr. Dish Shooting Machine',
      location: 'Manhattan, New York',
      courtType: 'Equipment',
      availability: 'Available Today',
      price: '\$45/day',
      rating: 4.5,
      reviews: 52,
      thumbnailUrl:
          'https://images.unsplash.com/photo-1518401543587-56c8892a3d4f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      category: 'equipment',
      hostName: 'Elite Basketball Training',
      hostRating: 4.6,
      features: [
        'Automatic ball return',
        'Shot tracking',
        'Multiple training modes',
        'Portable'
      ],
    ),
    BookingModel(
      id: 'training_gear',
      title: 'Vertimax Training System',
      location: 'Chelsea, New York',
      courtType: 'Equipment',
      availability: 'Available This Week',
      price: '\$60/day',
      rating: 4.7,
      reviews: 89,
      thumbnailUrl:
          'https://images.unsplash.com/photo-1518310383802-640c2de311b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      category: 'equipment',
      hostName: 'Performance Edge Training',
      hostRating: 4.9,
      features: [
        'Vertical jump training',
        'Resistance bands',
        'Platform included',
        'Training guide'
      ],
    ),
    // Training Bookings
    BookingModel(
      id: 'pro_training',
      title: 'Pro Shooting Clinic',
      location: 'Washington Heights, New York',
      courtType: 'Training',
      availability: 'Available Today',
      price: '\$75/session',
      rating: 4.9,
      reviews: 112,
      thumbnailUrl:
          'https://images.unsplash.com/photo-1574680178050-55c6a6a96e0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      category: 'training',
      hostName: 'Coach Mike Johnson',
      hostRating: 5.0,
      features: [
        'Former NBA player',
        'Video analysis',
        'Personalized drills',
        '2-hour session'
      ],
    ),
    BookingModel(
      id: 'group_training',
      title: 'Youth Skills Camp',
      location: 'Queens, New York',
      courtType: 'Training',
      availability: 'Available Next Week',
      price: '\$35/person',
      rating: 4.6,
      reviews: 45,
      thumbnailUrl:
          'https://images.unsplash.com/photo-1544216717-3bbf52512659?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      category: 'training',
      hostName: 'Queens Basketball Academy',
      hostRating: 4.5,
      features: [
        'Ages 8-14',
        'All skill levels',
        'Equipment provided',
        'Small groups'
      ],
    ),
  ];

  void _applyFilters() {
    // First filter by search query
    List<BookingModel> filteredByQuery = _mockBookings;
    if (widget.searchQuery.isNotEmpty) {
      filteredByQuery = _mockBookings.where((booking) {
        return booking.title
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            booking.location
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            booking.courtType
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase());
      }).toList();
    }

    // Apply secondary filter first (booking type)
    List<BookingModel> filteredBySecondary = filteredByQuery;
    if (_selectedSecondaryFilter != null) {
      switch (_selectedSecondaryFilter) {
        case 'This Week':
          filteredBySecondary = filteredByQuery
              .where((booking) =>
                  booking.availability.toLowerCase().contains('this week') ||
                  booking.availability.toLowerCase().contains('today'))
              .toList();
          break;
        case 'Courts':
          filteredBySecondary = filteredByQuery
              .where((booking) => booking.category.toLowerCase() == 'court')
              .toList();
          break;
        case 'Equipment':
          filteredBySecondary = filteredByQuery
              .where((booking) => booking.category.toLowerCase() == 'equipment')
              .toList();
          break;
        case 'Training':
          filteredBySecondary = filteredByQuery
              .where((booking) => booking.category.toLowerCase() == 'training')
              .toList();
          break;
      }
    }

    // Then apply primary filter (sorting)
    switch (_selectedPrimaryFilter) {
      case 'Popular':
        _filteredBookings = List.from(filteredBySecondary)
          ..sort((a, b) => b.reviews.compareTo(a.reviews));
        break;
      case 'Nearby':
        // Mock implementation - sort alphabetically by location for now
        _filteredBookings = List.from(filteredBySecondary)
          ..sort((a, b) => a.location.compareTo(b.location));
        break;
      case 'Friends':
        // Mock implementation - sort by rating
        _filteredBookings = List.from(filteredBySecondary)
          ..sort((a, b) => b.rating.compareTo(a.rating));
        break;
      default:
        _filteredBookings = filteredBySecondary;
    }
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _applyFilters();
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        _applyFilters();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          // Filter row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: BookingsFilterRow(
              selectedPrimaryFilter: _selectedPrimaryFilter,
              selectedSecondaryFilter: _selectedSecondaryFilter,
              onFilterSelected: _handleFilterSelected,
            ),
          ),
          // Booking list
          Expanded(
            child: _buildBookingList(),
          ),
        ],
      ),
    );
  }

  Widget _buildBookingList() {
    if (_filteredBookings.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      itemCount: _filteredBookings.length,
      itemBuilder: (context, index) {
        final booking = _filteredBookings[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 16.0),
          child: _buildBookingCard(booking),
        );
      },
    );
  }

  Widget _buildBookingCard(BookingModel booking) {
    // Get category-specific icon
    IconData categoryIcon;
    Color categoryColor;

    switch (booking.category) {
      case 'court':
        categoryIcon = Icons.sports_basketball;
        categoryColor = Colors.orange;
        break;
      case 'equipment':
        categoryIcon = Icons.sports_handball;
        categoryColor = Colors.green;
        break;
      case 'training':
        categoryIcon = Icons.fitness_center;
        categoryColor = Colors.blue;
        break;
      default:
        categoryIcon = Icons.sports_basketball;
        categoryColor = Colors.orange;
    }

    return InkWell(
      onTap: () {
        // Navigate to booking detail page
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BookingDetailPage(
              booking: _convertToDetailBooking(booking),
              isHostView: false, // User view, not host view
            ),
          ),
        );
      },
      borderRadius: BorderRadius.circular(20),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2A2A2A),
              Color(0xFF1A1A1A),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 15,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image with overlays
            Stack(
              children: [
                // Main image
                ClipRRect(
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(20)),
                  child: Image.network(
                    booking.thumbnailUrl,
                    height: 200,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        height: 200,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.orange[800]!.withValues(alpha: 0.3),
                              Colors.orange[900]!.withValues(alpha: 0.3),
                            ],
                          ),
                        ),
                        child: Center(
                          child: Icon(categoryIcon,
                              size: 60, color: Colors.orange),
                        ),
                      );
                    },
                  ),
                ),

                // Price badge
                Positioned(
                  top: 16,
                  left: 16,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Text(
                      booking.price,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        fontFamily: 'Montserrat',
                      ),
                    ),
                  ),
                ),

                // Court type badge
                Positioned(
                  bottom: 16,
                  right: 16,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.8),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Colors.orange.withValues(alpha: 0.5),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      booking.courtType,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Montserrat',
                      ),
                    ),
                  ),
                ),
              ],
            ),

            // Content section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title only
                  Text(
                    booking.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Montserrat',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),

                  const SizedBox(height: 12),

                  // Hosted by section
                  Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text(
                            booking.hostName.isNotEmpty
                                ? booking.hostName[0].toUpperCase()
                                : 'H',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Montserrat',
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Hosted by',
                              style: TextStyle(
                                color: Colors.grey[400],
                                fontSize: 12,
                                fontFamily: 'Montserrat',
                              ),
                            ),
                            Text(
                              booking.hostName,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat',
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Location
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.orange.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.location_on,
                          color: Colors.orange,
                          size: 16,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          booking.location,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontFamily: 'Montserrat',
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Available Times Today section
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Available Times Today',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Montserrat',
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.green.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.green.withValues(alpha: 0.5),
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                color: Colors.green,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '6 slots',
                              style: const TextStyle(
                                color: Colors.green,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Time slots - using Wrap to prevent overflow
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      // First time slot (selected)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.orange.withValues(alpha: 0.3),
                              blurRadius: 6,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.access_time,
                              color: Colors.white,
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '9:00 AM',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat',
                              ),
                            ),
                            const SizedBox(width: 3),
                            Container(
                              width: 3,
                              height: 3,
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Second time slot
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.grey[800],
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.grey[600]!,
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.access_time,
                              color: Colors.grey[400],
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '11:00 AM',
                              style: TextStyle(
                                color: Colors.grey[300],
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat',
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Third time slot
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.grey[800],
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.grey[600]!,
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.access_time,
                              color: Colors.grey[400],
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '1:00 PM',
                              style: TextStyle(
                                color: Colors.grey[300],
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Book Now button
                  Container(
                    width: double.infinity,
                    height: 50,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.orange.withValues(alpha: 0.3),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => BookingDetailPage(
                                booking: _convertToDetailBooking(booking),
                                isHostView: false, // User view, not host view
                              ),
                            ),
                          );
                        },
                        borderRadius: BorderRadius.circular(25),
                        child: const Center(
                          child: Text(
                            'Book Now',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              fontFamily: 'Montserrat',
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    // Get appropriate icon based on selected filter
    IconData emptyStateIcon;
    String emptyStateMessage;

    if (_selectedSecondaryFilter == 'Courts') {
      emptyStateIcon = Icons.sports_basketball;
      emptyStateMessage = 'No court spaces available';
    } else if (_selectedSecondaryFilter == 'Equipment') {
      emptyStateIcon = Icons.sports_handball;
      emptyStateMessage = 'No equipment available';
    } else if (_selectedSecondaryFilter == 'Training') {
      emptyStateIcon = Icons.fitness_center;
      emptyStateMessage = 'No training sessions available';
    } else {
      emptyStateIcon = Icons.calendar_today;
      emptyStateMessage = 'No bookings found';
    }

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.grey[900],
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 15,
                  spreadRadius: 1,
                ),
              ],
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF2A2A2A),
                  Color(0xFF1A1A1A),
                ],
              ),
            ),
            child: Icon(
              emptyStateIcon,
              size: 64,
              color: Colors.orange,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            emptyStateMessage,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              widget.searchQuery.isEmpty
                  ? 'Try selecting a different filter or check back later'
                  : 'Try a different search term or check back later',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(25),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withValues(alpha: 0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Text(
              'Explore Other Categories',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Convert search BookingModel to domain BookingModel for detail page
domain.BookingModel _convertToDetailBooking(BookingModel searchBooking) {
  // Extract price value from the price string (e.g., "$25/hour" -> 25.0)
  double? priceValue;
  if (searchBooking.price.contains('/')) {
    final priceString =
        searchBooking.price.split('/').first.replaceAll(RegExp(r'[^\d.]'), '');
    priceValue = double.tryParse(priceString);
  }

  // Create description that includes features
  final featuresText = searchBooking.features.join(', ');
  final description =
      'Booking for ${searchBooking.courtType}\n\nFeatures: $featuresText\n\nHosted by ${searchBooking.hostName} (${searchBooking.hostRating} ★)';

  return domain.CourtBookingModel(
    id: searchBooking.id,
    title: searchBooking.title,
    description: description,
    dateTime:
        DateTime.now().add(const Duration(days: 1)), // Default to tomorrow
    location: searchBooking.location,
    bannerImageUrl: searchBooking.thumbnailUrl,
    status: domain.BookingStatus.pending,
    durationMinutes: 60, // Default duration
    numberOfPlayers: 2, // Default number
    bookingPrice: priceValue,
    equipment:
        searchBooking.category == 'equipment' ? searchBooking.features : [],
    amenities: searchBooking.category == 'court' ? searchBooking.features : [],
    hostName: searchBooking.hostName,
    hostContact:
        '${searchBooking.hostName.toLowerCase().replaceAll(' ', '.')}@example.com',
  );
}

/// Booking model class
class BookingModel {
  /// Booking ID
  final String id;

  /// Booking title
  final String title;

  /// Location
  final String location;

  /// Court type
  final String courtType;

  /// Availability
  final String availability;

  /// Price
  final String price;

  /// Rating
  final double rating;

  /// Number of reviews
  final int reviews;

  /// Thumbnail URL
  final String thumbnailUrl;

  /// Category (court, equipment, training)
  final String category;

  /// Host name
  final String hostName;

  /// Host rating
  final double hostRating;

  /// Specific features based on category
  final List<String> features;

  /// Constructor
  const BookingModel({
    required this.id,
    required this.title,
    required this.location,
    required this.courtType,
    required this.availability,
    required this.price,
    required this.rating,
    required this.reviews,
    required this.thumbnailUrl,
    required this.hostName,
    required this.hostRating,
    required this.features,
    this.category = 'court',
  });
}
