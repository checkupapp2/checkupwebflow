import 'package:flutter/material.dart';
import 'common_filter_row.dart';

/// Widget for displaying booking filters in a horizontal row
class BookingsFilterRow extends StatelessWidget {
  /// Currently selected primary filter (Popular, Nearby, Today)
  final String selectedPrimaryFilter;

  /// Currently selected secondary filter (This Week, Courts, etc.)
  final String? selectedSecondaryFilter;

  /// Callback when a filter is selected
  final Function(String) onFilterSelected;

  /// Constructor
  const BookingsFilterRow({
    super.key,
    required this.selectedPrimaryFilter,
    this.selectedSecondaryFilter,
    required this.onFilterSelected,
  });

  @override
  Widget build(BuildContext context) {
    // Dropdown options for the first filter button
    final List<String> dropdownOptions = [
      'Popular',
      'Nearby',
      'Friends',
    ];

    // Regular filter options
    final List<String> regularFilters = [
      'This Week',
      'Courts',
      'Equipment',
      'Training',
    ];

    return CommonFilterRow(
      selectedFilter: selectedPrimaryFilter,
      selectedSecondaryFilter: selectedSecondaryFilter,
      onFilterSelected: onFilterSelected,
      dropdownOptions: dropdownOptions,
      regularFilters: regularFilters,
    );
  }
}
