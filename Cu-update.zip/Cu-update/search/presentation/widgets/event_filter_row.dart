import 'package:flutter/material.dart';
import 'common_filter_row.dart';

/// Widget for displaying event filters in a horizontal row
class EventFilterRow extends StatelessWidget {
  /// Currently selected primary filter (Popular, Nearby, Friends)
  final String selectedPrimaryFilter;

  /// Currently selected secondary filter (Today, Free, etc.)
  final String? selectedSecondaryFilter;

  /// Callback when a filter is selected
  final Function(String) onFilterSelected;

  /// Constructor
  const EventFilterRow({
    super.key,
    required this.selectedPrimaryFilter,
    this.selectedSecondaryFilter,
    required this.onFilterSelected,
  });

  @override
  Widget build(BuildContext context) {
    // Dropdown options for the first filter button
    final List<String> dropdownOptions = [
      'Popular',
      'Nearby',
      'Friends',
    ];

    // Regular filter options
    final List<String> regularFilters = [
      'Today',
      'This Week',
      'Free',
      'Runs',
      'Tournaments',
      'Leagues',
      'Camp',
      'Training',
      'Special',
    ];

    return CommonFilterRow(
      selectedFilter: selectedPrimaryFilter,
      selectedSecondaryFilter: selectedSecondaryFilter,
      onFilterSelected: onFilterSelected,
      dropdownOptions: dropdownOptions,
      regularFilters: regularFilters,
    );
  }
}
