import 'package:flutter/material.dart';
import 'common_filter_row.dart';

/// Widget for displaying league filters in a horizontal row
class LeagueFilterRow extends StatelessWidget {
  /// Currently selected primary filter (Popular, Nearby, Friends)
  final String selectedPrimaryFilter;

  /// Currently selected secondary filter (Following, Recreational, etc.)
  final String? selectedSecondaryFilter;

  /// Callback when a filter is selected
  final Function(String) onFilterSelected;

  /// Constructor
  const LeagueFilterRow({
    super.key,
    required this.selectedPrimaryFilter,
    this.selectedSecondaryFilter,
    required this.onFilterSelected,
  });

  @override
  Widget build(BuildContext context) {
    // Dropdown options for the first filter button
    final List<String> dropdownOptions = [
      'Popular',
      'Nearby',
      'Friends',
    ];

    // Regular filter options
    final List<String> regularFilters = [
      'Following',
      'Recreational',
      'Competitive',
      'Professional',
      'Youth',
      'School',
      'Corporate',
      'Senior',
    ];

    return CommonFilterRow(
      selectedFilter: selectedPrimaryFilter,
      selectedSecondaryFilter: selectedSecondaryFilter,
      onFilterSelected: onFilterSelected,
      dropdownOptions: dropdownOptions,
      regularFilters: regularFilters,
    );
  }
}
