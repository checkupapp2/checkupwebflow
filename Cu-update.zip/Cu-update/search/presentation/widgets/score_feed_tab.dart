import 'package:flutter/material.dart';
import '../../domain/models/score_model.dart';
import '../../../feed/domain/models/feed_post_model.dart';
import '../../../feed/presentation/widgets/feed_post.dart';
import '../../../feed/data/feed_data_provider.dart';

/// Widget for displaying the feed tab in the score detail screen
class ScoreFeedTab extends StatefulWidget {
  /// The score model
  final ScoreModel score;

  /// Constructor
  const ScoreFeedTab({
    super.key,
    required this.score,
  });

  @override
  State<ScoreFeedTab> createState() => _ScoreFeedTabState();
}

class _ScoreFeedTabState extends State<ScoreFeedTab> {
  late List<FeedPostModel> _feedPosts;
  bool _isLoading = true;
  final TextEditingController _commentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadFeedData();
  }
  
  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  Future<void> _loadFeedData() async {
    // Simulate API call with a delay
    await Future.delayed(const Duration(milliseconds: 800));
    
    // Get actual feed data from feed data provider
    final feedDataProvider = FeedDataProvider();
    _feedPosts = feedDataProvider.getFeedPosts().take(5).toList();
    
    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return _buildLoadingState();
    }
    
    return Column(
      children: [
        // Comment input
        _buildCommentInput(),
        
        // Feed posts
        Expanded(
          child: _feedPosts.isEmpty
              ? _buildEmptyState()
              : _buildFeedList(),
        ),
      ],
    );
  }
  
  Widget _buildLoadingState() {
    return const Center(
      child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
      ),
    );
  }
  
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.forum,
            size: 64,
            color: Colors.grey[700],
          ),
          const SizedBox(height: 16),
          Text(
            'No comments yet',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Be the first to comment on this game',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildCommentInput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        border: Border(
          bottom: BorderSide(
            color: Colors.grey[800]!,
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          // User avatar
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: Colors.grey[800],
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.person,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          
          // Comment input field
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: Colors.grey[700]!,
                  width: 1,
                ),
              ),
              child: TextField(
                controller: _commentController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Add a comment...',
                  hintStyle: TextStyle(color: Colors.grey),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 10),
                ),
              ),
            ),
          ),
          
          const SizedBox(width: 12),
          
          // Post button
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF9800),
                  Color(0xFFFF5722),
                ],
              ),
              borderRadius: BorderRadius.circular(18),
            ),
            child: IconButton(
              onPressed: () {
                // Handle post comment
                if (_commentController.text.trim().isNotEmpty) {
                  debugPrint('Post comment: ${_commentController.text}');
                  _commentController.clear();
                  
                  // Show a snackbar
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Comment posted successfully'),
                      duration: Duration(seconds: 2),
                    ),
                  );
                }
              },
              icon: const Icon(
                Icons.send,
                color: Colors.white,
                size: 18,
              ),
              padding: const EdgeInsets.all(8),
              constraints: const BoxConstraints(),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildFeedList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _feedPosts.length,
      itemBuilder: (context, index) {
        final post = _feedPosts[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: FeedPost(
            post: post,
            onLikeTap: () {},
            onCommentTap: () {},
            onRepostTap: () {},
            onShareTap: () {},
          ),
        );
      },
    );
  }
  
  // Removed _buildFeedItem method - now using FeedPost widget directly
  
  // Removed _buildInteractionButton method - now using FeedPost widget directly
}
