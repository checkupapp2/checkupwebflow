import 'package:flutter/material.dart';
import '../../domain/models/league_model.dart';
import '../pages/league_detail_page.dart' as RegularLeagueDetail;
import '../pages/league_detail_page_new.dart' as HostLeagueDetail;
import 'league_list_item.dart';
import 'league_filter_row.dart';

/// Widget for displaying leagues search results
class LeaguesSearchResults extends StatefulWidget {
  /// Search query
  final String searchQuery;

  /// Constructor
  const LeaguesSearchResults({
    super.key,
    required this.searchQuery,
  });

  @override
  State<LeaguesSearchResults> createState() => _LeaguesSearchResultsState();
}

class _LeaguesSearchResultsState extends State<LeaguesSearchResults> {
  // Currently selected primary filter (Popular, Nearby, Friends)
  String _selectedPrimaryFilter = 'Popular';
  // Currently selected secondary filter (Following, Recreational, etc.)
  String? _selectedSecondaryFilter;
  // Filtered leagues
  List<LeagueModel> _filteredLeagues = [];
  // All leagues
  late List<LeagueModel> _allLeagues;

  @override
  void initState() {
    super.initState();
    // Load mock leagues
    _allLeagues = LeagueModel.getMockLeagues();
    // Initialize filtered leagues
    _applyFilters();
  }

  @override
  void didUpdateWidget(LeaguesSearchResults oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.searchQuery != widget.searchQuery) {
      _applyFilters();
    }
  }

  void _applyFilters() {
    // First filter by search query
    List<LeagueModel> filteredByQuery = _allLeagues;
    if (widget.searchQuery.isNotEmpty) {
      filteredByQuery = _allLeagues.where((league) {
        return league.name
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            league.handle
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            (league.description
                    ?.toLowerCase()
                    .contains(widget.searchQuery.toLowerCase()) ??
                false) ||
            (league.location
                    ?.toLowerCase()
                    .contains(widget.searchQuery.toLowerCase()) ??
                false);
      }).toList();
    }

    // Apply secondary filter first (league type)
    List<LeagueModel> filteredBySecondary = filteredByQuery;
    if (_selectedSecondaryFilter != null) {
      switch (_selectedSecondaryFilter) {
        case 'Following':
          filteredBySecondary =
              filteredByQuery.where((league) => league.isFollowing).toList();
          break;
        case 'Recreational':
          filteredBySecondary = filteredByQuery.where((league) {
            // First check if leagueType is set
            if (league.leagueType == 'Recreational') return true;

            // Fall back to name/description search for backward compatibility
            final description = league.description;
            return league.name.toLowerCase().contains('recreational') ||
                (description != null &&
                    description.toLowerCase().contains('recreational'));
          }).toList();
          break;
        case 'Competitive':
          filteredBySecondary = filteredByQuery.where((league) {
            // First check if leagueType is set
            if (league.leagueType == 'Competitive') return true;

            // Fall back to name/description search for backward compatibility
            final description = league.description;
            return league.name.toLowerCase().contains('competitive') ||
                (description != null &&
                    description.toLowerCase().contains('competitive'));
          }).toList();
          break;
        case 'Professional':
          filteredBySecondary = filteredByQuery.where((league) {
            // First check if leagueType is set
            if (league.leagueType == 'Professional') return true;

            // Fall back to name/description search for backward compatibility
            final description = league.description;
            return league.name.toLowerCase().contains('professional') ||
                league.name.toLowerCase().contains('pro') ||
                (description != null &&
                    description.toLowerCase().contains('professional'));
          }).toList();
          break;
        case 'Youth':
          filteredBySecondary = filteredByQuery.where((league) {
            // First check if leagueType is set
            if (league.leagueType == 'Youth') return true;

            // Fall back to name/description search for backward compatibility
            final description = league.description;
            return league.name.toLowerCase().contains('youth') ||
                (description != null &&
                    (description.toLowerCase().contains('youth') ||
                        description.toLowerCase().contains('young')));
          }).toList();
          break;
        case 'School':
          filteredBySecondary = filteredByQuery.where((league) {
            // First check if leagueType is set
            if (league.leagueType == 'School') return true;

            // Fall back to name/description search for backward compatibility
            final description = league.description;
            return league.name.toLowerCase().contains('school') ||
                league.name.toLowerCase().contains('college') ||
                (description != null &&
                    (description.toLowerCase().contains('school') ||
                        description.toLowerCase().contains('college') ||
                        description.toLowerCase().contains('university')));
          }).toList();
          break;
        case 'Corporate':
          filteredBySecondary = filteredByQuery.where((league) {
            // First check if leagueType is set
            if (league.leagueType == 'Corporate') return true;

            // Fall back to name/description search for backward compatibility
            final description = league.description;
            return league.name.toLowerCase().contains('corporate') ||
                league.name.toLowerCase().contains('company') ||
                (description != null &&
                    (description.toLowerCase().contains('corporate') ||
                        description.toLowerCase().contains('company') ||
                        description.toLowerCase().contains('business')));
          }).toList();
          break;
        case 'Senior':
          filteredBySecondary = filteredByQuery.where((league) {
            // First check if leagueType is set
            if (league.leagueType == 'Senior') return true;

            // Fall back to name/description search for backward compatibility
            final description = league.description;
            return league.name.toLowerCase().contains('senior') ||
                (description != null &&
                    (description.toLowerCase().contains('senior') ||
                        description.toLowerCase().contains('older') ||
                        description.toLowerCase().contains('veteran')));
          }).toList();
          break;
      }
    }

    // Then apply primary filter (sorting)
    switch (_selectedPrimaryFilter) {
      case 'Popular':
        // Sort by followers count
        _filteredLeagues = List.from(filteredBySecondary)
          ..sort((a, b) => b.followers.compareTo(a.followers));
        break;
      case 'Nearby':
        // Mock implementation - sort alphabetically by location
        _filteredLeagues = List.from(filteredBySecondary)
          ..sort((a, b) => (a.location ?? '').compareTo(b.location ?? ''));
        break;
      case 'Friends':
        // Mock implementation - show followed leagues first
        _filteredLeagues = List.from(filteredBySecondary)
          ..sort((a, b) => b.isFollowing ? 1 : -1);
        break;
      default:
        _filteredLeagues = filteredBySecondary;
    }

    setState(() {});
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _applyFilters();
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        _applyFilters();
      }
    });
  }

  void _handleFollowToggle(LeagueModel league) {
    // Find the league in the list and toggle its isFollowing state
    final index = _allLeagues.indexWhere((l) => l.id == league.id);
    if (index != -1) {
      setState(() {
        // Create a new league with toggled isFollowing state
        final updatedLeague = LeagueModel(
          id: league.id,
          name: league.name,
          handle: league.handle,
          logoUrl: league.logoUrl,
          description: league.description,
          teamsCount: league.teamsCount,
          playersCount: league.playersCount,
          followers: league.followers +
              (league.isFollowing ? -1 : 1), // Update followers count
          sport: league.sport,
          location: league.location,
          status: league.status,
          isFollowing: !league.isFollowing,
        );

        // Update the league in the list
        _allLeagues[index] = updatedLeague;

        // Re-apply filters to update the filtered list
        _applyFilters();
      });

      // Show a snackbar
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            league.isFollowing
                ? 'Unfollowed ${league.name}'
                : 'Following ${league.name}',
            style: const TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.grey[800],
          duration: const Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          margin: const EdgeInsets.all(10),
        ),
      );
    }
  }

  void _handleLeagueTap(LeagueModel league, int index) {
    // Navigate to league detail page
    debugPrint('League tapped: ${league.id} at index: $index');

    // First card (index 0) goes to host league detail page
    // All other cards go to regular league detail page
    if (index == 0) {
      // Navigate to host league detail page (with team chat icon and manage button)
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => HostLeagueDetail.LeagueDetailPage(
            league: league,
            isHostView: true,
          ),
        ),
      );
    } else {
      // Navigate to regular/attendee league detail page (no team chat icon, no settings button)
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => RegularLeagueDetail.LeagueDetailPage(
            league: league,
            isHostView: false,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          // Filter row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: LeagueFilterRow(
              selectedPrimaryFilter: _selectedPrimaryFilter,
              selectedSecondaryFilter: _selectedSecondaryFilter,
              onFilterSelected: _handleFilterSelected,
            ),
          ),
          // League list
          Expanded(
            child: _buildLeagueList(),
          ),
        ],
      ),
    );
  }

  Widget _buildLeagueList() {
    if (_filteredLeagues.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
      itemCount: _filteredLeagues.length,
      itemBuilder: (context, index) {
        final league = _filteredLeagues[index];
        return LeagueListItem(
          league: league,
          onTap: () => _handleLeagueTap(league, index),
          onFollowTap: _handleFollowToggle,
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.sports_basketball,
            size: 64,
            color: Colors.grey[700],
          ),
          const SizedBox(height: 16),
          Text(
            'No leagues found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.searchQuery.isEmpty
                ? 'Try selecting a different filter'
                : 'Try a different search term',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
