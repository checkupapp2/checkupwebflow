import 'package:flutter/material.dart';
import 'common_filter_row.dart';

/// Widget for displaying score filters in a horizontal row
class ScoreFilterRow extends StatelessWidget {
  /// Currently selected primary filter (Popular, Nearby, Friends)
  final String selectedPrimaryFilter;

  /// Currently selected secondary filter (All, Recent, etc.)
  final String? selectedSecondaryFilter;

  /// Callback when a filter is selected
  final Function(String) onFilterSelected;

  /// Constructor
  const ScoreFilterRow({
    super.key,
    required this.selectedPrimaryFilter,
    this.selectedSecondaryFilter,
    required this.onFilterSelected,
  });

  @override
  Widget build(BuildContext context) {
    // Dropdown options for the first filter button
    final List<String> dropdownOptions = [
      'Popular',
      'Nearby',
      'Friends',
    ];

    // Regular filter options
    final List<String> regularFilters = [
      'All',
      'Recent',
      'Live',
      'Upcoming',
    ];

    return CommonFilterRow(
      selectedFilter: selectedPrimaryFilter,
      selectedSecondaryFilter: selectedSecondaryFilter,
      onFilterSelected: onFilterSelected,
      dropdownOptions: dropdownOptions,
      regularFilters: regularFilters,
    );
  }
}
