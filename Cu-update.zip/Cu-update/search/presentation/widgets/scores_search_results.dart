import 'package:flutter/material.dart';
import '../../domain/models/score_model.dart';
import '../pages/score_detail_screen.dart';
import 'score_filter_row.dart';
import 'score_card.dart';
import '../../../feed/presentation/widgets/share_modal.dart';

/// Widget for displaying scores search results
class ScoresSearchResults extends StatefulWidget {
  /// Search query
  final String searchQuery;

  /// Constructor
  const ScoresSearchResults({
    super.key,
    required this.searchQuery,
  });

  @override
  State<ScoresSearchResults> createState() => _ScoresSearchResultsState();
}

class _ScoresSearchResultsState extends State<ScoresSearchResults> {
  // Currently selected primary filter (Popular, Nearby, Friends)
  String _selectedPrimaryFilter = 'Popular';
  // Currently selected secondary filter (All, Recent, etc.)
  String? _selectedSecondaryFilter;
  // Filtered scores
  List<ScoreModel> _filteredScores = [];
  // All scores
  late List<ScoreModel> _allScores;

  @override
  void initState() {
    super.initState();
    // Load mock scores
    _allScores = ScoreModel.getMockScores();
    // Initialize filtered scores
    _applyFilters();
  }

  @override
  void didUpdateWidget(ScoresSearchResults oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.searchQuery != widget.searchQuery) {
      _applyFilters();
    }
  }

  void _applyFilters() {
    // First filter by search query
    List<ScoreModel> filteredByQuery = _allScores;
    if (widget.searchQuery.isNotEmpty) {
      filteredByQuery = _allScores.where((score) {
        return score.homeTeamName
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            score.awayTeamName
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            score.courtName
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            score.courtLocation
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            score.hostName
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            (score.leagueName
                    ?.toLowerCase()
                    .contains(widget.searchQuery.toLowerCase()) ??
                false);
      }).toList();
    }

    // Apply secondary filter first (score type)
    List<ScoreModel> filteredBySecondary = filteredByQuery;
    if (_selectedSecondaryFilter != null) {
      switch (_selectedSecondaryFilter) {
        case 'All':
          filteredBySecondary = filteredByQuery;
          break;
        case 'Recent':
          filteredBySecondary = filteredByQuery
              .where((score) =>
                  score.gameStatus.toLowerCase() == 'final' &&
                  score.gameDateTime.isAfter(
                      DateTime.now().subtract(const Duration(days: 7))))
              .toList();
          break;
        case 'Live':
          filteredBySecondary = filteredByQuery
              .where((score) => score.gameStatus.toLowerCase() == 'in progress')
              .toList();
          break;
        case 'Upcoming':
          filteredBySecondary = filteredByQuery
              .where((score) => score.gameStatus.toLowerCase() == 'upcoming')
              .toList();
          break;
      }
    }

    // Then apply primary filter (sorting)
    switch (_selectedPrimaryFilter) {
      case 'Popular':
        // Sort by most recent games first
        _filteredScores = List.from(filteredBySecondary)
          ..sort((a, b) => b.gameDateTime.compareTo(a.gameDateTime));
        break;
      case 'Nearby':
        // Mock implementation - sort alphabetically by host names
        _filteredScores = List.from(filteredBySecondary)
          ..sort((a, b) => a.hostName.compareTo(b.hostName));
        break;
      case 'Friends':
        // Mock implementation - sort by league name
        _filteredScores = List.from(filteredBySecondary)
          ..sort((a, b) => (a.leagueName ?? '').compareTo(b.leagueName ?? ''));
        break;
      default:
        _filteredScores = filteredBySecondary;
    }

    setState(() {});
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _applyFilters();
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        _applyFilters();
      }
    });
  }

  void _handleViewFullScore(ScoreModel score) {
    // Navigate to score detail screen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ScoreDetailScreen(score: score),
      ),
    );
  }

  void _handleShareScore(ScoreModel score) {
    // Share score using ShareModal
    ShareModal.show(
      context: context,
      postId: score.id,
      postContent:
          '${score.homeTeamName} vs ${score.awayTeamName} - ${score.homeScore}-${score.awayScore}',
      shareUrl: 'https://checkup.app/scores/${score.id}',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          // Filter row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: ScoreFilterRow(
              selectedPrimaryFilter: _selectedPrimaryFilter,
              selectedSecondaryFilter: _selectedSecondaryFilter,
              onFilterSelected: _handleFilterSelected,
            ),
          ),
          // Score list
          Expanded(
            child: _buildScoreList(),
          ),
        ],
      ),
    );
  }

  Widget _buildScoreList() {
    if (_filteredScores.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      itemCount: _filteredScores.length,
      itemBuilder: (context, index) {
        final score = _filteredScores[index];
        return ScoreCard(
          score: score,
          onViewFullScore: () => _handleViewFullScore(score),
          onShare: () => _handleShareScore(score),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.sports_basketball,
            size: 64,
            color: Colors.grey[700],
          ),
          const SizedBox(height: 16),
          Text(
            'No scores found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.searchQuery.isEmpty
                ? 'Try selecting a different filter'
                : 'Try a different search term',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
