import 'package:flutter/material.dart';

/// A common filter row widget that can be used across all search tabs
/// with a dropdown for the first filter option
class CommonFilterRow extends StatefulWidget {
  /// Callback when a filter is selected
  final Function(String) onFilterSelected;

  /// Currently selected primary filter (from dropdown)
  final String selectedFilter;

  /// Currently selected secondary filter (from chips)
  final String? selectedSecondaryFilter;

  /// List of dropdown options for the first filter button
  final List<String> dropdownOptions;

  /// List of regular filter options
  final List<String> regularFilters;

  /// Constructor
  const CommonFilterRow({
    super.key,
    required this.onFilterSelected,
    required this.selectedFilter,
    this.selectedSecondaryFilter,
    required this.dropdownOptions,
    required this.regularFilters,
  });

  @override
  State<CommonFilterRow> createState() => _CommonFilterRowState();
}

class _CommonFilterRowState extends State<CommonFilterRow> {
  // Track if dropdown is open
  bool _isDropdownOpen = false;

  // Overlay entry for dropdown
  OverlayEntry? _overlayEntry;

  // Global key for dropdown button position
  final GlobalKey _dropdownKey = GlobalKey();

  @override
  void dispose() {
    // Remove overlay if it exists
    _removeDropdownOverlay();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      margin: const EdgeInsets.only(top: 20, bottom: 16),
      child: Row(
        children: [
          // Dropdown filter button
          _buildDropdownFilterButton(),
          const SizedBox(width: 10),
          // Regular filter buttons
          Expanded(
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: widget.regularFilters.length,
              padding: EdgeInsets.zero,
              itemBuilder: (context, index) {
                final filter = widget.regularFilters[index];
                final isSelected = filter == widget.selectedSecondaryFilter;

                return Padding(
                  padding: EdgeInsets.only(
                    left: index == 0 ? 0 : 10,
                    right: index == widget.regularFilters.length - 1 ? 0 : 10,
                  ),
                  child: _buildFilterChip(filter, isSelected),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownFilterButton() {
    // Check if any dropdown option is selected
    final isDropdownOptionSelected =
        widget.dropdownOptions.contains(widget.selectedFilter);

    return GestureDetector(
      key: _dropdownKey,
      onTap: _toggleDropdown,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          gradient: isDropdownOptionSelected
              ? const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: isDropdownOptionSelected ? null : Colors.grey[900],
          borderRadius: BorderRadius.circular(20),
          boxShadow: isDropdownOptionSelected
              ? [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              isDropdownOptionSelected
                  ? widget.selectedFilter
                  : widget.dropdownOptions[0],
              style: TextStyle(
                color:
                    isDropdownOptionSelected ? Colors.white : Colors.grey[400],
                fontWeight: isDropdownOptionSelected
                    ? FontWeight.w600
                    : FontWeight.normal,
                fontSize: 14,
              ),
            ),
            const SizedBox(width: 4),
            Icon(
              _isDropdownOpen ? Icons.arrow_drop_up : Icons.arrow_drop_down,
              color: isDropdownOptionSelected ? Colors.white : Colors.grey[400],
              size: 18,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String filter, bool isSelected) {
    return GestureDetector(
      onTap: () => widget.onFilterSelected(filter),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        decoration: BoxDecoration(
          gradient: isSelected
              ? const LinearGradient(
                  colors: [Color(0xFF1A1A1A), Color(0xFF333333)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: isSelected ? null : Colors.grey[900],
          borderRadius: BorderRadius.circular(20),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Text(
          filter,
          style: TextStyle(
            color: isSelected ? const Color(0xFFFF9800) : Colors.grey[400],
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  void _toggleDropdown() {
    setState(() {
      _isDropdownOpen = !_isDropdownOpen;
    });

    if (_isDropdownOpen) {
      _showDropdownOverlay();
    } else {
      _removeDropdownOverlay();
    }
  }

  void _showDropdownOverlay() {
    // Remove existing overlay if any
    _removeDropdownOverlay();

    // Create overlay entry
    _overlayEntry = _createOverlayEntry();

    // Add overlay to the context
    Overlay.of(context).insert(_overlayEntry!);
  }

  void _removeDropdownOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  OverlayEntry _createOverlayEntry() {
    // Get render box from global key
    final RenderBox renderBox =
        _dropdownKey.currentContext!.findRenderObject() as RenderBox;
    final size = renderBox.size;
    final position = renderBox.localToGlobal(Offset.zero);

    return OverlayEntry(
      builder: (context) => Positioned(
        left: position.dx,
        top: position.dy + size.height + 5,
        width: size.width,
        child: Material(
          color: Colors.transparent,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: widget.dropdownOptions.map((option) {
                final isSelected = option == widget.selectedFilter;
                return InkWell(
                  onTap: () {
                    widget.onFilterSelected(option);
                    _toggleDropdown();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 12, horizontal: 16),
                    decoration: BoxDecoration(
                      gradient: isSelected
                          ? const LinearGradient(
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            )
                          : null,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      option,
                      style: TextStyle(
                        color: isSelected ? Colors.white : Colors.grey[300],
                        fontWeight:
                            isSelected ? FontWeight.w600 : FontWeight.normal,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
    );
  }
}
