import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/team_model.dart';

/// A modern and beautiful team list item widget for the search results
class TeamListItem extends StatelessWidget {
  /// The team data to display
  final TeamModel team;
  
  /// Callback when the team item is tapped
  final VoidCallback? onTap;
  
  /// Callback when the follow button is tapped
  final Function(TeamModel)? onFollowTap;

  /// Constructor
  const TeamListItem({
    super.key,
    required this.team,
    this.onTap,
    this.onFollowTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.grey[900]!,
              Colors.grey[850]!,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
          border: Border.all(
            color: const Color(0xFFFF9800).withValues(alpha: 0.2),
            width: 1,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Top row with logo, name, handle and follow button
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Team Logo
                  _buildTeamLogo(),
                  const SizedBox(width: 12),
                  
                  // Team Info
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildTeamName(),
                        const SizedBox(height: 2),
                        _buildTeamHandle(),
                      ],
                    ),
                  ),
                  
                  // Follow Button
                  _buildFollowButton(),
                ],
              ),
              
              // Description and stats
              if (team.description != null && team.description!.isNotEmpty) ...[  
                const SizedBox(height: 8),
                _buildDescription(),
              ],
              const SizedBox(height: 8),
              _buildStats(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTeamLogo() {
    return Hero(
      tag: 'team_${team.id}',
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF9800).withValues(alpha: 0.4),
              blurRadius: 10,
              spreadRadius: 2,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        padding: const EdgeInsets.all(2), // Border width
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: team.logoUrl != null
              ? Image.network(
                  team.logoUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => _buildLogoPlaceholder(),
                )
              : _buildLogoPlaceholder(),
        ),
      ),
    );
  }

  Widget _buildLogoPlaceholder() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[800],
        gradient: LinearGradient(
          colors: [
            Colors.grey[800]!,
            Colors.grey[900]!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: Icon(
          Icons.sports_basketball,
          color: const Color(0xFFFF9800),
          size: 30,
        ),
      ),
    );
  }

  Widget _buildTeamName() {
    return Text(
      team.name,
      style: const TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.bold,
        fontSize: 18,
        letterSpacing: 0.2,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildTeamHandle() {
    return Row(
      children: [
        Flexible(
          child: Text(
            '@${team.handle}',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        if (team.sport != null) ...[  
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFFFF9800).withValues(alpha: 0.7),
                  const Color(0xFFFF5722).withValues(alpha: 0.7),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.sports_basketball,
                  color: Colors.white,
                  size: 8,
                ),
                const SizedBox(width: 3),
                Text(
                  team.sport!,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildDescription() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 2),
      child: Text(
        team.description!,
        style: TextStyle(
          color: Colors.grey[300],
          fontSize: 12,
          height: 1.2,
          fontStyle: FontStyle.italic,
        ),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  Widget _buildStats() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 4),
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Wrap(
        spacing: 12,
        runSpacing: 8,
        alignment: WrapAlignment.start,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          // Players stat
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.sports_basketball,
                size: 14,
                color: const Color(0xFFFF9800),
              ),
              const SizedBox(width: 4),
              Text(
                '${team.membersCount} players',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          
          // Fans stat
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.people,
                size: 14,
                color: const Color(0xFFFF9800),
              ),
              const SizedBox(width: 4),
              Text(
                '${team.followers} fans',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          
          // Location (if available)
          if (team.location != null)
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.location_on,
                  size: 14,
                  color: const Color(0xFFFF9800),
                ),
                const SizedBox(width: 4),
                Text(
                  team.location!,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildFollowButton() {
    final isFollowing = team.isFollowing;
    
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        if (onFollowTap != null) {
          onFollowTap!(team);
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: isFollowing
            ? const EdgeInsets.symmetric(horizontal: 10, vertical: 6)
            : const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          gradient: isFollowing 
              ? null 
              : const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          color: isFollowing ? Colors.transparent : null,
          borderRadius: BorderRadius.circular(16),
          border: isFollowing 
              ? Border.all(color: const Color(0xFFFF9800), width: 1.5) 
              : null,
          boxShadow: isFollowing 
              ? null 
              : [
                  BoxShadow(
                    color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isFollowing ? Icons.check : Icons.add,
              color: isFollowing ? const Color(0xFFFF9800) : Colors.white,
              size: 12,
            ),
            const SizedBox(width: 3),
            Text(
              isFollowing ? 'Following' : 'Follow',
              style: TextStyle(
                color: isFollowing ? const Color(0xFFFF9800) : Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
