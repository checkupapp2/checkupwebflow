import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../domain/models/score_model.dart';
import 'espn_score_card.dart';

/// Widget for displaying the header of the score detail screen
class ScoreDetailHeader extends StatelessWidget {
  /// The score model to display
  final ScoreModel score;

  /// Constructor
  const ScoreDetailHeader({
    super.key,
    required this.score,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: EspnScoreCard(
        homeTeamName: score.homeTeamName,
        awayTeamName: score.awayTeamName,
        homeScore: score.homeScore,
        awayScore: score.awayScore,
        gameStatus: score.gameStatus,
        gameDateTime: score.gameDateTime,
        courtName: score.courtName,
        courtLocation: score.courtLocation,
        hostName: score.hostName,
        leagueName: score.leagueName,
        homeTeamLogoUrl: score.homeTeamLogoUrl,
        awayTeamLogoUrl: score.awayTeamLogoUrl,
        onViewFullScore: null,
        onShare: null,
      ),
    );
  }
  
  Widget _buildDateTime() {
    final dateFormat = DateFormat('EEEE, MMMM d, yyyy • h:mm a');
    final formattedDate = dateFormat.format(score.gameDateTime);
    
    return Text(
      formattedDate,
      style: TextStyle(
        color: Colors.grey[400],
        fontSize: 14,
        fontWeight: FontWeight.w500,
      ),
    );
  }
  
  Widget _buildTeamsAndScores() {
    // Check if the game is live
    final bool isLive = score.gameStatus.toLowerCase() == 'in progress';
    
    return Column(
      children: [
        // Clock (time and period) for live games only
        if (isLive)
          Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.green.shade800,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 4,
                  spreadRadius: 0,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.timer,
                  color: Colors.white,
                  size: 14,
                ),
                const SizedBox(width: 4),
                Text(
                  '1st QTR • 12:00',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Home team
            Expanded(
              child: Column(
                children: [
                  _buildTeamLogo(score.homeTeamLogoUrl, size: 60),
                  const SizedBox(height: 8),
                  Text(
                    score.homeTeamName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            
            // Score display
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF3A3A3A),
                    Color(0xFF252525),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: const Offset(0, 3),
                  ),
                ],
                border: Border.all(
                  color: const Color(0xFF444444),
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    score.homeScore.toString(),
                    style: TextStyle(
                      color: score.homeScore > score.awayScore ? Colors.orange : Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 28,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    height: 30,
                    width: 1.5,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 10),
                  Text(
                    score.awayScore.toString(),
                    style: TextStyle(
                      color: score.awayScore > score.homeScore ? Colors.orange : Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 28,
                    ),
                  ),
                ],
              ),
            ),
            
            // Away team
            Expanded(
              child: Column(
                children: [
                  _buildTeamLogo(score.awayTeamLogoUrl, size: 60),
                  const SizedBox(height: 8),
                  Text(
                    score.awayTeamName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
  
  Widget _buildLocationAndHostInfo() {
    return Row(
      children: [
        // Court info
        Expanded(
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF333333),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: const Color(0xFF444444),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.location_on,
                  color: Colors.orange,
                  size: 18,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      score.courtName,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      score.courtLocation,
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 12,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Host info
        Expanded(
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF333333),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: const Color(0xFF444444),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.person,
                  color: Colors.lightBlue,
                  size: 18,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Hosted by',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                    ),
                    Text(
                      score.hostName,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildTeamLogo(String? logoUrl, {double size = 40}) {
    if (logoUrl == null || logoUrl.isEmpty) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: const Color(0xFF333333),
          borderRadius: BorderRadius.circular(size / 4),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 4,
              spreadRadius: 0,
              offset: const Offset(0, 2),
            ),
          ],
          border: Border.all(
            color: const Color(0xFF444444),
            width: 1,
          ),
        ),
        child: Icon(
          Icons.sports_basketball,
          color: Colors.orange,
          size: size / 2,
        ),
      );
    }
    
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size / 4),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 4,
            spreadRadius: 0,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: const Color(0xFF444444),
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size / 4),
        child: Image.network(
          logoUrl,
          width: size,
          height: size,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) {
            return Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                color: const Color(0xFF333333),
                borderRadius: BorderRadius.circular(size / 4),
              ),
              child: Icon(
                Icons.sports_basketball,
                color: Colors.orange,
                size: size / 2,
              ),
            );
          },
        ),
      ),
    );
  }
}
