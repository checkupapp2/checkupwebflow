import 'package:flutter/material.dart';
import '../../domain/models/group_model.dart';
import 'group_list_item.dart';
import 'groups_filter_row.dart';
import '../../../../features/groups/presentation/pages/group_detail_page.dart';

/// Widget for displaying groups search results
class GroupsSearchResults extends StatefulWidget {
  /// Search query
  final String searchQuery;

  /// Constructor
  const GroupsSearchResults({
    super.key,
    required this.searchQuery,
  });

  @override
  State<GroupsSearchResults> createState() => _GroupsSearchResultsState();
}

class _GroupsSearchResultsState extends State<GroupsSearchResults> {
  // Currently selected primary filter (Popular, Nearby, Friends)
  String _selectedPrimaryFilter = 'Popular';
  // Currently selected secondary filter (My Groups, Sports, etc.)
  String? _selectedSecondaryFilter;
  // Filtered groups
  List<GroupModel> _filteredGroups = [];

  @override
  void initState() {
    super.initState();
    // Initialize filtered groups
    _applyFilters();
  }

  // Mock data for demonstration
  final List<GroupModel> _mockGroups = [
    GroupModel(
      id: '1',
      name: 'Basketball Enthusiasts',
      imageUrl: 'https://images.unsplash.com/photo-1546519638-68e109acd618',
      description: 'Group for basketball players and fans',
      memberCount: 1250,
      isMember: false,
    ),
    GroupModel(
      id: '2',
      name: 'Tennis Club NYC',
      imageUrl: 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c1',
      description: 'Tennis players in New York City',
      memberCount: 876,
      isMember: true,
    ),
    GroupModel(
      id: '3',
      name: 'Soccer League',
      imageUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55',
      description: 'Local soccer league for all skill levels',
      memberCount: 2345,
      isMember: false,
    ),
    GroupModel(
      id: '4',
      name: 'Volleyball Beach',
      imageUrl: 'https://images.unsplash.com/photo-1612872087720-bb876e2e67d1',
      description: 'Beach volleyball community',
      memberCount: 543,
      isMember: true,
    ),
    GroupModel(
      id: '5',
      name: 'Yoga Community',
      imageUrl: 'https://images.unsplash.com/photo-1545205597-3d9d1c4be103',
      description: 'Yoga practitioners and instructors',
      memberCount: 1876,
      isMember: false,
    ),
    GroupModel(
      id: '6',
      name: 'Running Club',
      imageUrl: 'https://images.unsplash.com/photo-1552674605-db6ffd4facb5',
      description: 'Runners of all levels welcome',
      memberCount: 987,
      isMember: false,
    ),
    GroupModel(
      id: '7',
      name: 'Swimming Team',
      imageUrl: 'https://images.unsplash.com/photo-1560090995-01632a28895b',
      description: 'Competitive swimming team',
      memberCount: 432,
      isMember: true,
    ),
    GroupModel(
      id: '8',
      name: 'Cycling Enthusiasts',
      imageUrl: 'https://images.unsplash.com/photo-1541625602330-2277a4c46182',
      description: 'Group for cycling and bike tours',
      memberCount: 765,
      isMember: false,
    ),
    GroupModel(
      id: '9',
      name: 'Fitness Community',
      imageUrl: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438',
      description: 'Fitness tips and workout buddies',
      memberCount: 2198,
      isMember: false,
    ),
    GroupModel(
      id: '10',
      name: 'Hiking Adventures',
      imageUrl: 'https://images.unsplash.com/photo-1551632811-561732d1e306',
      description: 'Group for hiking and outdoor adventures',
      memberCount: 1543,
      isMember: true,
    ),
  ];

  void _applyFilters() {
    // First filter by search query
    List<GroupModel> filteredByQuery = _mockGroups;
    if (widget.searchQuery.isNotEmpty) {
      filteredByQuery = _mockGroups.where((group) {
        return group.name
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            (group.description != null &&
                group.description!
                    .toLowerCase()
                    .contains(widget.searchQuery.toLowerCase()));
      }).toList();
    }

    // Apply secondary filter first (group type)
    List<GroupModel> filteredBySecondary = filteredByQuery;
    if (_selectedSecondaryFilter != null) {
      switch (_selectedSecondaryFilter) {
        case 'My Groups':
          filteredBySecondary =
              filteredByQuery.where((group) => group.isMember).toList();
          break;
        case 'Sports':
          // Filter groups whose name or description contains sports-related terms
          filteredBySecondary = filteredByQuery
              .where((group) =>
                  group.name.toLowerCase().contains('basketball') ||
                  group.name.toLowerCase().contains('tennis') ||
                  group.name.toLowerCase().contains('soccer') ||
                  group.name.toLowerCase().contains('volleyball') ||
                  group.name.toLowerCase().contains('swimming') ||
                  group.name.toLowerCase().contains('running') ||
                  group.name.toLowerCase().contains('cycling') ||
                  (group.description != null &&
                      (group.description!.toLowerCase().contains('sport') ||
                          group.description!.toLowerCase().contains('player') ||
                          group.description!.toLowerCase().contains('team'))))
              .toList();
          break;
        case 'Social':
          // Filter groups whose name or description contains social-related terms
          filteredBySecondary = filteredByQuery
              .where((group) =>
                  group.name.toLowerCase().contains('community') ||
                  group.name.toLowerCase().contains('club') ||
                  group.name.toLowerCase().contains('social') ||
                  (group.description != null &&
                      (group.description!.toLowerCase().contains('community') ||
                          group.description!.toLowerCase().contains('social') ||
                          group.description!.toLowerCase().contains('club'))))
              .toList();
          break;
        case 'Community':
          // Filter groups whose name or description contains community-related terms
          filteredBySecondary = filteredByQuery
              .where((group) =>
                  group.name.toLowerCase().contains('community') ||
                  (group.description != null &&
                      group.description!.toLowerCase().contains('community')))
              .toList();
          break;
        case 'Events':
          // Filter groups whose name or description contains event-related terms
          filteredBySecondary = filteredByQuery
              .where((group) =>
                  group.name.toLowerCase().contains('event') ||
                  group.name.toLowerCase().contains('league') ||
                  (group.description != null &&
                      (group.description!.toLowerCase().contains('event') ||
                          group.description!.toLowerCase().contains('league'))))
              .toList();
          break;
        case 'New':
          // Mock implementation - just return the first few groups
          filteredBySecondary = filteredByQuery.take(3).toList();
          break;
      }
    }

    // Then apply primary filter (sorting)
    switch (_selectedPrimaryFilter) {
      case 'Popular':
        _filteredGroups = List.from(filteredBySecondary)
          ..sort((a, b) => b.memberCount.compareTo(a.memberCount));
        break;
      case 'Nearby':
        // Mock implementation - sort alphabetically for now
        _filteredGroups = List.from(filteredBySecondary)
          ..sort((a, b) => a.name.compareTo(b.name));
        break;
      case 'Friends':
        // Mock implementation - show joined groups first
        _filteredGroups = List.from(filteredBySecondary)
          ..sort((a, b) => b.isMember ? 1 : -1);
        break;
      default:
        _filteredGroups = filteredBySecondary;
    }
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _applyFilters();
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        _applyFilters();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          // Filter row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: GroupsFilterRow(
              selectedPrimaryFilter: _selectedPrimaryFilter,
              selectedSecondaryFilter: _selectedSecondaryFilter,
              onFilterSelected: _handleFilterSelected,
            ),
          ),
          // Group list
          Expanded(
            child: _buildGroupList(),
          ),
        ],
      ),
    );
  }

  Widget _buildGroupList() {
    if (_filteredGroups.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      itemCount: _filteredGroups.length,
      itemBuilder: (context, index) {
        final group = _filteredGroups[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: GroupListItem(
            group: group,
            onTap: () {
              // Navigate to group detail page
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => GroupDetailPage(groupId: group.id),
                ),
              );
            },
            onJoinTap: (group) {
              // Toggle join status
              setState(() {
                final updatedGroup = GroupModel(
                  id: group.id,
                  name: group.name,
                  imageUrl: group.imageUrl,
                  description: group.description,
                  memberCount: group.isMember
                      ? group.memberCount - 1
                      : group.memberCount + 1,
                  isMember: !group.isMember,
                );

                final index = _mockGroups.indexWhere((g) => g.id == group.id);
                if (index != -1) {
                  _mockGroups[index] = updatedGroup;
                }

                _applyFilters();
              });
            },
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.group_off,
            size: 64,
            color: Colors.grey[700],
          ),
          const SizedBox(height: 16),
          Text(
            'No groups found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.searchQuery.isEmpty
                ? 'Start typing to search for groups'
                : 'Try a different search term',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
