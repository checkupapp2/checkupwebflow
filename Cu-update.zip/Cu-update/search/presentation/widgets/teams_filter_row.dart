import 'package:flutter/material.dart';
import 'common_filter_row.dart';

/// Widget for displaying filter options for teams search results
class TeamsFilterRow extends StatelessWidget {
  /// Callback when a filter is selected
  final Function(String) onFilterSelected;

  /// Currently selected primary filter (Popular, Nearby, Friends)
  final String selectedPrimaryFilter;

  /// Currently selected secondary filter (Following, Recreational, etc.)
  final String? selectedSecondaryFilter;

  /// Constructor
  const TeamsFilterRow({
    super.key,
    required this.onFilterSelected,
    required this.selectedPrimaryFilter,
    this.selectedSecondaryFilter,
  });

  @override
  Widget build(BuildContext context) {
    // Dropdown options for the first filter button
    final List<String> dropdownOptions = [
      'Popular',
      'Nearby',
      'Friends',
    ];

    // Regular filter options
    final List<String> regularFilters = [
      'Following',
      'Recreational',
      'Competitive',
      'Professional',
      'Youth',
      'Crew',
      'League Team',
      'School',
      'Pickup',
    ];

    return CommonFilterRow(
      selectedFilter: selectedPrimaryFilter,
      selectedSecondaryFilter: selectedSecondaryFilter,
      onFilterSelected: onFilterSelected,
      dropdownOptions: dropdownOptions,
      regularFilters: regularFilters,
    );
  }
}
