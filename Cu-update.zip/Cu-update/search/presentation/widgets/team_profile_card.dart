import 'package:flutter/material.dart';
import 'dart:ui';
import '../../domain/models/team_model.dart';

/// A modern team profile card with gradient black glossy background
/// Displays team information, stats, and actions
class TeamProfileCard extends StatelessWidget {
  /// The team to display
  final TeamModel team;

  /// Whether the current user is following this team
  final bool isFollowing;

  /// Callback when follow button is tapped
  final VoidCallback? onFollowTap;

  /// Constructor
  const TeamProfileCard({
    Key? key,
    required this.team,
    required this.isFollowing,
    this.onFollowTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        // Gradient black glossy background
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF121212),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.5),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1),
                width: 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Sport and Location badges at top
                Padding(
                  padding: const EdgeInsets.only(top: 16, left: 16, right: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Sport badge (NBA) on top left
                      if (team.sport != null)
                        _buildInfoBadge(
                          icon: Icons.sports_basketball,
                          text: team.sport!,
                        ),

                      // Location badge on top right
                      if (team.location != null)
                        _buildInfoBadge(
                          icon: Icons.location_on,
                          text: team.location!,
                        ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Team Logo
                _buildTeamLogo(),

                const SizedBox(height: 16),

                // Team Name and Handle
                _buildTeamNameSection(),

                const SizedBox(height: 20),

                // Stats Row
                _buildStatsRow(),

                const SizedBox(height: 24),

                // Follow Button
                _buildFollowButton(),

                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Builds the team logo with a glowing effect
  Widget _buildTeamLogo() {
    return Container(
      width: 120,
      height: 120,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF9800).withValues(alpha: 0.5),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      padding: const EdgeInsets.all(3), // Border width
      child: Container(
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.black,
        ),
        child: ClipOval(
          child: team.logoUrl != null
              ? Image.network(
                  team.logoUrl!,
                  fit: BoxFit.cover,
                  width: 113,
                  height: 113,
                  errorBuilder: (context, error, stackTrace) =>
                      _buildLogoPlaceholder(),
                )
              : _buildLogoPlaceholder(),
        ),
      ),
    );
  }

  /// Builds a placeholder for the team logo
  Widget _buildLogoPlaceholder() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[800],
        gradient: LinearGradient(
          colors: [
            Colors.grey[800]!,
            Colors.grey[900]!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: const Center(
        child: Icon(
          Icons.sports_basketball,
          color: Color(0xFFFF9800),
          size: 50,
        ),
      ),
    );
  }

  /// Builds the team name and handle section
  Widget _buildTeamNameSection() {
    return Column(
      children: [
        Text(
          team.name,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '@${team.handle}',
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 16,
          ),
        ),

        // Description if available
        if (team.description != null) ...[
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Text(
              team.description!,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 14,
                height: 1.4,
              ),
            ),
          ),
        ],
      ],
    );
  }

  /// Builds the stats row (members, followers, games)
  Widget _buildStatsRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildStatItem('Players', '${team.membersCount}'),
          _buildDivider(),
          _buildStatItem('Followers', '${team.followers}'),
          _buildDivider(),
          _buildStatItem('Games', '0'),
        ],
      ),
    );
  }

  /// Builds a stat item
  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  /// Builds a divider between stat items
  Widget _buildDivider() {
    return Container(
      height: 24,
      width: 1,
      color: Colors.grey[800],
    );
  }

  /// Builds the sport and location badges
  Widget _buildInfoBadges() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (team.sport != null) ...[
          _buildInfoBadge(
            icon: Icons.sports_basketball,
            text: team.sport!,
          ),
          const SizedBox(width: 12),
        ],
        if (team.location != null)
          _buildInfoBadge(
            icon: Icons.location_on,
            text: team.location!,
          ),
      ],
    );
  }

  /// Builds an info badge
  Widget _buildInfoBadge({required IconData icon, required String text}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFFFF9800).withValues(alpha: 0.7),
            const Color(0xFFFF5722).withValues(alpha: 0.7),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: Colors.white,
            size: 14,
          ),
          const SizedBox(width: 6),
          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  /// Builds the follow button
  Widget _buildFollowButton() {
    return GestureDetector(
      onTap: onFollowTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: 200,
        height: 45,
        decoration: BoxDecoration(
          gradient: isFollowing
              ? null
              : const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          color: isFollowing ? Colors.transparent : null,
          borderRadius: BorderRadius.circular(24),
          border: isFollowing
              ? Border.all(color: const Color(0xFFFF9800), width: 1.5)
              : null,
          boxShadow: isFollowing
              ? null
              : [
                  BoxShadow(
                    color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                isFollowing ? Icons.check : Icons.add,
                color: isFollowing ? const Color(0xFFFF9800) : Colors.white,
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(
                isFollowing ? 'Following' : 'Follow',
                style: TextStyle(
                  color: isFollowing ? const Color(0xFFFF9800) : Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
