import 'package:flutter/material.dart';
import '../../domain/models/score_model.dart';
import '../../domain/models/team_stats_model.dart';
import '../../domain/models/player_stats_model.dart';

/// Widget for displaying the stats tab in the score detail screen
class ScoreStatsTab extends StatefulWidget {
  /// The score model
  final ScoreModel score;

  /// Constructor
  const ScoreStatsTab({
    super.key,
    required this.score,
  });

  @override
  State<ScoreStatsTab> createState() => _ScoreStatsTabState();
}

class _ScoreStatsTabState extends State<ScoreStatsTab> with SingleTickerProviderStateMixin {
  late TeamStatsModel _homeTeamStats;
  late TeamStatsModel _awayTeamStats;
  late List<PlayerStatsModel> _homePlayers;
  late List<PlayerStatsModel> _awayPlayers;
  bool _isLoading = true;
  late TabController _rosterTabController;
  
  @override
  void initState() {
    super.initState();
    _rosterTabController = TabController(length: 2, vsync: this);
    _loadStatsData();
  }
  
  @override
  void dispose() {
    _rosterTabController.dispose();
    super.dispose();
  }

  Future<void> _loadStatsData() async {
    // Simulate API call with a delay
    await Future.delayed(const Duration(milliseconds: 800));
    
    // Get mock data
    final stats = TeamStatsModel.getMockTeamStats(widget.score.id);
    _homeTeamStats = stats['home']!;
    _awayTeamStats = stats['away']!;
    
    // Get player stats
    final playerStats = PlayerStatsModel.getMockPlayerStats(widget.score.id);
    _homePlayers = playerStats['home']!;
    _awayPlayers = playerStats['away']!;
    
    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return _buildLoadingState();
    }
    
    return Column(
      children: [
        // Points by quarter summary
        _buildPointsByQuarter(),
        
        // Team roster tabs
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: BorderRadius.circular(16),
          ),
          child: TabBar(
            controller: _rosterTabController,
            indicatorSize: TabBarIndicatorSize.tab,
            indicatorPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            indicator: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF9800),
                  Color(0xFFFF5722),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            dividerColor: Colors.transparent,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey,
            labelStyle: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
            unselectedLabelStyle: const TextStyle(
              fontWeight: FontWeight.normal,
              fontSize: 14,
            ),
            tabs: [
              Tab(text: widget.score.homeTeamName),
              Tab(text: widget.score.awayTeamName),
            ],
          ),
        ),
        
        // Player roster content
        Expanded(
          child: TabBarView(
            controller: _rosterTabController,
            children: [
              // Home team roster
              _buildTeamRoster(_homePlayers, true),
              
              // Away team roster
              _buildTeamRoster(_awayPlayers, false),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildLoadingState() {
    return const Center(
      child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
      ),
    );
  }
  
  Widget _buildTeamNamesHeader() {
    return Row(
      children: [
        Expanded(
          child: Text(
            widget.score.homeTeamName,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(width: 80),
        Expanded(
          child: Text(
            widget.score.awayTeamName,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
  
  Widget _buildPointsByQuarter() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.grey[800]!,
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // Header row
          Row(
            children: [
              const SizedBox(width: 80),
              ...List.generate(_homeTeamStats.quarterPoints.length, (index) {
                return Expanded(
                  child: Text(
                    'Q${index + 1}',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,
                  ),
                );
              }),
              Expanded(
                child: Text(
                  'Total',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
          
          const Divider(color: Colors.grey, height: 24),
          
          // Home team row
          Row(
            children: [
              SizedBox(
                width: 80,
                child: Text(
                  'Home',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              ...List.generate(_homeTeamStats.quarterPoints.length, (index) {
                return Expanded(
                  child: Text(
                    '${_homeTeamStats.quarterPoints[index]}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,
                  ),
                );
              }),
              Expanded(
                child: Text(
                  '${widget.score.homeScore}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 8),
          
          // Away team row
          Row(
            children: [
              SizedBox(
                width: 80,
                child: Text(
                  'Away',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              ...List.generate(_awayTeamStats.quarterPoints.length, (index) {
                return Expanded(
                  child: Text(
                    '${_awayTeamStats.quarterPoints[index]}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,
                  ),
                );
              }),
              Expanded(
                child: Text(
                  '${widget.score.awayScore}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildStatComparison(
    String label, 
    int homeMade, 
    int awayMade,
    int homeAttempted, 
    int awayAttempted,
  ) {
    final homePercentage = homeAttempted > 0 ? homeMade / homeAttempted : 0.0;
    final awayPercentage = awayAttempted > 0 ? awayMade / awayAttempted : 0.0;
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Label
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
          
          // Stats row
          Row(
            children: [
              // Home team stats
              Expanded(
                child: Text(
                  '$homeMade/$homeAttempted (${(homePercentage * 100).toStringAsFixed(1)}%)',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              
              // Progress bar
              Expanded(
                flex: 2,
                child: Container(
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: (homePercentage * 100).round(),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              colors: [
                                Colors.blue,
                                Colors.lightBlue,
                              ],
                            ),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: (awayPercentage * 100).round(),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              colors: [
                                Colors.red,
                                Colors.redAccent,
                              ],
                            ),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 100 - (homePercentage * 100).round() - (awayPercentage * 100).round(),
                        child: Container(),
                      ),
                    ],
                  ),
                ),
              ),
              
              // Away team stats
              Expanded(
                child: Text(
                  '$awayMade/$awayAttempted (${(awayPercentage * 100).toStringAsFixed(1)}%)',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildSimpleStatComparison(String label, int homeValue, int awayValue) {
    final total = homeValue + awayValue;
    final homePercentage = total > 0 ? homeValue / total : 0.5;
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Label
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
          
          // Stats row
          Row(
            children: [
              // Home team value
              Expanded(
                child: Text(
                  '$homeValue',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              
              // Progress bar
              Expanded(
                flex: 2,
                child: Container(
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: (homePercentage * 100).round(),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.only(
                              topLeft: const Radius.circular(4),
                              bottomLeft: const Radius.circular(4),
                              topRight: homePercentage >= 0.99 ? const Radius.circular(4) : Radius.zero,
                              bottomRight: homePercentage >= 0.99 ? const Radius.circular(4) : Radius.zero,
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 100 - (homePercentage * 100).round(),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.only(
                              topRight: const Radius.circular(4),
                              bottomRight: const Radius.circular(4),
                              topLeft: homePercentage <= 0.01 ? const Radius.circular(4) : Radius.zero,
                              bottomLeft: homePercentage <= 0.01 ? const Radius.circular(4) : Radius.zero,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              // Away team value
              Expanded(
                child: Text(
                  '$awayValue',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildTeamRoster(List<PlayerStatsModel> players, bool isHomeTeam) {
    // Separate starters from bench players
    final starters = players.where((player) => player.isStarter).toList();
    final bench = players.where((player) => !player.isStarter).toList();
    
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      children: [
        // Starters section
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Text(
            'STARTERS',
            style: TextStyle(
              color: Colors.white70,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ),
        
        // Starters list
        ...starters.map((player) => _buildPlayerStatRow(player, isHomeTeam)),
        
        const Divider(color: Colors.grey, height: 32),
        
        // Bench section
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Text(
            'BENCH',
            style: TextStyle(
              color: Colors.white70,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ),
        
        // Bench players list
        ...bench.map((player) => _buildPlayerStatRow(player, isHomeTeam)),
      ],
    );
  }
  
  Widget _buildPlayerStatRow(PlayerStatsModel player, bool isHomeTeam) {
    final teamColor = isHomeTeam ? Colors.blue : Colors.red;
    
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Colors.grey[800]!,
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // Player name, position, and basic stats
          Row(
            children: [
              // Jersey number
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: teamColor.withValues(alpha: 0.2),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: teamColor,
                    width: 1.5,
                  ),
                ),
                child: Center(
                  child: Text(
                    player.jerseyNumber,
                    style: TextStyle(
                      color: teamColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              
              const SizedBox(width: 12),
              
              // Player name and position
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      player.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                    Text(
                      player.position,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              
              // Minutes played
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.grey[800],
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  player.minutesPlayed,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 10),
          
          // Player stats
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStatItem('PTS', player.points.toString()),
              _buildStatItem('REB', player.rebounds.toString()),
              _buildStatItem('AST', player.assists.toString()),
              _buildStatItem('STL', player.steals.toString()),
              _buildStatItem('BLK', player.blocks.toString()),
              _buildStatItem('+/-', player.plusMinus.toString(), 
                color: player.plusMinus >= 0 ? Colors.green : Colors.red),
            ],
          ),
          
          const SizedBox(height: 8),
          
          // Shooting stats
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              player.shootingStats,
              style: const TextStyle(
                color: Colors.white60,
                fontSize: 12,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildStatItem(String label, String value, {Color? color}) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            color: color ?? Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white60,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
  
  Widget _buildTopPerformerCard({
    required String teamName,
    required String playerName,
    required String statLine,
    required bool isHomeTeam,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.grey[800]!,
          width: 1,
        ),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isHomeTeam
              ? [Colors.blue.withValues(alpha: 0.2), Colors.blue.withValues(alpha: 0.05)]
              : [Colors.red.withValues(alpha: 0.2), Colors.red.withValues(alpha: 0.05)],
        ),
      ),
      child: Row(
        children: [
          // Player avatar placeholder
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: Colors.grey[800],
              shape: BoxShape.circle,
              border: Border.all(
                color: isHomeTeam ? Colors.blue : Colors.red,
                width: 2,
              ),
            ),
            child: const Icon(
              Icons.person,
              color: Colors.white,
              size: 36,
            ),
          ),
          
          const SizedBox(width: 16),
          
          // Player info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  playerName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  teamName,
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  statLine,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          
          // Team indicator
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: isHomeTeam ? Colors.blue : Colors.red,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                isHomeTeam ? 'H' : 'A',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
