import 'package:flutter/material.dart';
import 'package:check_up_app/features/feed/domain/models/feed_post_model.dart';

/// Widget for displaying a post card in search results
class PostCard extends StatelessWidget {
  /// The post model to display
  final FeedPostModel post;

  /// Callback when the card is tapped
  final VoidCallback onTap;

  /// Constructor
  const PostCard({
    super.key,
    required this.post,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2A2A2A),
              Color(0xFF1A1A1A),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 15,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Post header
            _buildPostHeader(),

            // Post content
            _buildPostContent(),

            // Post media (if any)
            _buildPostMedia(),

            // Post footer with interaction buttons
            _buildPostFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildPostHeader() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          // Profile image
          CircleAvatar(
            radius: 20,
            backgroundColor: Colors.orange,
            backgroundImage: post.profileImagePath != null
                ? NetworkImage(post.profileImagePath!)
                : null,
            child: post.profileImagePath == null
                ? const Icon(Icons.person, color: Colors.white)
                : null,
          ),
          const SizedBox(width: 12),

          // Username and time
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      post.username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    if (post.isVerified) ...[
                      const SizedBox(width: 4),
                      const Icon(
                        Icons.verified,
                        color: Colors.blue,
                        size: 14,
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  post.timeAgo ?? '',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPostContent() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Text(
        post.content,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 14,
        ),
      ),
    );
  }

  Widget _buildPostMedia() {
    // Handle different post types
    switch (post.postType) {
      case PostType.standard:
        if (post.imageUrl != null) {
          return _buildSingleImage(post.imageUrl!);
        }
        return const SizedBox.shrink();

      case PostType.multipleImages:
        if (post.imageUrls != null && post.imageUrls!.isNotEmpty) {
          return _buildFirstImage(post.imageUrls!.first);
        }
        return const SizedBox.shrink();

      case PostType.video:
        if (post.videoThumbnailUrl != null) {
          return _buildVideoThumbnail(post.videoThumbnailUrl!);
        }
        return const SizedBox.shrink();

      case PostType.youtubeVideo:
        return _buildYouTubeThumbnail();

      case PostType.event:
        if (post.eventData?.imageUrl != null) {
          return _buildEventImage(post.eventData!.imageUrl!);
        }
        return _buildEventInfo();

      case PostType.court:
        if (post.courtData?.imageUrl != null) {
          return _buildCourtImage(post.courtData!.imageUrl!);
        }
        return _buildCourtInfo();

      case PostType.poll:
        return _buildPollPreview();

      case PostType.gameScore:
        return _buildGameScorePreview();

      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildSingleImage(String imageUrl) {
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
        child: AspectRatio(
          aspectRatio: 1, // 1:1 aspect ratio
          child: Image.network(
            imageUrl,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                color: Colors.grey[900],
                child: const Center(
                  child: Icon(Icons.error, color: Colors.white),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildFirstImage(String imageUrl) {
    return Stack(
      children: [
        _buildSingleImage(imageUrl),
        Positioned(
          top: 24,
          right: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.7),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.photo_library, color: Colors.white, size: 14),
                const SizedBox(width: 4),
                Text(
                  '+${post.imageUrls!.length - 1}',
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildVideoThumbnail(String thumbnailUrl) {
    return Stack(
      children: [
        _buildSingleImage(thumbnailUrl),
        Positioned.fill(
          child: Center(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.5),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.play_arrow,
                color: Colors.white,
                size: 32,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildYouTubeThumbnail() {
    return Stack(
      children: [
        Container(
          height: 200,
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(20),
              bottomRight: Radius.circular(20),
            ),
          ),
          child: const Center(
            child: Icon(Icons.play_arrow, color: Colors.red, size: 48),
          ),
        ),
        Positioned(
          bottom: 16,
          left: 16,
          child: Row(
            children: [
              const Icon(Icons.youtube_searched_for,
                  color: Colors.white, size: 16),
              const SizedBox(width: 8),
              Text(
                post.youtubeVideoTitle ?? 'YouTube Video',
                style: const TextStyle(color: Colors.white, fontSize: 14),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildEventImage(String imageUrl) {
    return Stack(
      children: [
        _buildSingleImage(imageUrl),
        Positioned(
          bottom: 16,
          left: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.orange,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Row(
              children: [
                Icon(Icons.event, color: Colors.white, size: 14),
                SizedBox(width: 4),
                Text('Event',
                    style: TextStyle(color: Colors.white, fontSize: 12)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEventInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          const Icon(Icons.event, color: Colors.orange),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  post.eventData?.title ?? 'Event',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  post.eventData?.location ?? 'Location',
                  style: TextStyle(color: Colors.grey[400], fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCourtImage(String imageUrl) {
    return Stack(
      children: [
        _buildSingleImage(imageUrl),
        Positioned(
          bottom: 16,
          left: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Row(
              children: [
                Icon(Icons.sports_basketball, color: Colors.white, size: 14),
                SizedBox(width: 4),
                Text('Court',
                    style: TextStyle(color: Colors.white, fontSize: 12)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCourtInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          const Icon(Icons.sports_basketball, color: Colors.blue),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  post.courtData?.name ?? 'Court',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  post.courtData?.address ?? 'Address',
                  style: TextStyle(color: Colors.grey[400], fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPollPreview() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.poll, color: Colors.purple),
              SizedBox(width: 8),
              Text(
                'Poll',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            post.pollData?.question ?? 'Poll Question',
            style: const TextStyle(color: Colors.white),
          ),
          const SizedBox(height: 8),
          Text(
            '${post.pollData?.totalVotes ?? 0} votes',
            style: TextStyle(color: Colors.grey[400], fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildGameScorePreview() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              children: [
                Text(
                  post.gameScoreData?.homeTeam ?? 'Home',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  '${post.gameScoreData?.homeScore ?? 0}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.grey[800],
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              post.gameScoreData?.gameStatus ?? 'vs',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Column(
              children: [
                Text(
                  post.gameScoreData?.awayTeam ?? 'Away',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  '${post.gameScoreData?.awayScore ?? 0}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPostFooter() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildInteractionButton(
            icon: Icons.favorite_border,
            count: post.likes,
          ),
          _buildInteractionButton(
            icon: Icons.chat_bubble_outline,
            count: post.comments,
          ),
          _buildInteractionButton(
            icon: Icons.repeat,
            count: post.reposts,
          ),
          _buildInteractionButton(
            icon: Icons.share_outlined,
            count: null,
          ),
        ],
      ),
    );
  }

  Widget _buildInteractionButton({
    required IconData icon,
    required int? count,
  }) {
    return Row(
      children: [
        Icon(
          icon,
          color: Colors.grey[400],
          size: 18,
        ),
        if (count != null) ...[
          const SizedBox(width: 4),
          Text(
            count.toString(),
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 12,
            ),
          ),
        ],
      ],
    );
  }
}
