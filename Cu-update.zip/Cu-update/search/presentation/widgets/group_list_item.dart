import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/group_model.dart';

/// A modern and beautiful group list item widget for the search results
class GroupListItem extends StatelessWidget {
  /// The group data to display
  final GroupModel group;
  
  /// Callback when the group item is tapped
  final VoidCallback? onTap;
  
  /// Callback when the join button is tapped
  final Function(GroupModel)? onJoinTap;

  /// Constructor
  const GroupListItem({
    super.key,
    required this.group,
    this.onTap,
    this.onJoinTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.2),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(  
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Group Image
              _buildGroupImage(),
              const SizedBox(width: 16),
              
              // Group Info
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildGroupName(),
                    if (group.description != null && group.description!.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      _buildDescription(),
                    ],
                    const SizedBox(height: 8),
                    _buildMemberCount(),
                  ],
                ),
              ),
              
              // Join Button
              _buildJoinButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGroupImage() {
    return Hero(
      tag: 'group_${group.id}',
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF9800).withValues(alpha: 0.3),
              blurRadius: 8,
              spreadRadius: 2,
            ),
          ],
        ),
        padding: const EdgeInsets.all(2), // Border width
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: group.imageUrl != null
              ? Image.network(
                  group.imageUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => _buildGroupImagePlaceholder(),
                )
              : _buildGroupImagePlaceholder(),
        ),
      ),
    );
  }

  Widget _buildGroupImagePlaceholder() {
    return Container(
      color: Colors.grey[800],
      child: Center(
        child: Text(
          group.name.isNotEmpty ? group.name[0].toUpperCase() : '?',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
      ),
    );
  }

  Widget _buildGroupName() {
    return Text(
      group.name,
      style: const TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.bold,
        fontSize: 16,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildDescription() {
    return Text(
      group.description!,
      style: TextStyle(
        color: Colors.grey[300],
        fontSize: 13,
        height: 1.2,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildMemberCount() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          Icons.people,
          size: 14,
          color: Colors.grey[400],
        ),
        const SizedBox(width: 4),
        Text(
          '${group.memberCount} ${group.memberCount == 1 ? 'member' : 'members'}',
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildJoinButton() {
    final isMember = group.isMember;
    
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        if (onJoinTap != null) {
          onJoinTap!(group);
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          gradient: isMember 
              ? null 
              : const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          color: isMember ? Colors.transparent : null,
          borderRadius: BorderRadius.circular(20),
          border: isMember 
              ? Border.all(color: const Color(0xFFFF9800), width: 1) 
              : null,
        ),
        child: Text(
          isMember ? 'Member' : 'Join',
          style: TextStyle(
            color: isMember ? const Color(0xFFFF9800) : Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
      ),
    );
  }
}
