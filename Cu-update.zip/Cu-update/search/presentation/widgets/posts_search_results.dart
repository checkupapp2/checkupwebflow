import 'package:flutter/material.dart';
import 'package:check_up_app/features/feed/domain/models/feed_post_model.dart';
import 'package:check_up_app/features/feed/data/feed_data_provider.dart';
import 'package:check_up_app/features/feed/presentation/widgets/feed_post.dart';
import 'package:check_up_app/features/feed/presentation/post_detail_screen.dart';
import 'post_filter_row.dart';

/// Widget for displaying posts search results
class PostsSearchResults extends StatefulWidget {
  /// Search query
  final String searchQuery;

  /// Constructor
  const PostsSearchResults({
    super.key,
    required this.searchQuery,
  });

  @override
  State<PostsSearchResults> createState() => _PostsSearchResultsState();
}

class _PostsSearchResultsState extends State<PostsSearchResults> {
  // Currently selected primary filter (Popular, Nearby, Friends)
  String _selectedPrimaryFilter = 'Popular';
  // Currently selected secondary filter (Photos, Videos, etc.)
  String? _selectedSecondaryFilter;
  // Filtered posts
  List<FeedPostModel> _filteredPosts = [];
  // All posts
  late List<FeedPostModel> _allPosts;

  @override
  void initState() {
    super.initState();
    // Load posts from feed data provider
    final feedDataProvider = FeedDataProvider();
    _allPosts = feedDataProvider.getFeedPosts();
    // Initialize filtered posts
    _applyFilters();
  }

  @override
  void didUpdateWidget(PostsSearchResults oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.searchQuery != widget.searchQuery) {
      _applyFilters();
    }
  }

  void _applyFilters() {
    // First filter by search query
    List<FeedPostModel> filteredByQuery = _allPosts;
    if (widget.searchQuery.isNotEmpty) {
      filteredByQuery = _allPosts.where((post) {
        return post.content
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            post.username
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase());
      }).toList();
    }

    // Apply secondary filter first (content type)
    List<FeedPostModel> filteredBySecondary = filteredByQuery;
    if (_selectedSecondaryFilter != null) {
      switch (_selectedSecondaryFilter) {
        case 'All':
          filteredBySecondary = filteredByQuery;
          break;
        case 'Photos':
          filteredBySecondary = filteredByQuery
              .where((post) =>
                  post.postType == PostType.standard && post.imageUrl != null ||
                  post.postType == PostType.multipleImages)
              .toList();
          break;
        case 'Videos':
          filteredBySecondary = filteredByQuery
              .where((post) =>
                  post.postType == PostType.video ||
                  post.postType == PostType.youtubeVideo)
              .toList();
          break;
        case 'Polls':
          filteredBySecondary = filteredByQuery
              .where((post) => post.postType == PostType.poll)
              .toList();
          break;
        case 'Events':
          filteredBySecondary = filteredByQuery
              .where((post) => post.postType == PostType.event)
              .toList();
          break;
        case 'Courts':
          filteredBySecondary = filteredByQuery
              .where((post) => post.postType == PostType.court)
              .toList();
          break;
        case 'Scores':
          filteredBySecondary = filteredByQuery
              .where((post) => post.postType == PostType.gameScore)
              .toList();
          break;
      }
    }

    // Then apply primary filter (sorting)
    switch (_selectedPrimaryFilter) {
      case 'Popular':
        _filteredPosts = List.from(filteredBySecondary)
          ..sort((a, b) => b.likes.compareTo(a.likes));
        break;
      case 'Nearby':
        // Mock implementation - sort by username for now
        _filteredPosts = List.from(filteredBySecondary)
          ..sort((a, b) => a.username.compareTo(b.username));
        break;
      case 'Friends':
        // Mock implementation - sort by verified status
        _filteredPosts = List.from(filteredBySecondary)
          ..sort((a, b) => b.isVerified ? 1 : -1);
        break;
      default:
        _filteredPosts = filteredBySecondary;
    }

    setState(() {});
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _applyFilters();
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        _applyFilters();
      }
    });
  }

  void _handlePostInteraction(String action, String postId) {
    debugPrint('$action on post $postId');

    // Find the post by ID
    final post = _allPosts.firstWhere((post) => post.id == postId);

    // Navigate to post detail screen based on action
    if (action == 'comment') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PostDetailScreen(
            post: post,
            focusComment: true,
          ),
        ),
      );
    }
  }

  // Handle tap on the post itself
  void _handlePostTap(String postId) {
    debugPrint('Post tapped: $postId');

    // Find the post by ID
    final post = _allPosts.firstWhere((post) => post.id == postId);

    // Navigate to post detail screen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PostDetailScreen(
          post: post,
          focusComment: false,
        ),
      ),
    );
  }

  void _handlePollOptionSelected(String postId, int optionIndex) {
    debugPrint('Poll option $optionIndex selected for post $postId');
  }

  void _handleImageTap(String postId, int imageIndex) {
    debugPrint('Image $imageIndex tapped in post $postId');
    _navigateToPostDetail(postId);
  }

  void _handlePostVideoTap(String postId) {
    debugPrint('Video tapped in post $postId');
    _navigateToPostDetail(postId);
  }

  void _handleYouTubeVideoTap(String postId) {
    debugPrint('YouTube video tapped in post $postId');
    _navigateToPostDetail(postId);
  }

  void _handleEventGoingTap(String postId) {
    debugPrint('Going to event in post $postId');
    // Don't navigate for this action as it's just toggling the going status
  }

  void _handleEventInterestedTap(String postId) {
    debugPrint('Interested in event in post $postId');
    // Don't navigate for this action as it's just toggling the interested status
  }

  void _handleEventTap(String postId) {
    debugPrint('Event tapped in post $postId');
    _navigateToPostDetail(postId);
  }

  void _handleGameTap(String postId) {
    debugPrint('Game tapped in post $postId');
    _navigateToPostDetail(postId);
  }

  // Helper method to navigate to post detail
  void _navigateToPostDetail(String postId) {
    // Find the post by ID
    final post = _allPosts.firstWhere((post) => post.id == postId);

    // Navigate to post detail screen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PostDetailScreen(
          post: post,
          focusComment: false,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          // Filter row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: PostFilterRow(
              selectedPrimaryFilter: _selectedPrimaryFilter,
              selectedSecondaryFilter: _selectedSecondaryFilter,
              onFilterSelected: _handleFilterSelected,
            ),
          ),
          // Post list
          Expanded(
            child: _buildPostList(),
          ),
        ],
      ),
    );
  }

  Widget _buildPostList() {
    if (_filteredPosts.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      itemCount: _filteredPosts.length,
      itemBuilder: (context, index) {
        final post = _filteredPosts[index];
        return Column(
          children: [
            GestureDetector(
              onTap: () => _handlePostTap(post.id),
              child: FeedPost(
                post: post,
                onLikeTap: () => _handlePostInteraction('like', post.id),
                onCommentTap: () => _handlePostInteraction('comment', post.id),
                onRepostTap: () => _handlePostInteraction('repost', post.id),
                onShareTap: () => _handlePostInteraction('share', post.id),
                onPollOptionSelected: (optionIndex) =>
                    _handlePollOptionSelected(post.id, optionIndex),
                onImageTap: (imageIndex) =>
                    _handleImageTap(post.id, imageIndex),
                onVideoTap: () => _handlePostVideoTap(post.id),
                onYouTubeVideoTap: () => _handleYouTubeVideoTap(post.id),
                onEventGoingTap: () => _handleEventGoingTap(post.id),
                onEventInterestedTap: () => _handleEventInterestedTap(post.id),
                onEventTap: () => _handleEventTap(post.id),
                onGameTap: () => _handleGameTap(post.id),
              ),
            ),
            // Add spacing between posts, but not after the last one
            if (index < _filteredPosts.length - 1) const SizedBox(height: 16),
          ],
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.post_add,
            size: 64,
            color: Colors.grey[700],
          ),
          const SizedBox(height: 16),
          Text(
            'No posts found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.searchQuery.isEmpty
                ? 'Try selecting a different filter'
                : 'Try a different search term',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
