import 'package:flutter/material.dart';

/// Widget for displaying a team's statistics
class TeamStatsTab extends StatefulWidget {
  /// Team ID
  final String teamId;
  
  /// Team name
  final String teamName;

  /// Constructor
  const TeamStatsTab({
    super.key,
    required this.teamId,
    required this.teamName,
  });

  @override
  State<TeamStatsTab> createState() => _TeamStatsTabState();
}

class _TeamStatsTabState extends State<TeamStatsTab> {
  // Selected season for stats filtering
  String _selectedSeason = 'All';
  
  // Sample seasons data
  final List<String> _seasons = ['All', '2024-2025', '2023-2024', '2022-2023', '2021-2022'];
  

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSeasonFilter(),
        const SizedBox(height: 20),
        _buildStatsSection(
          title: 'Standings',
          icon: Icons.emoji_events,
          child: _buildStandingsTable(),
        ),
        const SizedBox(height: 24),
        _buildStatsSection(
          title: 'Player Stats',
          icon: Icons.person,
          child: _buildPlayerStatsTable(),
        ),
      ],
    );
  }

  // Season filter widget
  Widget _buildSeasonFilter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Season filter title
        Row(
          children: [
            Icon(
              Icons.calendar_today,
              color: const Color(0xFFFF9800),
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(
              'Season',
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        
        // Season filter chips
        Container(
          height: 40,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _seasons.length,
            itemBuilder: (context, index) {
              final season = _seasons[index];
              final isSelected = season == _selectedSeason;
              
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedSeason = season;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: isSelected
                      ? LinearGradient(
                          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        )
                      : null,
                    color: isSelected ? null : Colors.black.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected 
                        ? Colors.transparent 
                        : Colors.orange.withValues(alpha: 0.3),
                    ),
                    boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: const Color(0xFFFF9800).withValues(alpha: 0.4),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                  ),
                  child: Text(
                    season,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      fontSize: 14,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // Helper method to build stats sections
  Widget _buildStatsSection({required String title, required IconData icon, required Widget child}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              icon,
              color: const Color(0xFFFF9800),
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        child,
      ],
    );
  }
  
  // Standings table
  Widget _buildStandingsTable() {
    // Sample standings data for the team's league
    final standings = [
      {'rank': '1', 'team': widget.teamName, 'wins': '10', 'losses': '2', 'pct': '.833'},
      {'rank': '2', 'team': 'Lakers', 'wins': '9', 'losses': '3', 'pct': '.750'},
      {'rank': '3', 'team': 'Celtics', 'wins': '8', 'losses': '4', 'pct': '.667'},
      {'rank': '4', 'team': 'Bulls', 'wins': '7', 'losses': '5', 'pct': '.583'},
      {'rank': '5', 'team': 'Heat', 'wins': '6', 'losses': '6', 'pct': '.500'},
    ];
    
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.withValues(alpha: 0.2)),
      ),
      child: Column(
        children: [
          // Table header
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.grey[800]!, Colors.grey[900]!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
            ),
            child: Row(
              children: [
                _buildTableHeaderCell('#', flex: 1),
                _buildTableHeaderCell('Team', flex: 4, alignment: Alignment.centerLeft),
                _buildTableHeaderCell('W', flex: 1),
                _buildTableHeaderCell('L', flex: 1),
                _buildTableHeaderCell('PCT', flex: 2),
              ],
            ),
          ),
          // Table rows
          ...standings.map((team) => Container(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.grey.withValues(alpha: 0.2))),
              color: team['team'] == widget.teamName ? Colors.orange.withValues(alpha: 0.1) : null,
            ),
            child: Row(
              children: [
                _buildTableCell(team['rank']!, flex: 1),
                _buildTableCell(team['team']!, flex: 4, alignment: Alignment.centerLeft, 
                  isHighlighted: team['team'] == widget.teamName),
                _buildTableCell(team['wins']!, flex: 1),
                _buildTableCell(team['losses']!, flex: 1),
                _buildTableCell(team['pct']!, flex: 2),
              ],
            ),
          )).toList(),
        ],
      ),
    );
  }

  // Player stats table
  Widget _buildPlayerStatsTable() {
    // Sample player stats data from the team
    final playerStats = [
      {'player': 'LeBron James', 'ppg': '28.4', 'rpg': '7.6', 'apg': '8.3', 'fg': '.520'},
      {'player': 'Stephen Curry', 'ppg': '26.8', 'rpg': '5.2', 'apg': '6.4', 'fg': '.480'},
      {'player': 'Kevin Durant', 'ppg': '29.1', 'rpg': '7.3', 'apg': '5.8', 'fg': '.510'},
    ];
    
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey.withValues(alpha: 0.2)),
      ),
      child: Column(
        children: [
          // Table header
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.grey[800]!, Colors.grey[900]!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
            ),
            child: Row(
              children: [
                _buildTableHeaderCell('Player', flex: 5, alignment: Alignment.centerLeft),
                _buildTableHeaderCell('PPG', flex: 2),
                _buildTableHeaderCell('RPG', flex: 2),
                _buildTableHeaderCell('APG', flex: 2),
                _buildTableHeaderCell('FG%', flex: 2),
              ],
            ),
          ),
          // Table rows
          ...playerStats.map((player) => Container(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.grey.withValues(alpha: 0.2))),
            ),
            child: Row(
              children: [
                _buildTableCell(player['player']!, flex: 5, alignment: Alignment.centerLeft),
                _buildTableCell(player['ppg']!, flex: 2),
                _buildTableCell(player['rpg']!, flex: 2),
                _buildTableCell(player['apg']!, flex: 2),
                _buildTableCell(player['fg']!, flex: 2),
              ],
            ),
          )).toList(),
        ],
      ),
    );
  }

  // Helper method for table header cells
  Widget _buildTableHeaderCell(String text, {int flex = 1, Alignment alignment = Alignment.center}) {
    return Expanded(
      flex: flex,
      child: Container(
        alignment: alignment,
        child: Text(
          text,
          style: TextStyle(
            color: Colors.grey[300],
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ),
    );
  }
  
  // Helper method for table cells
  Widget _buildTableCell(String text, {int flex = 1, Alignment alignment = Alignment.center, bool isHighlighted = false}) {
    return Expanded(
      flex: flex,
      child: Container(
        alignment: alignment,
        child: Text(
          text,
          style: TextStyle(
            color: isHighlighted ? const Color(0xFFFF9800) : Colors.grey[400],
            fontSize: 14,
            fontWeight: isHighlighted ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }
}

/// Model class for player statistics
class PlayerStats {
  final String name;
  final String position;
  final int gamesPlayed;
  final double pointsPerGame;
  final double reboundsPerGame;
  final double assistsPerGame;
  final double stealsPerGame;
  final double blocksPerGame;
  final double fieldGoalPercentage;
  final double threePointPercentage;
  final double freeThrowPercentage;
  final double minutesPerGame;
  final double plusMinus;
  final String photoUrl;

  PlayerStats({
    required this.name,
    required this.position,
    required this.gamesPlayed,
    required this.pointsPerGame,
    required this.reboundsPerGame,
    required this.assistsPerGame,
    required this.stealsPerGame,
    required this.blocksPerGame,
    required this.fieldGoalPercentage,
    required this.threePointPercentage,
    required this.freeThrowPercentage,
    required this.minutesPerGame,
    required this.plusMinus,
    required this.photoUrl,
  });
}
