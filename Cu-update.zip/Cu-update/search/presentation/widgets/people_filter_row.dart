import 'package:flutter/material.dart';
import 'common_filter_row.dart';

/// Widget for displaying filter options in the people search tab
class PeopleFilterRow extends StatelessWidget {
  /// Callback when a filter is selected
  final Function(String) onFilterSelected;

  /// Currently selected primary filter (Popular, Nearby, Friends)
  final String selectedPrimaryFilter;

  /// Currently selected secondary filter (Players, Hosts, etc.)
  final String? selectedSecondaryFilter;

  /// Constructor
  const PeopleFilterRow({
    super.key,
    required this.onFilterSelected,
    required this.selectedPrimaryFilter,
    this.selectedSecondaryFilter,
  });

  @override
  Widget build(BuildContext context) {
    // Dropdown options for the first filter button
    final List<String> dropdownOptions = [
      'Popular',
      'Nearby',
      'Friends',
    ];

    // Regular filter options
    final List<String> regularFilters = [
      'Players',
      'Hosts',
      'Trainers',
      'Refs',
      'Media',
    ];

    return CommonFilterRow(
      selectedFilter: selectedPrimaryFilter,
      selectedSecondaryFilter: selectedSecondaryFilter,
      onFilterSelected: onFilterSelected,
      dropdownOptions: dropdownOptions,
      regularFilters: regularFilters,
    );
  }
}
