import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/league_model.dart';

/// A modern and beautiful league list item widget for the search results
class LeagueListItem extends StatelessWidget {
  /// The league data to display
  final LeagueModel league;
  
  /// Callback when the league item is tapped
  final VoidCallback? onTap;
  
  /// Callback when the follow button is tapped
  final Function(LeagueModel)? onFollowTap;

  /// Constructor
  const LeagueListItem({
    super.key,
    required this.league,
    this.onTap,
    this.onFollowTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.grey[900]!.withValues(alpha: 0.95),
              Colors.grey[850]!.withValues(alpha: 0.9),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Colors.grey[800]!.withValues(alpha: 0.3),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.4),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: const Color(0xFFFF9800).withValues(alpha: 0.05),
              blurRadius: 20,
              offset: const Offset(0, 0),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // League name - full width, no constraints
              Container(
                width: double.infinity,
                child: _buildLeagueName(),
              ),
              const SizedBox(height: 12),
              
              // Handle and stats row
              Row(
                children: [
                  _buildCompactLeagueLogo(),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildLeagueHandle(),
                        const SizedBox(height: 6),
                        _buildFullWidthStats(),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Column(
                    children: [
                      _buildCompactStatus(),
                      const SizedBox(height: 8),
                      _buildCompactFollowButton(),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCompactLeagueLogo() {
    return Hero(
      tag: 'league_${league.id}',
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF9800).withValues(alpha: 0.3),
              blurRadius: 4,
              spreadRadius: 0.5,
            ),
          ],
        ),
        padding: const EdgeInsets.all(2),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: league.logoUrl != null
              ? Image.network(
                  league.logoUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return _buildFallbackLogo();
                  },
                )
              : _buildFallbackLogo(),
        ),
      ),
    );
  }

  Widget _buildFallbackLogo() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF333333),
        shape: BoxShape.circle,
      ),
      child: const Icon(
        Icons.sports_basketball,
        color: Color(0xFFFF9800),
        size: 30,
      ),
    );
  }

  Widget _buildLeagueName() {
    return Text(
      league.name,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.1,
      ),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildLeagueHandle() {
    return Text(
      '@${league.handle}',
      style: TextStyle(
        color: Colors.grey[400],
        fontSize: 13,
      ),
      overflow: TextOverflow.ellipsis,
      maxLines: 1,
    );
  }

  Widget _buildCompactStatus() {
    Color statusColor;
    switch (league.status.toLowerCase()) {
      case 'in season':
        statusColor = Colors.green;
        break;
      case 'off season':
        statusColor = Colors.grey;
        break;
      case 'playoffs':
        statusColor = Colors.orange;
        break;
      case 'registration open':
        statusColor = Colors.blue;
        break;
      case 'upcoming':
        statusColor = Colors.blue;
        break;
      case 'registration closed':
        statusColor = Colors.red;
        break;
      default:
        statusColor = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: statusColor.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: statusColor.withValues(alpha: 0.3),
          width: 0.5,
        ),
      ),
      child: Text(
        league.status,
        style: TextStyle(
          color: statusColor,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }



  Widget _buildFullWidthStats() {
    return Text(
      '${league.teamsCount} teams • ${league.playersCount} players',
      style: TextStyle(
        color: Colors.grey[500],
        fontSize: 12,
        fontWeight: FontWeight.w400,
      ),
      overflow: TextOverflow.ellipsis,
      maxLines: 1,
    );
  }


  Widget _buildCompactFollowButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        if (onFollowTap != null) {
          onFollowTap!(league);
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: league.isFollowing ? Colors.grey[800] : null,
          gradient: league.isFollowing
              ? null
              : const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: league.isFollowing 
                  ? Colors.black.withValues(alpha: 0.2)
                  : const Color(0xFFFF9800).withValues(alpha: 0.3),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Text(
          league.isFollowing ? 'Following' : 'Follow',
          style: TextStyle(
            color: league.isFollowing ? Colors.grey[300] : Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 12,
          ),
        ),
      ),
    );
  }
}
