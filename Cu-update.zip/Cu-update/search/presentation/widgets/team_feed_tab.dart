import 'package:flutter/material.dart';
import 'package:check_up_app/features/feed/domain/models/feed_post_model.dart';
import 'package:check_up_app/features/feed/presentation/widgets/feed_post.dart';
import 'package:check_up_app/features/feed/data/feed_data_provider.dart';

/// Widget for displaying a team's feed
class TeamFeedTab extends StatefulWidget {
  /// Team ID
  final String teamId;
  
  /// Team name
  final String teamName;

  /// Constructor
  TeamFeedTab({
    super.key,
    required this.teamId,
    required this.teamName,
  });

  @override
  State<TeamFeedTab> createState() => _TeamFeedTabState();
}

class _TeamFeedTabState extends State<TeamFeedTab> {
  late List<FeedPostModel> _feedPosts;
  
  @override
  void initState() {
    super.initState();
    // Initialize feed posts using the same data provider as league
    final feedDataProvider = FeedDataProvider();
    _feedPosts = feedDataProvider.getFeedPosts().take(5).toList();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ..._feedPosts.map((post) => Padding(
          padding: const EdgeInsets.only(bottom: 16.0),
          child: FeedPost(
            post: post,
            onLikeTap: () {},
            onCommentTap: () {},
            onRepostTap: () {},
            onShareTap: () {},
          ),
        )).toList(),
        Center(
          child: TextButton(
            onPressed: () {},
            child: Text(
              'View All Posts',
              style: TextStyle(
                color: Colors.orange[300],
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    );
  }

}

