import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:check_up_app/features/search/bloc/search_cubit.dart';
import 'package:check_up_app/features/search/data/search_repository.dart';
import 'package:check_up_app/features/search/domain/models/search_event_model.dart';
import 'package:check_up_app/features/events/data/events_repository.dart';
import 'package:check_up_app/features/events/presentation/pages/event_detail_page.dart';
import 'event_filter_row.dart';

class EventsSearchResults extends StatefulWidget {
  final String searchQuery;
  const EventsSearchResults({super.key, required this.searchQuery});

  @override
  State<EventsSearchResults> createState() => _EventsSearchResultsState();
}

class _EventsSearchResultsState extends State<EventsSearchResults> {
  String _selectedPrimaryFilter = 'Popular';
  String? _selectedSecondaryFilter;
  late final SearchCubit _cubit;

  @override
  void initState() {
    super.initState();
    // Swap to your service locator if needed
    final eventsRepo = EventsRepository();
    final searchRepo = SearchRepository(eventsRepository: eventsRepo);
    _cubit = SearchCubit(searchRepo)
      ..init(query: widget.searchQuery, selectedFilter: _selectedPrimaryFilter);
  }

  @override
  void didUpdateWidget(covariant EventsSearchResults oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.searchQuery != widget.searchQuery) {
      _cubit.setQuery(widget.searchQuery);
    }
  }

  @override
  void dispose() {
    _cubit.close();
    super.dispose();
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _cubit.setFilter(filter);
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        // Apply combined filter logic here if needed
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SearchCubit, SearchState>(
      bloc: _cubit,
      builder: (context, state) {
        if (state.loading) {
          return const Scaffold(
            backgroundColor: Colors.black,
            body: Center(child: CircularProgressIndicator.adaptive()),
          );
        }
        if (state.error != null) {
          return Scaffold(
            backgroundColor: Colors.black,
            body: Center(
              child: Text('Error: ${state.error}',
                  style: const TextStyle(color: Colors.redAccent)),
            ),
          );
        }

        final items = state.items;

        return Scaffold(
          backgroundColor: Colors.black,
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: EventFilterRow(
                  selectedPrimaryFilter: _selectedPrimaryFilter,
                  selectedSecondaryFilter: _selectedSecondaryFilter,
                  onFilterSelected: _handleFilterSelected,
                ),
              ),
              Expanded(
                child: items.isEmpty
                    ? _buildEmptyState()
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(
                            vertical: 16, horizontal: 16),
                        itemCount: items.length,
                        itemBuilder: (context, i) =>
                            _EventCard(event: items[i]),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.event_busy, size: 64, color: Colors.grey[700]),
          const SizedBox(height: 16),
          Text(
            'No events found',
            style: TextStyle(
                color: Colors.grey[400],
                fontSize: 18,
                fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            _selectedPrimaryFilter.isEmpty
                ? 'Try selecting a different filter'
                : 'Try a different search term or filter',
            style: TextStyle(color: Colors.grey[600], fontSize: 14),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

/// Card widget (unchanged visuals)
class _EventCard extends StatelessWidget {
  const _EventCard({required this.event});
  final SearchEventModel event;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 15,
              spreadRadius: 1,
              offset: const Offset(0, 8)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        EventDetailPage(eventId: event.id, title: event.title)),
              );
            },
            splashColor: Colors.orange.withValues(alpha: 0.1),
            highlightColor: Colors.orange.withValues(alpha: 0.05),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // image
                Stack(
                  children: [
                    AspectRatio(
                      aspectRatio: 1 / 1,
                      child: Image.network(
                        event.thumbnailUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (context, _, __) => Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.orange[800]!.withValues(alpha: 0.3),
                                Colors.orange[900]!.withValues(alpha: 0.3)
                              ],
                            ),
                          ),
                          child: const Center(
                            child: Icon(Icons.sports_basketball,
                                size: 60, color: Colors.orange),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 16,
                      left: 16,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.orange[400]!,
                              Colors.deepOrange[700]!
                            ],
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black.withValues(alpha: 0.4),
                                blurRadius: 10,
                                offset: const Offset(0, 3))
                          ],
                          border: Border.all(
                              color: Colors.white.withValues(alpha: 0.3), width: 1),
                        ),
                        child: Text(
                          event.price,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              letterSpacing: 0.5),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 16,
                      left: 16,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.7),
                            borderRadius: BorderRadius.circular(20)),
                        child: Text(
                          event.gameType,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 12),
                        ),
                      ),
                    ),
                  ],
                ),

                // content
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(event.title,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: Colors.orange.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8)),
                            child: const Icon(Icons.location_on,
                                color: Colors.orange, size: 16),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(event.location,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 14),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: Colors.orange.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8)),
                            child: const Icon(Icons.calendar_today,
                                color: Colors.orange, size: 16),
                          ),
                          const SizedBox(width: 10),
                          Text(event.date,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 32,
                                height: 32,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      Colors.orange.shade300,
                                      Colors.deepOrange.shade700
                                    ],
                                  ),
                                  border: Border.all(
                                      color: Colors.white.withValues(alpha: 0.3),
                                      width: 1),
                                ),
                                child: Center(
                                  child: Text(
                                    event.hostName.isNotEmpty
                                        ? event.hostName[0].toUpperCase()
                                        : 'H',
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                event.hostName.isEmpty
                                    ? 'Hosted Event'
                                    : event.hostName,
                                style: TextStyle(
                                    color: Colors.grey[400], fontSize: 14),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                                color: Colors.grey.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(12)),
                            child: Row(
                              children: [
                                const Icon(Icons.people,
                                    color: Colors.grey, size: 14),
                                const SizedBox(width: 4),
                                Text('${event.reviews} joined',
                                    style: TextStyle(
                                        color: Colors.grey[400], fontSize: 12)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
