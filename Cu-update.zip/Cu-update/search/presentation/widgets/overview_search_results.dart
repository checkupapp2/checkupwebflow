import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/court_model.dart';
import '../../domain/models/search_event_model.dart';
import '../../domain/models/score_model.dart';
import '../../domain/models/user_model.dart';
import '../pages/score_detail_screen.dart';
import '../../../profile/presentation/pages/profile_page.dart';
import '../../../events/presentation/pages/event_detail_page.dart';
import '../../../courts/presentation/routes/court_routes.dart';
import 'court_card.dart';
import 'espn_score_card.dart';
import 'event_card.dart';

/// Widget to display the Overview tab in the Search screen
class OverviewSearchResults extends StatefulWidget {
  /// Search query to filter results
  final String searchQuery;

  /// Constructor
  const OverviewSearchResults({
    super.key,
    required this.searchQuery,
  });

  @override
  State<OverviewSearchResults> createState() => _OverviewSearchResultsState();
}

class _OverviewSearchResultsState extends State<OverviewSearchResults> {
  // Mock data for users
  late List<UserModel> _users;
  // Mock data for courts
  late List<CourtModel> _courts;
  // Mock data for events
  late List<SearchEventModel> _events;
  // Mock data for scores
  late List<ScoreModel> _scores;

  @override
  void initState() {
    super.initState();
    _initializeMockData();
  }

  void _initializeMockData() {
    // Initialize users with mock data
    _users = [
      UserModel(
        id: '1',
        name: 'John Smith',
        username: '@johnsmith',
        profileImageUrl:
            'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        bio: 'Hooper from Brooklyn',
        followers: 1243,
        following: 567,
        isFollowing: true,
      ),
      UserModel(
        id: '2',
        name: 'Sarah Johnson',
        username: '@sarahj',
        profileImageUrl:
            'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        bio: 'Basketball coach & trainer',
        followers: 892,
        following: 231,
        isFollowing: false,
      ),
      UserModel(
        id: '3',
        name: 'Michael Chen',
        username: '@mchen',
        profileImageUrl:
            'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        bio: 'Streetball legend',
        followers: 2341,
        following: 124,
        isFollowing: true,
      ),
      UserModel(
        id: '4',
        name: 'Alicia Rodriguez',
        username: '@alicia_r',
        profileImageUrl:
            'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        bio: 'Pro player | NYC',
        followers: 5621,
        following: 267,
        isFollowing: false,
      ),
      UserModel(
        id: '5',
        name: 'David Wilson',
        username: '@dwilson',
        profileImageUrl:
            'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        bio: 'Basketball referee',
        followers: 432,
        following: 321,
        isFollowing: true,
      ),
      UserModel(
        id: '6',
        name: 'Tanya Williams',
        username: '@tanya_w',
        profileImageUrl:
            'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        bio: 'College player & coach',
        followers: 1876,
        following: 543,
        isFollowing: false,
      ),
      UserModel(
        id: '7',
        name: 'James Thompson',
        username: '@jthompson',
        profileImageUrl:
            'https://images.unsplash.com/photo-1552058544-f2b08422138a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        bio: 'Streetball player',
        followers: 987,
        following: 432,
        isFollowing: true,
      ),
      UserModel(
        id: '8',
        name: 'Sophia Lee',
        username: '@sophial',
        profileImageUrl:
            'https://images.unsplash.com/photo-1491349174775-aaafddd81942?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
        bio: 'Basketball analyst',
        followers: 2341,
        following: 154,
        isFollowing: false,
      ),
    ];

    // Initialize courts
    _courts = [
      CourtModel(
        id: '1',
        name: 'Rucker Park',
        city: 'Harlem',
        state: 'NY',
        followers: 1243,
        imageUrl:
            'https://images.unsplash.com/photo-1505666287802-931dc83a5dc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        isVerified: true,
        isFollowing: true,
      ),
      CourtModel(
        id: '2',
        name: 'West 4th Street',
        city: 'Manhattan',
        state: 'NY',
        followers: 876,
        imageUrl:
            'https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        isVerified: true,
        isFollowing: false,
      ),
      CourtModel(
        id: '3',
        name: 'Brooklyn Bridge Park',
        city: 'Brooklyn',
        state: 'NY',
        followers: 954,
        imageUrl:
            'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        isVerified: true,
        isFollowing: true,
      ),
      CourtModel(
        id: '4',
        name: 'Dyckman Courts',
        city: 'Manhattan',
        state: 'NY',
        followers: 732,
        imageUrl:
            'https://images.unsplash.com/photo-1504450758481-7338eba7524a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        isVerified: false,
        isFollowing: false,
      ),
    ];

    // Initialize events
    _events = [
      SearchEventModel(
        id: 'nyc_streetball',
        title: 'NYC Streetball Tournament',
        location: 'Rucker Park, Harlem',
        gameType: '5v5 Tournament',
        date: 'Jun 15 • 3:00 PM',
        price: '\$20 entry fee',
        rating: 4.9,
        reviews: 124,
        hostName: 'NYC Basketball League',
        thumbnailUrl:
            'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        imageUrls: [
          'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        ],
      ),
      SearchEventModel(
        id: 'brooklyn_bridge_3v3',
        title: 'Brooklyn Bridge 3v3',
        location: 'Brooklyn Bridge Park',
        gameType: '3v3 Tournament',
        date: 'Jun 20 • 2:00 PM',
        price: '\$15 entry fee',
        rating: 4.8,
        reviews: 76,
        hostName: 'Brooklyn Ballers',
        thumbnailUrl:
            'https://images.unsplash.com/photo-1505666287802-931dc83a5dc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        imageUrls: [
          'https://images.unsplash.com/photo-1505666287802-931dc83a5dc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        ],
      ),
      SearchEventModel(
        id: 'west_4th_open_run',
        title: 'West 4th Open Run',
        location: 'West 4th Street Courts',
        gameType: 'Open Play',
        date: 'Today • 6:00 PM',
        price: 'Free',
        rating: 4.5,
        reviews: 52,
        hostName: 'Village Basketball Club',
        thumbnailUrl:
            'https://images.unsplash.com/photo-1587614382346-4ec70e388b28?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        imageUrls: [
          'https://images.unsplash.com/photo-1587614382346-4ec70e388b28?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        ],
      ),
    ];

    // Initialize scores
    _scores = ScoreModel.getMockScores().take(4).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // People section
              _buildSectionHeader('People', Icons.people, 1),
              _buildPeopleSection(),

              const SizedBox(height: 16), // Reduced spacing

              // Courts section
              _buildSectionHeader('Courts', Icons.location_on, 2),
              _buildCourtsSection(),

              const SizedBox(height: 16), // Reduced spacing

              // Events section
              _buildSectionHeader('Events', Icons.event, 3),
              _buildEventsSection(),

              const SizedBox(height: 16), // Reduced spacing

              // Scores section
              _buildSectionHeader('Scores', Icons.sports_basketball, 5),
              _buildScoresSection(),

              // No Quick Actions section

              // Add extra padding at the bottom to prevent content from being cut off
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, int? tabIndex) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: Colors.orange,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          if (tabIndex != null)
            GestureDetector(
              onTap: () {
                // Navigate to the specific tab
                final tabController = DefaultTabController.of(context);
                tabController.animateTo(tabIndex);
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.grey[800],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'See All',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPeopleSection() {
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _users.length,
        itemBuilder: (context, index) {
          final user = _users[index];
          return GestureDetector(
            onTap: () {
              HapticFeedback.lightImpact();
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ProfilePage(),
                ),
              );
            },
            child: Container(
              margin: const EdgeInsets.only(right: 16),
              child: Column(
                children: [
                  // Profile image with gradient border
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.3),
                          blurRadius: 8,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(2), // Border width
                    child: ClipOval(
                      child: Image.network(
                        user.profileImageUrl ??
                            'https://via.placeholder.com/150',
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) => Container(
                          color: Colors.grey[800],
                          child: const Icon(Icons.person, color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Username
                  Text(
                    user.username,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCourtsSection() {
    return SizedBox(
      height: 140, // Further reduced height to prevent overflow
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _courts.length,
        itemBuilder: (context, index) {
          final court = _courts[index];
          return Container(
            width: MediaQuery.of(context).size.width *
                0.35, // Further reduced width
            height: 140, // Fixed height
            margin: const EdgeInsets.only(right: 16),
            // Wrap in ClipRRect to prevent overflow
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: OverflowBox(
                maxHeight: 140,
                maxWidth: MediaQuery.of(context).size.width * 0.35,
                child: CourtCard(
                  court: court,
                  onFollowTap: (court) {
                    HapticFeedback.mediumImpact();
                    setState(() {
                      court.isFollowing = !court.isFollowing;
                    });
                  },
                  onCardTap: (court) {
                    HapticFeedback.lightImpact();
                    CourtRoutes.navigateToCourtDetail(
                      context,
                      courtId: court.id,
                      isVerified: court.isVerified,
                    );
                  },
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEventsSection() {
    return SizedBox(
      height:
          520, // Further increased height to accommodate 500px event cards with complete host information
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _events.length,
        itemBuilder: (context, index) {
          final event = _events[index];
          return Container(
            width: MediaQuery.of(context).size.width *
                0.85, // Increased width to 85% to prevent cutoff and show more content
            margin: const EdgeInsets.only(right: 16),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: EventCard(
                event: event,
                onTap: () {
                  HapticFeedback.lightImpact();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => EventDetailPage(
                        eventId: event.id,
                        title: event.title,
                      ),
                    ),
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildScoresSection() {
    return SizedBox(
      height: 240, // Slightly increased height for ESPN card
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _scores.length,
        itemBuilder: (context, index) {
          final score = _scores[index];
          return Container(
            width: MediaQuery.of(context).size.width *
                0.75, // Slightly increased width
            margin: const EdgeInsets.only(right: 16),
            child: EspnScoreCard(
              homeTeamName: score.homeTeamName,
              awayTeamName: score.awayTeamName,
              homeScore: score.homeScore,
              awayScore: score.awayScore,
              gameStatus: score.gameStatus,
              gameDateTime: score.gameDateTime,
              courtName: score.courtName,
              courtLocation: score.courtLocation,
              hostName: score.hostName,
              leagueName: score.leagueName,
              homeTeamLogoUrl: score.homeTeamLogoUrl,
              awayTeamLogoUrl: score.awayTeamLogoUrl,
              onViewFullScore: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ScoreDetailScreen(score: score),
                  ),
                );
              },
              onShare: () {
                // Share score
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildQuickActionButtons() {
    final actions = [
      {
        'title': 'Teams',
        'icon': Icons.group,
        'tabIndex': 6,
        'gradient': const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF4A148C), Color(0xFF7B1FA2)],
        ),
      },
      {
        'title': 'Leagues',
        'icon': Icons.emoji_events,
        'tabIndex': 7,
        'gradient': const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0D47A1), Color(0xFF1976D2)],
        ),
      },
      {
        'title': 'Groups',
        'icon': Icons.people_alt,
        'tabIndex': 8,
        'gradient': const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1B5E20), Color(0xFF388E3C)],
        ),
      },
      {
        'title': 'Jobs',
        'icon': Icons.work,
        'tabIndex': 9,
        'gradient': const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFE65100), Color(0xFFEF6C00)],
        ),
      },
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12, // Reduced spacing
          mainAxisSpacing: 12, // Reduced spacing
          childAspectRatio: 3.0, // Adjusted for better fit on mobile
        ),
        itemCount: actions.length,
        itemBuilder: (context, index) {
          final action = actions[index];
          return GestureDetector(
            onTap: () {
              // Navigate to the specific tab using the parent TabController
              final tabController = DefaultTabController.of(context);
              // Animate to the specified tab index
              tabController.animateTo(action['tabIndex'] as int);

              // Print debug info
              print(
                  'Navigating to ${action['title']} tab (index: ${action['tabIndex']})');
            },
            child: Container(
              decoration: BoxDecoration(
                gradient: action['gradient'] as LinearGradient,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    action['icon'] as IconData,
                    color: Colors.white,
                    size: 20, // Smaller icon
                  ),
                  const SizedBox(width: 4), // Reduced spacing
                  Text(
                    action['title'] as String,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14, // Smaller text
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
