import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../bloc/courts_search_cubit.dart';
import '../../domain/models/court_model.dart' as search_models;
import 'court_card.dart';
import 'court_filter_row.dart';
import '../../../courts/presentation/routes/court_routes.dart';

class CourtsSearchResults extends StatefulWidget {
  final String searchQuery;
  const CourtsSearchResults({super.key, required this.searchQuery});

  @override
  State<CourtsSearchResults> createState() => _CourtsSearchResultsState();
}

class _CourtsSearchResultsState extends State<CourtsSearchResults> {
  String _selectedPrimaryFilter = 'Popular';
  String? _selectedSecondaryFilter;

  @override
  void initState() {
    super.initState();
    context.read<CourtsSearchCubit>().init(
          query: widget.searchQuery,
          selectedFilter: _selectedPrimaryFilter,
        );
  }

  @override
  void didUpdateWidget(CourtsSearchResults oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.searchQuery != oldWidget.searchQuery) {
      context.read<CourtsSearchCubit>().setQuery(widget.searchQuery);
    }
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          context.read<CourtsSearchCubit>().setFilter(filter);
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        // Apply combined filter logic here if needed
      }
    });
  }

  void _handleFollowTap(search_models.CourtModel court) {
    HapticFeedback.mediumImpact();
    CourtRoutes.navigateToCourtDetail(
      context,
      courtId: court.id,
      isVerified: court.isVerified,
    );
  }

  void _handleCardTap(search_models.CourtModel court) {
    HapticFeedback.lightImpact();
    CourtRoutes.navigateToCourtDetail(
      context,
      courtId: court.id,
      isVerified: court.isVerified,
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CourtsSearchCubit, CourtsSearchState>(
      builder: (context, state) {
        if (state.loading) {
          return const Scaffold(
            backgroundColor: Colors.black,
            body: Center(child: CircularProgressIndicator.adaptive()),
          );
        }

        if (state.error != null) {
          return Scaffold(
            backgroundColor: Colors.black,
            body: Center(
              child: Text(
                'Error: ${state.error}',
                style: const TextStyle(color: Colors.redAccent),
              ),
            ),
          );
        }

        final items = state.items;
        return Scaffold(
          backgroundColor: Colors.black,
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: CourtFilterRow(
                  selectedPrimaryFilter: _selectedPrimaryFilter,
                  selectedSecondaryFilter: _selectedSecondaryFilter,
                  onFilterSelected: _handleFilterSelected,
                ),
              ),
              Expanded(
                child: items.isEmpty
                    ? _buildEmptyState()
                    : Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: GridView.builder(
                          key: ValueKey(
                              '${state.query}:${state.selectedFilter}'),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 0.7,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                          ),
                          itemCount: items.length,
                          itemBuilder: (context, index) {
                            final c = items[index];
                            return CourtCard(
                              court: c,
                              onFollowTap: _handleFollowTap,
                              onCardTap: _handleCardTap,
                            );
                          },
                        ),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.sports_basketball, size: 64, color: Colors.orange[400]),
          const SizedBox(height: 16),
          const Text(
            'No courts found',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.searchQuery.isEmpty
                ? 'Try searching for courts in your area'
                : 'Try a different search term',
            style: TextStyle(color: Colors.grey[400], fontSize: 16),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
