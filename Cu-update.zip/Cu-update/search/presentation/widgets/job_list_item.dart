import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../../domain/models/job_model.dart';

/// A modern and beautiful job list item widget for the search results
class JobListItem extends StatelessWidget {
  /// The job data to display
  final JobModel job;
  
  /// Callback when the job item is tapped
  final VoidCallback? onTap;
  
  /// Callback when the apply button is tapped
  final Function(JobModel)? onApplyTap;

  /// Constructor
  const JobListItem({
    super.key,
    required this.job,
    this.onTap,
    this.onApplyTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2A2A2A),
              Color(0xFF1A1A1A),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildMinimalHeader(),
              const SizedBox(height: 8),
              _buildMinimalDetails(),
              const SizedBox(height: 8),
              _buildMinimalFooter(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMinimalHeader() {
    return Row(
      children: [
        // Simple orange icon
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: const Color(0xFFFF9800).withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(
            Icons.work,
            color: Color(0xFFFF9800),
            size: 20,
          ),
        ),
        const SizedBox(width: 12),
        // Title and company
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                job.title,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                job.posterName,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 13,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        // Simple job type badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: const Color(0xFFFF9800).withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            job.type,
            style: const TextStyle(
              color: Color(0xFFFF9800),
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMinimalDetails() {
    return Row(
      children: [
        // Location
        if (job.location != null && job.location!.isNotEmpty) ...[
          const Icon(
            Icons.location_on,
            size: 14,
            color: Colors.white60,
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Text(
              job.location!,
              style: const TextStyle(
                color: Colors.white60,
                fontSize: 13,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
        // Pay rate
        if (job.payRate != null && job.payRate!.isNotEmpty) ...[
          const SizedBox(width: 12),
          Text(
            job.payRate!,
            style: const TextStyle(
              color: Color(0xFFFF9800),
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildMinimalFooter() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Date - simplified
        if (job.date != null)
          Text(
            _formatDate(job.date!),
            style: const TextStyle(
              color: Colors.white60,
              fontSize: 12,
            ),
          )
        else
          const SizedBox.shrink(),
        // Apply button - minimal
        _buildMinimalApplyButton(),
      ],
    );
  }

  Widget _buildMinimalApplyButton() {
    final hasApplied = job.hasApplied;
    
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        onApplyTap?.call(job);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          gradient: hasApplied 
            ? null 
            : const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
          color: hasApplied ? Colors.transparent : null,
          borderRadius: BorderRadius.circular(16),
          border: hasApplied 
            ? Border.all(color: Colors.white30, width: 1)
            : null,
        ),
        child: Text(
          hasApplied ? 'Applied' : 'Apply',
          style: TextStyle(
            color: hasApplied ? Colors.white60 : Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }


  Widget _buildHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildPosterImage(),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                job.title,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _getJobTypeColor(),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      job.type,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    job.posterName,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 13,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPosterImage() {
    return Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF9800).withValues(alpha: 0.3),
            blurRadius: 8,
            spreadRadius: 2,
          ),
        ],
      ),
      padding: const EdgeInsets.all(2), // Border width
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: job.imageUrl != null
            ? Image.network(
                job.imageUrl!,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => _buildImagePlaceholder(),
              )
            : _buildImagePlaceholder(),
      ),
    );
  }

  Widget _buildImagePlaceholder() {
    return Container(
      color: Colors.grey[800],
      child: Center(
        child: Icon(
          _getJobTypeIcon(),
          color: Colors.white,
          size: 24,
        ),
      ),
    );
  }

  Widget _buildDescription() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        job.description!,
        style: TextStyle(
          color: Colors.grey[300],
          fontSize: 14,
          height: 1.4,
        ),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  Widget _buildDetails() {
    return Column(
      children: [
        if (job.location != null && job.location!.isNotEmpty)
          _buildDetailRow(Icons.location_on, job.location!),
        if (job.payRate != null && job.payRate!.isNotEmpty)
          _buildDetailRow(Icons.attach_money, job.payRate!),
        if (job.date != null)
          _buildDetailRow(Icons.calendar_today, _formatDate(job.date!)),
      ],
    );
  }

  Widget _buildDetailRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(
            icon,
            size: 16,
            color: const Color(0xFFFF9800),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 14,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        // Date posted or other info could go here
        const Spacer(),
        _buildApplyButton(),
      ],
    );
  }

  Widget _buildApplyButton() {
    final hasApplied = job.hasApplied;
    
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        if (onApplyTap != null) {
          onApplyTap!(job);
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          gradient: hasApplied 
              ? null 
              : const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          color: hasApplied ? Colors.transparent : null,
          borderRadius: BorderRadius.circular(20),
          border: hasApplied 
              ? Border.all(color: const Color(0xFFFF9800), width: 1) 
              : null,
        ),
        child: Text(
          hasApplied ? 'Applied' : 'Apply Now',
          style: TextStyle(
            color: hasApplied ? const Color(0xFFFF9800) : Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  Color _getJobTypeColor() {
    switch (job.type.toLowerCase()) {
      case 'referee':
        return Colors.blue;
      case 'videographer':
        return Colors.purple;
      case 'scorekeeper':
        return Colors.green;
      case 'trainer':
        return Colors.orange;
      case 'coach':
        return Colors.red;
      case 'event staff':
        return Colors.teal;
      case 'medical':
        return Colors.pink;
      default:
        return Colors.grey;
    }
  }

  IconData _getJobTypeIcon() {
    switch (job.type.toLowerCase()) {
      case 'referee':
        return Icons.sports_basketball;
      case 'videographer':
        return Icons.videocam;
      case 'scorekeeper':
        return Icons.scoreboard;
      case 'trainer':
        return Icons.sports_basketball;
      case 'coach':
        return Icons.sports_basketball;
      case 'event staff':
        return Icons.event;
      case 'medical':
        return Icons.medical_services;
      default:
        return Icons.sports_basketball;
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('MMM d, yyyy').format(date);
  }
}
