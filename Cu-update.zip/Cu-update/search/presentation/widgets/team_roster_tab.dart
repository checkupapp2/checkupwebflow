import 'package:flutter/material.dart';

/// Widget for displaying a team's roster
class TeamRosterTab extends StatefulWidget {
  /// Team ID
  final String teamId;
  
  /// Team name
  final String teamName;

  /// Constructor
  const TeamRosterTab({
    super.key,
    required this.teamId,
    required this.teamName,
  });

  @override
  State<TeamRosterTab> createState() => _TeamRosterTabState();
}

class _TeamRosterTabState extends State<TeamRosterTab> {
  String _selectedFilter = 'All';
  final List<String> _filters = ['All', 'Starters', 'Bench', 'Staff'];
  
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildFilterBar(),
        Expanded(
          child: _buildRosterList(),
        ),
      ],
    );
  }
  
  Widget _buildFilterBar() {
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _filters.length,
        itemBuilder: (context, index) {
          final filter = _filters[index];
          final isSelected = filter == _selectedFilter;
          
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedFilter = filter;
                });
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: isSelected
                      ? const LinearGradient(
                          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : null,
                  color: isSelected ? null : Colors.grey[900],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Center(
                  child: Text(
                    filter,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
  
  Widget _buildRosterList() {
    final filteredPlayers = _getFilteredPlayers();
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: filteredPlayers.length,
      itemBuilder: (context, index) {
        final player = filteredPlayers[index];
        return _buildPlayerCard(player);
      },
    );
  }
  
  List<Player> _getFilteredPlayers() {
    switch (_selectedFilter) {
      case 'Starters':
        return _mockPlayers.where((player) => player.isStarter).toList();
      case 'Bench':
        return _mockPlayers.where((player) => !player.isStarter && player.role == 'Player').toList();
      case 'Staff':
        return _mockPlayers.where((player) => player.role != 'Player').toList();
      case 'All':
      default:
        return _mockPlayers;
    }
  }
  
  Widget _buildPlayerCard(Player player) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[800]!, width: 1),
      ),
      child: InkWell(
        onTap: () {
          // Navigate to player profile
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              // Player image
              Hero(
                tag: 'player_${player.id}',
                child: Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(2),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(35),
                    child: player.imageUrl != null
                        ? Image.network(
                            player.imageUrl!,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) => _buildPlayerImagePlaceholder(),
                          )
                        : _buildPlayerImagePlaceholder(),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              
              // Player info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          player.name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(width: 8),
                        if (player.isStarter)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFF9800),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text(
                              'STARTER',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 8,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${player.position} • ${player.role}',
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _buildStatBadge('#${player.jerseyNumber}', Icons.tag),
                        const SizedBox(width: 12),
                        _buildStatBadge(player.height, Icons.height),
                        const SizedBox(width: 12),
                        _buildStatBadge('${player.age} yrs', Icons.cake),
                      ],
                    ),
                  ],
                ),
              ),
              
              // Jersey number for players
              if (player.role == 'Player')
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.grey[800],
                  ),
                  child: Center(
                    child: Text(
                      '${player.jerseyNumber}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildStatBadge(String text, IconData icon) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: const Color(0xFFFF9800),
          size: 12,
        ),
        const SizedBox(width: 4),
        Text(
          text,
          style: TextStyle(
            color: Colors.grey[300],
            fontSize: 12,
          ),
        ),
      ],
    );
  }
  
  Widget _buildPlayerImagePlaceholder() {
    return Container(
      color: Colors.grey[800],
      child: const Icon(
        Icons.person,
        color: Colors.white,
        size: 40,
      ),
    );
  }
  
  // Mock data for players
  final List<Player> _mockPlayers = [
    Player(
      id: '1',
      name: 'Michael Jordan',
      position: 'SG',
      role: 'Player',
      jerseyNumber: 23,
      height: '6\'6"',
      age: 28,
      imageUrl: 'https://randomuser.me/api/portraits/men/32.jpg',
      isStarter: true,
    ),
    Player(
      id: '2',
      name: 'Scottie Pippen',
      position: 'SF',
      role: 'Player',
      jerseyNumber: 33,
      height: '6\'8"',
      age: 26,
      imageUrl: 'https://randomuser.me/api/portraits/men/42.jpg',
      isStarter: true,
    ),
    Player(
      id: '3',
      name: 'Dennis Rodman',
      position: 'PF',
      role: 'Player',
      jerseyNumber: 91,
      height: '6\'7"',
      age: 30,
      imageUrl: 'https://randomuser.me/api/portraits/men/52.jpg',
      isStarter: true,
    ),
    Player(
      id: '4',
      name: 'Steve Kerr',
      position: 'PG',
      role: 'Player',
      jerseyNumber: 25,
      height: '6\'3"',
      age: 27,
      imageUrl: 'https://randomuser.me/api/portraits/men/62.jpg',
      isStarter: false,
    ),
    Player(
      id: '5',
      name: 'Luc Longley',
      position: 'C',
      role: 'Player',
      jerseyNumber: 13,
      height: '7\'2"',
      age: 29,
      imageUrl: 'https://randomuser.me/api/portraits/men/72.jpg',
      isStarter: true,
    ),
    Player(
      id: '6',
      name: 'Toni Kukoc',
      position: 'SF',
      role: 'Player',
      jerseyNumber: 7,
      height: '6\'10"',
      age: 27,
      imageUrl: 'https://randomuser.me/api/portraits/men/82.jpg',
      isStarter: false,
    ),
    Player(
      id: '7',
      name: 'Ron Harper',
      position: 'PG',
      role: 'Player',
      jerseyNumber: 9,
      height: '6\'6"',
      age: 31,
      imageUrl: 'https://randomuser.me/api/portraits/men/92.jpg',
      isStarter: true,
    ),
    Player(
      id: '8',
      name: 'Phil Jackson',
      position: '',
      role: 'Head Coach',
      jerseyNumber: 0,
      height: '6\'8"',
      age: 50,
      imageUrl: 'https://randomuser.me/api/portraits/men/22.jpg',
      isStarter: false,
    ),
    Player(
      id: '9',
      name: 'Tex Winter',
      position: '',
      role: 'Assistant Coach',
      jerseyNumber: 0,
      height: '6\'2"',
      age: 65,
      imageUrl: 'https://randomuser.me/api/portraits/men/12.jpg',
      isStarter: false,
    ),
    Player(
      id: '10',
      name: 'John Smith',
      position: '',
      role: 'Team Manager',
      jerseyNumber: 0,
      height: '5\'11"',
      age: 42,
      imageUrl: 'https://randomuser.me/api/portraits/men/2.jpg',
      isStarter: false,
    ),
  ];
}

/// Model class for player items
class Player {
  /// Unique ID
  final String id;
  
  /// Player name
  final String name;
  
  /// Player position (e.g., PG, SG, SF, PF, C)
  final String position;
  
  /// Player role (Player, Coach, etc.)
  final String role;
  
  /// Jersey number
  final int jerseyNumber;
  
  /// Player height
  final String height;
  
  /// Player age
  final int age;
  
  /// URL to player image
  final String? imageUrl;
  
  /// Whether the player is a starter
  final bool isStarter;

  /// Constructor
  Player({
    required this.id,
    required this.name,
    required this.position,
    required this.role,
    required this.jerseyNumber,
    required this.height,
    required this.age,
    this.imageUrl,
    this.isStarter = false,
  });
}
