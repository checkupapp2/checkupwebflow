import 'package:flutter/material.dart';
import '../../domain/models/score_model.dart';
import '../../domain/models/play_by_play_model.dart';

/// Widget for displaying the play-by-play tab in the score detail screen
class ScorePlayByPlayTab extends StatefulWidget {
  /// The score model
  final ScoreModel score;

  /// Constructor
  const ScorePlayByPlayTab({
    super.key,
    required this.score,
  });

  @override
  State<ScorePlayByPlayTab> createState() => _ScorePlayByPlayTabState();
}

class _ScorePlayByPlayTabState extends State<ScorePlayByPlayTab> {
  late List<PlayByPlayModel> _playByPlayEvents;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadPlayByPlayData();
  }

  Future<void> _loadPlayByPlayData() async {
    // Simulate API call with a delay
    await Future.delayed(const Duration(milliseconds: 800));
    
    // Get mock data
    _playByPlayEvents = PlayByPlayModel.getMockPlayByPlayEvents(widget.score.id);
    
    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return _buildLoadingState();
    }
    
    if (_playByPlayEvents.isEmpty) {
      return _buildEmptyState();
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _playByPlayEvents.length,
      itemBuilder: (context, index) {
        final event = _playByPlayEvents[index];
        
        // Group header for quarter/period
        if (event.isQuarterHeader) {
          return _buildQuarterHeader(event);
        }
        
        return _buildPlayByPlayItem(event);
      },
    );
  }
  
  Widget _buildLoadingState() {
    return const Center(
      child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
      ),
    );
  }
  
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.sports_basketball,
            size: 64,
            color: Colors.grey[700],
          ),
          const SizedBox(height: 16),
          Text(
            'No play-by-play data available',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Check back later for updates',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildQuarterHeader(PlayByPlayModel event) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 12),
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF3A3A3A),
            Color(0xFF252525),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Center(
        child: Text(
          event.description,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
      ),
    );
  }
  
  Widget _buildPlayByPlayItem(PlayByPlayModel event) {
    // Determine icon and color based on event type
    IconData icon;
    Color iconColor;
    
    switch (event.eventType) {
      case PlayByPlayEventType.score:
        icon = Icons.sports_score;
        iconColor = Colors.green;
        break;
      case PlayByPlayEventType.foul:
        icon = Icons.warning_amber;
        iconColor = Colors.amber;
        break;
      case PlayByPlayEventType.turnover:
        icon = Icons.change_circle;
        iconColor = Colors.red;
        break;
      case PlayByPlayEventType.timeout:
        icon = Icons.timer;
        iconColor = Colors.blue;
        break;
      case PlayByPlayEventType.substitution:
        icon = Icons.swap_horiz;
        iconColor = Colors.purple;
        break;
      default:
        icon = Icons.sports_basketball;
        iconColor = Colors.orange;
    }
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Time
          SizedBox(
            width: 50,
            child: Text(
              event.timeRemaining,
              style: TextStyle(
                color: Colors.grey[400],
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
          
          // Event icon
          Container(
            width: 32,
            height: 32,
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: Colors.grey[900],
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Colors.grey[800]!,
                width: 1,
              ),
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: 18,
            ),
          ),
          
          // Event description
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  event.playerName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  event.description,
                  style: TextStyle(
                    color: Colors.grey[300],
                    fontSize: 14,
                  ),
                ),
                if (event.score.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    'Score: ${event.score}',
                    style: TextStyle(
                      color: Colors.grey[500],
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ],
            ),
          ),
          
          // Team logo or indicator
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: event.isHomeTeam ? Colors.blue[900] : Colors.red[900],
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.grey[800]!,
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                event.isHomeTeam ? 'H' : 'A',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
