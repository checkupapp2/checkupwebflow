import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/user_model.dart';

/// A modern and beautiful user list item widget for the search results
class UserListItem extends StatelessWidget {
  /// The user data to display
  final UserModel user;
  
  /// Callback when the user item is tapped
  final VoidCallback? onTap;
  
  /// Callback when the follow button is tapped
  final Function(UserModel)? onFollowTap;

  /// Constructor
  const UserListItem({
    super.key,
    required this.user,
    this.onTap,
    this.onFollowTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.2),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(  
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Profile Image
              _buildProfileImage(),
              const SizedBox(width: 16),
              
              // User Info
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildUserName(),
                    const SizedBox(height: 4),
                    _buildUsername(),
                    const SizedBox(height: 4),
                    _buildProfileType(),
                    if ((user.city != null && user.city!.isNotEmpty) || 
                        (user.state != null && user.state!.isNotEmpty)) ...[  
                      const SizedBox(height: 6),
                      _buildLocation(),
                    ],
                    if (user.bio != null && user.bio!.isNotEmpty) ...[  
                      const SizedBox(height: 8),
                      _buildBio(),
                    ],
                    const SizedBox(height: 8),
                    _buildStats(),
                  ],
                ),
              ),
              
              // Follow Button
              _buildFollowButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileImage() {
    return Hero(
      tag: 'user_${user.id}',
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            colors: user.isActive 
                ? [const Color(0xFF4CAF50), const Color(0xFF2E7D32)] // Green for active
                : [const Color(0xFFFF9800), const Color(0xFFFF5722)], // Orange for inactive
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: user.isActive 
                  ? const Color(0xFF4CAF50).withValues(alpha: 0.3)
                  : const Color(0xFFFF9800).withValues(alpha: 0.3),
              blurRadius: 8,
              spreadRadius: 2,
            ),
          ],
        ),
        padding: const EdgeInsets.all(2), // Border width
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: user.profileImageUrl != null
              ? Image.network(
                  user.profileImageUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => _buildProfilePlaceholder(),
                )
              : _buildProfilePlaceholder(),
        ),
      ),
    );
  }

  Widget _buildProfilePlaceholder() {
    return Container(
      color: Colors.grey[800],
      child: Center(
        child: Text(
          user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
      ),
    );
  }

  Widget _buildUserName() {
    return Text(
      user.name,
      style: const TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.bold,
        fontSize: 16,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildUsername() {
    return Text(
      '@${user.username}',
      style: TextStyle(
        color: Colors.grey[400],
        fontSize: 14,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildBio() {
    return Text(
      user.bio!,
      style: TextStyle(
        color: Colors.grey[300],
        fontSize: 13,
        height: 1.2,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildProfileType() {
    // If no profile type is available, return an empty container
    if (user.profileType == null || user.profileType!.isEmpty) {
      return Container();
    }
    
    // Determine background color based on profile type
    Color backgroundColor;
    switch (user.profileType?.toLowerCase()) {
      case 'player':
        backgroundColor = Colors.blue;
        break;
      case 'host':
        backgroundColor = Colors.purple;
        break;
      case 'trainer':
        backgroundColor = Colors.orange;
        break;
      case 'referee':
        backgroundColor = Colors.red;
        break;
      case 'media':
        backgroundColor = Colors.teal;
        break;
      default:
        backgroundColor = Colors.grey;
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: backgroundColor.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: backgroundColor, width: 1),
      ),
      child: Text(
        user.profileType!,
        style: TextStyle(
          color: backgroundColor,
          fontSize: 11,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  
  Widget _buildLocation() {
    String locationText = '';
    
    if (user.city != null && user.city!.isNotEmpty) {
      locationText = user.city!;
    }
    
    if (user.state != null && user.state!.isNotEmpty) {
      if (locationText.isNotEmpty) {
        locationText += ', ${user.state!}';
      } else {
        locationText = user.state!;
      }
    }
    
    return Text(
      locationText,
      style: TextStyle(
        color: Colors.grey[400],
        fontSize: 13,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }
  
  // This method is kept for compatibility but not used in the UI anymore
  Widget _buildStats() {
    return Container();
  }

  Widget _buildFollowButton() {
    final isFollowing = user.isFollowing;
    
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        if (onFollowTap != null) {
          onFollowTap!(user);
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          gradient: isFollowing 
              ? null 
              : const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          color: isFollowing ? Colors.transparent : null,
          borderRadius: BorderRadius.circular(20),
          border: isFollowing 
              ? Border.all(color: const Color(0xFFFF9800), width: 1) 
              : null,
        ),
        child: Text(
          isFollowing ? 'Following' : 'Follow',
          style: TextStyle(
            color: isFollowing ? const Color(0xFFFF9800) : Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
      ),
    );
  }
}
