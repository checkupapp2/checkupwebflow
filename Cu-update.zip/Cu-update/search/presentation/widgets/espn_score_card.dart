import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/// Reusable ESPN-style score card widget
class EspnScoreCard extends StatelessWidget {
  /// Home team name
  final String homeTeamName;
  
  /// Away team name
  final String awayTeamName;
  
  /// Home team score (null if game hasn't started)
  final int? homeScore;
  
  /// Away team score (null if game hasn't started)
  final int? awayScore;
  
  /// Game status (e.g., 'final', 'in progress', 'upcoming')
  final String gameStatus;
  
  /// Game date and time
  final DateTime gameDateTime;
  
  /// Court/venue name
  final String courtName;
  
  /// Court/venue location
  final String courtLocation;
  
  /// Host name
  final String hostName;
  
  /// League name (optional)
  final String? leagueName;
  
  /// Home team logo URL (optional)
  final String? homeTeamLogoUrl;
  
  /// Away team logo URL (optional)
  final String? awayTeamLogoUrl;
  
  /// Callback when view full score button is tapped
  final VoidCallback? onViewFullScore;
  
  /// Callback when share button is tapped
  final VoidCallback? onShare;

  /// Constructor
  const EspnScoreCard({
    super.key,
    required this.homeTeamName,
    required this.awayTeamName,
    this.homeScore,
    this.awayScore,
    required this.gameStatus,
    required this.gameDateTime,
    required this.courtName,
    required this.courtLocation,
    required this.hostName,
    this.leagueName,
    this.homeTeamLogoUrl,
    this.awayTeamLogoUrl,
    this.onViewFullScore,
    this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    // Determine border color based on game status
    Color borderColor;
    switch (gameStatus.toLowerCase()) {
      case 'in progress':
        borderColor = Colors.green.shade700;
        break;
      case 'upcoming':
        borderColor = Colors.orange.shade700;
        break;
      default:
        borderColor = Colors.transparent;
    }
    
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: borderColor,
          width: borderColor != Colors.transparent ? 1.5 : 0,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 10,
            spreadRadius: 0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Game status and date
          _buildGameHeader(),
          
          // Teams and scores
          _buildScoreSection(),
          
          // Divider
          Divider(
            color: Colors.grey[700],
            thickness: 1,
            height: 1,
            indent: 12,
            endIndent: 12,
          ),
          
          // Game details (court, host)
          _buildGameDetails(),
          
          // Action buttons (only show if callbacks are provided)
          if (onViewFullScore != null || onShare != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: _buildActionButtons(),
            ),
        ],
      ),
    );
  }

  Widget _buildGameHeader() {
    final dateFormat = DateFormat('MMM d • h:mm a');
    final formattedDate = dateFormat.format(gameDateTime);
    
    Color statusColor;
    Color textColor = Colors.white;
    String statusText = gameStatus;
    
    switch (gameStatus.toLowerCase()) {
      case 'final':
        statusColor = Colors.grey.shade700;
        break;
      case 'in progress':
        statusColor = Colors.green.shade600;
        statusText = 'LIVE';
        break;
      case 'upcoming':
        statusColor = Colors.orange.shade600;
        break;
      default:
        statusColor = Colors.grey.shade700;
    }
    
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 2),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF333333),
            const Color(0xFF2A2A2A).withValues(alpha: 0),
          ],
        ),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: statusColor.withValues(alpha: 0.4),
                        blurRadius: 4,
                        spreadRadius: 0,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Text(
                    statusText.toUpperCase(),
                    style: TextStyle(
                      color: textColor,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                if (leagueName != null) ...[
                  const SizedBox(width: 6),
                  Flexible(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFF444444),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        leagueName!,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 9,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.2,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            formattedDate,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScoreSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          // Teams section (stacked vertically)
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Home team row
                Row(
                  children: [
                    _buildTeamLogo(homeTeamLogoUrl, size: 28),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        homeTeamName,
                        style: TextStyle(
                          color: (homeScore != null && awayScore != null && homeScore! > awayScore!) 
                              ? Colors.orange.shade300 
                              : Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 0.2,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                // Away team row
                Row(
                  children: [
                    _buildTeamLogo(awayTeamLogoUrl, size: 28),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        awayTeamName,
                        style: TextStyle(
                          color: (homeScore != null && awayScore != null && awayScore! > homeScore!) 
                              ? Colors.orange.shade300 
                              : Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 0.2,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          const SizedBox(width: 12),
          
          // Score display (vertical layout)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF3A3A3A),
                  Color(0xFF252525),
                ],
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 6,
                  spreadRadius: 0,
                  offset: const Offset(0, 3),
                ),
              ],
              border: Border.all(
                color: const Color(0xFF444444),
                width: 1,
              ),
            ),
            child: homeScore != null && awayScore != null
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Home team score
                      Text(
                        homeScore.toString(),
                        style: TextStyle(
                          color: homeScore! > awayScore! ? Colors.orange.shade300 : Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 2),
                      // Divider
                      Container(
                        height: 1,
                        width: 16,
                        color: Colors.grey[600],
                      ),
                      const SizedBox(height: 2),
                      // Away team score
                      Text(
                        awayScore.toString(),
                        style: TextStyle(
                          color: awayScore! > homeScore! ? Colors.orange.shade300 : Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  )
                : Text(
                    'VS',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamLogo(String? logoUrl, {double size = 40}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF444444),
            Color(0xFF2A2A2A),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 3,
            spreadRadius: 0,
            offset: const Offset(0, 1),
          ),
        ],
        border: Border.all(
          color: const Color(0xFF444444),
          width: 1,
        ),
      ),
      child: logoUrl != null && logoUrl.isNotEmpty
          ? ClipOval(
              child: Image.network(
                logoUrl,
                width: size,
                height: size,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return _buildFallbackLogo(size);
                },
              ),
            )
          : _buildFallbackLogo(size),
    );
  }

  Widget _buildFallbackLogo(double size) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF444444),
            Color(0xFF2A2A2A),
          ],
        ),
      ),
      child: const Icon(
        Icons.sports_basketball,
        color: Colors.orange,
        size: 16,
      ),
    );
  }

  Widget _buildGameDetails() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 2),
      child: Column(
        children: [
          // Court info row
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: const Color(0xFF333333),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.2),
                      blurRadius: 3,
                      spreadRadius: 0,
                      offset: const Offset(0, 1),
                    ),
                  ],
                  border: Border.all(
                    color: const Color(0xFF444444),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.location_on,
                  color: Colors.lightBlue,
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      courtName,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.2,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      courtLocation,
                      style: TextStyle(
                        color: Colors.grey[500],
                        fontSize: 10,
                        letterSpacing: 0.1,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 3),
          // Host info row
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: const Color(0xFF333333),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.2),
                      blurRadius: 3,
                      spreadRadius: 0,
                      offset: const Offset(0, 1),
                    ),
                  ],
                  border: Border.all(
                    color: const Color(0xFF444444),
                    width: 1,
                  ),
                ),
                child: const Icon(
                  Icons.person,
                  color: Colors.lightBlue,
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  hostName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.2,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 4),
      child: Row(
        children: [
          // View Full Score Button
          if (onViewFullScore != null)
            Expanded(
              child: ElevatedButton(
                onPressed: onViewFullScore,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF333333),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  minimumSize: const Size(0, 28),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 2,
                  textStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                ),
                child: const Text('View Score'),
              ),
            ),
          
          if (onViewFullScore != null && onShare != null)
            const SizedBox(width: 8),
          
          // Share Button
          if (onShare != null)
            Container(
              height: 28,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFFFF9800),
                    Color(0xFFFF5722),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.orange.withValues(alpha: 0.3),
                    blurRadius: 4,
                    spreadRadius: 0,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: onShare,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                  minimumSize: const Size(0, 28),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 0,
                  textStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.share, size: 14),
                    SizedBox(width: 4),
                    Text('Share'),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
