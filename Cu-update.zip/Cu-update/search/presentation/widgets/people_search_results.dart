import 'package:flutter/material.dart';
import '../../domain/models/user_model.dart';
import 'user_list_item.dart';
import 'people_filter_row.dart';

/// Widget for displaying people search results
class PeopleSearchResults extends StatefulWidget {
  /// Search query
  final String searchQuery;

  /// Constructor
  const PeopleSearchResults({
    super.key,
    required this.searchQuery,
  });

  @override
  State<PeopleSearchResults> createState() => _PeopleSearchResultsState();
}

class _PeopleSearchResultsState extends State<PeopleSearchResults> {
  // Currently selected primary filter (Popular, Nearby, Friends)
  String _selectedPrimaryFilter = 'Popular';
  // Currently selected secondary filter (Players, Hosts, etc.)
  String? _selectedSecondaryFilter;
  // Filtered users
  List<UserModel> _filteredUsers = [];

  @override
  void initState() {
    super.initState();
    // Initialize filtered users
    _applyFilters();
  }

  // Mock data for demonstration
  final List<UserModel> _mockUsers = [
    UserModel(
      id: '1',
      name: 'John Smith',
      username: 'johnsmith',
      profileImageUrl: 'https://randomuser.me/api/portraits/men/1.jpg',
      bio: 'Basketball player | Fitness enthusiast',
      followers: 1200,
      following: 300,
      isFollowing: false,
      isActive: true,
      profileType: 'Player',
      city: 'Chicago',
      state: 'IL',
    ),
    UserModel(
      id: '2',
      name: 'Emma Johnson',
      username: 'emma_j',
      profileImageUrl: 'https://randomuser.me/api/portraits/women/2.jpg',
      bio: 'Tennis player | Fitness enthusiast',
      followers: 3287,
      following: 412,
      isFollowing: true,
      isActive: false,
      profileType: 'Player',
      city: 'New York',
      state: 'NY',
    ),
    UserModel(
      id: '3',
      name: 'Michael Brown',
      username: 'mike_brown',
      profileImageUrl: 'https://randomuser.me/api/portraits/men/3.jpg',
      bio: 'Tournament host | Event organizer',
      followers: 876,
      following: 230,
      isFollowing: false,
      isActive: true,
      profileType: 'Host',
      city: 'Los Angeles',
      state: 'CA',
    ),
    UserModel(
      id: '4',
      name: 'Sophia Garcia',
      username: 'sophiag',
      profileImageUrl: 'https://randomuser.me/api/portraits/women/4.jpg',
      bio: 'Volleyball player | Beach volleyball enthusiast',
      followers: 2156,
      following: 305,
      isFollowing: true,
      isActive: true,
      profileType: 'Player',
      city: 'Miami',
      state: 'FL',
    ),
    UserModel(
      id: '5',
      name: 'Olivia Martinez',
      username: 'olivia_m',
      profileImageUrl: 'https://randomuser.me/api/portraits/women/5.jpg',
      bio: 'Yoga instructor | Personal trainer',
      followers: 5432,
      following: 267,
      isFollowing: true,
      isActive: false,
      profileType: 'Trainer',
      city: 'Seattle',
      state: 'WA',
    ),
    UserModel(
      id: '6',
      name: 'William Davis',
      username: 'will_davis',
      profileImageUrl: 'https://randomuser.me/api/portraits/men/6.jpg',
      bio: 'Basketball coach | Trainer for youth teams',
      followers: 8765,
      following: 189,
      isFollowing: false,
      isActive: true,
      profileType: 'Trainer',
      city: 'Boston',
      state: 'MA',
    ),
    UserModel(
      id: '7',
      name: 'Ava Wilson',
      username: 'ava_wilson',
      profileImageUrl: 'https://randomuser.me/api/portraits/women/7.jpg',
      bio: 'Sports journalist | Media correspondent',
      followers: 4321,
      following: 567,
      isFollowing: false,
      isActive: false,
      profileType: 'Media',
      city: 'Atlanta',
      state: 'GA',
    ),
    UserModel(
      id: '8',
      name: 'James Taylor',
      username: 'james_t',
      profileImageUrl: 'https://randomuser.me/api/portraits/men/8.jpg',
      bio: 'Basketball referee | Certified ref for college games',
      followers: 3456,
      following: 432,
      isFollowing: false,
      isActive: true,
      profileType: 'Referee',
      city: 'Dallas',
      state: 'TX',
    ),
    UserModel(
      id: '9',
      name: 'Sarah Johnson',
      username: 'sarah_j',
      profileImageUrl: 'https://randomuser.me/api/portraits/women/9.jpg',
      bio: 'Event host | Community organizer',
      followers: 2890,
      following: 345,
      isFollowing: true,
      isActive: true,
      profileType: 'Host',
      city: 'Denver',
      state: 'CO',
    ),
    UserModel(
      id: '10',
      name: 'David Miller',
      username: 'david_m',
      profileImageUrl: 'https://randomuser.me/api/portraits/men/10.jpg',
      bio: 'Sports photographer | Media professional',
      followers: 1765,
      following: 289,
      isFollowing: false,
      isActive: false,
      profileType: 'Media',
      city: 'Phoenix',
      state: 'AZ',
    ),
  ];

  void _applyFilters() {
    // First filter by search query
    List<UserModel> filteredByQuery = _mockUsers;
    if (widget.searchQuery.isNotEmpty) {
      filteredByQuery = _mockUsers.where((user) {
        return user.name
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase()) ||
            user.username
                .toLowerCase()
                .contains(widget.searchQuery.toLowerCase());
      }).toList();
    }

    // Apply secondary filter first (Players, Hosts, etc.)
    List<UserModel> filteredBySecondary = filteredByQuery;
    if (_selectedSecondaryFilter != null) {
      switch (_selectedSecondaryFilter) {
        case 'Players':
          filteredBySecondary = filteredByQuery
              .where((user) =>
                  user.bio != null &&
                  user.bio!.toLowerCase().contains('player'))
              .toList();
          break;
        case 'Hosts':
          filteredBySecondary = filteredByQuery
              .where((user) =>
                  user.bio != null && user.bio!.toLowerCase().contains('host'))
              .toList();
          break;
        case 'Trainers':
          filteredBySecondary = filteredByQuery
              .where((user) =>
                  user.bio != null &&
                  (user.bio!.toLowerCase().contains('trainer') ||
                      user.bio!.toLowerCase().contains('coach')))
              .toList();
          break;
        case 'Refs':
          filteredBySecondary = filteredByQuery
              .where((user) =>
                  user.bio != null &&
                  (user.bio!.toLowerCase().contains('referee') ||
                      user.bio!.toLowerCase().contains('ref')))
              .toList();
          break;
        case 'Media':
          filteredBySecondary = filteredByQuery
              .where((user) =>
                  user.bio != null &&
                  (user.bio!.toLowerCase().contains('media') ||
                      user.bio!.toLowerCase().contains('journalist') ||
                      user.bio!.toLowerCase().contains('photographer')))
              .toList();
          break;
      }
    }

    // Then apply primary filter (Popular, Nearby, Friends)
    switch (_selectedPrimaryFilter) {
      case 'Popular':
        _filteredUsers = List.from(filteredBySecondary)
          ..sort((a, b) => b.followers.compareTo(a.followers));
        break;
      case 'Nearby':
        // Mock implementation - sort by city/state proximity
        _filteredUsers = List.from(filteredBySecondary)
          ..sort((a, b) => (a.city ?? '').compareTo(b.city ?? ''));
        break;
      case 'Friends':
        // Mock implementation - show followed users first
        _filteredUsers = List.from(filteredBySecondary)
          ..sort((a, b) => b.isFollowing ? 1 : -1);
        break;
      default:
        _filteredUsers = filteredBySecondary;
    }
  }

  void _handleFilterSelected(String filter) {
    setState(() {
      // Check if it's a primary filter (dropdown options)
      if (['Popular', 'Nearby', 'Friends'].contains(filter)) {
        if (_selectedPrimaryFilter != filter) {
          _selectedPrimaryFilter = filter;
          _applyFilters();
        }
      } else {
        // It's a secondary filter (regular chips)
        if (_selectedSecondaryFilter == filter) {
          // Deselect if already selected
          _selectedSecondaryFilter = null;
        } else {
          _selectedSecondaryFilter = filter;
        }
        _applyFilters();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          // Filter row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: PeopleFilterRow(
              selectedPrimaryFilter: _selectedPrimaryFilter,
              selectedSecondaryFilter: _selectedSecondaryFilter,
              onFilterSelected: _handleFilterSelected,
            ),
          ),
          // User list
          Expanded(
            child: _buildUserList(),
          ),
        ],
      ),
    );
  }

  Widget _buildUserList() {
    if (_filteredUsers.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      itemCount: _filteredUsers.length,
      itemBuilder: (context, index) {
        final user = _filteredUsers[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: UserListItem(
            user: user,
            onTap: () {
              // Navigate to user profile (to be implemented)
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Viewing ${user.name}\'s profile')),
              );
            },
            onFollowTap: (user) {
              // Toggle follow status
              setState(() {
                final updatedUser = UserModel(
                  id: user.id,
                  name: user.name,
                  username: user.username,
                  profileImageUrl: user.profileImageUrl,
                  bio: user.bio,
                  followers: user.isFollowing
                      ? user.followers - 1
                      : user.followers + 1,
                  following: user.following,
                  isFollowing: !user.isFollowing,
                  isActive: user.isActive,
                  profileType: user.profileType,
                  city: user.city,
                  state: user.state,
                );

                final index = _mockUsers.indexWhere((u) => u.id == user.id);
                if (index != -1) {
                  _mockUsers[index] = updatedUser;
                }
              });
            },
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.person_search,
            size: 64,
            color: Colors.grey[700],
          ),
          const SizedBox(height: 16),
          Text(
            'No users found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            widget.searchQuery.isEmpty
                ? 'Start typing to search for people'
                : 'Try a different search term',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
