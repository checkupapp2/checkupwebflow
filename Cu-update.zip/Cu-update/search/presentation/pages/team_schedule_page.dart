import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/team_model.dart';
import '../widgets/espn_score_card.dart';
import '../../../events/presentation/pages/event_detail_page.dart';
import 'score_detail_screen.dart';
import '../../domain/models/score_model.dart';
import '../../../leagues/presentation/pages/league_host_create_schedule_page.dart';

/// Team Schedule Page that displays the schedule for a specific team
class TeamSchedulePage extends StatefulWidget {
  /// The team to display schedule for
  final TeamModel team;

  /// Whether this is the host view with editing capabilities
  final bool isHostView;

  /// Constructor
  const TeamSchedulePage({
    super.key,
    required this.team,
    this.isHostView = false,
  });

  @override
  State<TeamSchedulePage> createState() => _TeamSchedulePageState();
}

class _TeamSchedulePageState extends State<TeamSchedulePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  DateTime? _selectedDate; // null means "ALL" is selected

  // Mock events data
  final List<Map<String, dynamic>> _teamEvents = [
    {
      'id': '1',
      'title': 'NYC Streetball Tournament',
      'date': 'Sep 15, 2024',
      'time': '6:49 PM',
      'location': 'Team Practice Court',
      'sport': 'Basketball',
      'eventType': 'League Games',
      'icon': Icons.sports_basketball,
      'thumbnail':
          'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    },
    {
      'id': '2',
      'title': 'Golden State Warriors Summer Tournament',
      'date': 'Sat, Sep 6',
      'time': '6:49 PM',
      'location': 'Main Arena',
      'sport': 'Basketball',
      'eventType': 'Tournament',
      'icon': Icons.emoji_events,
      'thumbnail':
          'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    },
    {
      'id': '3',
      'title': 'Hoops for Hope Charity Game',
      'date': 'Sat, Sep 13',
      'time': '6:49 PM',
      'location': 'Community Center',
      'sport': 'Basketball',
      'eventType': 'Charity',
      'icon': Icons.volunteer_activism,
      'thumbnail':
          'https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    },
  ];

  // Get all unique dates from events and games
  List<DateTime> get _availableDates {
    final dates = <DateTime>{};

    // Add event dates
    for (final event in _teamEvents) {
      final dateStr = event['date'] as String;
      // Parse date string like "Mon, Sep 1" to DateTime
      final now = DateTime.now();
      final month = _parseMonth(dateStr);
      final day = _parseDay(dateStr);
      dates.add(DateTime(now.year, month, day));
    }

    // Add game dates (for now using current date + index as mock)
    final baseDate = DateTime.now();
    for (int i = 0; i < _teamGames.length; i++) {
      dates.add(baseDate.add(Duration(days: i * 2)));
    }

    final sortedDates = dates.toList()..sort();
    return sortedDates;
  }

  int _parseMonth(String dateStr) {
    if (dateStr.contains('Sep')) return 9;
    if (dateStr.contains('Oct')) return 10;
    if (dateStr.contains('Nov')) return 11;
    if (dateStr.contains('Dec')) return 12;
    return DateTime.now().month;
  }

  int _parseDay(String dateStr) {
    final parts = dateStr.split(' ');
    if (parts.length >= 3) {
      return int.tryParse(parts[2]) ?? DateTime.now().day;
    }
    return DateTime.now().day;
  }

  // Mock game data for the team
  List<Map<String, dynamic>> get _teamGames => [
        {
          'id': '1',
          'time': '7:30 PM EDT',
          'location': 'Madison Square Garden',
          'court': 'Court 1',
          'team1': widget.team.name,
          'team1Code': widget.team.name.substring(0, 3).toUpperCase(),
          'team1Status': 'H',
          'team1Score': 89,
          'team2': 'Boston Celtics',
          'team2Code': 'BOS',
          'team2Status': 'A',
          'team2Score': 85,
          'pool': 'NBA Regular Season',
          'status': 'final',
          'final': true,
        },
        {
          'id': '2',
          'time': '8:00 PM EDT',
          'location': 'Staples Center',
          'court': 'Main Court',
          'team1': 'Miami Heat',
          'team1Code': 'MIA',
          'team1Status': 'H',
          'team2': widget.team.name,
          'team2Code': widget.team.name.substring(0, 3).toUpperCase(),
          'team2Status': 'A',
          'pool': 'NBA Regular Season',
          'status': 'upcoming',
          'final': false,
        },
        {
          'id': '3',
          'time': '6:30 PM EDT',
          'location': 'United Center',
          'court': 'Main Court',
          'team1': widget.team.name,
          'team1Code': widget.team.name.substring(0, 3).toUpperCase(),
          'team1Status': 'A',
          'team1Score': 102,
          'team2': 'Chicago Bulls',
          'team2Code': 'CHI',
          'team2Status': 'H',
          'team2Score': 98,
          'pool': 'NBA Regular Season',
          'status': 'final',
          'final': true,
        },
        {
          'id': '4',
          'time': '9:00 PM EDT',
          'location': 'Chase Center',
          'court': 'Main Court',
          'team1': 'Golden State Warriors',
          'team1Code': 'GSW',
          'team1Status': 'H',
          'team2': widget.team.name,
          'team2Code': widget.team.name.substring(0, 3).toUpperCase(),
          'team2Status': 'A',
          'pool': 'NBA Regular Season',
          'status': 'upcoming',
          'final': false,
        },
      ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          '${widget.team.name} S...',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: () {
              HapticFeedback.mediumImpact();
              setState(() {
                // Refresh schedule data
              });
            },
          ),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: _buildDatePicker(),
          ),
          SliverToBoxAdapter(
            child: _buildTabBar(),
          ),
          SliverToBoxAdapter(
            child: _buildSearchBar(),
          ),
          SliverFillRemaining(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildEventsTab(),
                _buildGamesTab(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton:
          widget.isHostView ? _buildHostActionButtons() : null,
    );
  }

  Widget _buildHostActionButtons() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        FloatingActionButton(
          heroTag: "add_event",
          onPressed: () {
            HapticFeedback.mediumImpact();
            _showCreateEventDialog();
          },
          backgroundColor: const Color(0xFFFF9800),
          child: const Icon(Icons.event_note, color: Colors.white),
        ),
        const SizedBox(height: 16),
        FloatingActionButton(
          heroTag: "add_game",
          onPressed: () {
            HapticFeedback.mediumImpact();
            _showCreateGameDialog();
          },
          backgroundColor: const Color(0xFF4CAF50),
          child: const Icon(Icons.sports_basketball, color: Colors.white),
        ),
      ],
    );
  }

  Widget _buildDatePicker() {
    final availableDates = _availableDates;

    return Container(
      height: 80,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: availableDates.length + 1, // +1 for ALL button
        itemBuilder: (context, index) {
          // First item is the ALL button
          if (index == 0) {
            final isSelected = _selectedDate == null;
            return GestureDetector(
              onTap: () {
                HapticFeedback.mediumImpact();
                setState(() {
                  _selectedDate = null; // null means show all
                });
              },
              child: Container(
                width: 70,
                margin: const EdgeInsets.only(right: 12),
                decoration: BoxDecoration(
                  gradient: isSelected
                      ? const LinearGradient(
                          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : null,
                  color: isSelected ? null : const Color(0xFF1A1A1A),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected
                        ? Colors.transparent
                        : Colors.grey.withValues(alpha: 0.3),
                    width: 1,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'ALL',
                      style: TextStyle(
                        color: isSelected ? Colors.white : Colors.grey[400],
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          // Date buttons (index - 1 because ALL button takes index 0)
          final date = availableDates[index - 1];
          final isSelected = _selectedDate != null &&
              _selectedDate!.day == date.day &&
              _selectedDate!.month == date.month;

          return GestureDetector(
            onTap: () {
              HapticFeedback.mediumImpact();
              setState(() {
                _selectedDate = date;
              });
            },
            child: Container(
              width: 70,
              margin: const EdgeInsets.only(right: 12),
              decoration: BoxDecoration(
                gradient: isSelected
                    ? const LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : null,
                color: isSelected ? null : const Color(0xFF1A1A1A),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isSelected
                      ? Colors.transparent
                      : Colors.grey.withValues(alpha: 0.3),
                  width: 1,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    _getDayName(date.weekday).toUpperCase(),
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    date.day.toString(),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  String _getDayName(int weekday) {
    switch (weekday) {
      case 1:
        return 'Mon';
      case 2:
        return 'Tue';
      case 3:
        return 'Wed';
      case 4:
        return 'Thu';
      case 5:
        return 'Fri';
      case 6:
        return 'Sat';
      case 7:
        return 'Sun';
      default:
        return 'Mon';
    }
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(25),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(25),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey[400],
        labelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
        unselectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.normal,
          fontSize: 16,
        ),
        dividerColor: Colors.transparent,
        tabs: const [
          Tab(text: 'Events'),
          Tab(text: 'Games'),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFF333333),
          width: 1,
        ),
      ),
      child: TextField(
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: 'Search games...',
          hintStyle: const TextStyle(color: Color(0xFF888888)),
          prefixIcon: const Icon(Icons.search, color: Color(0xFF888888)),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),
    );
  }

  Widget _buildEventsTab() {
    // If no date selected (ALL), show all events
    final filteredEvents = _selectedDate == null
        ? _teamEvents
        : _teamEvents.where((event) {
            final eventMonth = _parseMonth(event['date']);
            final eventDay = _parseDay(event['date']);
            return _selectedDate!.month == eventMonth &&
                _selectedDate!.day == eventDay;
          }).toList();

    final headerText = _selectedDate == null
        ? '${filteredEvents.length} total event${filteredEvents.length != 1 ? 's' : ''}'
        : '${filteredEvents.length} event${filteredEvents.length != 1 ? 's' : ''} on ${_formatSelectedDate()}';

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              headerText,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          ...filteredEvents
              .map((event) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildEventCard(event),
                  ))
              .toList(),
          const SizedBox(height: 100), // Extra space at bottom
        ],
      ),
    );
  }

  Widget _buildGamesTab() {
    // Show all games when ALL is selected, otherwise show all games for now
    // (In a real app, you'd filter games by selected date similar to events)
    final filteredGames = _teamGames;

    final headerText = _selectedDate == null
        ? '${filteredGames.length} total game${filteredGames.length != 1 ? 's' : ''}'
        : '${filteredGames.length} game${filteredGames.length != 1 ? 's' : ''} scheduled';

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              headerText,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          ...filteredGames
              .map((game) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 16),
                      child: _buildGameCard(game),
                    ),
                  ))
              .toList(),
          const SizedBox(height: 100), // Extra space at bottom
        ],
      ),
    );
  }

  String _formatSelectedDate() {
    if (_selectedDate == null) return 'All dates';
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return '${_getDayName(_selectedDate!.weekday)}, ${months[_selectedDate!.month - 1]} ${_selectedDate!.day}';
  }

  Widget _buildEventCard(Map<String, dynamic> event) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.mediumImpact();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => EventDetailPage(
              eventId: event['id'],
              title: event['title'],
              // eventType: event['eventType'],
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1A),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey[800]!, width: 1),
        ),
        child: Row(
          children: [
            // Square thumbnail on the left
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    width: 60,
                    height: 60,
                    child: Image.network(
                      event['thumbnail'],
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Container(
                        color: const Color(0xFF2A2A2A),
                        child: const Center(
                          child: Icon(
                            Icons.image_not_supported,
                            color: Colors.grey,
                            size: 24,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // Event type icon overlay
                Positioned(
                  top: 4,
                  left: 4,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      event['icon'],
                      color: const Color(0xFFFF9800),
                      size: 14,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            // Event details on the right
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    event['title'],
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(
                        Icons.access_time,
                        color: Colors.grey[400],
                        size: 12,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${event['date']} • ${event['time']}',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Icon(
                        Icons.location_on,
                        color: Colors.grey[400],
                        size: 12,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          event['location'],
                          style: TextStyle(
                            color: Colors.grey[400],
                            fontSize: 12,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF9800).withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      event['eventType'] ?? event['sport'],
                      style: const TextStyle(
                        color: Color(0xFFFF9800),
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Host edit/remove options
            if (widget.isHostView)
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert, color: Colors.grey),
                color: const Color(0xFF2A2A2A),
                onSelected: (value) {
                  switch (value) {
                    case 'edit':
                      _editEvent(event);
                      break;
                    case 'remove':
                      _removeEvent(event);
                      break;
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(Icons.edit, color: Colors.white, size: 20),
                        SizedBox(width: 8),
                        Text('Edit', style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'remove',
                    child: Row(
                      children: [
                        Icon(Icons.delete, color: Colors.red, size: 20),
                        SizedBox(width: 8),
                        Text('Remove', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameCard(Map<String, dynamic> game) {
    final isTeamHome = game['team1'] == widget.team.name;
    final teamScore = isTeamHome ? game['team1Score'] : game['team2Score'];
    final opponentScore = isTeamHome ? game['team2Score'] : game['team1Score'];
    final opponent = isTeamHome ? game['team2'] : game['team1'];

    // Determine home and away teams for ESPN card
    final homeTeam = isTeamHome ? widget.team.name : opponent;
    final awayTeam = isTeamHome ? opponent : widget.team.name;
    final homeScore = isTeamHome ? teamScore : opponentScore;
    final awayScore = isTeamHome ? opponentScore : teamScore;

    return EspnScoreCard(
      homeTeamName: homeTeam,
      awayTeamName: awayTeam,
      homeScore: homeScore,
      awayScore: awayScore,
      gameStatus: game['status'] ?? 'upcoming',
      gameDateTime: DateTime.now(), // You can parse from game['time'] if needed
      courtName: game['court'] ?? 'Main Court',
      courtLocation: game['location'] ?? 'Unknown Location',
      hostName: 'Game Host', // You can add this to your game data
      leagueName: game['pool'],
      onViewFullScore: () {
        HapticFeedback.mediumImpact();
        // Create a ScoreModel from the game data
        final scoreModel = ScoreModel(
          id: game['id'],
          homeTeamName: homeTeam,
          awayTeamName: awayTeam,
          homeScore: homeScore ?? 0,
          awayScore: awayScore ?? 0,
          gameDateTime: DateTime.now(),
          gameStatus: game['status'] ?? 'upcoming',
          courtName: game['court'] ?? 'Main Court',
          courtLocation: game['location'] ?? 'Unknown Location',
          hostName: 'Game Host',
          gameType: '5v5',
          leagueName: game['pool'],
        );

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ScoreDetailScreen(score: scoreModel),
          ),
        );
      },
      onShare: () {
        HapticFeedback.mediumImpact();
        // Share game details
      },
    );
  }

  Widget _buildEventInfo(Map<String, dynamic> game) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: game['status'] == 'final'
                  ? Colors.green.withValues(alpha: 0.2)
                  : game['status'] == 'in progress'
                      ? Colors.orange.withValues(alpha: 0.2)
                      : Colors.blue.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              game['status'] == 'final'
                  ? 'FINAL'
                  : game['status'] == 'in progress'
                      ? 'LIVE'
                      : 'UPCOMING',
              style: TextStyle(
                color: game['status'] == 'final'
                    ? Colors.green
                    : game['status'] == 'in progress'
                        ? Colors.orange
                        : Colors.blue,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGameTimeLocation(Map<String, dynamic> game) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: Row(
        children: [
          Icon(
            Icons.access_time,
            color: Colors.grey[400],
            size: 16,
          ),
          const SizedBox(width: 8),
          Text(
            game['time'],
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(width: 16),
          Icon(
            Icons.location_on,
            color: Colors.grey[400],
            size: 16,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              game['location'],
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamRow(
      String teamName, String teamCode, String status, int? score,
      {bool isWinner = false}) {
    return Column(
      crossAxisAlignment:
          status == 'H' ? CrossAxisAlignment.start : CrossAxisAlignment.end,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (status == 'H') ...[
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    teamCode,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
            ],
            Flexible(
              child: Text(
                teamName,
                style: TextStyle(
                  color: isWinner ? const Color(0xFFFF9800) : Colors.white,
                  fontSize: 14,
                  fontWeight: isWinner ? FontWeight.bold : FontWeight.w500,
                ),
                overflow: TextOverflow.ellipsis,
                textAlign: status == 'H' ? TextAlign.left : TextAlign.right,
              ),
            ),
            if (status == 'A') ...[
              const SizedBox(width: 8),
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    teamCode,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 4),
        Text(
          status == 'H' ? 'Home' : 'Away',
          style: TextStyle(
            color: Colors.grey[500],
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildPoolInfo(Map<String, dynamic> game) {
    final poolName = game['pool'] ?? 'Regular Season';

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF333333),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: const Color(0xFF444444),
                      width: 1,
                    ),
                  ),
                  child: const Icon(
                    Icons.sports_basketball,
                    color: Colors.orange,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    poolName,
                    style: const TextStyle(
                      color: Color(0xFFB0B0B0),
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          if (game['court'] != null)
            Container(
              margin: const EdgeInsets.only(left: 8),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFF333333),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: const Color(0xFF444444),
                  width: 1,
                ),
              ),
              child: Text(
                game['court'],
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _showCreateEventDialog() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const LeagueHostCreateSchedulePage(),
      ),
    );
  }

  void _showCreateGameDialog() {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const LeagueHostCreateSchedulePage(),
      ),
    );
  }

  IconData _getEventIcon(String eventType) {
    switch (eventType.toLowerCase()) {
      case 'tournament':
        return Icons.emoji_events;
      case 'charity':
        return Icons.volunteer_activism;
      case 'practice':
        return Icons.fitness_center;
      default:
        return Icons.sports_basketball;
    }
  }

  String _getMonthName(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }

  void _editEvent(Map<String, dynamic> event) {
    final titleController = TextEditingController(text: event['title']);
    final locationController = TextEditingController(text: event['location']);
    String selectedEventType = event['eventType'];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text(
            'Edit Event',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Event Title',
                    labelStyle: TextStyle(color: Colors.grey[400]),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: locationController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Location',
                    labelStyle: TextStyle(color: Colors.grey[400]),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: selectedEventType,
                  dropdownColor: const Color(0xFF2A2A2A),
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Event Type',
                    labelStyle: TextStyle(color: Colors.grey[400]),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  items: ['League Games', 'Tournament', 'Charity', 'Practice']
                      .map((type) {
                    return DropdownMenuItem(value: type, child: Text(type));
                  }).toList(),
                  onChanged: (value) {
                    setDialogState(() {
                      selectedEventType = value!;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () {
                if (titleController.text.isNotEmpty &&
                    locationController.text.isNotEmpty) {
                  setState(() {
                    final index =
                        _teamEvents.indexWhere((e) => e['id'] == event['id']);
                    if (index != -1) {
                      _teamEvents[index] = {
                        ...event,
                        'title': titleController.text,
                        'location': locationController.text,
                        'eventType': selectedEventType,
                        'icon': _getEventIcon(selectedEventType),
                      };
                    }
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Event "${titleController.text}" updated'),
                      backgroundColor: const Color(0xFF4CAF50),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF9800)),
              child: const Text('Update Event'),
            ),
          ],
        ),
      ),
    );
  }

  void _removeEvent(Map<String, dynamic> event) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title:
            const Text('Remove Event', style: TextStyle(color: Colors.white)),
        content: Text(
          'Are you sure you want to remove "${event['title']}"?',
          style: TextStyle(color: Colors.grey[400]),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _teamEvents.removeWhere((e) => e['id'] == event['id']);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Event "${event['title']}" removed'),
                  backgroundColor: Colors.red,
                ),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }
}
