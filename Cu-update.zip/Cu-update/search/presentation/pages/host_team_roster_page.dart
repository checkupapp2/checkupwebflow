import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/team_model.dart';

/// Host Team Roster Page with editing capabilities
class HostTeamRosterPage extends StatefulWidget {
  /// The team to display roster for
  final TeamModel team;

  /// Constructor
  const HostTeamRosterPage({
    super.key,
    required this.team,
  });

  @override
  State<HostTeamRosterPage> createState() => _HostTeamRosterPageState();
}

class _HostTeamRosterPageState extends State<HostTeamRosterPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Mock player data for the team - simplified with profile types
  List<Map<String, dynamic>> _players = [
    {
      'id': '1',
      'name': 'LeBron James',
      'number': '6',
      'position': 'SF',
      'isStarter': true,
      'isCaptain': true,
      'hasProfile': true,
      'profileImage': null,
    },
    {
      'id': '2',
      'name': 'Anthony Davis',
      'number': '3',
      'position': 'PF/C',
      'isStarter': true,
      'isCaptain': false,
      'hasProfile': true,
      'profileImage': null,
    },
    {
      'id': '3',
      'name': 'Austin Reaves',
      'number': '15',
      'position': 'SG',
      'isStarter': true,
      'isCaptain': false,
      'hasProfile': false,
      'profileImage': null,
    },
    {
      'id': '4',
      'name': 'Rui Hachimura',
      'number': '28',
      'position': 'PF',
      'isStarter': true,
      'isCaptain': false,
      'hasProfile': true,
      'profileImage': null,
    },
    {
      'id': '5',
      'name': 'D\'Angelo Russell',
      'number': '1',
      'position': 'PG',
      'isStarter': true,
      'isCaptain': false,
      'hasProfile': false,
      'profileImage': null,
    },
  ];

  // Mock staff data for the team
  List<Map<String, dynamic>> _staff = [
    {
      'id': '1',
      'name': 'Darvin Ham',
      'role': 'Head Coach',
      'experience': 8,
      'hasProfile': true,
    },
    {
      'id': '2',
      'name': 'Phil Handy',
      'role': 'Assistant Coach',
      'experience': 15,
      'hasProfile': true,
    },
    {
      'id': '3',
      'name': 'Rob Pelinka',
      'role': 'General Manager',
      'experience': 12,
      'hasProfile': false,
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          '${widget.team.name} Roster',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: Colors.white),
            onPressed: _showAddPlayerOptions,
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Tab Bar
          _buildTabBar(),

          const SizedBox(height: 16),

          // Tab Content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildPlayersTab(),
                _buildStaffTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.grey[900]!, Colors.black],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.1),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.grey[400],
          indicatorSize: TabBarIndicatorSize.tab,
          indicator: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          indicatorPadding: const EdgeInsets.all(4),
          labelStyle: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15,
            letterSpacing: 0.5,
          ),
          unselectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 15,
            letterSpacing: 0.3,
          ),
          dividerColor: Colors.transparent,
          overlayColor: MaterialStateProperty.all(Colors.transparent),
          splashFactory: NoSplash.splashFactory,
          tabs: const [
            Tab(
              height: 48,
              child: Text('Players'),
            ),
            Tab(
              height: 48,
              child: Text('Staff'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlayersTab() {
    final starters =
        _players.where((player) => player['isStarter'] == true).toList();
    final bench =
        _players.where((player) => player['isStarter'] == false).toList();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Starters section
          _buildSectionHeader(
              'Starters', starters.length, () => _showAddPlayerOptions()),
          ...starters.map((player) => _buildPlayerCard(player)),

          const SizedBox(height: 16),

          // Bench section
          _buildSectionHeader(
              'Bench', bench.length, () => _showAddPlayerOptions()),
          ...bench.map((player) => _buildPlayerCard(player)),

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildStaffTab() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(
              'Coaching Staff', _staff.length, () => _showAddStaffOptions()),
          ..._staff.map((staff) => _buildStaffCard(staff)),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title, int count, VoidCallback onAdd) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFFF9800).withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '$count',
                  style: const TextStyle(
                    color: Color(0xFFFF9800),
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          IconButton(
            icon:
                const Icon(Icons.add_circle_outline, color: Color(0xFFFF9800)),
            onPressed: onAdd,
          ),
        ],
      ),
    );
  }

  void _showAddPlayerOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFF1A1A1A),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(top: 12),
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Add Player',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            _buildAddOption(
              icon: Icons.search,
              title: 'Add Existing User',
              subtitle: 'Search for users with profiles',
              onTap: () {
                Navigator.pop(context);
                _showSearchUsersDialog();
              },
            ),
            _buildAddOption(
              icon: Icons.person_add,
              title: 'Add Manual Entry',
              subtitle: 'Create a roster entry manually',
              onTap: () {
                Navigator.pop(context);
                _showAddManualPlayerDialog();
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  void _showAddStaffOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFF1A1A1A),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(top: 12),
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Add Staff Member',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            _buildAddOption(
              icon: Icons.search,
              title: 'Add Existing User',
              subtitle: 'Search for users with profiles',
              onTap: () {
                Navigator.pop(context);
                _showSearchUsersDialog(isStaff: true);
              },
            ),
            _buildAddOption(
              icon: Icons.person_add,
              title: 'Add Manual Entry',
              subtitle: 'Create a staff entry manually',
              onTap: () {
                Navigator.pop(context);
                _showAddManualStaffDialog();
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildAddOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPlayerCard(Map<String, dynamic> player) {
    final hasProfile = player['hasProfile'] ?? false;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: hasProfile
              ? const Color(0xFFFF9800).withValues(alpha: 0.3)
              : Colors.white.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            HapticFeedback.mediumImpact();
            if (hasProfile) {
              // Show profile for users with connected profiles
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Opening ${player['name']}\'s profile',
                    style: const TextStyle(color: Colors.white),
                  ),
                  backgroundColor: const Color(0xFFFF9800),
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  margin: const EdgeInsets.all(10),
                ),
              );
            } else {
              // Show edit dialog only for manual entries
              _editPlayer(player);
            }
          },
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Player avatar
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    gradient: hasProfile
                        ? const LinearGradient(
                            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : LinearGradient(
                            colors: [Colors.grey[600]!, Colors.grey[800]!],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                    borderRadius: BorderRadius.circular(28),
                    border: hasProfile
                        ? Border.all(
                            color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                            width: 2)
                        : null,
                  ),
                  child: Stack(
                    children: [
                      Center(
                        child: Text(
                          player['name']
                              .split(' ')
                              .map((n) => n[0])
                              .take(2)
                              .join(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      if (hasProfile)
                        Positioned(
                          bottom: 2,
                          right: 2,
                          child: Container(
                            width: 16,
                            height: 16,
                            decoration: BoxDecoration(
                              color: const Color(0xFF4CAF50),
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                            child: const Icon(
                              Icons.person,
                              color: Colors.white,
                              size: 8,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),

                // Player info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              player['name'],
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          if (player['isCaptain'] == true)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFF9800).withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Text(
                                'C',
                                style: TextStyle(
                                  color: Color(0xFFFF9800),
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              '#${player['number']}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            player['position'],
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const Spacer(),
                          if (hasProfile)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: const Color(0xFF4CAF50).withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Text(
                                'Profile',
                                style: TextStyle(
                                  color: Color(0xFF4CAF50),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            )
                          else
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.grey.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                'Manual',
                                style: TextStyle(
                                  color: Colors.grey[400],
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Edit/Remove options
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert, color: Colors.grey),
                  color: const Color(0xFF2A2A2A),
                  onSelected: (value) {
                    switch (value) {
                      case 'edit':
                        _editPlayer(player);
                        break;
                      case 'switch':
                        _switchPlayer(player);
                        break;
                      case 'remove':
                        _removePlayer(player);
                        break;
                    }
                  },
                  itemBuilder: (context) => [
                    if (!hasProfile)
                      const PopupMenuItem(
                        value: 'edit',
                        child: Row(
                          children: [
                            Icon(Icons.edit, color: Colors.white, size: 20),
                            SizedBox(width: 8),
                            Text('Edit', style: TextStyle(color: Colors.white)),
                          ],
                        ),
                      ),
                    if (hasProfile)
                      const PopupMenuItem(
                        value: 'switch',
                        child: Row(
                          children: [
                            Icon(Icons.swap_horiz,
                                color: Colors.blue, size: 20),
                            SizedBox(width: 8),
                            Text('Switch Player',
                                style: TextStyle(color: Colors.white)),
                          ],
                        ),
                      ),
                    const PopupMenuItem(
                      value: 'remove',
                      child: Row(
                        children: [
                          Icon(Icons.delete, color: Colors.red, size: 20),
                          SizedBox(width: 8),
                          Text('Remove', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStaffCard(Map<String, dynamic> staff) {
    final hasProfile = staff['hasProfile'] ?? false;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: hasProfile
              ? const Color(0xFFFF9800).withValues(alpha: 0.3)
              : Colors.white.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            HapticFeedback.mediumImpact();
            if (hasProfile) {
              // Show profile for users with connected profiles
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Opening ${staff['name']}\'s profile',
                    style: const TextStyle(color: Colors.white),
                  ),
                  backgroundColor: const Color(0xFFFF9800),
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  margin: const EdgeInsets.all(10),
                ),
              );
            } else {
              // Show edit dialog only for manual entries
              _editStaff(staff);
            }
          },
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Staff avatar
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    gradient: hasProfile
                        ? const LinearGradient(
                            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : LinearGradient(
                            colors: [Colors.grey[600]!, Colors.grey[800]!],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                    borderRadius: BorderRadius.circular(28),
                    border: hasProfile
                        ? Border.all(
                            color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                            width: 2)
                        : null,
                  ),
                  child: Stack(
                    children: [
                      Center(
                        child: Icon(
                          _getStaffIcon(staff['role']),
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      if (hasProfile)
                        Positioned(
                          bottom: 2,
                          right: 2,
                          child: Container(
                            width: 16,
                            height: 16,
                            decoration: BoxDecoration(
                              color: const Color(0xFF4CAF50),
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                            child: const Icon(
                              Icons.person,
                              color: Colors.white,
                              size: 8,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),

                // Staff info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        staff['name'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        staff['role'],
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                // Experience and profile status
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        '${staff['experience']}y',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (hasProfile)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: const Color(0xFF4CAF50).withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          'Profile',
                          style: TextStyle(
                            color: Color(0xFF4CAF50),
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      )
                    else
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.grey.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'Manual',
                          style: TextStyle(
                            color: Colors.grey[400],
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                  ],
                ),

                // Edit/Remove options
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert, color: Colors.grey),
                  color: const Color(0xFF2A2A2A),
                  onSelected: (value) {
                    switch (value) {
                      case 'edit':
                        _editStaff(staff);
                        break;
                      case 'profile':
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Opening ${staff['name']}\'s profile',
                              style: const TextStyle(color: Colors.white),
                            ),
                            backgroundColor: const Color(0xFFFF9800),
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            margin: const EdgeInsets.all(10),
                          ),
                        );
                        break;
                      case 'remove':
                        _removeStaff(staff);
                        break;
                    }
                  },
                  itemBuilder: (context) => [
                    if (!hasProfile)
                      const PopupMenuItem(
                        value: 'edit',
                        child: Row(
                          children: [
                            Icon(Icons.edit, color: Colors.white, size: 20),
                            SizedBox(width: 8),
                            Text('Edit', style: TextStyle(color: Colors.white)),
                          ],
                        ),
                      ),
                    if (hasProfile)
                      const PopupMenuItem(
                        value: 'profile',
                        child: Row(
                          children: [
                            Icon(Icons.person,
                                color: Color(0xFFFF9800), size: 20),
                            SizedBox(width: 8),
                            Text('View Profile',
                                style: TextStyle(color: Colors.white)),
                          ],
                        ),
                      ),
                    const PopupMenuItem(
                      value: 'remove',
                      child: Row(
                        children: [
                          Icon(Icons.delete, color: Colors.red, size: 20),
                          SizedBox(width: 8),
                          Text('Remove', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  IconData _getStaffIcon(String role) {
    switch (role.toLowerCase()) {
      case 'head coach':
        return Icons.sports;
      case 'assistant coach':
        return Icons.assistant;
      case 'general manager':
        return Icons.manage_accounts;
      case 'head trainer':
        return Icons.fitness_center;
      case 'trainer':
        return Icons.fitness_center;
      default:
        return Icons.person;
    }
  }

  void _showSearchUsersDialog({bool isStaff = false}) {
    final searchController = TextEditingController();
    final mockUsers = [
      {
        'id': '1',
        'name': 'Alex Johnson',
        'username': '@alexj',
        'avatar': '🏀',
        'position': 'PG'
      },
      {
        'id': '2',
        'name': 'Sarah Williams',
        'username': '@sarahw',
        'avatar': '⚡',
        'position': 'SG'
      },
      {
        'id': '3',
        'name': 'Mike Davis',
        'username': '@miked',
        'avatar': '🔥',
        'position': 'SF'
      },
      {
        'id': '4',
        'name': 'Jordan Smith',
        'username': '@jordans',
        'avatar': '🌟',
        'position': 'PF'
      },
      {
        'id': '5',
        'name': 'Taylor Brown',
        'username': '@taylorb',
        'avatar': '💎',
        'position': 'C'
      },
    ];

    List<Map<String, dynamic>> filteredUsers = List.from(mockUsers);

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text(
            isStaff ? 'Add Staff Member' : 'Add Player',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SizedBox(
            width: double.maxFinite,
            height: 400,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Modern search field
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2A2A),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey[700]!, width: 1),
                  ),
                  child: TextField(
                    controller: searchController,
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                    onChanged: (value) {
                      setDialogState(() {
                        filteredUsers = mockUsers.where((user) {
                          return user['name']!
                                  .toLowerCase()
                                  .contains(value.toLowerCase()) ||
                              user['username']!
                                  .toLowerCase()
                                  .contains(value.toLowerCase());
                        }).toList();
                      });
                    },
                    decoration: InputDecoration(
                      hintText: isStaff
                          ? 'Search for staff members...'
                          : 'Search for players...',
                      hintStyle:
                          TextStyle(color: Colors.grey[400], fontSize: 16),
                      prefixIcon: const Icon(Icons.search,
                          color: Color(0xFFFF9800), size: 24),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 16),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                // Results header
                if (filteredUsers.isNotEmpty) ...[
                  Row(
                    children: [
                      Text(
                        'Found ${filteredUsers.length} ${isStaff ? 'staff members' : 'players'}',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                ],
                // User list
                Expanded(
                  child: filteredUsers.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.search_off,
                                  color: Colors.grey[600], size: 48),
                              const SizedBox(height: 16),
                              Text(
                                'No users found',
                                style: TextStyle(
                                    color: Colors.grey[400], fontSize: 16),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Try a different search term',
                                style: TextStyle(
                                    color: Colors.grey[600], fontSize: 14),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: filteredUsers.length,
                          itemBuilder: (context, index) {
                            final user = filteredUsers[index];
                            return Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              decoration: BoxDecoration(
                                color: const Color(0xFF2A2A2A),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: Colors.grey[800]!, width: 1),
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 8),
                                leading: Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [
                                        Color(0xFFFF9800),
                                        Color(0xFFFF5722)
                                      ],
                                    ),
                                    borderRadius: BorderRadius.circular(24),
                                  ),
                                  child: Center(
                                    child: Text(
                                      user['avatar']!,
                                      style: const TextStyle(fontSize: 20),
                                    ),
                                  ),
                                ),
                                title: Text(
                                  user['name']!,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                subtitle: Row(
                                  children: [
                                    Text(
                                      user['username']!,
                                      style: TextStyle(
                                          color: Colors.grey[400],
                                          fontSize: 14),
                                    ),
                                    if (!isStaff &&
                                        user['position'] != null) ...[
                                      const SizedBox(width: 8),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 6, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFF9800)
                                              .withValues(alpha: 0.2),
                                          borderRadius:
                                              BorderRadius.circular(4),
                                        ),
                                        child: Text(
                                          user['position']!,
                                          style: const TextStyle(
                                            color: Color(0xFFFF9800),
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                                trailing: const Icon(Icons.add_circle_outline,
                                    color: Color(0xFFFF9800)),
                                onTap: () {
                                  Navigator.pop(context);
                                  _addExistingUser(user, isStaff);
                                },
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Cancel',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${filteredUsers.length} ${isStaff ? 'Staff' : 'Players'} Available',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _addExistingUser(Map<String, dynamic> user, bool isStaff) {
    setState(() {
      if (isStaff) {
        _staff.add({
          'id': DateTime.now().millisecondsSinceEpoch.toString(),
          'name': user['name'],
          'role': 'Assistant Coach',
          'experience': 5,
          'hasProfile': true,
        });
      } else {
        _players.add({
          'id': DateTime.now().millisecondsSinceEpoch.toString(),
          'name': user['name'],
          'number': '${_players.length + 1}',
          'position': 'PG',
          'isStarter': false,
          'isCaptain': false,
          'hasProfile': true,
          'profileImage': null,
        });
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${user['name']} added to roster'),
        backgroundColor: const Color(0xFF4CAF50),
      ),
    );
  }

  void _showAddManualPlayerDialog() {
    final nameController = TextEditingController();
    final numberController = TextEditingController();
    String selectedPosition = 'PG';
    bool isStarter = false;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title: const Text('Add Manual Player',
              style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Player Name',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: numberController,
                style: const TextStyle(color: Colors.white),
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Jersey Number',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedPosition,
                dropdownColor: const Color(0xFF2A2A2A),
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Position',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                items: ['PG', 'SG', 'SF', 'PF', 'C'].map((position) {
                  return DropdownMenuItem(
                    value: position,
                    child: Text(position),
                  );
                }).toList(),
                onChanged: (value) {
                  setDialogState(() {
                    selectedPosition = value!;
                  });
                },
              ),
              const SizedBox(height: 16),
              CheckboxListTile(
                title: const Text('Starter',
                    style: TextStyle(color: Colors.white)),
                value: isStarter,
                activeColor: const Color(0xFFFF9800),
                onChanged: (value) {
                  setDialogState(() {
                    isStarter = value!;
                  });
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.isNotEmpty &&
                    numberController.text.isNotEmpty) {
                  setState(() {
                    _players.add({
                      'id': DateTime.now().millisecondsSinceEpoch.toString(),
                      'name': nameController.text,
                      'number': numberController.text,
                      'position': selectedPosition,
                      'isStarter': isStarter,
                      'isCaptain': false,
                      'hasProfile': false,
                      'profileImage': null,
                    });
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${nameController.text} added to roster'),
                      backgroundColor: const Color(0xFF4CAF50),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF9800),
              ),
              child: const Text('Add Player'),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddManualStaffDialog() {
    final nameController = TextEditingController();
    String selectedRole = 'Assistant Coach';
    int experience = 1;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title: const Text('Add Manual Staff',
              style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Staff Name',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedRole,
                dropdownColor: const Color(0xFF2A2A2A),
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Role',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                items: [
                  'Head Coach',
                  'Assistant Coach',
                  'General Manager',
                  'Head Trainer',
                  'Trainer'
                ].map((role) {
                  return DropdownMenuItem(
                    value: role,
                    child: Text(role),
                  );
                }).toList(),
                onChanged: (value) {
                  setDialogState(() {
                    selectedRole = value!;
                  });
                },
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Text('Experience: ',
                      style: TextStyle(color: Colors.grey[400])),
                  Expanded(
                    child: Slider(
                      value: experience.toDouble(),
                      min: 1,
                      max: 30,
                      divisions: 29,
                      activeColor: const Color(0xFFFF9800),
                      label: '$experience years',
                      onChanged: (value) {
                        setDialogState(() {
                          experience = value.round();
                        });
                      },
                    ),
                  ),
                  Text('$experience yrs',
                      style: const TextStyle(color: Colors.white)),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.isNotEmpty) {
                  setState(() {
                    _staff.add({
                      'id': DateTime.now().millisecondsSinceEpoch.toString(),
                      'name': nameController.text,
                      'role': selectedRole,
                      'experience': experience,
                      'hasProfile': false,
                    });
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${nameController.text} added to staff'),
                      backgroundColor: const Color(0xFF4CAF50),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF9800),
              ),
              child: const Text('Add Staff'),
            ),
          ],
        ),
      ),
    );
  }

  void _editPlayer(Map<String, dynamic> player) {
    final nameController = TextEditingController(text: player['name']);
    final numberController = TextEditingController(text: player['number']);
    String selectedPosition = player['position'];
    bool isStarter = player['isStarter'];
    bool isCaptain = player['isCaptain'];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title:
              const Text('Edit Player', style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Player Name',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: numberController,
                style: const TextStyle(color: Colors.white),
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Jersey Number',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedPosition,
                dropdownColor: const Color(0xFF2A2A2A),
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Position',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                items: ['PG', 'SG', 'SF', 'PF', 'C'].map((position) {
                  return DropdownMenuItem(
                    value: position,
                    child: Text(position),
                  );
                }).toList(),
                onChanged: (value) {
                  setDialogState(() {
                    selectedPosition = value!;
                  });
                },
              ),
              const SizedBox(height: 16),
              CheckboxListTile(
                title: const Text('Starter',
                    style: TextStyle(color: Colors.white)),
                value: isStarter,
                activeColor: const Color(0xFFFF9800),
                onChanged: (value) {
                  setDialogState(() {
                    isStarter = value!;
                  });
                },
              ),
              CheckboxListTile(
                title: const Text('Captain',
                    style: TextStyle(color: Colors.white)),
                value: isCaptain,
                activeColor: const Color(0xFFFF9800),
                onChanged: (value) {
                  setDialogState(() {
                    isCaptain = value!;
                  });
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  final index =
                      _players.indexWhere((p) => p['id'] == player['id']);
                  if (index != -1) {
                    _players[index] = {
                      ...player,
                      'name': nameController.text,
                      'number': numberController.text,
                      'position': selectedPosition,
                      'isStarter': isStarter,
                      'isCaptain': isCaptain,
                    };
                  }
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('${nameController.text} updated'),
                    backgroundColor: const Color(0xFF4CAF50),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF9800),
              ),
              child: const Text('Update'),
            ),
          ],
        ),
      ),
    );
  }

  void _editStaff(Map<String, dynamic> staff) {
    final nameController = TextEditingController(text: staff['name']);
    String selectedRole = staff['role'];
    int experience = staff['experience'];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title:
              const Text('Edit Staff', style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Staff Name',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedRole,
                dropdownColor: const Color(0xFF2A2A2A),
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Role',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                items: [
                  'Head Coach',
                  'Assistant Coach',
                  'General Manager',
                  'Head Trainer',
                  'Trainer'
                ].map((role) {
                  return DropdownMenuItem(
                    value: role,
                    child: Text(role),
                  );
                }).toList(),
                onChanged: (value) {
                  setDialogState(() {
                    selectedRole = value!;
                  });
                },
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Text('Experience: ',
                      style: TextStyle(color: Colors.grey[400])),
                  Expanded(
                    child: Slider(
                      value: experience.toDouble(),
                      min: 1,
                      max: 30,
                      divisions: 29,
                      activeColor: const Color(0xFFFF9800),
                      label: '$experience years',
                      onChanged: (value) {
                        setDialogState(() {
                          experience = value.round();
                        });
                      },
                    ),
                  ),
                  Text('$experience yrs',
                      style: const TextStyle(color: Colors.white)),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  final index =
                      _staff.indexWhere((s) => s['id'] == staff['id']);
                  if (index != -1) {
                    _staff[index] = {
                      ...staff,
                      'name': nameController.text,
                      'role': selectedRole,
                      'experience': experience,
                    };
                  }
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('${nameController.text} updated'),
                    backgroundColor: const Color(0xFF4CAF50),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF9800),
              ),
              child: const Text('Update'),
            ),
          ],
        ),
      ),
    );
  }

  void _removePlayer(Map<String, dynamic> player) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title:
            const Text('Remove Player', style: TextStyle(color: Colors.white)),
        content: Text(
          'Are you sure you want to remove ${player['name']} from the roster?',
          style: TextStyle(color: Colors.grey[400]),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _players.removeWhere((p) => p['id'] == player['id']);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${player['name']} removed from roster'),
                  backgroundColor: Colors.red,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }

  void _removeStaff(Map<String, dynamic> staff) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title:
            const Text('Remove Staff', style: TextStyle(color: Colors.white)),
        content: Text(
          'Are you sure you want to remove ${staff['name']} from the staff?',
          style: TextStyle(color: Colors.grey[400]),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _staff.removeWhere((s) => s['id'] == staff['id']);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${staff['name']} removed from staff'),
                  backgroundColor: Colors.red,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }

  void _switchPlayer(Map<String, dynamic> player) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Switch ${player['name']}',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Choose how to replace ${player['name']} on the roster:',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 20),
            _buildSwitchOption(
              icon: Icons.search,
              title: 'Replace with Existing User',
              subtitle: 'Search for users with profiles',
              onTap: () {
                Navigator.pop(context);
                _showSwitchPlayerDialog(player);
              },
            ),
            const SizedBox(height: 12),
            _buildSwitchOption(
              icon: Icons.person_add,
              title: 'Replace with Manual Entry',
              subtitle: 'Create a new roster entry',
              onTap: () {
                Navigator.pop(context);
                _switchToManualEntry(player);
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSwitchOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF2A2A2A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey[800]!, width: 1),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
            ],
          ),
        ),
      ),
    );
  }

  void _showSwitchPlayerDialog(Map<String, dynamic> currentPlayer) {
    final searchController = TextEditingController();
    final mockUsers = [
      {
        'id': '1',
        'name': 'Alex Johnson',
        'username': '@alexj',
        'avatar': '🏀',
        'position': 'PG'
      },
      {
        'id': '2',
        'name': 'Sarah Williams',
        'username': '@sarahw',
        'avatar': '⚡',
        'position': 'SG'
      },
      {
        'id': '3',
        'name': 'Mike Davis',
        'username': '@miked',
        'avatar': '🔥',
        'position': 'SF'
      },
      {
        'id': '4',
        'name': 'Jordan Smith',
        'username': '@jordans',
        'avatar': '🌟',
        'position': 'PF'
      },
      {
        'id': '5',
        'name': 'Taylor Brown',
        'username': '@taylorb',
        'avatar': '💎',
        'position': 'C'
      },
    ];

    List<Map<String, dynamic>> filteredUsers = List.from(mockUsers);

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text(
            'Replace ${currentPlayer['name']}',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: SizedBox(
            width: double.maxFinite,
            height: 400,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Search field
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2A2A),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey[700]!, width: 1),
                  ),
                  child: TextField(
                    controller: searchController,
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                    onChanged: (value) {
                      setDialogState(() {
                        filteredUsers = mockUsers.where((user) {
                          return user['name']!
                                  .toLowerCase()
                                  .contains(value.toLowerCase()) ||
                              user['username']!
                                  .toLowerCase()
                                  .contains(value.toLowerCase());
                        }).toList();
                      });
                    },
                    decoration: InputDecoration(
                      hintText: 'Search for replacement player...',
                      hintStyle:
                          TextStyle(color: Colors.grey[400], fontSize: 16),
                      prefixIcon: const Icon(Icons.search,
                          color: Color(0xFFFF9800), size: 24),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 16),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                // User list
                Expanded(
                  child: filteredUsers.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.search_off,
                                  color: Colors.grey[600], size: 48),
                              const SizedBox(height: 16),
                              Text(
                                'No users found',
                                style: TextStyle(
                                    color: Colors.grey[400], fontSize: 16),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: filteredUsers.length,
                          itemBuilder: (context, index) {
                            final user = filteredUsers[index];
                            return Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              decoration: BoxDecoration(
                                color: const Color(0xFF2A2A2A),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: Colors.grey[800]!, width: 1),
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 8),
                                leading: Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [
                                        Color(0xFFFF9800),
                                        Color(0xFFFF5722)
                                      ],
                                    ),
                                    borderRadius: BorderRadius.circular(24),
                                  ),
                                  child: Center(
                                    child: Text(
                                      user['avatar']!,
                                      style: const TextStyle(fontSize: 20),
                                    ),
                                  ),
                                ),
                                title: Text(
                                  user['name']!,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                subtitle: Row(
                                  children: [
                                    Text(
                                      user['username']!,
                                      style: TextStyle(
                                          color: Colors.grey[400],
                                          fontSize: 14),
                                    ),
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFFF9800)
                                            .withValues(alpha: 0.2),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: Text(
                                        user['position']!,
                                        style: const TextStyle(
                                          color: Color(0xFFFF9800),
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                trailing: const Icon(Icons.swap_horiz,
                                    color: Colors.blue),
                                onTap: () {
                                  Navigator.pop(context);
                                  _replacePlayerWithUser(currentPlayer, user);
                                },
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
          ],
        ),
      ),
    );
  }

  void _switchToManualEntry(Map<String, dynamic> currentPlayer) {
    final nameController = TextEditingController();
    final numberController =
        TextEditingController(text: currentPlayer['number']);
    String selectedPosition = currentPlayer['position'];
    bool isStarter = currentPlayer['isStarter'];
    bool isCaptain = currentPlayer['isCaptain'];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text(
            'Replace ${currentPlayer['name']}',
            style: const TextStyle(
                color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Player Name',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: numberController,
                style: const TextStyle(color: Colors.white),
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Jersey Number',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedPosition,
                dropdownColor: const Color(0xFF2A2A2A),
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Position',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                items: ['PG', 'SG', 'SF', 'PF', 'C'].map((position) {
                  return DropdownMenuItem(
                      value: position, child: Text(position));
                }).toList(),
                onChanged: (value) {
                  setDialogState(() {
                    selectedPosition = value!;
                  });
                },
              ),
              const SizedBox(height: 16),
              CheckboxListTile(
                title: const Text('Starter',
                    style: TextStyle(color: Colors.white)),
                value: isStarter,
                activeColor: const Color(0xFFFF9800),
                onChanged: (value) {
                  setDialogState(() {
                    isStarter = value!;
                  });
                },
              ),
              CheckboxListTile(
                title: const Text('Captain',
                    style: TextStyle(color: Colors.white)),
                value: isCaptain,
                activeColor: const Color(0xFFFF9800),
                onChanged: (value) {
                  setDialogState(() {
                    isCaptain = value!;
                  });
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.isNotEmpty) {
                  setState(() {
                    final index = _players
                        .indexWhere((p) => p['id'] == currentPlayer['id']);
                    if (index != -1) {
                      _players[index] = {
                        'id': currentPlayer['id'],
                        'name': nameController.text,
                        'number': numberController.text,
                        'position': selectedPosition,
                        'isStarter': isStarter,
                        'isCaptain': isCaptain,
                        'hasProfile': false,
                        'profileImage': null,
                      };
                    }
                  });
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                          '${currentPlayer['name']} replaced with ${nameController.text}'),
                      backgroundColor: const Color(0xFF4CAF50),
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF9800)),
              child: const Text('Replace Player'),
            ),
          ],
        ),
      ),
    );
  }

  void _replacePlayerWithUser(
      Map<String, dynamic> currentPlayer, Map<String, dynamic> newUser) {
    setState(() {
      final index = _players.indexWhere((p) => p['id'] == currentPlayer['id']);
      if (index != -1) {
        _players[index] = {
          'id': currentPlayer['id'],
          'name': newUser['name'],
          'number': currentPlayer['number'],
          'position': newUser['position'] ?? currentPlayer['position'],
          'isStarter': currentPlayer['isStarter'],
          'isCaptain': currentPlayer['isCaptain'],
          'hasProfile': true,
          'profileImage': null,
        };
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content:
            Text('${currentPlayer['name']} replaced with ${newUser['name']}'),
        backgroundColor: const Color(0xFF4CAF50),
      ),
    );
  }
}
