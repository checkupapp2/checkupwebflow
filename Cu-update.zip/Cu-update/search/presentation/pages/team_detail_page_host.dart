import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:check_up_app/features/search/domain/models/team_model.dart';
import 'package:check_up_app/features/feed/domain/models/feed_post_model.dart';
import 'package:check_up_app/features/feed/presentation/widgets/feed_post.dart';
import '../widgets/team_feed_tab.dart';
import '../widgets/team_stats_tab.dart';
import '../widgets/team_profile_card.dart';
import '../widgets/team_media_tab.dart';
import '../../../dues/presentation/pages/team_dues_page.dart';
import '../../../chat/presentation/pages/team_chat_page.dart';
import 'team_schedule_page.dart';
import 'host_team_roster_page.dart';

/// Host team detail page that shows comprehensive information about a team (identical to regular team detail page)
class HostTeamDetailPage extends StatefulWidget {
  /// The team to display details for
  final TeamModel team;

  /// Constructor
  const HostTeamDetailPage({
    super.key,
    required this.team,
  });

  @override
  State<HostTeamDetailPage> createState() => _HostTeamDetailPageState();
}

// The SliverAppBarDelegate class has been removed as it's no longer needed with the new design

class _HostTeamDetailPageState extends State<HostTeamDetailPage>
    with SingleTickerProviderStateMixin {
  bool _isFollowing = false;
  late TabController _tabController;
  final List<String> _tabs = ['Feed', 'Media', 'Stats'];

  @override
  void initState() {
    super.initState();
    _isFollowing = widget.team.isFollowing;
    _tabController = TabController(length: _tabs.length, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _toggleFollow() {
    HapticFeedback.mediumImpact();
    setState(() {
      _isFollowing = !_isFollowing;
    });
    // In a real app, you would call an API to update the follow status
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // App Bar
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    // Check Up Logo
                    Image.asset(
                      'assets/images/checkup_main-1.png',
                      height: 30,
                      fit: BoxFit.contain,
                    ),
                    IconButton(
                      icon: const Icon(Icons.more_vert, color: Colors.white),
                      onPressed: () {
                        // Show options menu
                      },
                    ),
                  ],
                ),
              ),
            ),

            // Team Profile Card
            SliverToBoxAdapter(
              child: TeamProfileCard(
                team: widget.team,
                isFollowing: _isFollowing,
                onFollowTap: _toggleFollow,
              ),
            ),

            // Action Cards
            SliverToBoxAdapter(
              child: _buildActionCards(),
            ),

            // Reduced space between action cards and tabs
            SliverToBoxAdapter(
              child: const SizedBox(height: 8),
            ),

            // Tab Row
            SliverToBoxAdapter(
              child: _buildTabRow(),
            ),

            SliverToBoxAdapter(
              child: const SizedBox(height: 16),
            ),

            // Content based on selected tab
            SliverFillRemaining(
              child: TabBarView(
                controller: _tabController,
                children: [
                  TeamFeedTab(
                    teamId: widget.team.id,
                    teamName: widget.team.name,
                  ),
                  TeamMediaTab(
                    teamId: widget.team.id,
                    teamName: widget.team.name,
                  ),
                  TeamStatsTab(
                    teamId: widget.team.id,
                    teamName: widget.team.name,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Builds the action cards in unified 2x2 grid layout matching screenshot
  Widget _buildActionCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        children: [
          // Unified container with all four buttons
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1),
                width: 1,
              ),
            ),
            child: Column(
              children: [
                // First row: Schedule and Rosters
                Row(
                  children: [
                    Expanded(
                      child: _buildMinimalistCard(
                        icon: Icons.calendar_today_outlined,
                        title: 'Schedule',
                        subtitle: 'View games',
                        onTap: () {
                          HapticFeedback.mediumImpact();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TeamSchedulePage(
                                  team: widget.team, isHostView: true),
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      width: 1,
                      height: 60,
                      color: Colors.white.withValues(alpha: 0.1),
                    ),
                    Expanded(
                      child: _buildMinimalistCard(
                        icon: Icons.groups_outlined,
                        title: 'Rosters',
                        subtitle: 'Players',
                        onTap: () {
                          HapticFeedback.mediumImpact();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  HostTeamRosterPage(team: widget.team),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
                // Horizontal divider
                Container(
                  height: 1,
                  color: Colors.white.withValues(alpha: 0.1),
                  margin: const EdgeInsets.symmetric(vertical: 8),
                ),
                // Second row: Dues and Team Chat
                Row(
                  children: [
                    Expanded(
                      child: _buildMinimalistCard(
                        icon: Icons.credit_card_outlined,
                        title: 'Dues',
                        subtitle: 'Payments',
                        onTap: () {
                          HapticFeedback.mediumImpact();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TeamDuesPage(
                                teamName: widget.team.name,
                                teamId: widget.team.id,
                                isHost: true,
                                currentUserId:
                                    'host_user_id', // In real app, get from auth
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      width: 1,
                      height: 60,
                      color: Colors.white.withValues(alpha: 0.1),
                    ),
                    Expanded(
                      child: _buildMinimalistCard(
                        icon: Icons.chat_outlined,
                        title: 'Team Chat',
                        subtitle: 'Messages',
                        onTap: () {
                          HapticFeedback.mediumImpact();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TeamChatPage(
                                teamName: widget.team.name,
                                teamId: widget.team.id,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  /// Builds minimalist card matching league detail page design
  Widget _buildMinimalistCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ).createShader(bounds),
                child: Icon(
                  icon,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.6),
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Builds the tab row
  Widget _buildTabRow() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 50, // Increased height for better appearance
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(30),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey,
        labelStyle: const TextStyle(
            fontWeight: FontWeight.bold, fontSize: 14), // Reduced font size
        unselectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.normal, fontSize: 14), // Reduced font size
        indicatorWeight: 0, // Remove default indicator
        indicatorSize: TabBarIndicatorSize.tab, // Make indicator fill the tab
        indicatorPadding: EdgeInsets.zero, // Remove padding around indicator
        padding: const EdgeInsets.all(4), // Add padding inside the container
        isScrollable: false, // Ensure tabs are evenly distributed
        labelPadding: const EdgeInsets.symmetric(
            horizontal: 8), // Reduce horizontal padding
        dividerColor: Colors.transparent, // Remove white line/divider
        tabs: _tabs
            .map((tab) => Tab(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(tab),
                  ),
                ))
            .toList(),
      ),
    );
  }

  // Helper methods for building individual tabs are no longer needed
  // as tab content is now built directly in the build method

  Widget _buildPlaceholderContent({
    required IconData icon,
    required String title,
    required String message,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: Colors.grey[700],
            size: 64,
          ),
          const SizedBox(height: 16),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            message,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}
