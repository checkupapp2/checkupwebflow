import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Season Detail Page that displays detailed information about a season
class SeasonDetailPage extends StatefulWidget {
  /// The season to display details for
  final Map<String, dynamic> season;

  /// Constructor
  const SeasonDetailPage({
    super.key,
    required this.season,
  });

  @override
  State<SeasonDetailPage> createState() => _SeasonDetailPageState();
}

class _SeasonDetailPageState extends State<SeasonDetailPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final List<String> _tabs = ['Standings', 'Schedule', 'Teams', 'Stats'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
    _tabController.addListener(() {
      setState(() {}); // Rebuild to show current tab content
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share, color: Colors.white),
            onPressed: () {
              HapticFeedback.mediumImpact();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Sharing ${widget.season["name"]}',
                    style: const TextStyle(color: Colors.white),
                  ),
                  backgroundColor: Colors.grey[850],
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(0),
          child: Container(),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildSeasonDetails(),
            const SizedBox(height: 16),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.orange.withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
              child: TabBar(
                controller: _tabController,
                tabs: _tabs.map((tab) => Tab(
                  child: Text(
                    tab,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                      letterSpacing: 0.3,
                    ),
                  ),
                )).toList(),
                labelColor: Colors.white,
                unselectedLabelColor: Colors.grey[400],
                indicatorColor: const Color(0xFFFF6600),
                indicatorWeight: 3,
                indicatorSize: TabBarIndicatorSize.tab,
                indicator: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFFFF6600),
                      Color(0xFFE55A00),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                labelPadding: const EdgeInsets.symmetric(vertical: 12),
                dividerColor: Colors.transparent,
              ),
            ),
            const SizedBox(height: 16),
            // Tab content with fixed height for proper display
            SizedBox(
              height: 600, // Fixed height to ensure content displays
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildStandingsTab(),
                  _buildScheduleTab(),
                  _buildTeamsTab(),
                  _buildStatsTab(),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      expandedHeight: 0,
      pinned: true,
      backgroundColor: Colors.black,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: Colors.white),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.share, color: Colors.white),
          onPressed: () {
            HapticFeedback.mediumImpact();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'Sharing ${widget.season['name']}',
                  style: const TextStyle(color: Colors.white),
                ),
                backgroundColor: Colors.grey[850],
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                margin: const EdgeInsets.all(10),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildCurrentTabContent() {
    switch (_tabController.index) {
      case 0:
        return _buildStandingsTab();
      case 1:
        return _buildScheduleTab();
      case 2:
        return _buildTeamsTab();
      case 3:
        return _buildStatsTab();
      default:
        return _buildStandingsTab();
    }
  }

  // Tab content methods
  Widget _buildStandingsTab() {
    // Mock standings data
    final List<Map<String, dynamic>> teams = [
      {
        'name': 'Thunder Hawks',
        'logo': 'https://picsum.photos/100?random=1',
        'wins': 8,
        'losses': 2,
        'rank': 1,
      },
      {
        'name': 'City Ballers',
        'logo': 'https://picsum.photos/100?random=2',
        'wins': 7,
        'losses': 3,
        'rank': 2,
      },
      {
        'name': 'Slam Dunkers',
        'logo': 'https://picsum.photos/100?random=3',
        'wins': 6,
        'losses': 4,
        'rank': 3,
      },
      {
        'name': 'Hoopsters',
        'logo': 'https://picsum.photos/100?random=4',
        'wins': 5,
        'losses': 5,
        'rank': 4,
      },
      {
        'name': 'Rim Rockers',
        'logo': 'https://picsum.photos/100?random=5',
        'wins': 4,
        'losses': 6,
        'rank': 5,
      },
      {
        'name': 'Court Kings',
        'logo': 'https://picsum.photos/100?random=6',
        'wins': 3,
        'losses': 7,
        'rank': 6,
      },
    ];

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      itemCount: teams.length,
      itemBuilder: (context, index) {
        final team = teams[index];
        return _buildTeamListItem(team);
      },
    );
  }

  Widget _buildSeasonDetails() {
    Color statusColor;
    IconData statusIcon;
    
    switch(widget.season['status']) {
      case 'Active':
        statusColor = Colors.green;
        statusIcon = Icons.check_circle;
        break;
      case 'Upcoming':
        statusColor = Colors.blue;
        statusIcon = Icons.schedule;
        break;
      case 'Completed':
        statusColor = Colors.grey;
        statusIcon = Icons.done_all;
        break;
      default:
        statusColor = Colors.orange;
        statusIcon = Icons.info;
    }
    
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
          BoxShadow(
            color: Colors.orange.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: Colors.orange.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top row with icon, name and status
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Season Icon with orange gradient
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFFFF6600),
                        Color(0xFFE55A00),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.orange.withValues(alpha: 0.4),
                        blurRadius: 12,
                        spreadRadius: 2,
                        offset: const Offset(0, 3),
                      ),
                    ],
                    border: Border.all(
                      color: Colors.orange.withValues(alpha: 0.3),
                      width: 2,
                    ),
                  ),
                  child: Icon(
                    widget.season['icon'],
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                const SizedBox(width: 16),
                
                // Season Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.season['name'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 26,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: statusColor.withValues(alpha: 0.3),
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              statusIcon,
                              color: statusColor,
                              size: 18,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              widget.season['status'],
                              style: TextStyle(
                                color: statusColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                letterSpacing: 0.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Registration Button
                if (widget.season['isRegistrationOpen']) ...[  
                  Container(
                    height: 40,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFFFF9800),
                          Color(0xFFFF5722),
                        ],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () {
                          HapticFeedback.mediumImpact();
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Registering for ${widget.season['name']}',
                                style: const TextStyle(color: Colors.white),
                              ),
                              backgroundColor: Colors.grey[850],
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                              margin: const EdgeInsets.all(10),
                            ),
                          );
                        },
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          child: Text(
                            'Register',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
            
            const SizedBox(height: 24),
            
            // Season details
            Row(
              children: [
                Icon(
                  Icons.calendar_today,
                  color: Colors.grey[400],
                  size: 18,
                ),
                const SizedBox(width: 8),
                Text(
                  widget.season['dateRange'],
                  style: TextStyle(
                    color: Colors.grey[300],
                    fontSize: 16,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 12),
            
            // Stats row
            Row(
              children: [
                // Teams count
                Row(
                  children: [
                    Icon(
                      Icons.group,
                      color: Colors.grey[400],
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${widget.season['teams']} Teams',
                      style: TextStyle(
                        color: Colors.grey[300],
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 24),
                
                // Division
                Row(
                  children: [
                    Icon(
                      widget.season['division'] == 'Youth' ? Icons.child_care : Icons.person,
                      color: Colors.grey[400],
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      widget.season['division'],
                      style: TextStyle(
                        color: Colors.grey[300],
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            
            const SizedBox(height: 24),
            
            // Action buttons
            Row(
              children: [
                _buildActionButton(
                  icon: Icons.leaderboard,
                  label: 'Standings',
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Viewing ${widget.season['name']} standings'),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  },
                ),
                const SizedBox(width: 8),
                _buildActionButton(
                  icon: Icons.event,
                  label: 'Schedule',
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Viewing ${widget.season['name']} schedule'),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  },
                ),
                const SizedBox(width: 8),
                _buildActionButton(
                  icon: Icons.people,
                  label: 'Teams',
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Viewing ${widget.season['name']} teams'),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScheduleTab() {
    // Mock schedule data
    final List<Map<String, dynamic>> events = [
      {
        'title': 'Thunder Hawks vs City Ballers',
        'dateTime': 'Sep 15, 2024 • 7:00 PM',
        'location': 'Downtown Arena',
        'category': 'Regular Season',
        'status': 'Completed',
        'iconData': Icons.sports_basketball,
        'iconColor': Colors.orange,
      },
      {
        'title': 'Slam Dunkers vs Hoopsters',
        'dateTime': 'Sep 22, 2024 • 6:30 PM',
        'location': 'Community Center',
        'category': 'Regular Season',
        'status': 'Completed',
        'iconData': Icons.sports_basketball,
        'iconColor': Colors.orange,
      },
      {
        'title': 'Rim Rockers vs Court Kings',
        'dateTime': 'Oct 5, 2024 • 8:00 PM',
        'location': 'Sports Complex',
        'category': 'Regular Season',
        'status': 'Completed',
        'iconData': Icons.sports_basketball,
        'iconColor': Colors.orange,
      },
      {
        'title': 'City Ballers vs Slam Dunkers',
        'dateTime': 'Oct 12, 2024 • 7:30 PM',
        'location': 'Downtown Arena',
        'category': 'Regular Season',
        'status': 'Completed',
        'iconData': Icons.sports_basketball,
        'iconColor': Colors.orange,
      },
      {
        'title': 'Thunder Hawks vs Hoopsters',
        'dateTime': 'Oct 19, 2024 • 6:00 PM',
        'location': 'Community Center',
        'category': 'Regular Season',
        'status': 'Completed',
        'iconData': Icons.sports_basketball,
        'iconColor': Colors.orange,
      },
    ];

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      itemCount: events.length,
      itemBuilder: (context, index) {
        final event = events[index];
        return _buildEventCard(
          title: event['title'],
          dateTime: event['dateTime'],
          location: event['location'],
          category: event['category'],
          status: event['status'],
          iconData: event['iconData'],
          iconColor: event['iconColor'],
        );
      },
    );
  }

  Widget _buildTeamsTab() {
    // Mock teams data
    final List<Map<String, dynamic>> teams = [
      {
        'name': 'Thunder Hawks',
        'logo': 'https://picsum.photos/100?random=1',
        'wins': 8,
        'losses': 2,
        'rank': 1,
      },
      {
        'name': 'City Ballers',
        'logo': 'https://picsum.photos/100?random=2',
        'wins': 7,
        'losses': 3,
        'rank': 2,
      },
      {
        'name': 'Slam Dunkers',
        'logo': 'https://picsum.photos/100?random=3',
        'wins': 6,
        'losses': 4,
        'rank': 3,
      },
      {
        'name': 'Hoopsters',
        'logo': 'https://picsum.photos/100?random=4',
        'wins': 5,
        'losses': 5,
        'rank': 4,
      },
      {
        'name': 'Rim Rockers',
        'logo': 'https://picsum.photos/100?random=5',
        'wins': 4,
        'losses': 6,
        'rank': 5,
      },
      {
        'name': 'Court Kings',
        'logo': 'https://picsum.photos/100?random=6',
        'wins': 3,
        'losses': 7,
        'rank': 6,
      },
    ];

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      itemCount: teams.length,
      itemBuilder: (context, index) {
        final team = teams[index];
        return _buildTeamListItem(team);
      },
    );
  }

  Widget _buildStatsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Season Highlights
          const Text(
            'Season Highlights',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _buildHighlightItem('Games', '30', Icons.sports_basketball),
              const SizedBox(width: 16),
              _buildHighlightItem('Teams', '${widget.season['teams']}', Icons.group),
              const SizedBox(width: 16),
              _buildHighlightItem('Players', '120', Icons.person),
            ],
          ),
          const SizedBox(height: 32),
          
          // Season Leaders
          const Text(
            'Season Leaders',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          _buildLeaderItem('Points', 'Michael Johnson (Thunder Hawks)', Icons.star),
          const SizedBox(height: 8),
          _buildLeaderItem('Assists', 'David Smith (City Ballers)', Icons.handshake),
          const SizedBox(height: 8),
          _buildLeaderItem('Rebounds', 'Chris Williams (Slam Dunkers)', Icons.loop),
          const SizedBox(height: 8),
          _buildLeaderItem('Steals', 'James Brown (Hoopsters)', Icons.security),
          const SizedBox(height: 8),
          _buildLeaderItem('Blocks', 'Robert Davis (Rim Rockers)', Icons.block),
        ],
      ),
    );
  }

  Widget _buildHighlightItem(String label, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[850],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFFFF6600), size: 24),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLeaderItem(String category, String name, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[850],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.grey[800],
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: const Color(0xFFFF6600), size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  category,
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEventCard({
    required String title,
    required String dateTime,
    required String location,
    required String category,
    required String status,
    required IconData iconData,
    required Color iconColor,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      color: Colors.grey[850],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: iconColor.withValues(alpha: 0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(iconData, color: iconColor, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(Icons.calendar_today, color: Colors.grey[400], size: 16),
                const SizedBox(width: 8),
                Text(
                  dateTime,
                  style: TextStyle(
                    color: Colors.grey[300],
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.location_on, color: Colors.grey[400], size: 16),
                const SizedBox(width: 8),
                Text(
                  location,
                  style: TextStyle(
                    color: Colors.grey[300],
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    category,
                    style: TextStyle(
                      color: Colors.grey[300],
                      fontSize: 12,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: status == 'Completed' ? Colors.green.withValues(alpha: 0.2) : Colors.blue.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    status,
                    style: TextStyle(
                      color: status == 'Completed' ? Colors.green : Colors.blue,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTeamListItem(Map<String, dynamic> team) {
    final bool isTopThree = team['rank'] <= 3;
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isTopThree 
              ? Colors.orange.withValues(alpha: 0.3)
              : Colors.grey[600]!.withValues(alpha: 0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
          if (isTopThree)
            BoxShadow(
              color: Colors.orange.withValues(alpha: 0.1),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () {
            HapticFeedback.lightImpact();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Viewing ${team['name']} details'),
                behavior: SnackBarBehavior.floating,
                backgroundColor: Colors.grey[850],
              ),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Rank badge
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: isTopThree
                        ? const LinearGradient(
                            colors: [
                              Color(0xFFFFD700),
                              Color(0xFFFFA500),
                            ],
                          )
                        : LinearGradient(
                            colors: [
                              Colors.grey[700]!,
                              Colors.grey[800]!,
                            ],
                          ),
                    boxShadow: [
                      BoxShadow(
                        color: isTopThree 
                            ? const Color(0xFFFFD700).withValues(alpha: 0.3)
                            : Colors.black.withValues(alpha: 0.2),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      '${team['rank']}',
                      style: TextStyle(
                        color: isTopThree ? Colors.white : Colors.grey[300],
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                // Team logo
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.grey[800],
                    border: Border.all(
                      color: Colors.orange.withValues(alpha: 0.2),
                      width: 1,
                    ),
                    image: DecorationImage(
                      image: NetworkImage(team['logo']),
                      fit: BoxFit.cover,
                      onError: (exception, stackTrace) => const AssetImage('assets/images/team_placeholder.png'),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                // Team info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        team['name'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          letterSpacing: 0.3,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(
                            Icons.sports_basketball,
                            color: Colors.orange.withValues(alpha: 0.7),
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '${team['wins']}W - ${team['losses']}L',
                            style: TextStyle(
                              color: Colors.grey[300],
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Win percentage
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.orange.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.orange.withValues(alpha: 0.3),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    '${((team['wins'] / (team['wins'] + team['losses'])) * 100).toInt()}%',
                    style: TextStyle(
                      color: Colors.orange.withValues(alpha: 0.9),
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return Expanded(
      child: TextButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 18, color: Colors.grey[400]),
        label: Text(
          label,
          style: TextStyle(color: Colors.grey[300], fontSize: 14),
        ),
        style: TextButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          backgroundColor: Colors.grey[850],
        ),
      ),
    );
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;

  _SliverAppBarDelegate(this.child);

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: Colors.black,
      child: child,
    );
  }

  @override
  double get maxExtent => 56.0;

  @override
  double get minExtent => 56.0;

  @override
  bool shouldRebuild(covariant SliverPersistentHeaderDelegate oldDelegate) {
    return false;
  }
}
