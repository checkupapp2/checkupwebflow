import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/league_model.dart';

/// Page for teams to join a league
class JoinLeaguePage extends StatefulWidget {
  /// The league to join
  final LeagueModel league;

  /// Constructor
  const JoinLeaguePage({
    super.key,
    required this.league,
  });

  @override
  State<JoinLeaguePage> createState() => _JoinLeaguePageState();
}

class _JoinLeaguePageState extends State<JoinLeaguePage> {
  final TextEditingController _teamNameController = TextEditingController();
  final TextEditingController _teamHandleController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();
  
  // Free agent controllers
  final TextEditingController _playerNameController = TextEditingController();
  final TextEditingController _playerEmailController = TextEditingController();
  final TextEditingController _playerPhoneController = TextEditingController();
  final TextEditingController _playerPositionController = TextEditingController();
  final TextEditingController _playerExperienceController = TextEditingController();
  
  // Registration mode: 'selection', 'existing', 'new', or 'freeagent'
  String _registrationMode = 'selection';
  
  // Mock existing teams for search
  final List<Map<String, dynamic>> _existingTeams = [
    {
      'id': '1',
      'name': 'Thunder Bolts',
      'handle': '@thunderbolts',
      'location': 'Miami, FL',
      'players': 12,
      'logoUrl': null,
    },
    {
      'id': '2', 
      'name': 'Fire Hawks',
      'handle': '@firehawks',
      'location': 'Orlando, FL',
      'players': 15,
      'logoUrl': null,
    },
    {
      'id': '3',
      'name': 'Storm Riders',
      'handle': '@stormriders', 
      'location': 'Tampa, FL',
      'players': 10,
      'logoUrl': null,
    },
  ];

  List<Map<String, dynamic>> _filteredTeams = [];

  @override
  void initState() {
    super.initState();
    _filteredTeams = _existingTeams;
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _teamNameController.dispose();
    _teamHandleController.dispose();
    _locationController.dispose();
    _descriptionController.dispose();
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    
    // Free agent controllers
    _playerNameController.dispose();
    _playerEmailController.dispose();
    _playerPhoneController.dispose();
    _playerPositionController.dispose();
    _playerExperienceController.dispose();
    
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredTeams = _existingTeams.where((team) {
        return team['name'].toLowerCase().contains(query) ||
               team['handle'].toLowerCase().contains(query) ||
               team['location'].toLowerCase().contains(query);
      }).toList();
    });
  }

  void _submitExistingTeam(Map<String, dynamic> team) {
    HapticFeedback.mediumImpact();
    
    // Show success dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Join Request Sent!',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Your request to join ${widget.league.name} with team "${team['name']}" has been sent to the league administrator.',
          style: TextStyle(color: Colors.grey[300]),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Go back to league page
            },
            child: Text(
              'OK',
              style: TextStyle(color: Color(0xFFFF9800)),
            ),
          ),
        ],
      ),
    );
  }

  void _submitNewTeam() {
    if (_teamNameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter a team name'),
          backgroundColor: Colors.red[700],
        ),
      );
      return;
    }

    HapticFeedback.mediumImpact();
    
    // Show success dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Join Request Sent!',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Your request to join ${widget.league.name} with new team "${_teamNameController.text.trim()}" has been sent to the league administrator.',
          style: TextStyle(color: Colors.grey[300]),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Go back to league page
            },
            child: Text(
              'OK',
              style: TextStyle(color: Color(0xFFFF9800)),
            ),
          ),
        ],
      ),
    );
  }

  void _submitFreeAgent() {
    if (_playerNameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter your name'),
          backgroundColor: Colors.red[700],
        ),
      );
      return;
    }

    if (_playerEmailController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter your email'),
          backgroundColor: Colors.red[700],
        ),
      );
      return;
    }

    HapticFeedback.mediumImpact();
    
    // Show success dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Free Agent Request Sent!',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Your free agent request for ${widget.league.name} has been submitted. You\'ll be added to the waitlist and teams can contact you to join.',
          style: TextStyle(color: Colors.grey[300]),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Go back to league page
            },
            child: Text(
              'OK',
              style: TextStyle(color: Color(0xFFFF9800)),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.grey[900],
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            if (_registrationMode != 'selection') {
              setState(() {
                _registrationMode = 'selection';
              });
            } else {
              Navigator.pop(context);
            }
          },
        ),
        title: Text(
          _registrationMode == 'selection' 
              ? 'Join ${widget.league.name}'
              : _registrationMode == 'existing' 
                  ? 'Select Your Team'
                  : _registrationMode == 'new'
                      ? 'Create New Team'
                      : 'Join as Free Agent',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: AnimatedSwitcher(
        duration: Duration(milliseconds: 300),
        child: _buildCurrentView(),
      ),
    );
  }

  Widget _buildCurrentView() {
    switch (_registrationMode) {
      case 'selection':
        return _buildSelectionView();
      case 'existing':
        return _buildExistingTeamView();
      case 'new':
        return _buildNewTeamView();
      case 'freeagent':
        return _buildFreeAgentView();
      default:
        return _buildSelectionView();
    }
  }

  Widget _buildSelectionView() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Text(
            'How would you like to join?',
            style: TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 12),
          Text(
            'Choose the best option for your team registration',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 16,
            ),
          ),
          SizedBox(height: 40),
          
          // Existing Team Option
          _buildRegistrationOption(
            title: 'Use Existing Team',
            subtitle: 'Join with a team you already manage',
            icon: Icons.group,
            iconColor: Color(0xFF4CAF50),
            onTap: () {
              setState(() {
                _registrationMode = 'existing';
              });
            },
          ),
          
          SizedBox(height: 20),
          
          // New Team Option
          _buildRegistrationOption(
            title: 'Create New Team',
            subtitle: 'Start fresh with a brand new team',
            icon: Icons.add_circle,
            iconColor: Color(0xFFFF9800),
            onTap: () {
              setState(() {
                _registrationMode = 'new';
              });
            },
          ),
          
          SizedBox(height: 20),
          
          // Free Agent Option
          _buildRegistrationOption(
            title: 'Join as Free Agent',
            subtitle: 'Get on the waitlist for teams to pick you up',
            icon: Icons.person_add,
            iconColor: Color(0xFF2196F3),
            onTap: () {
              setState(() {
                _registrationMode = 'freeagent';
              });
            },
          ),
          
          SizedBox(height: 40),
          
          // League Info Card
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.grey[900]!.withValues(alpha: 0.8),
                  Colors.grey[850]!.withValues(alpha: 0.6),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Colors.grey[800]!.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: Color(0xFFFF9800),
                      size: 20,
                    ),
                    SizedBox(width: 8),
                    Text(
                      'League Information',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 12),
                Text(
                  widget.league.name,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 4),
                if (widget.league.description != null) ...[
                  Text(
                    widget.league.description!,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRegistrationOption({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.grey[900]!.withValues(alpha: 0.95),
              Colors.grey[850]!.withValues(alpha: 0.9),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.grey[800]!.withValues(alpha: 0.3),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.2),
              blurRadius: 8,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: iconColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: iconColor.withValues(alpha: 0.3),
                  width: 1,
                ),
              ),
              child: Icon(
                icon,
                color: iconColor,
                size: 28,
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.grey[600],
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExistingTeamView() {
    return Column(
      children: [
        // Header
        Container(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Select Your Team',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Choose from your existing teams to join ${widget.league.name}',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
        
        // Search bar
        Container(
          margin: EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey[700]!, width: 1),
          ),
          child: TextField(
            controller: _searchController,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Search your teams...',
              hintStyle: TextStyle(color: Colors.grey[500]),
              prefixIcon: Icon(Icons.search, color: Colors.grey[500]),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
        ),
        
        SizedBox(height: 16),
        
        // Teams list
        Expanded(
          child: _filteredTeams.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _filteredTeams.length,
                  itemBuilder: (context, index) {
                    final team = _filteredTeams[index];
                    return _buildTeamCard(team);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildNewTeamView() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Text(
            'Create New Team',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Fill out the information below to create a new team and join ${widget.league.name}',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 16,
            ),
          ),
          SizedBox(height: 32),
          
          // Team Name
          _buildInputField(
            controller: _teamNameController,
            label: 'Team Name',
            hint: 'Enter your team name',
            icon: Icons.group,
            required: true,
          ),
          
          SizedBox(height: 20),
          
          // Team Handle
          _buildInputField(
            controller: _teamHandleController,
            label: 'Team Handle (Optional)',
            hint: '@yourteam',
            icon: Icons.alternate_email,
          ),
          
          SizedBox(height: 20),
          
          // Location
          _buildInputField(
            controller: _locationController,
            label: 'Location (Optional)',
            hint: 'City, State',
            icon: Icons.location_on,
          ),
          
          SizedBox(height: 20),
          
          // Description
          _buildInputField(
            controller: _descriptionController,
            label: 'Team Description (Optional)',
            hint: 'Tell us about your team...',
            icon: Icons.description,
            maxLines: 3,
          ),
          
          SizedBox(height: 40),
          
          // Submit Button
          Container(
            width: double.infinity,
            height: 50,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Color(0xFFFF9800).withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _submitNewTeam,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Submit Join Request',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFreeAgentView() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Text(
            'Join as Free Agent',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Register as a free agent to be added to the ${widget.league.name} waitlist. Teams can then contact you to join their roster.',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 16,
            ),
          ),
          SizedBox(height: 32),
          
          // Player Name
          _buildInputField(
            controller: _playerNameController,
            label: 'Full Name',
            hint: 'Enter your full name',
            icon: Icons.person,
            required: true,
          ),
          
          SizedBox(height: 20),
          
          // Email
          _buildInputField(
            controller: _playerEmailController,
            label: 'Email Address',
            hint: 'your.email@example.com',
            icon: Icons.email,
            required: true,
          ),
          
          SizedBox(height: 20),
          
          // Phone
          _buildInputField(
            controller: _playerPhoneController,
            label: 'Phone Number (Optional)',
            hint: '(555) 123-4567',
            icon: Icons.phone,
          ),
          
          SizedBox(height: 20),
          
          // Position
          _buildInputField(
            controller: _playerPositionController,
            label: 'Preferred Position (Optional)',
            hint: 'e.g., Point Guard, Forward, etc.',
            icon: Icons.sports_basketball,
          ),
          
          SizedBox(height: 20),
          
          // Experience
          _buildInputField(
            controller: _playerExperienceController,
            label: 'Experience Level (Optional)',
            hint: 'e.g., Beginner, Intermediate, Advanced',
            icon: Icons.star,
          ),
          
          SizedBox(height: 40),
          
          // Info Card
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Color(0xFF2196F3).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Color(0xFF2196F3).withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: Color(0xFF2196F3),
                  size: 20,
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Teams will be able to see your information and contact you directly to join their roster.',
                    style: TextStyle(
                      color: Colors.grey[300],
                      fontSize: 14,
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          SizedBox(height: 30),
          
          // Submit Button
          Container(
            width: double.infinity,
            height: 50,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF2196F3), Color(0xFF1976D2)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Color(0xFF2196F3).withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _submitFreeAgent,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Submit Free Agent Request',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamCard(Map<String, dynamic> team) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.grey[900]!.withValues(alpha: 0.95),
            Colors.grey[850]!.withValues(alpha: 0.9),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.grey[800]!.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Row(
          children: [
            // Team Avatar
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Center(
                child: Text(
                  team['name'][0].toUpperCase(),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            
            SizedBox(width: 16),
            
            // Team Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    team['name'],
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    team['handle'],
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    '${team['players']} players • ${team['location']}',
                    style: TextStyle(
                      color: Colors.grey[500],
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            
            // Join Button
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: ElevatedButton(
                onPressed: () => _submitExistingTeam(team),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  'Join',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    bool required = false,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            if (required) ...[
              SizedBox(width: 4),
              Text(
                '*',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 16,
                ),
              ),
            ],
          ],
        ),
        SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey[700]!, width: 1),
          ),
          child: TextField(
            controller: controller,
            maxLines: maxLines,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: Colors.grey[500]),
              prefixIcon: Icon(icon, color: Colors.grey[500]),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off,
            size: 64,
            color: Colors.grey[700],
          ),
          SizedBox(height: 16),
          Text(
            'No teams found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Try a different search term',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}
