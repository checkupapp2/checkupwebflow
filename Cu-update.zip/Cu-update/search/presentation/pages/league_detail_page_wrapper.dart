import 'package:flutter/material.dart';
import '../../domain/models/league_model.dart';
import 'league_detail_page_new.dart';
import 'package:check_up_app/features/leagues/presentation/pages/host_league_detail_page_new.dart';

/// Wrapper for the league detail page to maintain backward compatibility
class LeagueDetailPageWrapper extends StatelessWidget {
  /// The league to display details for
  final LeagueModel league;

  /// Constructor
  const LeagueDetailPageWrapper({
    super.key,
    required this.league,
  });

  @override
  Widget build(BuildContext context) {
    // Check if the user is a host of this league
    // For demo purposes, we'll assume the user is a host of the "Pro Basketball Association" league
    // In a real app, this would check against user permissions or league ownership
    if (league.name == 'Pro Basketball Association') {
      // Use the host league page with FAB for league hosts
      return HostLeagueDetailPageNew(league: league);
    } else {
      // Use the regular league detail page for non-hosts
      return LeagueDetailPage(league: league);
    }
  }
}
