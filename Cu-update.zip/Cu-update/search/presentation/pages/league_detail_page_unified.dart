import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../domain/models/league_model.dart';
import '../../../leagues/presentation/routes/league_routes.dart';
import '../../../leagues/presentation/widgets/league_tabbed_feed.dart';
import '../../../leagues/presentation/pages/league_settings_page.dart';
import '../../../feed/domain/models/feed_post_model.dart';
import '../../../feed/data/feed_data_provider.dart';
import '../search_screen.dart';
import '../../../leagues/domain/models/league_model.dart' as leagues_model;
import 'league_teams_page.dart';
import '../../../brackets/presentation/pages/league_brackets_page.dart';

/// League Detail Page that displays detailed information about a league
class LeagueDetailPage extends StatefulWidget {
  /// The league to display details for
  final LeagueModel league;

  /// Whether this is the host view (with team chat icon and manage button)
  final bool isHostView;

  /// Constructor
  const LeagueDetailPage({
    super.key,
    required this.league,
    this.isHostView = false,
  });

  @override
  State<LeagueDetailPage> createState() => _LeagueDetailPageState();
}

class _LeagueDetailPageState extends State<LeagueDetailPage> {
  bool _isFollowing = false;
  late List<FeedPostModel> _feedPosts;

  /// Generate a season name based on current date or league info
  String _getCurrentSeasonName() {
    final now = DateTime.now();
    final year = now.year;
    final month = now.month;

    // Determine season based on month
    String season;
    if (month >= 3 && month <= 5) {
      season = 'Spring';
    } else if (month >= 6 && month <= 8) {
      season = 'Summer';
    } else if (month >= 9 && month <= 11) {
      season = 'Fall';
    } else {
      season = 'Winter';
    }

    return '$season $year';
  }

  @override
  void initState() {
    super.initState();
    // Initialize feed posts
    final feedDataProvider = FeedDataProvider();
    _feedPosts = feedDataProvider.getFeedPosts().take(5).toList();
    _isFollowing = widget.league.isFollowing == true;
  }

  void _toggleFollow() {
    setState(() {
      _isFollowing = !_isFollowing;
      // In a real app, this would call an API to follow/unfollow
    });

    // Show a snackbar
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _isFollowing
              ? 'Following ${widget.league.name}'
              : 'Unfollowed ${widget.league.name}',
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.grey[800],
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        margin: const EdgeInsets.all(10),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF121212),
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF2A2A2A),
                Color(0xFF121212),
              ],
            ),
          ),
        ),
        elevation: 0,
        centerTitle: true,
        title: Text(
          'Nike EYB',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildLeagueHeader(),
            _buildActionCards(),
            _buildLeagueFeed(),
          ],
        ),
      ),
    );
  }

  Widget _buildLeagueHeader() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF121212),
            Color(0xFF121212),
          ],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 20),

              // Minimalist Card Container
              Stack(
                children: [
                  Container(
                    padding: const EdgeInsets.all(32),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(32),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.1),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.3),
                          blurRadius: 20,
                          offset: Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        // Minimalist Logo
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFFFF9800).withValues(alpha: 0.4),
                                blurRadius: 20,
                                offset: Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              'JR',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 24),

                        // League Name - Clean Typography
                        Text(
                          widget.league.name,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.w300,
                            letterSpacing: 1,
                            height: 1.3,
                          ),
                          textAlign: TextAlign.center,
                        ),

                        const SizedBox(height: 12),

                        // League Label
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFFFF9800).withValues(alpha: 0.3),
                                blurRadius: 8,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Text(
                            'BASKETBALL LEAGUE',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),

                        // Clean Info Row
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            // Season Info
                            Column(
                              children: [
                                Icon(
                                  Icons.calendar_today,
                                  color: Colors.grey[400],
                                  size: 20,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  _getCurrentSeasonName(),
                                  style: TextStyle(
                                    color: Colors.grey[300],
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),

                            // Location Info
                            Column(
                              children: [
                                Icon(
                                  Icons.location_on,
                                  color: Colors.grey[400],
                                  size: 20,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Augusta, Georgia',
                                  style: TextStyle(
                                    color: Colors.grey[300],
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),

                        const SizedBox(height: 32),

                        // Action Buttons
                        _buildActionButtonsWidget(),
                      ],
                    ),
                  ),

                  // Team Chat Icon (only for host view)
                  if (widget.isHostView)
                    Positioned(
                      top: 16,
                      right: 16,
                      child: GestureDetector(
                        onTap: () {
                          HapticFeedback.mediumImpact();
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Opening team chat...',
                                style: TextStyle(color: Colors.white),
                              ),
                              backgroundColor: Colors.grey[850],
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              margin: const EdgeInsets.all(10),
                            ),
                          );
                        },
                        child: Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFFFF9800).withValues(alpha: 0.4),
                                blurRadius: 12,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Icon(
                            Icons.chat_bubble,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButtonsWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Row(
        children: [
          // Follow Button
          Expanded(
            flex: 2,
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                gradient: _isFollowing
                    ? null
                    : const LinearGradient(
                        colors: [Color(0xFFFF7700), Color(0xFFFF9800)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                color: _isFollowing ? Colors.grey[850] : null,
                borderRadius: BorderRadius.circular(22),
                border: _isFollowing
                    ? Border.all(
                        color: Colors.grey[700]!,
                        width: 1,
                      )
                    : null,
              ),
              child: ElevatedButton(
                onPressed: _toggleFollow,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(22),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _isFollowing ? Icons.check_circle : Icons.add_circle,
                      color: _isFollowing ? Colors.grey[400] : Colors.white,
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      _isFollowing ? 'Following' : 'Follow',
                      style: TextStyle(
                        color: _isFollowing ? Colors.grey[300] : Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(width: 12),

          // Share Button
          Container(
            height: 44,
            width: 44,
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: Colors.grey[700]!,
                width: 1,
              ),
            ),
            child: IconButton(
              onPressed: () {
                HapticFeedback.mediumImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Sharing ${widget.league.name}',
                      style: const TextStyle(color: Colors.white),
                    ),
                    backgroundColor: Colors.grey[850],
                    behavior: SnackBarBehavior.floating,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    margin: const EdgeInsets.all(10),
                  ),
                );
              },
              icon: const Icon(
                Icons.share,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),

          // Manage League Button (only for host view)
          if (widget.isHostView) ...[
            const SizedBox(width: 12),
            Container(
              height: 44,
              width: 44,
              decoration: BoxDecoration(
                color: Colors.grey[850],
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: Colors.grey[700]!,
                  width: 1,
                ),
              ),
              child: IconButton(
                onPressed: () {
                  HapticFeedback.mediumImpact();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          LeagueSettingsPage(league: widget.league),
                    ),
                  );
                },
                icon: const Icon(
                  Icons.settings,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildActionCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Row(
        children: [
          Expanded(
            child: _buildEnhancedActionCard(
              icon: Icons.schedule,
              title: 'Schedule',
              color: Color(0xFFFF9800),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _buildEnhancedActionCard(
              icon: Icons.people,
              title: 'Teams',
              color: Color(0xFF4CAF50),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEnhancedActionCard({
    required IconData icon,
    required String title,
    required Color color,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF333333),
            Color(0xFF222222),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: () {
          HapticFeedback.mediumImpact();
          if (title == 'Teams') {
            final leaguesModel = _convertToLeaguesModel(widget.league);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => LeagueTeamsPage(
                  league: widget.league,
                  isHostView: true,
                ),
              ),
            );
          } else if (title == 'Schedule') {
            _navigateToSearchWithEvents(widget.league.name);
          }
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: color,
                size: 28,
              ),
              const SizedBox(height: 8),
              Text(
                title,
                style: TextStyle(
                  color: Colors.grey[300],
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLeagueFeed() {
    return Container(
      margin: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'League Feed',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          // Feed content would go here
          Container(
            height: 200,
            decoration: BoxDecoration(
              color: Colors.grey[900],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                'Feed content coming soon...',
                style: TextStyle(
                  color: Colors.grey[500],
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  leagues_model.LeagueModel _convertToLeaguesModel(LeagueModel searchModel) {
    return leagues_model.LeagueModel(
      id: searchModel.id,
      name: searchModel.name,
      description: searchModel.description ?? '',
      location: searchModel.location ?? '',
      type: '',
      creatorId: '',
    );
  }

  void _navigateToSearchWithEvents(String leagueName) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SearchScreen(
          // initialQuery: leagueName,
          initialTabIndex: 1, // Events tab
        ),
      ),
    );
  }
}
