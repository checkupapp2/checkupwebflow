import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/team_model.dart';
import '../../domain/models/league_model.dart';
import '../widgets/team_list_item.dart';
import 'team_detail_page.dart';
import 'add_team_page.dart';
import 'add_player_page.dart';
import 'add_staff_page.dart';

/// League Teams page showing all teams in a specific league
class LeagueTeamsPage extends StatefulWidget {
  /// The league to show teams for
  final LeagueModel league;
  
  /// Whether this is the host view (with add/edit capabilities)
  final bool isHostView;

  /// Constructor
  const LeagueTeamsPage({
    super.key,
    required this.league,
    this.isHostView = false,
  });

  @override
  State<LeagueTeamsPage> createState() => _LeagueTeamsPageState();
}

class _LeagueTeamsPageState extends State<LeagueTeamsPage> with SingleTickerProviderStateMixin {
  
  // Mock data for league teams - in a real app this would come from an API
  late List<TeamModel> _leagueTeams;
  late List<TeamModel> _filteredTeams;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  
  // Tab controller for Teams, Players, Staff tabs
  late TabController _tabController;
  
  // Mock data for players and staff
  final List<Map<String, dynamic>> _players = [];
  final List<Map<String, dynamic>> _staff = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _initializeTeams();
    _initializePlayers();
    _initializeStaff();
    _filteredTeams = _leagueTeams;
    _searchController.addListener(_onSearchChanged);
  }
  
  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    _tabController.dispose();
    super.dispose();
  }
  
  void _onSearchChanged() {
    setState(() {
      _searchQuery = _searchController.text.toLowerCase();
      _filteredTeams = _leagueTeams.where((team) {
        return team.name.toLowerCase().contains(_searchQuery) ||
               team.handle.toLowerCase().contains(_searchQuery) ||
               (team.location ?? '').toLowerCase().contains(_searchQuery);
      }).toList();
    });
  }

  void _initializeTeams() {
    // Mock teams data for the league using search TeamModel structure
    _leagueTeams = [
      TeamModel(
        id: '1',
        name: 'LA Lakers',
        handle: '@lakers',
        description: '17-time NBA Champions - Showtime legacy',
        logoUrl: 'assets/images/teams/lakers.jpg',
        membersCount: 15,
        followers: 8700,
        sport: 'Basketball',
        location: 'Los Angeles, CA',
        isFollowing: true,
      ),
      TeamModel(
        id: '2',
        name: 'Golden State Warriors',
        handle: '@warriors',
        description: 'Modern dynasty with revolutionary play style',
        logoUrl: 'assets/images/teams/warriors.jpg',
        membersCount: 15,
        followers: 7500,
        sport: 'Basketball',
        location: 'San Francisco, CA',
        isFollowing: false,
      ),
      TeamModel(
        id: '3',
        name: 'Miami Heat',
        handle: '@heat',
        description: 'Culture and championship mentality',
        logoUrl: 'assets/images/teams/heat.jpg',
        membersCount: 15,
        followers: 6200,
        sport: 'Basketball',
        location: 'Miami, FL',
        isFollowing: false,
      ),
      TeamModel(
        id: '4',
        name: 'Boston Celtics',
        handle: '@celtics',
        description: 'Historic franchise with winning tradition',
        logoUrl: 'assets/images/teams/celtics.jpg',
        membersCount: 15,
        followers: 7800,
        sport: 'Basketball',
        location: 'Boston, MA',
        isFollowing: false,
      ),
      TeamModel(
        id: '5',
        name: 'Chicago Bulls',
        handle: '@bulls',
        description: 'Jordan era legacy and championship history',
        logoUrl: 'assets/images/teams/bulls.jpg',
        membersCount: 15,
        followers: 9200,
        sport: 'Basketball',
        location: 'Chicago, IL',
        isFollowing: true,
      ),
    ];
  }
  
  void _initializePlayers() {
    // Mock players data from all teams in the league
    _players.addAll([
      {
        'name': 'LeBron James',
        'position': 'Forward',
        'team': 'LA Lakers',
        'number': 23,
      },
      {
        'name': 'Anthony Davis',
        'position': 'Center',
        'team': 'LA Lakers',
        'number': 3,
      },
      {
        'name': 'Stephen Curry',
        'position': 'Guard',
        'team': 'Golden State Warriors',
        'number': 30,
      },
      {
        'name': 'Klay Thompson',
        'position': 'Guard',
        'team': 'Golden State Warriors',
        'number': 11,
      },
      {
        'name': 'Jimmy Butler',
        'position': 'Forward',
        'team': 'Miami Heat',
        'number': 22,
      },
      {
        'name': 'Bam Adebayo',
        'position': 'Center',
        'team': 'Miami Heat',
        'number': 13,
      },
      {
        'name': 'Jayson Tatum',
        'position': 'Forward',
        'team': 'Boston Celtics',
        'number': 0,
      },
      {
        'name': 'Jaylen Brown',
        'position': 'Guard',
        'team': 'Boston Celtics',
        'number': 7,
      },
      {
        'name': 'DeMar DeRozan',
        'position': 'Guard',
        'team': 'Chicago Bulls',
        'number': 11,
      },
      {
        'name': 'Nikola Vucevic',
        'position': 'Center',
        'team': 'Chicago Bulls',
        'number': 9,
      },
    ]);
  }
  
  void _initializeStaff() {
    // Mock staff data from all teams in the league
    _staff.addAll([
      {
        'name': 'Darvin Ham',
        'role': 'Head Coach',
        'team': 'LA Lakers',
        'experience': 8,
      },
      {
        'name': 'Phil Handy',
        'role': 'Assistant Coach',
        'team': 'LA Lakers',
        'experience': 15,
      },
      {
        'name': 'Steve Kerr',
        'role': 'Head Coach',
        'team': 'Golden State Warriors',
        'experience': 12,
      },
      {
        'name': 'Kenny Atkinson',
        'role': 'Assistant Coach',
        'team': 'Golden State Warriors',
        'experience': 18,
      },
      {
        'name': 'Erik Spoelstra',
        'role': 'Head Coach',
        'team': 'Miami Heat',
        'experience': 20,
      },
      {
        'name': 'Chris Quinn',
        'role': 'Assistant Coach',
        'team': 'Miami Heat',
        'experience': 6,
      },
      {
        'name': 'Joe Mazzulla',
        'role': 'Head Coach',
        'team': 'Boston Celtics',
        'experience': 3,
      },
      {
        'name': 'Sam Cassell',
        'role': 'Assistant Coach',
        'team': 'Boston Celtics',
        'experience': 10,
      },
      {
        'name': 'Billy Donovan',
        'role': 'Head Coach',
        'team': 'Chicago Bulls',
        'experience': 25,
      },
      {
        'name': 'Maurice Cheeks',
        'role': 'Assistant Coach',
        'team': 'Chicago Bulls',
        'experience': 30,
      },
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            HapticFeedback.mediumImpact();
            Navigator.pop(context);
          },
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.league.name,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'TEAMS',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
                fontWeight: FontWeight.w500,
                letterSpacing: 1.0,
              ),
            ),
          ],
        ),
        actions: [],
      ),
      body: Column(
        children: [
          // Search bar
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey[900],
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey[700]!, width: 1),
            ),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Search teams...',
                hintStyle: TextStyle(color: Colors.grey[500]),
                prefixIcon: Icon(Icons.search, color: Colors.grey[500]),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
          ),
          // Tab Bar with enhanced design
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.grey[900]!, Colors.black],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: TabBar(
                controller: _tabController,
                labelColor: Colors.white,
                unselectedLabelColor: Colors.grey[400],
                indicatorSize: TabBarIndicatorSize.tab,
                indicator: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                indicatorPadding: const EdgeInsets.all(4),
                labelStyle: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  letterSpacing: 0.5,
                ),
                unselectedLabelStyle: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                  letterSpacing: 0.3,
                ),
                dividerColor: Colors.transparent,
                overlayColor: MaterialStateProperty.all(Colors.transparent),
                splashFactory: NoSplash.splashFactory,
                tabs: const [
                  Tab(
                    height: 48,
                    child: Text('Teams'),
                  ),
                  Tab(
                    height: 48,
                    child: Text('Players'),
                  ),
                  Tab(
                    height: 48,
                    child: Text('Staff'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Tab content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildTeamsTab(),
                _buildPlayersTab(),
                _buildStaffTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamsTab() {
    return Column(
      children: [
        // Add Team button for host view
        if (widget.isHostView)
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Icon(
                  Icons.groups,
                  color: const Color(0xFFFF9800),
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  'Teams',
                  style: TextStyle(
                    color: Colors.grey[300],
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                _buildAddButton(
                  onTap: () => _navigateToAddTeam(),
                  label: 'Add Team',
                ),
              ],
            ),
          ),
        
        // Teams list
        Expanded(
          child: _filteredTeams.isEmpty
            ? (_searchQuery.isNotEmpty 
                ? _buildNoSearchResults()
                : _buildEmptyTeamsState())
            : ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _filteredTeams.length,
                itemBuilder: (context, index) {
                  final team = _filteredTeams[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: widget.isHostView 
                      ? _buildHostTeamCard(team)
                      : TeamListItem(
                          team: team,
                          onTap: () => _navigateToTeamDetail(team),
                        ),
                  );
                },
              ),
        ),
      ],
    );
  }
  
  // Host team card with add/remove functionality
  Widget _buildHostTeamCard(TeamModel team) {
    return Stack(
      children: [
        TeamListItem(
          team: team,
          onTap: () => _navigateToTeamDetail(team),
        ),
        // Remove button positioned in top right
        Positioned(
          top: 8,
          right: 8,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.red.withValues(alpha: 0.9),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.red.withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: IconButton(
              onPressed: () => _showRemoveTeamDialog(team),
              icon: const Icon(
                Icons.remove_circle_outline,
                color: Colors.white,
                size: 18,
              ),
              tooltip: 'Remove Team',
              padding: const EdgeInsets.all(6),
              constraints: const BoxConstraints(
                minWidth: 32,
                minHeight: 32,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPlayersTab() {
    return Column(
      children: [
        // Add Player button for host view
        if (widget.isHostView)
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Icon(
                  Icons.sports_basketball,
                  color: const Color(0xFFFF9800),
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  'Players',
                  style: TextStyle(
                    color: Colors.grey[300],
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                _buildAddButton(
                  onTap: () => _navigateToAddPlayer(),
                  label: 'Add Player',
                ),
              ],
            ),
          ),
        
        // Players list
        Expanded(
          child: _players.isEmpty
            ? _buildEmptyPlayersState()
            : ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _players.length,
                itemBuilder: (context, index) {
                  final player = _players[index];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.grey[900],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey[700]!, width: 1),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            shape: BoxShape.circle,
                          ),
                          child: Center(
                            child: Text(
                              player['name'][0],
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                player['name'],
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${player['position']} • ${player['team']}',
                                style: TextStyle(
                                  color: Colors.grey[400],
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '#${player['number']}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        if (widget.isHostView) ...[
                          const SizedBox(width: 8),
                          GestureDetector(
                            onTap: () => _showRemovePlayerDialog(player['name']),
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.red.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: Colors.red.withValues(alpha: 0.3)),
                              ),
                              child: const Icon(
                                Icons.remove,
                                color: Colors.red,
                                size: 16,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  );
                },
              ),
        ),
      ],
    );
  }
  
  Widget _buildStaffTab() {
    return Column(
      children: [
        // Add Staff button for host view
        if (widget.isHostView)
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Icon(
                  Icons.person_pin,
                  color: const Color(0xFFFF9800),
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  'Staff',
                  style: TextStyle(
                    color: Colors.grey[300],
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                _buildAddButton(
                  onTap: () => _navigateToAddStaff(),
                  label: 'Add Staff',
                ),
              ],
            ),
          ),
        
        // Staff list
        Expanded(
          child: _staff.isEmpty
            ? _buildEmptyStaffState()
            : ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _staff.length,
                itemBuilder: (context, index) {
                  final staffMember = _staff[index];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.grey[900],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey[700]!, width: 1),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 25,
                          backgroundColor: Colors.grey[700],
                          child: Icon(
                            _getStaffIcon(staffMember['role']),
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                staffMember['name'],
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${staffMember['role']} • ${staffMember['team']}',
                                style: TextStyle(
                                  color: Colors.grey[400],
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '${staffMember['experience']}y',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        if (widget.isHostView) ...[
                          const SizedBox(width: 8),
                          GestureDetector(
                            onTap: () => _showRemoveStaffDialog(staffMember['name']),
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.red.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: Colors.red.withValues(alpha: 0.3)),
                              ),
                              child: const Icon(
                                Icons.remove,
                                color: Colors.red,
                                size: 16,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  );
                },
              ),
        ),
      ],
    );
  }
  
  IconData _getStaffIcon(String role) {
    switch (role.toLowerCase()) {
      case 'head coach':
        return Icons.sports;
      case 'assistant coach':
        return Icons.assistant;
      case 'trainer':
        return Icons.fitness_center;
      case 'manager':
        return Icons.manage_accounts;
      default:
        return Icons.person;
    }
  }
  
  Widget _buildEmptyTeamsState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.groups_outlined,
            color: Colors.grey[600],
            size: 80,
          ),
          const SizedBox(height: 16),
          Text(
            'No teams in this league yet',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Teams will appear here once they join the league',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildEmptyPlayersState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.sports_basketball,
            color: Colors.grey[600],
            size: 80,
          ),
          const SizedBox(height: 16),
          Text(
            'No players found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Players will appear here once teams are added',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildEmptyStaffState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.people_outline,
            color: Colors.grey[600],
            size: 80,
          ),
          const SizedBox(height: 16),
          Text(
            'No staff found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Staff members will appear here once teams are added',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  

  
  Widget _buildNoSearchResults() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off,
            color: Colors.grey[600],
            size: 80,
          ),
          const SizedBox(height: 16),
          Text(
            'No teams found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Try adjusting your search terms',
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  void _navigateToTeamDetail(TeamModel team) {
    HapticFeedback.mediumImpact();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TeamDetailPage(team: team),
      ),
    );
  }
  
  // Modern add button widget
  Widget _buildAddButton({required VoidCallback onTap, required String label}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF9800).withValues(alpha: 0.3),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.add,
              color: Colors.white,
              size: 16,
            ),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddTeamDialog() {
    if (!widget.isHostView) return;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF212121),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Text(
          'Add New Team',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Team Name',
                labelStyle: TextStyle(color: Colors.grey[400]),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey[600]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFFF9800)),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('CANCEL', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // Add team logic here
            },
            child: Text('ADD TEAM', style: TextStyle(color: Color(0xFFFF9800))),
          ),
        ],
      ),
    );
  }
  
  void _showRemoveTeamDialog(TeamModel team) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF212121),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Text(
          'Remove Team',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Are you sure you want to remove ${team.name} from the league?',
          style: TextStyle(color: Colors.grey[300]),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('CANCEL', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _leagueTeams.removeWhere((t) => t.id == team.id);
                _filteredTeams = _leagueTeams;
              });
            },
            child: Text('REMOVE', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
  

  void _navigateToAddTeam() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddTeamPage(leagueName: widget.league.name),
      ),
    );
    
    if (result != null) {
      // Handle the returned team data
      setState(() {
        // Add team to the list (in a real app, this would be an API call)
      });
    }
  }

  void _navigateToAddPlayer() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddPlayerPage(leagueName: widget.league.name),
      ),
    );
    
    if (result != null) {
      // Handle the returned player data
      setState(() {
        // Add player to the list (in a real app, this would be an API call)
      });
    }
  }

  void _navigateToAddStaff() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddStaffPage(leagueName: widget.league.name),
      ),
    );
    
    if (result != null) {
      // Handle the returned staff data
      setState(() {
        // Add staff to the list (in a real app, this would be an API call)
      });
    }
  }
  
  void _showRemovePlayerDialog(String playerName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF212121),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Text(
          'Remove Player',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Are you sure you want to remove $playerName from the league?',
          style: TextStyle(color: Colors.grey[300]),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('CANCEL', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _players.removeWhere((p) => p['name'] == playerName);
              });
            },
            child: Text('REMOVE', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
  
  void _showAddStaffDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF212121),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Text(
          'Add New Staff Member',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Full Name',
                labelStyle: TextStyle(color: Colors.grey[400]),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey[600]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFFF9800)),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Role',
                labelStyle: TextStyle(color: Colors.grey[400]),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey[600]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFFF9800)),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('CANCEL', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // Add staff logic here
            },
            child: Text('ADD STAFF', style: TextStyle(color: Color(0xFFFF9800))),
          ),
        ],
      ),
    );
  }
  
  void _showRemoveStaffDialog(String staffName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF212121),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Text(
          'Remove Staff Member',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Are you sure you want to remove $staffName from the league staff?',
          style: TextStyle(color: Colors.grey[300]),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('CANCEL', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _staff.removeWhere((s) => s['name'] == staffName);
              });
            },
            child: Text('REMOVE', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
  




}
