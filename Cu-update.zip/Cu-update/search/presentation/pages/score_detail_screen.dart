import 'package:flutter/material.dart';
import '../../domain/models/score_model.dart';
import '../widgets/score_detail_header.dart';
import '../widgets/score_play_by_play_tab.dart';
import '../widgets/score_feed_tab.dart';
import '../widgets/score_stats_tab.dart';
import '../../../feed/presentation/widgets/share_modal.dart';

/// Screen for displaying detailed information about a game score
class ScoreDetailScreen extends StatefulWidget {
  /// The score model to display details for
  final ScoreModel score;

  /// Constructor
  const ScoreDetailScreen({
    super.key,
    required this.score,
  });

  @override
  State<ScoreDetailScreen> createState() => _ScoreDetailScreenState();
}

class _ScoreDetailScreenState extends State<ScoreDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: NestedScrollView(
          headerSliverBuilder: (context, innerBoxIsScrolled) {
            return [
              SliverToBoxAdapter(
                child: Column(
                  children: [
                    // Back button and share button
                    _buildAppBar(),

                    // Score header with teams and score
                    ScoreDetailHeader(score: widget.score),

                    // Tab bar
                    _buildTabBar(),
                  ],
                ),
              ),
            ];
          },
          body: TabBarView(
            controller: _tabController,
            children: [
              ScorePlayByPlayTab(score: widget.score),
              ScoreFeedTab(score: widget.score),
              ScoreStatsTab(score: widget.score),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Back button
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.arrow_back,
                color: Colors.white,
                size: 24,
              ),
            ),
          ),

          // Game status only
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _getStatusColor(),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  _getStatusText(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
              // Game type removed as requested
            ],
          ),

          // Share button
          GestureDetector(
            onTap: () => _handleShareScore(),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFFFF9800),
                    Color(0xFFFF5722),
                  ],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.share,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(24),
      ),
      child: TabBar(
        controller: _tabController,
        // Make indicator wider with padding
        indicatorPadding:
            const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        // Use tab bar indicator size to make it wider
        indicatorSize: TabBarIndicatorSize.tab,
        indicator: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFFF9800),
              Color(0xFFFF5722),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          // Add subtle shadow for modern look
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF9800).withValues(alpha: 0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        dividerColor: Colors.transparent,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey,
        // Increase padding for tabs to make them wider
        padding: const EdgeInsets.symmetric(horizontal: 4),
        labelPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        labelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 14,
        ),
        unselectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.normal,
          fontSize: 14,
        ),
        tabs: const [
          Tab(text: 'Play by Play'),
          Tab(text: 'Feed'),
          Tab(text: 'Stats'),
        ],
      ),
    );
  }

  Color _getStatusColor() {
    switch (widget.score.gameStatus.toLowerCase()) {
      case 'in progress':
        return Colors.green.shade700;
      case 'upcoming':
        return Colors.orange.shade700;
      case 'final':
        return Colors.grey.shade700;
      default:
        return Colors.grey.shade700;
    }
  }

  String _getStatusText() {
    switch (widget.score.gameStatus.toLowerCase()) {
      case 'in progress':
        return 'LIVE';
      case 'upcoming':
        return 'UPCOMING';
      case 'final':
        return 'FINAL';
      default:
        return widget.score.gameStatus.toUpperCase();
    }
  }

  void _handleShareScore() {
    // Share score using ShareModal with same functionality as search page
    ShareModal.show(
      context: context,
      postId: widget.score.id,
      postContent:
          '${widget.score.homeTeamName} vs ${widget.score.awayTeamName} - ${widget.score.homeScore}-${widget.score.awayScore}',
      shareUrl: 'https://checkup.app/scores/${widget.score.id}',
    );
  }
}
