import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Page for adding staff to a league - supports both search and manual creation
class AddStaffPage extends StatefulWidget {
  final String leagueName;

  const AddStaffPage({
    super.key,
    required this.leagueName,
  });

  @override
  State<AddStaffPage> createState() => _AddStaffPageState();
}

class _AddStaffPageState extends State<AddStaffPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _roleController = TextEditingController();
  final TextEditingController _teamController = TextEditingController();
  final TextEditingController _experienceController = TextEditingController();
  
  List<Map<String, dynamic>> _searchResults = [];
  bool _isSearching = false;

  // Mock directory of available staff
  final List<Map<String, dynamic>> _availableStaff = [
    {
      'id': 'staff_1',
      'name': 'Mike Budenholzer',
      'role': 'Head Coach',
      'team': 'Phoenix Suns',
      'experience': '15 years',
      'specialization': 'Offensive Strategy',
    },
    {
      'id': 'staff_2',
      'name': 'Michael Malone',
      'role': 'Head Coach',
      'team': 'Denver Nuggets',
      'experience': '12 years',
      'specialization': 'Player Development',
    },
    {
      'id': 'staff_3',
      'name': 'Joe Mazzulla',
      'role': 'Head Coach',
      'team': 'Boston Celtics',
      'experience': '8 years',
      'specialization': 'Defensive Systems',
    },
    {
      'id': 'staff_4',
      'name': 'David Fizdale',
      'role': 'Assistant Coach',
      'team': 'Phoenix Suns',
      'experience': '18 years',
      'specialization': 'Player Relations',
    },
    {
      'id': 'staff_5',
      'name': 'Aaron Nelson',
      'role': 'Athletic Trainer',
      'team': 'Phoenix Suns',
      'experience': '20 years',
      'specialization': 'Injury Prevention',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _searchResults = _availableStaff;
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    _nameController.dispose();
    _roleController.dispose();
    _teamController.dispose();
    _experienceController.dispose();
    super.dispose();
  }

  void _performSearch(String query) {
    setState(() {
      _isSearching = query.isNotEmpty;
      if (query.isEmpty) {
        _searchResults = _availableStaff;
      } else {
        _searchResults = _availableStaff.where((staff) =>
          staff['name'].toLowerCase().contains(query.toLowerCase()) ||
          staff['role'].toLowerCase().contains(query.toLowerCase()) ||
          staff['team'].toLowerCase().contains(query.toLowerCase()) ||
          staff['specialization'].toLowerCase().contains(query.toLowerCase())
        ).toList();
      }
    });
  }

  void _addExistingStaff(Map<String, dynamic> staff) {
    HapticFeedback.mediumImpact();
    // Add staff to league logic here
    Navigator.pop(context, staff);
  }

  void _createNewStaff() {
    if (_nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter a staff name'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    HapticFeedback.mediumImpact();
    
    final newStaff = {
      'id': 'new_${DateTime.now().millisecondsSinceEpoch}',
      'name': _nameController.text.trim(),
      'role': _roleController.text.trim().isEmpty ? 'Staff Member' : _roleController.text.trim(),
      'team': _teamController.text.trim().isEmpty ? widget.leagueName : _teamController.text.trim(),
      'experience': _experienceController.text.trim().isEmpty ? '0 years' : '${_experienceController.text.trim()} years',
      'specialization': 'General',
    };

    Navigator.pop(context, newStaff);
  }

  IconData _getStaffIcon(String role) {
    switch (role.toLowerCase()) {
      case 'head coach':
      case 'coach':
        return Icons.sports;
      case 'assistant coach':
        return Icons.assistant;
      case 'athletic trainer':
      case 'trainer':
        return Icons.fitness_center;
      case 'manager':
        return Icons.manage_accounts;
      case 'analyst':
        return Icons.analytics;
      default:
        return Icons.person;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.grey[900],
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Add Staff to ${widget.leagueName}',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(60),
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(12),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              indicatorPadding: EdgeInsets.all(4),
              labelColor: Colors.white,
              unselectedLabelColor: Colors.grey[400],
              labelStyle: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
              unselectedLabelStyle: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
              dividerColor: Colors.transparent,
              dividerHeight: 0,
              tabs: [
                Tab(
                  height: 44,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.search, size: 18),
                      SizedBox(width: 6),
                      Text('Search'),
                    ],
                  ),
                ),
                Tab(
                  height: 44,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.add_circle_outline, size: 18),
                      SizedBox(width: 6),
                      Text('Create'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildSearchTab(),
          _buildCreateTab(),
        ],
      ),
    );
  }

  Widget _buildSearchTab() {
    return Column(
      children: [
        // Search bar
        Container(
          margin: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey[700]!),
          ),
          child: TextField(
            controller: _searchController,
            style: TextStyle(color: Colors.white),
            onChanged: _performSearch,
            decoration: InputDecoration(
              hintText: 'Search staff by name, role, team, or specialization...',
              hintStyle: TextStyle(color: Colors.grey[400]),
              prefixIcon: Icon(Icons.search, color: Color(0xFFFF9800)),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
        ),

        // Search results
        Expanded(
          child: _searchResults.isEmpty
            ? _buildEmptyState()
            : ListView.builder(
                padding: EdgeInsets.symmetric(horizontal: 16),
                itemCount: _searchResults.length,
                itemBuilder: (context, index) {
                  final staff = _searchResults[index];
                  return _buildStaffCard(staff);
                },
              ),
        ),
      ],
    );
  }

  Widget _buildCreateTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Create New Staff Member',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Add a new staff member to ${widget.leagueName}',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 16,
            ),
          ),
          SizedBox(height: 32),

          _buildInputField(
            controller: _nameController,
            label: 'Staff Name *',
            hint: 'Enter staff member name',
            icon: Icons.person,
          ),
          SizedBox(height: 16),

          _buildInputField(
            controller: _roleController,
            label: 'Role',
            hint: 'e.g., Head Coach, Assistant Coach, Trainer',
            icon: Icons.work,
          ),
          SizedBox(height: 16),

          _buildInputField(
            controller: _teamController,
            label: 'Team',
            hint: 'Enter team name',
            icon: Icons.groups,
          ),
          SizedBox(height: 16),

          _buildInputField(
            controller: _experienceController,
            label: 'Years of Experience',
            hint: 'e.g., 5',
            icon: Icons.timeline,
          ),
          SizedBox(height: 32),

          // Create button
          Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Color(0xFFFF9800).withValues(alpha: 0.3),
                  blurRadius: 12,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _createNewStaff,
                borderRadius: BorderRadius.circular(12),
                child: Center(
                  child: Text(
                    'CREATE STAFF MEMBER',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey[700]!),
          ),
          child: TextField(
            controller: controller,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: Colors.grey[400]),
              prefixIcon: Icon(icon, color: Color(0xFFFF9800)),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStaffCard(Map<String, dynamic> staff) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[700]!),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _addExistingStaff(staff),
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                // Staff avatar
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Icon(
                      _getStaffIcon(staff['role']),
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                ),
                SizedBox(width: 16),

                // Staff info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        staff['name'],
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        '${staff['role']} • ${staff['team']}',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 14,
                        ),
                      ),
                      SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              staff['experience'],
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(width: 8),
                          Text(
                            staff['specialization'],
                            style: TextStyle(
                              color: Colors.grey[500],
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Add button
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.add, color: Colors.white, size: 16),
                      SizedBox(width: 4),
                      Text(
                        'ADD',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off,
            color: Colors.grey[600],
            size: 64,
          ),
          SizedBox(height: 16),
          Text(
            'No staff found',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Try a different search term or create a new staff member',
            style: TextStyle(
              color: Colors.grey[500],
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
