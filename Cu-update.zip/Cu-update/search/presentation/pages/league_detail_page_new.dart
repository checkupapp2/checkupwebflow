import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../domain/models/league_model.dart';
import '../../../leagues/presentation/routes/league_routes.dart';
import '../../../leagues/presentation/widgets/league_tabbed_feed.dart';
import '../../../leagues/presentation/pages/schedule_page.dart';
import '../../../leagues/presentation/pages/league_settings_page.dart';
import '../../../feed/domain/models/feed_post_model.dart';
import '../../../feed/data/feed_data_provider.dart';
import '../search_screen.dart';
import '../../../leagues/domain/models/league_model.dart' as leagues_model;
import 'league_teams_page.dart';
import '../../../brackets/presentation/pages/league_brackets_page.dart';

/// League Detail Page that displays detailed information about a league
class LeagueDetailPage extends StatefulWidget {
  /// The league to display details for
  final LeagueModel league;
  
  /// Whether this is the host view (with team chat icon and manage button)
  final bool isHostView;
  
  /// Optional custom button builder to override the default follow/share buttons
  /// If provided, this will be used instead of the default follow button
  final Widget Function(BuildContext context, LeagueModel league, bool isFollowing, Function() toggleFollow)? customButtonBuilder;

  /// Optional custom feed builder to override the default feed section
  /// If provided, this will be used instead of the default feed section
  final Widget Function(BuildContext context, LeagueModel league, List<FeedPostModel> feedPosts)? customFeedBuilder;

  /// Constructor
  const LeagueDetailPage({
    super.key,
    required this.league,
    this.isHostView = true,
    this.customButtonBuilder,
    this.customFeedBuilder,
  });

  @override
  State<LeagueDetailPage> createState() => _LeagueDetailPageState();
}

class _LeagueDetailPageState extends State<LeagueDetailPage> {
  bool _isFollowing = false;
  late List<FeedPostModel> _feedPosts;
  
  /// Generate a season name based on current date or league info
  String _getCurrentSeasonName() {
    final now = DateTime.now();
    final year = now.year;
    final month = now.month;
    
    // Determine season based on month
    String season;
    if (month >= 3 && month <= 5) {
      season = 'Spring';
    } else if (month >= 6 && month <= 8) {
      season = 'Summer';
    } else if (month >= 9 && month <= 11) {
      season = 'Fall';
    } else {
      season = 'Winter';
    }
    
    return '$season $year';
  }

  @override
  void initState() {
    super.initState();
    // Initialize feed posts
    final feedDataProvider = FeedDataProvider();
    _feedPosts = feedDataProvider.getFeedPosts().take(5).toList();
    _isFollowing = widget.league.isFollowing == true;
  }

  void _toggleFollow() {
    setState(() {
      _isFollowing = !_isFollowing;
      // In a real app, this would call an API to follow/unfollow
    });

    // Show feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _isFollowing ? 'Following ${widget.league.name}' : 'Unfollowed ${widget.league.name}',
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.grey[800],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(10),
      ),
    );
  }

  /// Determine if the league is currently in season
  bool _isInSeason() {
    // Simple logic: assume leagues are in season from March to October
    final now = DateTime.now();
    final month = now.month;
    return month >= 3 && month <= 10;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF121212),
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF2A2A2A),
                Color(0xFF121212),
              ],
            ),
          ),
        ),
        elevation: 0,
        centerTitle: true,
        title: Text(
          'Nike EYB',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () {
                  HapticFeedback.mediumImpact();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Sharing ${widget.league.name}',
                        style: const TextStyle(color: Colors.white),
                      ),
                      backgroundColor: Colors.grey[850],
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      margin: const EdgeInsets.all(10),
                    ),
                  );
                },
                borderRadius: BorderRadius.circular(20),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.share,
                        color: Colors.white,
                        size: 16,
                      ),
                      const SizedBox(width: 6),
                      const Text(
                        'Share',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildLeagueHeader(),
            _buildActionCards(),
            const SizedBox(height: 24),
            _buildLeagueFeed(),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildLeagueHeader() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF121212),
            Color(0xFF121212),
          ],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 20),
              
              // Minimalist Card Container
              Stack(
                children: [
                  Container(
                    padding: const EdgeInsets.all(32),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(32),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.1),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.3),
                          blurRadius: 20,
                          offset: Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        // Minimalist Logo
                        Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFFFF9800).withValues(alpha: 0.4),
                                blurRadius: 20,
                                offset: Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              'JR',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2,
                              ),
                            ),
                          ),
                        ),
                        
                        const SizedBox(height: 24),
                        
                        // League Name - Clean Typography
                        Text(
                          widget.league.name,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.w300,
                            letterSpacing: 1,
                            height: 1.3,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        
                        const SizedBox(height: 12),
                        
                        // Season Status Label
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: _isInSeason() ? Colors.green[700] : Colors.grey[700],
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: _isInSeason() ? Colors.green[500]! : Colors.grey[500]!,
                              width: 1,
                            ),
                          ),
                          child: Text(
                            _isInSeason() ? 'IN SEASON' : 'OFF SEASON',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),
                        
                        const SizedBox(height: 20),
                        
                        // Clean Info Row
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            // Season Info
                            Column(
                              children: [
                                ShaderMask(
                                  shaderCallback: (bounds) => LinearGradient(
                                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ).createShader(bounds),
                                  child: Text(
                                    _getCurrentSeasonName(),
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'SEASON',
                                  style: TextStyle(
                                    color: Colors.white.withValues(alpha: 0.6),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                            
                            // Divider
                            Container(
                              width: 1,
                              height: 40,
                              color: Colors.white.withValues(alpha: 0.2),
                            ),
                            
                            // Location Info
                            Column(
                              children: [
                                Text(
                                  'Augusta, GA',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'LOCATION',
                                  style: TextStyle(
                                    color: Colors.white.withValues(alpha: 0.6),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        
                        const SizedBox(height: 24),
                        
                        // Action Buttons (Follow, Share, Manage)
                        _buildActionButtonsWidget(),
                      ],
                    ),
                  ),
                  
                ],
              ),
              
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildActionButtonsWidget() {
    return Row(
      children: [
        // Follow/Edit Button - Show Edit League for hosts, Follow for regular users
        Expanded(
          flex: 2,
          child: Container(
            height: 44,
            decoration: BoxDecoration(
              gradient: widget.isHostView
                  ? const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    )
                  : _isFollowing
                      ? null
                      : const LinearGradient(
                          colors: [Color(0xFFFF7700), Color(0xFFFF9800)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
              color: (!widget.isHostView && _isFollowing) ? Colors.grey[850] : null,
              borderRadius: BorderRadius.circular(22),
              border: (!widget.isHostView && _isFollowing)
                  ? Border.all(
                      color: Colors.grey[700]!,
                      width: 1,
                    )
                  : null,
            ),
            child: ElevatedButton(
              onPressed: widget.isHostView 
                  ? () {
                      HapticFeedback.mediumImpact();
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => LeagueSettingsPage(league: widget.league),
                        ),
                      );
                    }
                  : _toggleFollow,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(22),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    widget.isHostView 
                        ? Icons.settings
                        : _isFollowing ? Icons.check_circle : Icons.add_circle,
                    color: widget.isHostView 
                        ? Colors.white
                        : _isFollowing ? Colors.grey[400] : Colors.white,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    widget.isHostView 
                        ? 'Edit League'
                        : _isFollowing ? 'Following' : 'Follow',
                    style: TextStyle(
                      color: widget.isHostView 
                          ? Colors.white
                          : _isFollowing ? Colors.grey[300] : Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        
      ],
    );
  }

  Widget _buildActionButtons() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      child: widget.customButtonBuilder != null
        ? widget.customButtonBuilder!(context, widget.league, _isFollowing, _toggleFollow)
        : Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                // Follow Button - Minimalist Design
                Expanded(
                  child: Container(
                    height: 48,
                    margin: const EdgeInsets.only(right: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: _toggleFollow,
                        borderRadius: BorderRadius.circular(12),
                        child: Center(
                          child: Text(
                            _isFollowing ? 'FOLLOWING' : 'FOLLOW',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                
              ],
            ),
          ),
    );
  }
  
  Widget _buildCategoryPill(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF333333),
            Color(0xFF222222),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.orange.withValues(alpha: 0.5), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Text(
        text,
        style: TextStyle(
          color: Colors.orange[100],
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildLeagueLogo() {
    return Container(
      width: 80,
      height: 80,
      margin: const EdgeInsets.only(top: 20, bottom: 10),
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xFF222222),
          border: Border.all(color: Colors.grey[600]!, width: 1),
        ),
        child: Center(
          child: ClipOval(
            child: _buildFallbackLogo(),
          ),
        ),
      ),
    );
  }

  Widget _buildFallbackLogo() {
    return Container(
      width: 76,
      height: 76,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.black,
            Color(0xFF222222),
          ],
        ),
      ),
      child: Center(
        child: Text(
          'JR.EYBL',
          style: TextStyle(
            color: Colors.orange[300],
            fontWeight: FontWeight.bold,
            fontSize: 14,
            shadows: [
              Shadow(
                color: Colors.black.withValues(alpha: 0.5),
                blurRadius: 2,
                offset: Offset(1, 1),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        children: [
          // Minimalist Navigation Cards
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: _buildMinimalistCard(
                    icon: Icons.calendar_today_outlined,
                    title: 'Schedule',
                    subtitle: 'View games',
                  ),
                ),
                Container(
                  width: 1,
                  height: 60,
                  color: Colors.white.withValues(alpha: 0.1),
                ),
                Expanded(
                  child: _buildMinimalistCard(
                    icon: Icons.groups_outlined,
                    title: 'Teams',
                    subtitle: 'Players',
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
  
  Widget _buildLeagueFeed() {
    // If a custom feed builder is provided, use it instead of the default feed
    if (widget.customFeedBuilder != null) {
      return widget.customFeedBuilder!(context, widget.league, _feedPosts);
    }
    
    // Use the new tabbed feed widget for the default implementation
    return LeagueTabbedFeed(
      league: widget.league,
      feedPosts: _feedPosts,
    );
  }

  // Convert from search league model to leagues league model
  leagues_model.LeagueModel _convertToLeaguesModel(LeagueModel searchModel) {
    return leagues_model.LeagueModel(
      id: searchModel.id,
      name: searchModel.name,
      description: searchModel.description ?? '',
      type: searchModel.leagueType ?? 'recreational',
      logoUrl: searchModel.logoUrl,
      creatorId: 'user1', // Default creator ID
      location: searchModel.location ?? '',
    );
  }

  // Navigate to search screen with Events tab selected
  void _navigateToSearchWithEvents(String leagueName) {
    // Navigate to the search screen with the Events tab (index 3) selected
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SearchScreen(
          initialTabIndex: 3, // Events tab index
        ),
      ),
    );
    
    // Note: The SearchScreen doesn't accept an initialSearchQuery parameter
    // We'd need to modify the SearchScreen to accept and pre-fill a search query
    // For now, we'll just navigate to the Events tab
  }

  // Keeping this method for reference but not using it
  Widget _buildEventActivityRow() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF333333),
            Color(0xFF222222),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.groups_outlined,
                color: const Color(0xFFFF9800),
                size: 24,
              ),
              const SizedBox(width: 8),
              Text(
                'Event Activity',
                style: TextStyle(
                  color: Colors.grey[300],
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // User Avatars Row
          _buildUserAvatarsRow(),
          const SizedBox(height: 16),
          _buildActivityItem('Going', '128 players', Icons.check_circle_outline),
          const SizedBox(height: 8),
          _buildActivityItem('Invited', '43 players', Icons.mail_outline),
          const SizedBox(height: 16),
          // Event Feed Section
          _buildEventFeed(),
        ],
      ),
    );
  }
  
  Widget _buildEventFeed() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(color: Colors.grey.withValues(alpha: 0.3), height: 24),
        Text(
          'Recent Activity',
          style: TextStyle(
            color: Colors.grey[300],
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        _buildFeedItem(
          username: 'Michael Jordan',
          action: 'is going',
          timeAgo: '2h ago',
          avatarUrl: 'https://i.pravatar.cc/150?img=8',
        ),
        const SizedBox(height: 12),
        _buildFeedItem(
          username: 'LeBron James',
          action: 'commented',
          comment: 'Looking forward to this tournament!',
          timeAgo: '4h ago',
          avatarUrl: 'https://i.pravatar.cc/150?img=9',
        ),
        const SizedBox(height: 12),
        _buildFeedItem(
          username: 'Stephen Curry',
          action: 'is going',
          timeAgo: '6h ago',
          avatarUrl: 'https://i.pravatar.cc/150?img=10',
        ),
        const SizedBox(height: 12),
        _buildFeedItem(
          username: 'Kevin Durant',
          action: 'invited 5 players',
          timeAgo: '1d ago',
          avatarUrl: 'https://i.pravatar.cc/150?img=11',
        ),
        const SizedBox(height: 8),
        Center(
          child: TextButton(
            onPressed: () {},
            child: Text(
              'View All Activity',
              style: TextStyle(
                color: Colors.orange[300],
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    );
  }
  
  Widget _buildFeedItem({
    required String username,
    required String action,
    String? comment,
    required String timeAgo,
    required String avatarUrl,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: Colors.orange.withValues(alpha: 0.5), width: 1),
          ),
          child: ClipOval(
            child: Image.network(
              avatarUrl,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFF444444),
                        Color(0xFF333333),
                      ],
                    ),
                  ),
                  child: Center(
                    child: Text(
                      username.substring(0, 1),
                      style: TextStyle(
                        color: Colors.orange[300],
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: username,
                      style: TextStyle(
                        color: Colors.grey[300],
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    TextSpan(
                      text: ' $action',
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              if (comment != null) ...[  
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey.withValues(alpha: 0.2)),
                  ),
                  child: Text(
                    comment,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 13,
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 4),
              Text(
                timeAgo,
                style: TextStyle(
                  color: Colors.grey[500],
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildUserAvatarsRow() {
    // List of avatar image URLs or initials for fallback
    final List<String> avatars = [
      'https://i.pravatar.cc/150?img=1',
      'https://i.pravatar.cc/150?img=2',
      'https://i.pravatar.cc/150?img=3',
      'https://i.pravatar.cc/150?img=4',
      'https://i.pravatar.cc/150?img=5',
      'https://i.pravatar.cc/150?img=6',
      'https://i.pravatar.cc/150?img=7',
    ];
    
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          ...avatars.map((avatar) => _buildAvatarCircle(avatar)).toList(),
          // More indicator
          Container(
            margin: const EdgeInsets.only(left: 8),
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF444444),
                  Color(0xFF333333),
                ],
              ),
              border: Border.all(color: Colors.orange.withValues(alpha: 0.5), width: 1),
            ),
            child: Center(
              child: Text(
                '+42',
                style: TextStyle(
                  color: Colors.orange[300],
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildAvatarCircle(String imageUrl) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Colors.orange.withValues(alpha: 0.5), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: ClipOval(
        child: Image.network(
          imageUrl,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) {
            // Fallback for failed image loads
            return Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF444444),
                    Color(0xFF333333),
                  ],
                ),
              ),
              child: Center(
                child: Text(
                  imageUrl.substring(imageUrl.length - 1),
                  style: TextStyle(
                    color: Colors.orange[300],
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
  
  Widget _buildActivityItem(String title, String count, IconData icon) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Icon(
              icon,
              color: Colors.orange[300],
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        Text(
          count,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _buildMinimalistCard({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          HapticFeedback.mediumImpact();
          if (title == 'Schedule') {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => SchedulePage(isHostView: true),
              ),
            );
          } else if (title == 'Teams') {
            HapticFeedback.mediumImpact();
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => LeagueTeamsPage(
                  league: widget.league,
                  isHostView: true,
                ),
              ),
            );
          }
        },
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ).createShader(bounds),
                child: Icon(
                  icon,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.6),
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEnhancedActionCard({
    required IconData icon,
    required String title,
    required Color color,
  }) {
    return Container(
      height: 80,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: color.withValues(alpha: 0.4),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.2),
            blurRadius: 12,
            offset: Offset(0, 6),
          ),
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            HapticFeedback.mediumImpact();
            if (title == 'Schedule') {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SchedulePage(isHostView: true),
                ),
              );
            } else if (title == 'Brackets') {
              // Navigate to brackets - simplified for now
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Opening ${widget.league.name} Brackets',
                    style: const TextStyle(color: Colors.white),
                  ),
                  backgroundColor: Colors.grey[850],
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  margin: const EdgeInsets.all(10),
                ),
              );
            }
          },
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    icon,
                    color: color,
                    size: 24,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required Color color,
  }) {
    // Special case for Seasons card to include Create Season button
    if (title == 'Seasons') {
      return _buildSeasonsCard(icon, title, color);
    }
    
    return InkWell(
      onTap: () {
        HapticFeedback.mediumImpact();
        if (title == 'Schedule') {
          print('🚀 HOST League Detail: Navigating to Schedule with isHostView: true');
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) {
                print('🏗️ HOST League Detail: Building SchedulePage with isHostView: true');
                return SchedulePage(isHostView: true);
              },
            ),
          );
        } else if (title == 'Events') {
          // Navigate to search screen with Events tab selected and league name as search query
          _navigateToSearchWithEvents(widget.league.name);
        } else if (title == 'Brackets') {
          // Navigate to the league brackets page
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => LeagueBracketsPage(league: widget.league),
            ),
          );
        } else {
          // Handle other card actions in the future
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                '$title feature coming soon',
                style: const TextStyle(color: Colors.white),
              ),
              backgroundColor: Colors.grey[850],
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              margin: const EdgeInsets.all(10),
            ),
          );
        }
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        height: 80,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF333333),
              Color(0xFF222222),
            ],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: color,
              size: 28,
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  // Special card for Seasons with Create Season button
  Widget _buildSeasonsCard(IconData icon, String title, Color color) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF333333),
            Color(0xFF222222),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Create Season Button at the top
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () {
                  HapticFeedback.mediumImpact();
                  // Navigate to create season page
                  final leaguesModel = _convertToLeaguesModel(widget.league);
                  LeagueRoutes.navigateToCreateSeasonPage(context, leaguesModel);
                },
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12),
                  topRight: Radius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.add_circle_outline,
                        color: Colors.white,
                        size: 18,
                      ),
                      SizedBox(width: 8),
                      Text(
                        'Create Season',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          // Seasons content
          InkWell(
            onTap: () {
              HapticFeedback.mediumImpact();
              // Navigate to the seasons page with the current league
              final leaguesModel = _convertToLeaguesModel(widget.league);
              LeagueRoutes.navigateToSeasonPage(context, leaguesModel);
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    icon,
                    color: color,
                    size: 28,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    title,
                    style: TextStyle(
                      color: Colors.grey[300],
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


}
