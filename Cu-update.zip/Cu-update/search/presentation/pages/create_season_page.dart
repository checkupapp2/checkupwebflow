import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../domain/models/league_model.dart';

/// Create Season Page for adding a new season to a league
class CreateSeasonPage extends StatefulWidget {
  /// The league to create a season for
  final LeagueModel league;

  /// Constructor
  const CreateSeasonPage({
    super.key,
    required this.league,
  });

  @override
  State<CreateSeasonPage> createState() => _CreateSeasonPageState();
}

class _CreateSeasonPageState extends State<CreateSeasonPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _startDateController = TextEditingController();
  final _endDateController = TextEditingController();
  final _teamsController = TextEditingController();
  
  DateTime? _startDate;
  DateTime? _endDate;
  String _selectedDivision = 'Adult';
  String _selectedStatus = 'Upcoming';
  bool _isRegistrationOpen = true;
  
  final List<String> _divisions = ['Adult', 'Youth', '16U', '12U'];
  final List<String> _statuses = ['Upcoming', 'Active', 'Completed'];
  
  @override
  void dispose() {
    _nameController.dispose();
    _startDateController.dispose();
    _endDateController.dispose();
    _teamsController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      extendBodyBehindAppBar: false,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF000000), Color(0xFF1A1A1A)],
            ),
          ),
        ),
        title: const Text(
          'Create New Season',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: TextButton(
              onPressed: _submitForm,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                      blurRadius: 8,
                      spreadRadius: 1,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Text(
                  'Create',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // League info card
              _buildLeagueInfoCard(),
              
              const SizedBox(height: 24),
              
              // Season name
              _buildSectionTitle('Season Name'),
              _buildTextField(
                controller: _nameController,
                hintText: 'e.g. Summer 2025',
                prefixIcon: Icons.sports_soccer,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a season name';
                  }
                  return null;
                },
              ),
              
              const SizedBox(height: 24),
              
              // Date Range
              _buildSectionTitle('Date Range'),
              Row(
                children: [
                  // Start date
                  Expanded(
                    child: _buildDateField(
                      controller: _startDateController,
                      labelText: 'Start Date',
                      onTap: () => _selectDate(context, isStartDate: true),
                    ),
                  ),
                  const SizedBox(width: 16),
                  // End date
                  Expanded(
                    child: _buildDateField(
                      controller: _endDateController,
                      labelText: 'End Date',
                      onTap: () => _selectDate(context, isStartDate: false),
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 24),
              
              // Division
              _buildSectionTitle('Division'),
              _buildDropdown(
                value: _selectedDivision,
                items: _divisions,
                prefixIcon: Icons.category,
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      _selectedDivision = value;
                      HapticFeedback.lightImpact();
                    });
                  }
                },
              ),
              
              const SizedBox(height: 24),
              
              // Status
              _buildSectionTitle('Status'),
              _buildDropdown(
                value: _selectedStatus,
                items: _statuses,
                prefixIcon: Icons.flag,
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      _selectedStatus = value;
                      HapticFeedback.lightImpact();
                    });
                  }
                },
              ),
              
              const SizedBox(height: 24),
              
              // Teams
              _buildSectionTitle('Expected Teams'),
              _buildTextField(
                controller: _teamsController,
                hintText: 'e.g. 12',
                keyboardType: TextInputType.number,
                prefixIcon: Icons.groups,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter expected number of teams';
                  }
                  if (int.tryParse(value) == null) {
                    return 'Please enter a valid number';
                  }
                  return null;
                },
              ),
              
              const SizedBox(height: 24),
              
              // Registration toggle
              _buildSectionTitle('Registration'),
              Container(
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 8,
                      spreadRadius: 1,
                      offset: const Offset(0, 2),
                    ),
                  ],
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Colors.grey[900]!, Colors.grey[850]!],
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: SwitchListTile(
                    title: const Text(
                      'Open Registration',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                    subtitle: Text(
                      _isRegistrationOpen 
                          ? 'Teams can register for this season' 
                          : 'Registration is closed',
                      style: TextStyle(color: Colors.grey[400]),
                    ),
                    secondary: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _isRegistrationOpen 
                            ? const Color(0xFFFF9800).withValues(alpha: 0.1)
                            : Colors.grey.withValues(alpha: 0.1),
                      ),
                      child: Icon(
                        _isRegistrationOpen ? Icons.app_registration : Icons.do_not_disturb,
                        color: _isRegistrationOpen ? const Color(0xFFFF9800) : Colors.grey,
                      ),
                    ),
                    value: _isRegistrationOpen,
                    onChanged: (value) {
                      HapticFeedback.mediumImpact();
                      setState(() {
                        _isRegistrationOpen = value;
                      });
                    },
                    activeColor: const Color(0xFFFF9800),
                    activeTrackColor: const Color(0xFFFF9800).withValues(alpha: 0.3),
                    inactiveThumbColor: Colors.grey,
                    inactiveTrackColor: Colors.grey.withValues(alpha: 0.3),
                  ),
                ),
              ),
              
              // Submit button at bottom
              const SizedBox(height: 40),
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 24),
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF9800).withValues(alpha: 0.4),
                      blurRadius: 12,
                      spreadRadius: 2,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: _submitForm,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(28),
                    ),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.add_circle_outline,
                        color: Colors.white,
                        size: 24,
                      ),
                      SizedBox(width: 8),
                      Text(
                        'Create Season',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildLeagueInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.grey[900]!,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[800]!),
      ),
      child: Row(
        children: [
          // League logo
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.grey[800],
              image: widget.league.logoUrl != null
                  ? DecorationImage(
                      image: NetworkImage(widget.league.logoUrl!),
                      fit: BoxFit.cover,
                    )
                  : null,
            ),
            child: widget.league.logoUrl == null
                ? Center(
                    child: Text(
                      widget.league.name.isNotEmpty
                          ? widget.league.name[0].toUpperCase()
                          : 'L',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  )
                : null,
          ),
          const SizedBox(width: 16),
          // League info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.league.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Creating new season',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 8),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 20,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              ),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
    IconData? prefixIcon,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            spreadRadius: 1,
            offset: const Offset(0, 2),
          ),
        ],
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.grey[900]!, Colors.grey[850]!],
        ),
      ),
      child: TextFormField(
        controller: controller,
        style: const TextStyle(color: Colors.white),
        keyboardType: keyboardType,
        cursorColor: const Color(0xFFFF9800),
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(color: Colors.grey[500]),
          filled: true,
          fillColor: Colors.transparent,
          prefixIcon: prefixIcon != null ? Icon(prefixIcon, color: const Color(0xFFFF9800)) : null,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFFFF9800), width: 2),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
        validator: validator,
      ),
    );
  }
  
  Widget _buildDateField({
    required TextEditingController controller,
    required String labelText,
    required VoidCallback onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            spreadRadius: 1,
            offset: const Offset(0, 2),
          ),
        ],
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.grey[900]!, Colors.grey[850]!],
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          splashColor: const Color(0xFFFF9800).withValues(alpha: 0.1),
          highlightColor: const Color(0xFFFF9800).withValues(alpha: 0.05),
          child: TextFormField(
            controller: controller,
            style: const TextStyle(color: Colors.white),
            readOnly: true,
            enabled: false,
            decoration: InputDecoration(
              hintText: labelText,
              hintStyle: TextStyle(color: Colors.grey[500]),
              filled: true,
              fillColor: Colors.transparent,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              prefixIcon: const Icon(Icons.calendar_today, color: Color(0xFFFF9800)),
              disabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please select a date';
              }
              return null;
            },
          ),
        ),
      ),
    );
  }
  
  Widget _buildDropdown({
    required String value,
    required List<String> items,
    required void Function(String?) onChanged,
    IconData? prefixIcon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            spreadRadius: 1,
            offset: const Offset(0, 2),
          ),
        ],
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.grey[900]!, Colors.grey[850]!],
        ),
      ),
      child: Row(
        children: [
          if (prefixIcon != null) 
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: Icon(prefixIcon, color: const Color(0xFFFF9800)),
            ),
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: value,
                isExpanded: true,
                dropdownColor: Colors.grey[850],
                style: const TextStyle(color: Colors.white),
                icon: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFFF9800).withValues(alpha: 0.1),
                  ),
                  child: const Icon(Icons.arrow_drop_down, color: Color(0xFFFF9800)),
                ),
                items: items.map((String item) {
                  return DropdownMenuItem<String>(
                    value: item,
                    child: Text(
                      item,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  );
                }).toList(),
                onChanged: onChanged,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Future<void> _selectDate(BuildContext context, {required bool isStartDate}) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isStartDate ? (_startDate ?? DateTime.now()) : (_endDate ?? DateTime.now().add(const Duration(days: 90))),
      firstDate: isStartDate ? DateTime.now() : (_startDate ?? DateTime.now()),
      lastDate: DateTime.now().add(const Duration(days: 730)), // 2 years ahead
      builder: (context, child) {
        return Theme(
          data: ThemeData.dark().copyWith(
            colorScheme: const ColorScheme.dark(
              primary: Color(0xFFFF9800),
              onPrimary: Colors.white,
              surface: Color(0xFF303030),
              onSurface: Colors.white,
            ),
            dialogBackgroundColor: const Color(0xFF212121),
          ),
          child: child!,
        );
      },
    );
    
    if (picked != null) {
      setState(() {
        if (isStartDate) {
          _startDate = picked;
          _startDateController.text = _formatDate(picked);
          
          // If end date is before start date, update end date
          if (_endDate != null && _endDate!.isBefore(_startDate!)) {
            _endDate = _startDate!.add(const Duration(days: 90));
            _endDateController.text = _formatDate(_endDate!);
          }
        } else {
          _endDate = picked;
          _endDateController.text = _formatDate(picked);
        }
      });
    }
  }
  
  String _formatDate(DateTime date) {
    return '${date.month}/${date.day}/${date.year}';
  }
  
  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      HapticFeedback.mediumImpact();
      
      // Create a new season object
      final newSeason = {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'name': _nameController.text,
        'status': _selectedStatus,
        'dateRange': '${_formatDate(_startDate!)} - ${_formatDate(_endDate!)}',
        'teams': int.parse(_teamsController.text),
        'division': _selectedDivision,
        'icon': _getIconForDivision(_selectedDivision),
        'color': _getColorForDivision(_selectedDivision),
        'isRegistrationOpen': _isRegistrationOpen,
      };
      
      // Show success message with animation
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(
                Icons.check_circle_outline,
                color: Colors.white,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Season ${_nameController.text} created successfully!',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          backgroundColor: Colors.green[700],
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          margin: const EdgeInsets.all(16),
          duration: const Duration(seconds: 3),
          action: SnackBarAction(
            label: 'DISMISS',
            textColor: Colors.white,
            onPressed: () {},
          ),
        ),
      );
      
      // Return to previous screen with animation
      Navigator.pop(context);
    }
  }
  
  IconData _getIconForDivision(String division) {
    switch (division) {
      case 'Adult':
        return Icons.person;
      case 'Youth':
        return Icons.school;
      case '16U':
        return Icons.sports;
      case '12U':
        return Icons.child_care;
      default:
        return Icons.sports;
    }
  }
  
  Color _getColorForDivision(String division) {
    switch (division) {
      case 'Adult':
        return const Color(0xFFFF9800); // Orange
      case 'Youth':
        return const Color(0xFF2196F3); // Blue
      case '16U':
        return const Color(0xFF4CAF50); // Green
      case '12U':
        return const Color(0xFFE91E63); // Pink
      default:
        return const Color(0xFFFF9800); // Orange
    }
  }
}
