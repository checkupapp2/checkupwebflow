import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:check_up_app/features/events/domain/models/location_model.dart';
import 'package:check_up_app/features/events/presentation/widgets/enhanced_location_selector.dart';
import 'package:check_up_app/features/events/presentation/widgets/modern_date_time_picker.dart';

/// Step widgets for Create Job Page
class CreateJobSteps {
  static Widget buildJobTypeStep({
    required String selectedJobType,
    required List<String> jobTypes,
    required Function(String) onJobTypeSelected,
    required TextEditingController titleController,
  }) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStepHeader(
            'What type of job are you posting?',
            'Select the job type and enter a descriptive title',
            Icons.work_outline,
          ),
          const SizedBox(height: 32),
          
          // Job type selector
          _buildJobTypeGrid(
            selectedJobType: selectedJobType,
            jobTypes: jobTypes,
            onJobTypeSelected: onJobTypeSelected,
          ),
          
          const SizedBox(height: 32),
          
          // Job title
          Text(
            'Job Title',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: titleController,
            hintText: 'Enter a descriptive job title',
          ),
        ],
      ),
    );
  }

  static Widget buildJobDetailsStep({
    required TextEditingController descriptionController,
    required TextEditingController payRateController,
    required TextEditingController positionsController,
  }) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStepHeader(
            'Tell us about the job',
            'Provide details about responsibilities and compensation',
            Icons.description_outlined,
          ),
          const SizedBox(height: 32),
          
          // Job description
          Text(
            'Job Description',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: descriptionController,
            hintText: 'Describe the job responsibilities, requirements, qualifications...',
            maxLines: 5,
          ),
          
          const SizedBox(height: 24),
          
          // Pay rate
          Text(
            'Pay Rate',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: payRateController,
            hintText: 'e.g. \$25/hr, \$150 flat rate, or \$200-300',
          ),
          
          const SizedBox(height: 24),
          
          // Number of positions
          Text(
            'Positions Available',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: positionsController,
            hintText: 'How many people do you need?',
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          ),
        ],
      ),
    );
  }

  static Widget buildScheduleStep({
    required DateTime? jobDate,
    required DateTime? applicationDeadline,
    required Function(DateTime) onJobDateSelected,
    required Function(DateTime) onDeadlineSelected,
  }) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStepHeader(
            'When is the job?',
            'Set the job date and application deadline',
            Icons.event_note,
          ),
          const SizedBox(height: 32),
          
          // Job date
          Text(
            'Job Date & Time',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          ModernDateTimePicker(
            selectedDateTime: jobDate,
            onDateTimeSelected: onJobDateSelected,
          ),
          
          const SizedBox(height: 32),
          
          // Application deadline
          Text(
            'Application Deadline',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'When should applications close?',
            style: TextStyle(
              color: AppColors.lightGray,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 12),
          ModernDateTimePicker(
            selectedDateTime: applicationDeadline,
            onDateTimeSelected: onDeadlineSelected,
          ),
        ],
      ),
    );
  }

  static Widget buildLocationStep({
    required LocationModel? selectedLocation,
    required bool isLocationPrivate,
    required Function(LocationModel?) onLocationSelected,
    required Function(bool) onPrivacyChanged,
    required TextEditingController locationController,
  }) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStepHeader(
            'Where is the job located?',
            'Set the location where the job will take place',
            Icons.location_on_outlined,
          ),
          const SizedBox(height: 32),
          
          Container(
            decoration: BoxDecoration(
              color: AppColors.secondaryBlack,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.darkGray),
            ),
            child: EnhancedLocationSelector(
              selectedLocation: selectedLocation,
              isLocationPrivate: isLocationPrivate,
              onLocationSelected: onLocationSelected,
              onPrivacyChanged: onPrivacyChanged,
              locationController: locationController,
              hideTitle: true,
            ),
          ),
        ],
      ),
    );
  }

  static Widget buildContactStep({
    required TextEditingController posterNameController,
    required TextEditingController contactEmailController,
    required TextEditingController contactPhoneController,
  }) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStepHeader(
            'Contact Information',
            'How can applicants reach you?',
            Icons.contact_mail_outlined,
          ),
          const SizedBox(height: 32),
          
          // Poster name
          Text(
            'Posted By',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: posterNameController,
            hintText: 'Your name or organization',
          ),
          
          const SizedBox(height: 24),
          
          // Contact email
          Text(
            'Contact Email',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: contactEmailController,
            hintText: 'Email address for applicants',
            keyboardType: TextInputType.emailAddress,
          ),
          
          const SizedBox(height: 24),
          
          // Contact phone (optional)
          Text(
            'Contact Phone (Optional)',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: contactPhoneController,
            hintText: 'Phone number for applicants',
            keyboardType: TextInputType.phone,
          ),
        ],
      ),
    );
  }

  static Widget buildReviewStep({
    required String selectedJobType,
    required TextEditingController titleController,
    required TextEditingController descriptionController,
    required TextEditingController payRateController,
    required TextEditingController positionsController,
    required DateTime? jobDate,
    required DateTime? applicationDeadline,
    required LocationModel? selectedLocation,
    required TextEditingController locationController,
    required TextEditingController posterNameController,
    required TextEditingController contactEmailController,
    required TextEditingController contactPhoneController,
    required bool isFeatured,
    required Function(bool) onFeaturedChanged,
  }) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStepHeader(
            'Review Your Job Post',
            'Make sure everything looks good before posting',
            Icons.preview_outlined,
          ),
          const SizedBox(height: 32),
          
          // Job preview card
          _buildJobPreviewCard(
            selectedJobType: selectedJobType,
            titleController: titleController,
            descriptionController: descriptionController,
            payRateController: payRateController,
            positionsController: positionsController,
            jobDate: jobDate,
            applicationDeadline: applicationDeadline,
            selectedLocation: selectedLocation,
            locationController: locationController,
            posterNameController: posterNameController,
            contactEmailController: contactEmailController,
            contactPhoneController: contactPhoneController,
          ),
          
          const SizedBox(height: 24),
          
          // Featured job option
          _buildFeaturedJobToggle(
            isFeatured: isFeatured,
            onFeaturedChanged: onFeaturedChanged,
          ),
        ],
      ),
    );
  }

  static Widget _buildStepHeader(String title, String subtitle, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppColors.blackGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.darkGray.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: AppColors.orangeGradient,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: AppColors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: AppColors.lightGray,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _buildJobTypeGrid({
    required String selectedJobType,
    required List<String> jobTypes,
    required Function(String) onJobTypeSelected,
  }) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.2,
      ),
      itemCount: jobTypes.length,
      itemBuilder: (context, index) {
        final jobType = jobTypes[index];
        final isSelected = selectedJobType == jobType;
        
        return GestureDetector(
          onTap: () {
            onJobTypeSelected(jobType);
            HapticFeedback.lightImpact();
          },
          child: Container(
            decoration: BoxDecoration(
              gradient: isSelected ? AppColors.orangeGradient : null,
              color: isSelected ? null : AppColors.secondaryBlack,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: isSelected ? Colors.transparent : AppColors.darkGray,
                width: 1,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isSelected ? Colors.white.withValues(alpha: 0.2) : AppColors.darkGray,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _getJobTypeIcon(jobType),
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  jobType,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  static IconData _getJobTypeIcon(String jobType) {
    switch (jobType) {
      case 'Referee':
        return Icons.sports_basketball;
      case 'Scorekeeper':
        return Icons.scoreboard_outlined;
      case 'Videographer':
        return Icons.videocam_outlined;
      case 'Coach':
        return Icons.sports_outlined;
      case 'Trainer':
        return Icons.fitness_center_outlined;
      case 'Other':
        return Icons.work_outline;
      default:
        return Icons.work_outline;
    }
  }

  static Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    int maxLines = 1,
    TextInputType keyboardType = TextInputType.text,
    List<TextInputFormatter>? inputFormatters,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(color: Colors.grey[600]),
        filled: true,
        fillColor: AppColors.secondaryBlack,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: AppColors.darkGray),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: AppColors.darkGray),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: AppColors.orangeGradientEnd),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.red),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.red),
        ),
        errorStyle: const TextStyle(color: Colors.red),
      ),
    );
  }

  static Widget _buildJobPreviewCard({
    required String selectedJobType,
    required TextEditingController titleController,
    required TextEditingController descriptionController,
    required TextEditingController payRateController,
    required TextEditingController positionsController,
    required DateTime? jobDate,
    required DateTime? applicationDeadline,
    required LocationModel? selectedLocation,
    required TextEditingController locationController,
    required TextEditingController posterNameController,
    required TextEditingController contactEmailController,
    required TextEditingController contactPhoneController,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppColors.blackGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.darkGray.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: AppColors.orangeGradient,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  _getJobTypeIcon(selectedJobType),
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      titleController.text,
                      style: TextStyle(
                        color: AppColors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      selectedJobType,
                      style: TextStyle(
                        color: AppColors.lightGray,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          _buildPreviewRow('Description', descriptionController.text),
          _buildPreviewRow('Pay Rate', payRateController.text),
          _buildPreviewRow('Positions', positionsController.text),
          _buildPreviewRow('Job Date', jobDate?.toString().split(' ')[0] ?? 'Not set'),
          _buildPreviewRow('Application Deadline', applicationDeadline?.toString().split(' ')[0] ?? 'Not set'),
          _buildPreviewRow('Location', selectedLocation?.name ?? locationController.text),
          _buildPreviewRow('Posted By', posterNameController.text),
          _buildPreviewRow('Contact Email', contactEmailController.text),
          if (contactPhoneController.text.isNotEmpty)
            _buildPreviewRow('Contact Phone', contactPhoneController.text),
        ],
      ),
    );
  }

  static Widget _buildPreviewRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: TextStyle(
                color: AppColors.lightGray,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value.isEmpty ? 'Not provided' : value,
              style: TextStyle(
                color: value.isEmpty ? AppColors.lightGray.withValues(alpha: 0.6) : AppColors.white,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  static Widget _buildFeaturedJobToggle({
    required bool isFeatured,
    required Function(bool) onFeaturedChanged,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.secondaryBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isFeatured ? AppColors.orangeGradientEnd : AppColors.darkGray,
          width: isFeatured ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: isFeatured ? AppColors.orangeGradient : null,
              color: isFeatured ? null : AppColors.darkGray,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.star,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Featured Job',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Featured jobs appear at the top of search results and include a special badge',
                  style: TextStyle(
                    color: Colors.grey[500],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Switch(
            value: isFeatured,
            onChanged: onFeaturedChanged,
            activeColor: AppColors.orangeGradientEnd,
            activeTrackColor: AppColors.orangeGradientStart.withValues(alpha: 0.5),
          ),
        ],
      ),
    );
  }
}
