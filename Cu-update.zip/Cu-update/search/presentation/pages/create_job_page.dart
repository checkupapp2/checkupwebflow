import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:check_up_app/features/events/domain/models/location_model.dart';
import 'package:check_up_app/features/events/presentation/widgets/enhanced_location_selector.dart';
import 'package:check_up_app/features/events/presentation/widgets/modern_date_time_picker.dart';
import 'package:check_up_app/features/search/domain/models/job_model.dart';
import 'package:check_up_app/features/search/presentation/pages/create_job_steps.dart';

/// Create Job Page
class CreateJobPage extends StatefulWidget {
  /// Constructor
  const CreateJobPage({super.key});

  @override
  State<CreateJobPage> createState() => _CreateJobPageState();
}

class _CreateJobPageState extends State<CreateJobPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _locationController = TextEditingController();
  final _payRateController = TextEditingController();
  final _positionsController = TextEditingController();
  final _contactEmailController = TextEditingController();
  final _contactPhoneController = TextEditingController();
  final _posterNameController = TextEditingController();
  
  // Multi-step navigation
  int _currentStep = 0;
  final int _totalSteps = 6;
  final PageController _pageController = PageController();
  
  // Job type selection
  String _selectedJobType = 'Referee';
  final List<String> _jobTypes = ['Referee', 'Scorekeeper', 'Videographer', 'Coach', 'Trainer', 'Other'];
  
  // Location variables
  LocationModel? _selectedLocation;
  bool _isLocationPrivate = false;
  
  // Date variables
  DateTime? _jobDate;
  DateTime? _applicationDeadline;
  
  // Featured job
  bool _isFeatured = false;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    _payRateController.dispose();
    _positionsController.dispose();
    _contactEmailController.dispose();
    _contactPhoneController.dispose();
    _posterNameController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: SafeArea(
        child: Column(
          children: [
            // Progress indicator
            _buildProgressIndicator(),
            
            // Page content
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  CreateJobSteps.buildJobTypeStep(
                    selectedJobType: _selectedJobType,
                    jobTypes: _jobTypes,
                    onJobTypeSelected: (jobType) {
                      setState(() {
                        _selectedJobType = jobType;
                      });
                    },
                    titleController: _titleController,
                  ),
                  CreateJobSteps.buildJobDetailsStep(
                    descriptionController: _descriptionController,
                    payRateController: _payRateController,
                    positionsController: _positionsController,
                  ),
                  CreateJobSteps.buildScheduleStep(
                    jobDate: _jobDate,
                    applicationDeadline: _applicationDeadline,
                    onJobDateSelected: (dateTime) {
                      setState(() {
                        _jobDate = dateTime;
                      });
                    },
                    onDeadlineSelected: (dateTime) {
                      setState(() {
                        _applicationDeadline = dateTime;
                      });
                    },
                  ),
                  CreateJobSteps.buildLocationStep(
                    selectedLocation: _selectedLocation,
                    isLocationPrivate: _isLocationPrivate,
                    onLocationSelected: (location) {
                      setState(() {
                        _selectedLocation = location;
                      });
                    },
                    onPrivacyChanged: (isPrivate) {
                      setState(() {
                        _isLocationPrivate = isPrivate;
                      });
                    },
                    locationController: _locationController,
                  ),
                  CreateJobSteps.buildContactStep(
                    posterNameController: _posterNameController,
                    contactEmailController: _contactEmailController,
                    contactPhoneController: _contactPhoneController,
                  ),
                  CreateJobSteps.buildReviewStep(
                    selectedJobType: _selectedJobType,
                    titleController: _titleController,
                    descriptionController: _descriptionController,
                    payRateController: _payRateController,
                    positionsController: _positionsController,
                    jobDate: _jobDate,
                    applicationDeadline: _applicationDeadline,
                    selectedLocation: _selectedLocation,
                    locationController: _locationController,
                    posterNameController: _posterNameController,
                    contactEmailController: _contactEmailController,
                    contactPhoneController: _contactPhoneController,
                    isFeatured: _isFeatured,
                    onFeaturedChanged: (value) {
                      setState(() {
                        _isFeatured = value;
                      });
                    },
                  ),
                ],
              ),
            ),
            
            // Navigation buttons
            _buildNavigationButtons(),
          ],
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: Text(
        _getStepTitle(),
        style: const TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
        ),
      ),
      centerTitle: true,
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.4),
          shape: BoxShape.circle,
        ),
        child: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            if (_currentStep > 0) {
              _previousStep();
            } else {
              Navigator.pop(context);
            }
          },
          iconSize: 20,
        ),
      ),
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: AppColors.blackGradient,
        ),
      ),
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.dark,
      ),
    );
  }

  String _getStepTitle() {
    switch (_currentStep) {
      case 0:
        return 'Job Type & Title';
      case 1:
        return 'Job Details';
      case 2:
        return 'Schedule';
      case 3:
        return 'Location';
      case 4:
        return 'Contact Info';
      case 5:
        return 'Review & Post';
      default:
        return 'Post a Job';
    }
  }

  Widget _buildProgressIndicator() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Row(
            children: List.generate(_totalSteps, (index) {
              final isCompleted = index < _currentStep;
              final isCurrent = index == _currentStep;
              
              return Expanded(
                child: Container(
                  margin: EdgeInsets.only(
                    right: index < _totalSteps - 1 ? 8 : 0,
                  ),
                  child: Column(
                    children: [
                      Container(
                        height: 4,
                        decoration: BoxDecoration(
                          gradient: isCompleted || isCurrent
                              ? AppColors.orangeGradient
                              : null,
                          color: isCompleted || isCurrent
                              ? null
                              : AppColors.darkGray,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Step ${index + 1}',
                        style: TextStyle(
                          color: isCompleted || isCurrent
                              ? AppColors.white
                              : AppColors.lightGray,
                          fontSize: 12,
                          fontWeight: isCurrent
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 12),
          Text(
            '${_currentStep + 1} of $_totalSteps',
            style: TextStyle(
              color: AppColors.lightGray,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: AppColors.orangeGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: _getSectionIcon(title),
          ),
          const SizedBox(width: 12),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _getSectionIcon(String title) {
    switch (title) {
      case 'Job Basics':
        return const Icon(Icons.work_outline, color: Colors.white, size: 20);
      case 'Job Details':
        return const Icon(Icons.description_outlined, color: Colors.white, size: 20);
      case 'Date & Location':
        return const Icon(Icons.event_note, color: Colors.white, size: 20);
      case 'Contact Information':
        return const Icon(Icons.contact_mail_outlined, color: Colors.white, size: 20);
      default:
        return const Icon(Icons.circle, color: Colors.white, size: 20);
    }
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    int maxLines = 1,
    TextInputType keyboardType = TextInputType.text,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
    Icon? prefixIcon,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      validator: validator,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(color: Colors.grey[600]),
        prefixIcon: prefixIcon,
        filled: true,
        fillColor: AppColors.secondaryBlack,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: AppColors.darkGray),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: AppColors.darkGray),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: AppColors.orangeGradientEnd),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.red),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.red),
        ),
        errorStyle: const TextStyle(color: Colors.red),
      ),
    );
  }

  Widget _buildJobTypeSelector() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.secondaryBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.darkGray),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedJobType,
          dropdownColor: AppColors.secondaryBlack,
          borderRadius: BorderRadius.circular(12),
          icon: const Icon(Icons.arrow_drop_down, color: Colors.grey),
          isExpanded: true,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          style: const TextStyle(color: Colors.white, fontSize: 16),
          items: _jobTypes.map((String type) {
            return DropdownMenuItem<String>(
              value: type,
              child: Text(type),
            );
          }).toList(),
          onChanged: (String? newValue) {
            if (newValue != null) {
              setState(() {
                _selectedJobType = newValue;
              });
            }
          },
        ),
      ),
    );
  }

  Widget _buildLocationSection() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Location',
            style: TextStyle(
              color: Colors.grey[300],
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: AppColors.secondaryBlack,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.darkGray),
            ),
            child: EnhancedLocationSelector(
              selectedLocation: _selectedLocation,
              isLocationPrivate: _isLocationPrivate,
              onLocationSelected: (location) {
                setState(() {
                  _selectedLocation = location;
                });
              },
              onPrivacyChanged: (isPrivate) {
                setState(() {
                  _isLocationPrivate = isPrivate;
                });
              },
              locationController: _locationController,
              hideTitle: true,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow({
    required String title,
    required Widget child,
    String? subtitle,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: Colors.grey[300],
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          if (subtitle != null)
            Padding(
              padding: const EdgeInsets.only(top: 4, bottom: 8),
              child: Text(
                subtitle,
                style: TextStyle(
                  color: Colors.grey[500],
                  fontSize: 12,
                ),
              ),
            )
          else
            const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }

  Widget _buildFeaturedJobToggle() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.secondaryBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _isFeatured ? AppColors.orangeGradientEnd : AppColors.darkGray,
          width: _isFeatured ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: _isFeatured ? AppColors.orangeGradient : null,
              color: _isFeatured ? null : AppColors.darkGray,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.star,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Featured Job',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Featured jobs appear at the top of search results and include a special badge',
                  style: TextStyle(
                    color: Colors.grey[500],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Switch(
            value: _isFeatured,
            onChanged: (value) {
              setState(() {
                _isFeatured = value;
              });
            },
            activeColor: AppColors.orangeGradientEnd,
            activeTrackColor: AppColors.orangeGradientStart.withValues(alpha: 0.5),
          ),
        ],
      ),
    );
  }

  void _nextStep() {
    if (_validateCurrentStep()) {
      if (_currentStep < _totalSteps - 1) {
        setState(() {
          _currentStep++;
        });
        _pageController.nextPage(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
        HapticFeedback.lightImpact();
      }
    }
  }

  void _previousStep() {
    if (_currentStep > 0) {
      setState(() {
        _currentStep--;
      });
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      HapticFeedback.lightImpact();
    }
  }

  bool _validateCurrentStep() {
    // Allow navigation through all steps without validation for demo purposes
    return true;
  }

  void _submitJob() {
    if (_validateCurrentStep()) {
      // Create job model and save to database (implementation would be added later)
      JobModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: _titleController.text,
        type: _selectedJobType,
        posterName: _posterNameController.text,
        description: _descriptionController.text,
        location: _selectedLocation?.name ?? _locationController.text,
        payRate: _payRateController.text,
        date: _jobDate,
        imageUrl: null, // Would be set from a profile or uploaded image
        isFeatured: _isFeatured,
      );
      
      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Job posted successfully!')),
      );
      
      // Navigate back after successful creation
      Future.delayed(const Duration(seconds: 2), () {
        Navigator.pop(context);
      });
    }
  }

  Widget _buildNavigationButtons() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.primaryBlack,
        border: Border(
          top: BorderSide(color: AppColors.darkGray.withValues(alpha: 0.3)),
        ),
      ),
      child: Row(
        children: [
          if (_currentStep > 0)
            Expanded(
              child: SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: _previousStep,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.secondaryBlack,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: AppColors.darkGray),
                    ),
                  ),
                  child: Text(
                    'Previous',
                    style: TextStyle(
                      color: AppColors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          
          if (_currentStep > 0) const SizedBox(width: 16),
          
          Expanded(
            flex: _currentStep == 0 ? 1 : 1,
            child: SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: _currentStep == _totalSteps - 1 ? _submitJob : _nextStep,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: EdgeInsets.zero,
                ),
                child: Ink(
                  decoration: BoxDecoration(
                    gradient: AppColors.orangeGradient,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Container(
                    alignment: Alignment.center,
                    child: Text(
                      _currentStep == _totalSteps - 1 ? 'Post Job' : 'Next',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
