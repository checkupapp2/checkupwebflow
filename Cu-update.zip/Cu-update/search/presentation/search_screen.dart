import 'package:check_up_app/features/courts/data/courts_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import '../bloc/courts_search_cubit.dart';
import '../data/courts_search_repository.dart';
import 'widgets/overview_search_results.dart';
import 'widgets/people_search_results.dart';
import 'widgets/courts_search_results.dart';
import 'widgets/events_search_results.dart';
import 'widgets/bookings_search_results.dart';
import 'widgets/posts_search_results.dart';
import 'widgets/scores_search_results.dart';

/// Search screen implementation
class SearchScreen extends StatefulWidget {
  /// Initial tab index to show
  final int? initialTabIndex;

  /// Constructor
  const SearchScreen({
    super.key,
    this.initialTabIndex,
  });

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen>
    with SingleTickerProviderStateMixin {
  String _searchQuery = '';
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _tabScrollController = ScrollController();

  final List<String> _tabs = [
    'Overview',
    'People',
    'Courts',
    'Events',
    'Bookings',
    'Posts',
    'Scores',
    'Teams',
    'Leagues',
    'Groups',
    'Jobs'
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);

    // Listen to tab changes to update the tab bar scroll position
    _tabController.addListener(_handleTabChange);

    // Set the initial tab if provided
    if (widget.initialTabIndex != null &&
        widget.initialTabIndex! >= 0 &&
        widget.initialTabIndex! < _tabs.length) {
      _tabController.animateTo(widget.initialTabIndex!);

      // Scroll to the selected tab after a short delay to ensure everything is properly laid out
      Future.delayed(const Duration(milliseconds: 100), () {
        if (mounted) {
          _scrollToSelectedTab(widget.initialTabIndex!);
        }
      });
    }
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabChange);
    _tabController.dispose();
    _searchController.dispose();
    _tabScrollController.dispose();
    super.dispose();
  }

  /// Handle tab changes to update UI and scroll position
  void _handleTabChange() {
    if (_tabController.indexIsChanging ||
        _tabController.index != _tabController.previousIndex) {
      setState(() {}); // Update UI to reflect the new tab
      _scrollToSelectedTab(_tabController.index);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            _buildSearchBar(),
            _buildTabBar(),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                physics: const BouncingScrollPhysics(),
                children:
                    _tabs.map((tab) => _buildPlaceholderContent(tab)).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          // Back button
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.arrow_back,
                color: Colors.white,
                size: 24,
              ),
            ),
          ),
          const SizedBox(width: 12),
          // Search field
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextField(
                controller: _searchController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Search...',
                  hintStyle: TextStyle(color: Colors.grey),
                  prefixIcon: Icon(Icons.search, color: Colors.grey),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 15),
                ),
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value;
                  });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      height: 50,
      child: ListView.builder(
        controller: _tabScrollController,
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _tabs.length,
        itemBuilder: (context, index) {
          final isSelected = index == _tabController.index;
          return Row(
            children: [
              GestureDetector(
                onTap: () {
                  _tabController.animateTo(index);
                  _scrollToSelectedTab(index);
                  setState(() {});
                },
                child: _buildTab(_tabs[index], isSelected: isSelected),
              ),
              if (index < _tabs.length - 1) const SizedBox(width: 10),
            ],
          );
        },
      ),
    );
  }

  Widget _buildTab(String text, {bool isSelected = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        gradient: isSelected
            ? const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
        color: isSelected ? null : Colors.transparent,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Center(
        child: Text(
          text,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  /// Scrolls the tab bar to ensure the selected tab is visible
  void _scrollToSelectedTab(int index) {
    // Wait for the next frame to ensure the tab bar is properly laid out
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_tabScrollController.hasClients) return;

      // Get the screen width to calculate better scroll position
      final screenWidth = MediaQuery.of(context).size.width;

      // Calculate a better position that centers the tab in view when possible
      // For tabs near the start, we want to scroll to the beginning
      // For tabs near the end, we want to show as many tabs as possible
      double scrollPosition;

      if (index <= 1) {
        // For first two tabs, scroll to the beginning
        scrollPosition = 0.0;
      } else if (index >= _tabs.length - 2) {
        // For last two tabs, scroll to the end
        scrollPosition = _tabScrollController.position.maxScrollExtent;
      } else {
        // For middle tabs, try to center the tab
        // Each tab is approximately 100-140 pixels wide including padding
        const double approximateTabWidth = 120.0;
        scrollPosition = (index * approximateTabWidth) -
            (screenWidth / 2) +
            (approximateTabWidth / 2);

        // Ensure we don't scroll beyond bounds
        scrollPosition = scrollPosition.clamp(
            0.0, _tabScrollController.position.maxScrollExtent);
      }

      // Scroll to position with animation
      _tabScrollController.animateTo(
        scrollPosition,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    });
  }

  Widget _buildPlaceholderContent(String tabName) {
    // For the Overview tab, show the overview search results
    if (tabName == 'Overview') {
      return OverviewSearchResults(searchQuery: _searchQuery);
    }

    // For the People tab, show the actual people search results
    if (tabName == 'People') {
      return PeopleSearchResults(searchQuery: _searchQuery);
    }

    // For the Courts tab, show the courts search results
    if (tabName == 'Courts') {
      return BlocProvider(
        create: (_) => CourtsSearchCubit(
          CourtsSearchRepository(), // stream repo (discovery cards)
          GetIt.I<CourtsRepository>(), // core repo (following/created/claimed)
        )..init(query: _searchQuery, selectedFilter: 'Popular'),
        child: CourtsSearchResults(searchQuery: _searchQuery),
      );
    }

    // For the Events tab, show the events search results
    if (tabName == 'Events') {
      return EventsSearchResults(searchQuery: _searchQuery);
    }

    // For the Bookings tab, show the bookings search results
    if (tabName == 'Bookings') {
      return BookingsSearchResults(searchQuery: _searchQuery);
    }

    // For the Posts tab, show the posts search results
    if (tabName == 'Posts') {
      return PostsSearchResults(searchQuery: _searchQuery);
    }

    // For the Scores tab, show the scores search results
    if (tabName == 'Scores') {
      return ScoresSearchResults(searchQuery: _searchQuery);
    }

    // For the Teams tab, show upcoming feature message
    if (tabName == 'Teams') {
      return _buildUpcomingFeatureMessage('Teams');
    }

    // For the Leagues tab, show upcoming feature message
    if (tabName == 'Leagues') {
      return _buildUpcomingFeatureMessage('Leagues');
    }

    // For the Groups tab, show upcoming feature message
    if (tabName == 'Groups') {
      return _buildUpcomingFeatureMessage('Groups');
    }

    // For the Jobs tab, show upcoming feature message
    if (tabName == 'Jobs') {
      return _buildUpcomingFeatureMessage('Jobs');
    }

    // For other tabs, show a placeholder
    return Center(
      child: Text(
        '$tabName tab content will be implemented later',
        style: const TextStyle(color: Colors.white),
      ),
    );
  }

  /// Build upcoming feature message for disabled features
  Widget _buildUpcomingFeatureMessage(String featureName) {
    return Center(
      child: Container(
        margin: const EdgeInsets.all(32),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 10,
              spreadRadius: 2,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.upcoming,
                color: Colors.white,
                size: 32,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              '$featureName Coming Soon',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'We\'re working hard to bring you $featureName functionality. Stay tuned for updates!',
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
