// features/events/data/seed_events.dart
import 'package:cloud_firestore/cloud_firestore.dart';

import '../domain/models/event_model.dart';
import '../domain/models/event_model_firestore.dart';
import '../domain/models/event_type.dart';

/// --- Lightweight Search model just for seeding (mirrors your SearchEventModel) ---
class SearchEventModel {
  final String id;
  final String title;
  final String location;
  final String gameType;
  final String
      date; // e.g. 'Jun 15 • 3:00 PM', 'Today • 6:00 PM', 'Starts Jun 25 • Weekly'
  final String price; // 'Free', '$20 entry fee', '$100 per team'
  final double rating;
  final int reviews;
  final String hostName;
  final String thumbnailUrl;
  final List<String> imageUrls;

  const SearchEventModel({
    required this.id,
    required this.title,
    required this.location,
    required this.gameType,
    required this.date,
    required this.price,
    required this.rating,
    required this.reviews,
    required this.hostName,
    required this.thumbnailUrl,
    required this.imageUrls,
  });
}

/// --- Public entry point you call from anywhere in app (e.g., a debug button) ---
/// Will upsert each seed (uses provided ID) into `events` collection.
/// Pass a real `hostId` (e.g., current user uid) or anything convenient for dev.
Future<void> seedMockEventsToFirestore({
  required String hostId,
}) async {
  final now = DateTime.now();
  final fb = FirebaseFirestore.instance;
  final col = fb.collection('events');

  for (final s in _mockEvents) {
    final domain = _mapSearchToDomain(s, now, hostId);
    final map = EventFirestore.toMap(domain);
    // inject hostId at root so your EventFirestore.fromDoc picks it correctly
    map['hostId'] = domain.hostId;

    // Stable write: use provided search ID for deterministic docs
    final docRef = col.doc(s.id);
    await docRef.set(map, SetOptions(merge: true));
  }
}

/// --- Mapping from Search card to Domain Event variants you’ve defined ---
EventModel _mapSearchToDomain(
  SearchEventModel s,
  DateTime now,
  String hostId,
) {
  final dt = _parseFriendlyDate(s.date, now: now);
  final isFree = s.price.trim().toLowerCase().startsWith('free');
  final parsedPrice = _extractAmount(s.price);

  // use thumbnail as banner, but still persist the full gallery
  final banner = s.thumbnailUrl.isNotEmpty
      ? s.thumbnailUrl
      : (s.imageUrls.isNotEmpty ? s.imageUrls.first : null);

  final cat = s.gameType.isNotEmpty ? s.gameType : 'Basketball';
  final desc = 'Seeded event • ${s.hostName}';
  final gt = s.gameType.toLowerCase();

  if (gt.contains('tournament') || gt.contains('league')) {
    return TournamentEvent(
      id: s.id,
      hostId: hostId,
      title: s.title,
      description: desc,
      dateTime: dt,
      location: s.location,
      bannerImageUrl: banner,
      imageUrls: s.imageUrls, // <-- ADD THIS
      category: cat,
      isFree: isFree,
      price: isFree ? null : parsedPrice,
      numberOfTeams: 8,
      format: gt.contains('3v3')
          ? '3v3 Single Elimination'
          : '5v5 Single Elimination',
      prizePool: gt.contains('league') ? null : 500.0,
      registrationDeadline: dt.subtract(const Duration(days: 2)),
      locationHidden: false, // <-- ADD THIS
    );
  }

  if (gt.contains('donation') ||
      gt.contains('charity') ||
      gt.contains('fund')) {
    return DonationEvent(
      id: s.id,
      hostId: hostId,
      title: s.title,
      description: desc,
      dateTime: dt,
      location: s.location,
      bannerImageUrl: banner,
      imageUrls: s.imageUrls, // <-- ADD THIS
      category: 'Charity',
      isFree: isFree,
      price: isFree ? null : parsedPrice,
      donationGoal: 1000,
      currentAmount: 0,
      beneficiary: s.hostName,
      hasTaxReceipts: false,
      locationHidden: false, // <-- FIXED: Added the required argument
    );
  }

  final skill = gt.contains('youth')
      ? 'Youth'
      : gt.contains('exhibition')
          ? 'All Levels'
          : 'Beginner';
  final maxPlayers = gt.contains('3v3') ? 6 : 10;

  return PickupRunEvent(
    id: s.id,
    hostId: hostId,
    title: s.title,
    description: desc,
    dateTime: dt,
    location: s.location,
    bannerImageUrl: banner,
    imageUrls: s.imageUrls, // <-- ADD THIS
    category: cat,
    isFree: isFree,
    price: isFree ? null : parsedPrice,
    maxPlayers: maxPlayers,
    currentPlayers: 0,
    skillLevel: skill,
    locationHidden: false, // <-- ADD THIS
  );
}

/// --- Friendly date parser (no inline flags) ---
DateTime _parseFriendlyDate(String label, {required DateTime now}) {
  final clean = label.replaceAll('•', ' ').replaceAll('  ', ' ').trim();
  final lower = clean.toLowerCase();

  // Today • 6:00 PM
  if (lower.startsWith('today')) {
    final time = _extractTime(clean);
    var dt = DateTime(
        now.year, now.month, now.day, time?.hour ?? 18, time?.minute ?? 0);
    if (dt.isBefore(now)) dt = dt.add(const Duration(days: 1));
    return dt;
  }

  // Starts Jun 25 • Weekly
  if (lower.startsWith('starts ')) {
    final tail = clean
        .replaceFirst(RegExp(r'^starts\s+', caseSensitive: false), '')
        .trim();
    final md = RegExp(r'([A-Za-z]{3,})\s+(\d{1,2})').firstMatch(tail);
    if (md != null) {
      return _monthDayToDateTime('${md.group(1)} ${md.group(2)}', now,
          hour: 10, minute: 0);
    }
  }

  // This Week • Sat 5:00 PM
  if (lower.startsWith('this week')) {
    final tail = clean
        .replaceFirst(RegExp(r'^this week\s*', caseSensitive: false), '')
        .trim();
    final parts = tail.split(RegExp(r'\s+'));
    final weekdayStr = parts.isNotEmpty ? parts.first : 'Sat';
    final time = _extractTime(tail);
    final target = _nearestWeekdayInThisWeek(weekdayStr, now);
    return DateTime(target.year, target.month, target.day, time?.hour ?? 17,
        time?.minute ?? 0);
  }

  // Next Week • Jun 28-30 -> pick first day @ 10:00 AM
  if (lower.startsWith('next week')) {
    final tail = clean
        .replaceFirst(RegExp(r'^next week\s*', caseSensitive: false), '')
        .trim();
    final mdRange =
        RegExp(r'([A-Za-z]{3,})\s+(\d{1,2})(?:-\d{1,2})?').firstMatch(tail);
    if (mdRange != null) {
      final m = mdRange.group(1)!;
      final d = mdRange.group(2)!;
      return _monthDayToDateTime('$m $d', now.add(const Duration(days: 7)),
          hour: 10, minute: 0);
    }
  }

  // Generic: "Jun 15 3:00 PM" or "Jun 15"
  final md = RegExp(r'([A-Za-z]{3,})\s+(\d{1,2})').firstMatch(clean);
  if (md != null) {
    final time = _extractTime(clean);
    return _monthDayToDateTime(
      '${md.group(1)} ${md.group(2)}',
      now,
      hour: time?.hour ?? 15,
      minute: time?.minute ?? 0,
    );
  }

  // Fallback today 6pm
  return DateTime(now.year, now.month, now.day, 18, 0);
}

class _Hm {
  final int hour;
  final int minute;
  _Hm(this.hour, this.minute);
}

_Hm? _extractTime(String text) {
  final re = RegExp(r'(\d{1,2}):(\d{2})\s*(AM|PM)', caseSensitive: false);
  final m = re.firstMatch(text);
  if (m == null) return null;
  var hour = int.parse(m.group(1)!);
  final minute = int.parse(m.group(2)!);
  final ap = m.group(3)!.toUpperCase();
  if (ap == 'PM' && hour != 12) hour += 12;
  if (ap == 'AM' && hour == 12) hour = 0;
  return _Hm(hour, minute);
}

double? _extractAmount(String priceLabel) {
  final m =
      RegExp(r'(\d+(?:\.\d+)?)').firstMatch(priceLabel.replaceAll(',', ''));
  if (m == null) return null;
  return double.tryParse(m.group(1)!);
}

DateTime _monthDayToDateTime(String monthDay, DateTime base,
    {required int hour, required int minute}) {
  final months = {
    'jan': 1,
    'feb': 2,
    'mar': 3,
    'apr': 4,
    'may': 5,
    'jun': 6,
    'jul': 7,
    'aug': 8,
    'sep': 9,
    'oct': 10,
    'nov': 11,
    'dec': 12,
  };
  final m = RegExp(r'([A-Za-z]{3,})\s+(\d{1,2})').firstMatch(monthDay)!;
  final mon = months[m.group(1)!.substring(0, 3).toLowerCase()]!;
  final day = int.parse(m.group(2)!);

  var dt = DateTime(base.year, mon, day, hour, minute);
  if (dt.isBefore(base)) dt = DateTime(base.year + 1, mon, day, hour, minute);
  return dt;
}

DateTime _nearestWeekdayInThisWeek(String shortName, DateTime base) {
  final map = {
    'sun': DateTime.sunday,
    'mon': DateTime.monday,
    'tue': DateTime.tuesday,
    'wed': DateTime.wednesday,
    'thu': DateTime.thursday,
    'fri': DateTime.friday,
    'sat': DateTime.saturday,
  };
  final targetWd =
      map[shortName.toLowerCase().substring(0, 3)] ?? DateTime.saturday;

  // Start of week = Monday
  final startOfWeek =
      base.subtract(Duration(days: base.weekday - DateTime.monday));
  var candidate = startOfWeek.add(Duration(days: targetWd - DateTime.monday));
  if (candidate.isBefore(base))
    candidate = candidate.add(const Duration(days: 7));
  return candidate;
}

/// --- Your provided NYC seeds (SearchEventModel) ---
final List<SearchEventModel> _mockEvents = [
  SearchEventModel(
    id: 'nyc_streetball',
    title: 'NYC Streetball Tournament',
    location: 'Rucker Park, Harlem',
    gameType: '5v5 Tournament',
    date: 'Jun 15 • 3:00 PM',
    price: '\$20 entry fee',
    rating: 4.9,
    reviews: 124,
    hostName: 'NYC Basketball League',
    thumbnailUrl:
        'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    imageUrls: [
      'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      'https://images.unsplash.com/photo-1505666287802-931dc83a5dc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    ],
  ),
  SearchEventModel(
    id: 'brooklyn_bridge_3v3',
    title: 'Brooklyn Bridge 3v3',
    location: 'Brooklyn Bridge Park',
    gameType: '3v3 Tournament',
    date: 'Jun 20 • 2:00 PM',
    price: '\$15 entry fee',
    rating: 4.8,
    reviews: 76,
    hostName: 'Brooklyn Ballers',
    thumbnailUrl:
        'https://images.unsplash.com/photo-1505666287802-931dc83a5dc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    imageUrls: [
      'https://images.unsplash.com/photo-1505666287802-931dc83a5dc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      'https://images.unsplash.com/photo-1587614382346-4ec70e388b28?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    ],
  ),
  SearchEventModel(
    id: 'west_4th_open_run',
    title: 'West 4th Open Run',
    location: 'West 4th Street Courts',
    gameType: 'Open Play',
    date: 'Today • 6:00 PM',
    price: 'Free',
    rating: 4.5,
    reviews: 52,
    hostName: 'Village Basketball Club',
    thumbnailUrl:
        'https://images.unsplash.com/photo-1587614382346-4ec70e388b28?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    imageUrls: [
      'https://images.unsplash.com/photo-1587614382346-4ec70e388b28?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    ],
  ),
  SearchEventModel(
    id: 'central_park_league',
    title: 'Central Park Summer League',
    location: 'Central Park North Courts',
    gameType: 'League',
    date: 'Starts Jun 25 • Weekly',
    price: '\$100 per team',
    rating: 4.7,
    reviews: 89,
    hostName: 'NYC Parks & Rec',
    thumbnailUrl:
        'https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    imageUrls: [
      'https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    ],
  ),
  SearchEventModel(
    id: 'dyckman_showcase',
    title: 'Dyckman Talent Showcase',
    location: 'Dyckman Courts',
    gameType: 'Exhibition',
    date: 'This Week • Sat 5:00 PM',
    price: '\$5 entry',
    rating: 4.9,
    reviews: 112,
    hostName: 'Dyckman Basketball',
    thumbnailUrl:
        'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    imageUrls: [
      'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    ],
  ),
  SearchEventModel(
    id: 'queens_youth_tournament',
    title: 'Queens Youth Tournament',
    location: 'Flushing Meadows Corona Park',
    gameType: 'Youth Tournament',
    date: 'Next Week • Jun 28-30',
    price: 'Free',
    rating: 4.6,
    reviews: 45,
    hostName: 'Queens Community Basketball',
    thumbnailUrl:
        'https://images.unsplash.com/photo-1587614382346-4ec70e388b28?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    imageUrls: [
      'https://images.unsplash.com/photo-1587614382346-4ec70e388b28?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    ],
  ),
];
