// lib/features/events/data/events_repository.dart
import 'dart:convert';
import 'dart:io';
import 'dart:developer' as dev show log;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart' show debugPrint;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../../tickets/domain/models/ticket_model.dart';
import '../domain/models/event_model.dart';
import '../domain/models/event_model_firestore.dart'
    show eventFromDoc, eventToMap, EventFirestore;

import 'package:cloud_functions/cloud_functions.dart';
import '../domain/models/event_activity_model.dart';

class EventsRepository {
  final FirebaseFirestore _db;
  final FirebaseStorage _storage;
  final FirebaseFunctions _functions;

  EventsRepository({
    FirebaseFirestore? db,
    FirebaseStorage? storage,
    FirebaseFunctions? functions,
  })  : _db = db ?? FirebaseFirestore.instance,
        _storage = storage ?? FirebaseStorage.instance,
        _functions = functions ?? FirebaseFunctions.instance;

  // --------- small helper to keep logs consistent ----------
  void _log(String msg, {String tag = 'EventsRepository'}) {
    dev.log(msg, name: tag);
    debugPrint('[$tag] $msg');
  }

  // --------- sanitize helper: convert enums/datetimes/nested ----------
  Map<String, dynamic>? _sanitizeForFirestore(Map<String, dynamic>? raw) {
    if (raw == null) return null;

    dynamic _s(dynamic v) {
      if (v == null) return null;
      if (v is DateTime) return Timestamp.fromDate(v);
      if (v is Enum) return v.name;
      if (v is List) return v.map(_s).toList();
      if (v is Map) {
        return v.map((k, val) => MapEntry(k.toString(), _s(val)));
      }
      // primitives (num, String, bool) pass through
      return v;
    }

    return raw.map((k, v) => MapEntry(k, _s(v)));
  }

  // ---------- CREATE ----------
  /// Creates the event doc first (so Storage rule can check hostId), then uploads banner.
  Future<String> createEvent({
    required EventModel event,
    required String hostId,
    required String hostUsername, // 👈 add this
    required String hostEmail, // ←
    File? bannerFile, // mobile/desktop
    String? bannerPathOrUrl, // optional: local path or existing URL
    Map<String, dynamic>? extra, // ← NEW
  }) async {
    final sw = Stopwatch()..start();
    _log(
        'createEvent() called. hostId=$hostId, type=${event.eventType}, title="${event.title}"');

    // 1) Create doc first (enables strict Storage rule)
    final doc = _db.collection('events').doc();

    final sanitizedExtra = _sanitizeForFirestore(extra);

    final base = eventToMap(event)
      ..addAll({
        'hostId': hostId,
        'hostUsername': hostUsername, // 👈 persist here
        'hostEmail': hostEmail,
        'titleLower': event.title.toLowerCase(),
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        if (sanitizedExtra != null) 'extra': sanitizedExtra, // ← persist
      });

    _log('Writing base Firestore doc: /events/${doc.id}');
    await doc.set(base);
    _log('Base doc written in ${sw.elapsedMilliseconds} ms');

    // 2) Upload banner if provided (skip if already a URL)
    String? bannerUrl;
    try {
      if (bannerFile != null) {
        _log('Banner file provided → uploading to Storage...');
        bannerUrl = await _uploadBannerFile(doc.id, bannerFile);
        _log('Banner uploaded. url=$bannerUrl');
      } else if (bannerPathOrUrl != null &&
          bannerPathOrUrl.isNotEmpty &&
          !bannerPathOrUrl.startsWith('http')) {
        final f = File(bannerPathOrUrl);
        final exists = await f.exists();
        _log(
            'bannerPathOrUrl (local) provided. exists=$exists, path=$bannerPathOrUrl');
        if (exists) {
          bannerUrl = await _uploadBannerFile(doc.id, f);
          _log('Banner uploaded from local path. url=$bannerUrl');
        } else {
          _log('Local banner path does not exist, skipping upload.');
        }
      } else if (bannerPathOrUrl != null &&
          bannerPathOrUrl.startsWith('http')) {
        bannerUrl = bannerPathOrUrl; // already hosted
        _log('Hosted banner URL provided, skipping Storage upload.');
      }
    } catch (e, st) {
      _log('Banner upload failed: $e');
      _log(st.toString());
      // Not rethrowing here—event doc is already created. Decide if you prefer to rethrow.
    }

    if (bannerUrl != null) {
      _log('Updating event doc with bannerImageUrl...');
      await doc.update({
        'bannerImageUrl': bannerUrl,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      _log(
          'bannerImageUrl updated. Total createEvent time: ${sw.elapsedMilliseconds} ms');
    } else {
      _log(
          'No banner to set. Total createEvent time: ${sw.elapsedMilliseconds} ms');
    }

    return doc.id;
  }

  // ---------- UPDATE ----------
  /// Minimal update; pass only changed fields in [patch]. Provide [newBanner] to replace the banner.
  Future<void> updateEvent(
    String eventId,
    Map<String, dynamic> patch, {
    File? newBanner,
    String? newBannerPathOrUrl,
  }) async {
    final sw = Stopwatch()..start();
    _log(
        'updateEvent(eventId=$eventId) called with keys: ${patch.keys.toList()}');

    final Map<String, dynamic> toWrite = Map.of(patch);

    // Convert ISO -> Timestamp if present
    if (toWrite['dateTime'] is String) {
      _log('Converting dateTime String → Timestamp');
      toWrite['dateTime'] =
          Timestamp.fromDate(DateTime.parse(toWrite['dateTime'] as String));
    }

    // Sanitize entire extra map (handles enums, nested maps, DateTimes, etc.)
    if (toWrite['extra'] is Map<String, dynamic>) {
      toWrite['extra'] =
          _sanitizeForFirestore(toWrite['extra'] as Map<String, dynamic>);
    }

    // Optional banner replacement
    String? bannerUrl;
    try {
      if (newBanner != null) {
        _log('newBanner file provided → uploading...');
        bannerUrl = await _uploadBannerFile(eventId, newBanner);
      } else if (newBannerPathOrUrl != null &&
          newBannerPathOrUrl.isNotEmpty &&
          !newBannerPathOrUrl.startsWith('http')) {
        final f = File(newBannerPathOrUrl);
        final exists = await f.exists();
        _log(
            'newBannerPathOrUrl (local) provided. exists=$exists, path=$newBannerPathOrUrl');
        if (exists) {
          bannerUrl = await _uploadBannerFile(eventId, f);
        } else {
          _log('Local banner path does not exist, skipping upload.');
        }
      } else if (newBannerPathOrUrl != null &&
          newBannerPathOrUrl.startsWith('http')) {
        _log('Hosted banner URL provided—no upload.');
        bannerUrl = newBannerPathOrUrl;
      }
    } catch (e, st) {
      _log('Banner replacement failed: $e');
      _log(st.toString());
      // Decide if you want to rethrow
    }

    if (bannerUrl != null) {
      toWrite['bannerImageUrl'] = bannerUrl;
      _log('toWrite will include new bannerImageUrl.');
    }

    toWrite['updatedAt'] = FieldValue.serverTimestamp();
    _log('Updating Firestore doc: /events/$eventId');
    await _db.collection('events').doc(eventId).update(toWrite);
    _log('updateEvent done in ${sw.elapsedMilliseconds} ms');
  }

  // ---------- READ ----------
  Future<EventModel> getEventById(String id) async {
    _log('getEventById($id)');
    final doc = await _db.collection('events').doc(id).get();
    return eventFromDoc(doc);
  }

  Stream<List<EventModel>> streamHostEvents(String hostId) {
    _log('streamHostEvents(hostId=$hostId)');
    return _db
        .collection('events')
        .where('hostId', isEqualTo: hostId)
        .orderBy('dateTime')
        .snapshots()
        .map((snap) => snap.docs.map(eventFromDoc).toList());
  }

  Future<void> deleteEvent(String id) async {
    _log('deleteEvent($id) called');
    await _db.collection('events').doc(id).delete();
    // Optionally delete Storage assets too.
  }

  // ------------ Upload helpers ---------------
  // Update this method to log file sizes and enforce a 5MB cap
  Future<String> _uploadBannerFile(String eventId, File file) async {
    final exists = await file.exists();
    final size = exists ? await file.length() : 0;
    _log(
        '_uploadBannerFile: eventId=$eventId, exists=$exists, size=${_prettyBytes(size)}');

    const maxBytes = 5 * 1024 * 1024;
    if (!exists) throw StateError('Banner file does not exist');
    if (size > maxBytes) {
      throw StateError('Banner exceeds 5MB (${_prettyBytes(size)})');
    }

    final name =
        'banner_${DateTime.now().millisecondsSinceEpoch}_${file.path.split('/').last}.jpg';
    final ref = _storage.ref('events/$eventId/$name');

    final task = await ref.putFile(
      file,
      SettableMetadata(contentType: 'image/jpeg'),
    );
    final url = await task.ref.getDownloadURL();
    _log('_uploadBannerFile: uploaded OK → $url');
    return url;
  }

  // ===== Streams =====
  Stream<EventModel> streamEvent(String id) {
    _log('streamEvent($id)');
    return _db
        .collection('events')
        .doc(id)
        .snapshots()
        .map(EventFirestore.fromDoc);
  }

  // tickets: subcollection `events/{id}/tickets`
  Stream<List<Map<String, dynamic>>> streamTickets(String eventId) {
    _log('streamTickets(eventId=$eventId)');
    return _db
        .collection('events')
        .doc(eventId)
        .collection('tickets')
        .orderBy('price')
        .snapshots()
        .map((s) => s.docs.map((d) => {'id': d.id, ...d.data()}).toList());
  }

  // attendees: subcollection `events/{id}/attendees`
  Stream<List<Map<String, dynamic>>> streamAttendees(String eventId) {
    _log('streamAttendees(eventId=$eventId)');
    return _db
        .collection('events')
        .doc(eventId)
        .collection('attendees')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => {'id': d.id, ...d.data()}).toList());
  }

  Future<void> joinEvent(String eventId, String userId) async {
    await _db.collection('events').doc(eventId).update({
      'attendees': FieldValue.arrayUnion([userId]),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // ===== Mutations =====
  Future<void> setPublish(String id, bool isPublished) async {
    _log('setPublish(id=$id, isPublished=$isPublished)');
    await _db.collection('events').doc(id).update({
      'isPublished': isPublished,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> cancelEvent(String id, {String? reason}) async {
    _log('cancelEvent(id=$id, reason=${reason ?? '—'})');
    await _db.collection('events').doc(id).update({
      'status': 'canceled',
      if (reason != null) 'cancelReason': reason,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  bool isPublishedFrom(EventModel e) {
    return e.dateTime.isAfter(DateTime.now());
  }

  double estimateRevenue(List<Map<String, dynamic>> tickets) {
    double total = 0;
    for (final t in tickets) {
      final price = (t['price'] as num?)?.toDouble() ?? 0.0;
      final sold = (t['sold'] as num?)?.toInt();
      final qty = (t['quantity'] as num?)?.toInt();
      total += price * ((sold ?? 0) > 0 ? sold! : (qty ?? 0));
    }
    return total;
  }

  Stream<List<EventModel>> streamAttendingEvents(String uid) {
    _log('streamAttendingEvents(uid=$uid)');
    return _db
        .collection('events')
        .where('attendees', arrayContains: uid)
        .orderBy('dateTime')
        .snapshots()
        .map((snap) => snap.docs.map(EventFirestore.fromDoc).toList());
  }

  Stream<List<EventModel>> streamPastEvents(String uid) {
    _log('streamPastEvents(uid=$uid)');
    final now = DateTime.now();
    return _db
        .collection('events')
        .where('dateTime', isLessThan: Timestamp.fromDate(now))
        .orderBy('dateTime', descending: true)
        .limit(200)
        .snapshots()
        .map((snap) => snap.docs
            .map(EventFirestore.fromDoc)
            .where((e) => e.dateTime.isBefore(now))
            .toList());
  }

  // ---------- GALLERY ----------

  String _prettyBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    final kb = bytes / 1024;
    if (kb < 1024) return '${kb.toStringAsFixed(1)} KB';
    final mb = kb / 1024;
    return '${mb.toStringAsFixed(2)} MB';
  }

  // Now logs size per gallery file, skips files >5MB, and (optionally) mirrors to `images`
  Future<List<String>> uploadGalleryFiles(
      String eventId, List<File> files) async {
    _log('uploadGalleryFiles(eventId=$eventId, files=${files.length})');
    final sw = Stopwatch()..start();
    final List<String> urls = [];
    const maxBytes = 5 * 1024 * 1024;

    for (final f in files) {
      final exists = await f.exists();
      final size = exists ? await f.length() : 0;
      _log(
          '→ ${f.path.split('/').last}: exists=$exists, size=${_prettyBytes(size)}');

      if (!exists) {
        _log('   skip: not found');
        continue;
      }
      if (size > maxBytes) {
        _log('   skip: exceeds 5MB (${_prettyBytes(size)})');
        continue;
      }

      try {
        final ref = _storage.ref(
          'events/$eventId/gallery/${DateTime.now().millisecondsSinceEpoch}_${f.path.split('/').last}',
        );
        final task = await ref.putFile(
          f,
          SettableMetadata(contentType: 'image/jpeg'),
        );
        final url = await task.ref.getDownloadURL();
        urls.add(url);
        _log('   uploaded: $url');
      } on FirebaseException catch (e, st) {
        _log('   Firebase error: ${e.code} – ${e.message}');
        _log(st.toString());
      } catch (e, st) {
        _log('   error: $e');
        _log(st.toString());
      }
    }

    _log(
        'uploadGalleryFiles done: ${urls.length}/${files.length} in ${sw.elapsed.inMilliseconds} ms');
    return urls;
  }

  // Mirror gallery → images (if you want `images` populated too) and set banner if missing
  Future<void> setGallery(String eventId, List<String> urls) async {
    _log('setGallery(eventId=$eventId, urls=${urls.length})');
    final docRef = _db.collection('events').doc(eventId);

    final doc = await docRef.get();
    final data = doc.data() ?? {};
    final hasBanner =
        (data['bannerImageUrl'] as String?)?.startsWith('http') == true;

    final update = <String, dynamic>{
      'gallery': urls,
      'updatedAt': FieldValue.serverTimestamp(),
      'images': urls, // mirror for legacy readers
    };

    if (!hasBanner && urls.isNotEmpty) {
      update['bannerImageUrl'] = urls.first;
    }

    await docRef.update(update);
    _log('setGallery: updated. mirrored to images=${urls.isNotEmpty}');
  }

  /// Replace all tickets for an event with the provided list.
  /// Each ticket map may contain:
  /// { name (String), description (String?), price (num/String?),
  ///   quantity (num/String?), requiresWaiver (bool?), hasCustomQuestions (bool?) }
  Future<void> clearAndSetTickets(
    String eventId,
    List<Map<String, dynamic>> tickets,
  ) async {
    final col = _db.collection('events').doc(eventId).collection('tickets');

    // 1) Delete existing tickets (batched, safe for up to a few hundred docs)
    try {
      debugPrint(
          '[EventsRepository] clearAndSetTickets: deleting old tickets…');
      final snap = await col.get();
      if (snap.docs.isNotEmpty) {
        WriteBatch delBatch = _db.batch();
        int ops = 0;
        for (final d in snap.docs) {
          delBatch.delete(d.reference);
          ops++;
          if (ops == 450) {
            await delBatch.commit();
            delBatch = _db.batch();
            ops = 0;
          }
        }
        if (ops > 0) await delBatch.commit();
      }
      debugPrint('[EventsRepository] clearAndSetTickets: old tickets deleted.');
    } catch (e) {
      debugPrint('[EventsRepository] clearAndSetTickets: delete failed → $e');
      rethrow;
    }

    // 2) Insert new tickets
    if (tickets.isEmpty) {
      debugPrint(
          '[EventsRepository] clearAndSetTickets: no new tickets to set.');
      return;
    }

    try {
      debugPrint(
          '[EventsRepository] clearAndSetTickets: adding ${tickets.length} tickets…');
      WriteBatch addBatch = _db.batch();
      int ops = 0;
      int order = 0;

      for (final raw in tickets) {
        final name = (raw['name'] ?? '').toString().trim();
        final description = (raw['description'] ?? '').toString();

        // price → double?
        double? price;
        final p = raw['price'];
        if (p is num) {
          price = p.toDouble();
        } else if (p is String && p.trim().isNotEmpty) {
          price = double.tryParse(p.trim());
        }

        // quantity → int?
        int? quantity;
        final q = raw['quantity'];
        if (q is num) {
          quantity = q.toInt();
        } else if (q is String && q.trim().isNotEmpty) {
          quantity = int.tryParse(q.trim());
        }

        final requiresWaiver = (raw['requiresWaiver'] as bool?) ?? false;
        final hasCustomQuestions =
            (raw['hasCustomQuestions'] as bool?) ?? false;

        final docRef = col.doc();
        addBatch.set(docRef, {
          'name': name,
          'description': description,
          'price': price, // null = free
          'quantity': quantity, // null = unlimited / not enforced
          'requiresWaiver': requiresWaiver,
          'hasCustomQuestions': hasCustomQuestions,
          'order': order++,
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        });

        ops++;
        if (ops == 450) {
          await addBatch.commit();
          addBatch = _db.batch();
          ops = 0;
        }
      }

      if (ops > 0) await addBatch.commit();
      debugPrint('[EventsRepository] clearAndSetTickets: tickets added.');
    } catch (e) {
      debugPrint('[EventsRepository] clearAndSetTickets: add failed → $e');
      rethrow;
    }
  }

  Future<List<TicketModel>> fetchTicketsOnce(String eventId) async {
    final snap = await _db
        .collection('events')
        .doc(eventId)
        .collection('tickets')
        .orderBy('order')
        .get();

    return snap.docs.map((d) => TicketModel.fromMap(d.id, d.data())).toList();
  }

  double? minPaidTicketPrice(List<TicketModel> tickets) {
    final paid = tickets
        .map((t) => t.price)
        .where((p) => p != null && p! > 0)
        .cast<double>()
        .toList();
    if (paid.isEmpty) return null;
    paid.sort();
    return paid.first;
  }

  Future<List<Map<String, dynamic>>> fetchAttendeesOnce(String eventId) async {
    final snap = await _db
        .collection('events')
        .doc(eventId)
        .collection('attendees')
        .orderBy('createdAt', descending: true)
        .get();

    return snap.docs.map((d) => {'id': d.id, ...d.data()}).toList();
  }

  /// Calls Cloud Function `getEventActivity`.
  /// Returns registeredCount + preview users (already deduped server-side).
  Future<EventActivitySummary> fetchEventActivityOnce({
    required String eventId,
    int limit = 12,
  }) async {
    _log('fetchEventActivityOnce(eventId=$eventId, limit=$limit)');

    try {
      final callable = _functions.httpsCallable('getEventActivity');
      final resp = await callable.call({
        'eventId': eventId,
        'limit': limit,
      });

      final raw = (resp.data as Map).cast<String, dynamic>();

      // ✅ FULL RAW LOG (pretty)
      _log(
          'RAW getEventActivity response:\n${const JsonEncoder.withIndent('  ').convert(raw)}',
          tag: 'EventActivity');

      final summary = EventActivitySummary.fromMap(raw);

      // ✅ FULL PARSED LOG
      _log(
        'PARSED summary: registeredCount=${summary.registeredCount}, users=${summary.users.length}\n'
        'users=${summary.users.map((u) => "${u.userId}:${u.name}").toList()}',
        tag: 'EventActivity',
      );

      return summary;
    } catch (e, st) {
      _log('fetchEventActivityOnce FAILED: $e', tag: 'EventActivity');
      _log(st.toString(), tag: 'EventActivity');
      rethrow;
    }
  }

  // ===== Attending (via ticket_entitlements) =====

  CollectionReference<Map<String, dynamic>> get _entitlements =>
      _db.collection('ticket_entitlements');

  /// User's ACTIVE entitlements (tickets bought / free ticket grants)
  Stream<List<Map<String, dynamic>>> streamUserActiveEntitlements(String uid) {
    _log('streamUserActiveEntitlements(uid=$uid)');

    // If you later add composite index: (userId, status, createdAt desc)
    return _entitlements
        .where('userId', isEqualTo: uid)
        .where('status', isEqualTo: 'active')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => {'id': d.id, ...d.data()}).toList());
  }

  /// Stream "attending events" by looking up unique eventIds from entitlements.
  /// Option A: fetch event docs by ID individually.
  /// Deleted events are silently skipped.
  Stream<List<EventModel>> streamAttendingEventsFromEntitlements(
      String uid) async* {
    _log('streamAttendingEventsFromEntitlements(uid=$uid)');

    await for (final rows in streamUserActiveEntitlements(uid)) {
      final eventIds = <String>{};

      for (final r in rows) {
        final eid = (r['eventId'] ?? '').toString().trim();
        if (eid.isNotEmpty) eventIds.add(eid);
      }

      if (eventIds.isEmpty) {
        yield const <EventModel>[];
        continue;
      }

      // fetch individually (Option A)
      final snaps = await Future.wait(
        eventIds.map((id) => _db.collection('events').doc(id).get()),
      );

      final events = <EventModel>[];
      for (final d in snaps) {
        if (!d.exists) continue; // deleted event -> skip
        try {
          events.add(eventFromDoc(d));
        } catch (_) {
          // If parsing fails, skip to keep app stable
        }
      }

      // sort by dateTime ascending
      events.sort((a, b) => a.dateTime.compareTo(b.dateTime));

      yield events;
    }
  }

  /// Past events attended (via entitlements)
  Stream<List<EventModel>> streamPastEventsFromEntitlements(String uid) async* {
    _log('streamPastEventsFromEntitlements(uid=$uid)');

    await for (final all in streamAttendingEventsFromEntitlements(uid)) {
      final now = DateTime.now();
      final past = all.where((e) {
        // if dateTime is weird/missing, treat as past or exclude
        // (your model always has dateTime, so this is mostly defensive)
        return e.dateTime.isBefore(now);
      }).toList();

      // newest first
      past.sort((a, b) => b.dateTime.compareTo(a.dateTime));
      yield past;
    }
  }
}
