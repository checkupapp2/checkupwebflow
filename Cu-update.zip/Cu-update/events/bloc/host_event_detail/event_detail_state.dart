import 'package:equatable/equatable.dart';
import '../../domain/models/event_model.dart';

class HostEventDetailState extends Equatable {
  @override
  List<Object?> get props => [];
}

class HostEventDetailLoading extends HostEventDetailState {}

class EventDetailError extends HostEventDetailState {
  final String message;
  EventDetailError(this.message);
  @override
  List<Object?> get props => [message];
}

class HostEventExtras {
  final bool isPublished;
  final int attendeeCount;
  final double revenueTotal;

  const HostEventExtras({
    this.isPublished = false,
    this.attendeeCount = 0,
    this.revenueTotal = 0.0,
  });

  HostEventExtras copyWith({
    bool? isPublished,
    int? attendeeCount,
    double? revenueTotal,
  }) {
    return HostEventExtras(
      isPublished: isPublished ?? this.isPublished,
      attendeeCount: attendeeCount ?? this.attendeeCount,
      revenueTotal: revenueTotal ?? this.revenueTotal,
    );
  }
}

class HostEventDetailLoaded extends HostEventDetailState {
  final EventModel event;
  final HostEventExtras eventExtras;
  final List<Map<String, dynamic>>
      tickets; // keep generic if your TicketModel differs
  final List<Map<String, dynamic>>
      attendees; // same: render name/status/avatar if present
  final Map<String, dynamic> stats;

  HostEventDetailLoaded({
    required this.event,
    required this.eventExtras,
    required this.tickets,
    required this.attendees,
    required this.stats,
  });

  HostEventDetailLoaded copyWith({
    EventModel? event,
    HostEventExtras? eventExtras,
    List<Map<String, dynamic>>? tickets,
    List<Map<String, dynamic>>? attendees,
    Map<String, dynamic>? stats,
  }) {
    return HostEventDetailLoaded(
      event: event ?? this.event,
      eventExtras: eventExtras ?? this.eventExtras,
      tickets: tickets ?? this.tickets,
      attendees: attendees ?? this.attendees,
      stats: stats ?? this.stats,
    );
  }

  @override
  List<Object?> get props => [event, eventExtras, tickets, attendees, stats];
}
