// lib/features/events/bloc/host_event_detail/host_event_detail_cubit.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../data/events_repository.dart';
import '../../domain/models/event_model.dart';
import 'event_detail_state.dart';

class HostEventDetailCubit extends Cubit<HostEventDetailState> {
  final EventsRepository repo;
  HostEventDetailCubit({required this.repo}) : super(HostEventDetailLoading());

  Future<void> load(String eventId) async {
    emit(HostEventDetailLoading());
    try {
      final EventModel ev = await repo.getEventById(eventId);
      final tickets = await repo.fetchTicketsOnce(eventId);
      final attendees = await repo.fetchAttendeesOnce(eventId); // count + list

      final extras = HostEventExtras(
        isPublished: repo.isPublishedFrom(ev),
        attendeeCount: attendees.length,
        revenueTotal: repo.estimateRevenue(
          tickets
              .map((t) => {
                    'price': t.price,
                    'quantity': null, // unknown here (from once-off), keep null
                    'sold': null,
                  })
              .toList(),
        ),
      );

      emit(HostEventDetailLoaded(
        event: ev,
        eventExtras: extras,
        tickets: tickets
            .map((t) => {
                  'id': t.id,
                  'name': t.name,
                  'price': t.price,
                  'description': t.description,
                })
            .toList(),
        attendees: attendees, // List<Map<String,dynamic>>
        stats: {
          'attendees': attendees.length,
          'tickets': tickets.length,
          'revenue': extras.revenueTotal,
        },
      ));
    } catch (e) {
      emit(EventDetailError('Failed to load event: $e'));
    }
  }
}
