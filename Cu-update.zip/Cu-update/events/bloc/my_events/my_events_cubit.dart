// lib/features/events/bloc/my_events/my_events_cubit.dart
import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../data/events_repository.dart';
import '../../domain/models/event_model.dart';
import 'my_events_state.dart';

class MyEventsCubit extends Cubit<MyEventsState> {
  final EventsRepository repo;
  final FirebaseAuth auth;

  StreamSubscription<List<EventModel>>? _hostSub;
  StreamSubscription<List<EventModel>>? _attendSub;
  StreamSubscription<List<EventModel>>? _pastSub;

  MyEventsCubit({required this.repo, required this.auth})
      : super(MyEventsState());

  void init() {
    _loadStreams();
  }

  void _loadStreams() {
    final uid = auth.currentUser?.uid;
    if (uid == null) return;

    emit(state.copyWith(loading: true, error: null));

    // ---------------- Hosting (unchanged) ----------------
    _hostSub?.cancel();
    _hostSub = repo.streamHostEvents(uid).listen((all) {
      final now = DateTime.now();

      final today = all.where((e) =>
          e.dateTime.year == now.year &&
          e.dateTime.month == now.month &&
          e.dateTime.day == now.day);

      final upcoming = all.where((e) => e.dateTime.isAfter(now));

      emit(state.copyWith(
        hostingToday: today.toList(),
        hostingUpcoming: upcoming.toList(),
        loading: false,
      ));
    }, onError: (e) {
      emit(state.copyWith(loading: false, error: e.toString()));
    });

    // ---------------- Attending (via ticket_entitlements) ----------------
    _attendSub?.cancel();
    _attendSub = repo.streamAttendingEventsFromEntitlements(uid).listen((all) {
      final now = DateTime.now();

      final today = all.where((e) =>
          e.dateTime.year == now.year &&
          e.dateTime.month == now.month &&
          e.dateTime.day == now.day);

      final upcoming = all.where((e) => e.dateTime.isAfter(now));

      emit(state.copyWith(
        attendingToday: today.toList(),
        attendingUpcoming: upcoming.toList(),
        loading: false,
      ));
    }, onError: (e) {
      emit(state.copyWith(loading: false, error: e.toString()));
    });

    // ---------------- Past (attended via entitlements) ----------------
    _pastSub?.cancel();
    _pastSub = repo.streamPastEventsFromEntitlements(uid).listen((past) {
      emit(state.copyWith(
        past: past,
        loading: false,
      ));
    }, onError: (e) {
      emit(state.copyWith(loading: false, error: e.toString()));
    });
  }

  void refresh() => _loadStreams();

  void setSelectedFilter(String filter) {
    emit(state.copyWith(selectedFilter: filter));
  }

  void setSelectedDate(DateTime? date) {
    emit(state.copyWith(selectedDate: date));
  }

  void toggleCalendarExpanded() {
    emit(state.copyWith(calendarExpanded: !state.calendarExpanded));
  }

  void prevMonth() {
    final d = state.currentMonth;
    emit(state.copyWith(currentMonth: DateTime(d.year, d.month - 1)));
  }

  void nextMonth() {
    final d = state.currentMonth;
    emit(state.copyWith(currentMonth: DateTime(d.year, d.month + 1)));
  }

  @override
  Future<void> close() async {
    await _hostSub?.cancel();
    await _attendSub?.cancel();
    await _pastSub?.cancel();
    return super.close();
  }
}
