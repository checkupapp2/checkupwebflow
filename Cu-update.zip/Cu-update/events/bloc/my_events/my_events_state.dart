import 'package:equatable/equatable.dart';
import '../../domain/models/event_model.dart';

class MyEventsState extends Equatable {
  final bool loading;
  final List<EventModel> attendingToday;
  final List<EventModel> attendingUpcoming;
  final List<EventModel> hostingToday;
  final List<EventModel> hostingUpcoming;
  final List<EventModel> past;
  final DateTime? selectedDate;
  final String selectedFilter; // Popular, Today, This Week, Future, Past
  final DateTime currentMonth; // for calendar UI
  final bool calendarExpanded;
  final String? error;

  MyEventsState({
    this.loading = false,
    this.attendingToday = const [],
    this.attendingUpcoming = const [],
    this.hostingToday = const [],
    this.hostingUpcoming = const [],
    this.past = const [],
    this.selectedDate,
    this.selectedFilter = 'Popular',
    DateTime? currentMonth,
    this.calendarExpanded = false,
    this.error,
  }) : currentMonth = currentMonth ?? DateTime.now();

  MyEventsState copyWith({
    bool? loading,
    List<EventModel>? attendingToday,
    List<EventModel>? attendingUpcoming,
    List<EventModel>? hostingToday,
    List<EventModel>? hostingUpcoming,
    List<EventModel>? past,
    DateTime? selectedDate,
    String? selectedFilter,
    DateTime? currentMonth,
    bool? calendarExpanded,
    String? error,
  }) {
    return MyEventsState(
      loading: loading ?? this.loading,
      attendingToday: attendingToday ?? this.attendingToday,
      attendingUpcoming: attendingUpcoming ?? this.attendingUpcoming,
      hostingToday: hostingToday ?? this.hostingToday,
      hostingUpcoming: hostingUpcoming ?? this.hostingUpcoming,
      past: past ?? this.past,
      selectedDate: selectedDate ?? this.selectedDate,
      selectedFilter: selectedFilter ?? this.selectedFilter,
      currentMonth: currentMonth ?? this.currentMonth,
      calendarExpanded: calendarExpanded ?? this.calendarExpanded,
      error: error,
    );
  }

  @override
  List<Object?> get props => [
        loading,
        attendingToday,
        attendingUpcoming,
        hostingToday,
        hostingUpcoming,
        past,
        selectedDate,
        selectedFilter,
        currentMonth,
        calendarExpanded,
        error,
      ];
}
