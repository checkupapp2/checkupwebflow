// lib/features/events/bloc/events_event.dart
import 'dart:io';
import 'package:equatable/equatable.dart';
import '../domain/models/event_model.dart';

abstract class EventsEvent extends Equatable {
  const EventsEvent();
  @override
  List<Object?> get props => [];
}

class CreateEventRequested extends EventsEvent {
  final EventModel event;
  final String hostId;
  final String hostUsername; // 👈 add this
  final String hostEmail; // ←
  final File? bannerFile;

  /// List of ticket maps like:
  /// [{name, description, price, quantity, requiresWaiver, hasCustomQuestions}, ...]
  final List<Map<String, dynamic>> tickets;
  final Map<String, dynamic>? extra; // ← NEW

  const CreateEventRequested({
    required this.event,
    required this.hostId,
    required this.hostUsername,
    required this.hostEmail,
    this.bannerFile,
    this.tickets = const [],
    this.extra, // ← NEW
  });

  @override
  List<Object?> get props => [event, hostId, bannerFile?.path, tickets, extra];
}

class UpdateEventRequested extends EventsEvent {
  final String eventId;
  final Map<String, dynamic> patch;
  final File? newBanner;

  const UpdateEventRequested({
    required this.eventId,
    required this.patch,
    this.newBanner,
  });

  @override
  List<Object?> get props => [eventId, patch, newBanner?.path];
}

class LoadEventRequested extends EventsEvent {
  final String eventId;
  const LoadEventRequested(this.eventId);

  @override
  List<Object?> get props => [eventId];
}

class DeleteEventRequested extends EventsEvent {
  final String eventId;
  const DeleteEventRequested(this.eventId);

  @override
  List<Object?> get props => [eventId];
}
