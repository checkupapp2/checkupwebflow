// lib/features/events/bloc/event_detail/event_detail_cubit.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';

import '../../data/events_repository.dart';
import '../../domain/models/event_activity_model.dart';
import '../../domain/models/event_model.dart';
import 'event_detail_state.dart';

class EventDetailCubit extends Cubit<EventDetailState> {
  EventDetailCubit({
    required this.repo,
    required this.auth,
  }) : super(const EventDetailState());

  final EventsRepository repo;
  final dynamic auth; // FirebaseAuth instance

  // ------------------------------------------------------------
  // Safe parsers
  // ------------------------------------------------------------
  int? _asInt(dynamic v) {
    if (v == null) return null;
    if (v is int) return v;
    if (v is num) return v.toInt();
    if (v is String) return int.tryParse(v.trim());
    return null;
  }

  double? _asDouble(dynamic v) {
    if (v == null) return null;
    if (v is double) return v;
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v.trim());
    return null;
  }

  bool? _asBool(dynamic v) {
    if (v == null) return null;
    if (v is bool) return v;
    if (v is num) return v != 0;
    if (v is String) {
      final s = v.trim().toLowerCase();
      if (s == 'true' || s == '1' || s == 'yes') return true;
      if (s == 'false' || s == '0' || s == 'no') return false;
    }
    return null;
  }

  List<String> _asStringList(dynamic v) {
    if (v is List) {
      return v
          .map((e) => e?.toString() ?? '')
          .where((s) => s.trim().isNotEmpty)
          .toList();
    }
    return const [];
  }

  String _fmtMoney(double v) {
    return v == v.truncateToDouble()
        ? '\$${v.toStringAsFixed(0)}'
        : '\$${v.toStringAsFixed(2)}';
  }

  // ------------------------------------------------------------
  // LOAD EVENT
  // ------------------------------------------------------------
  Future<void> load(String eventId) async {
    if (isClosed) return;

    emit(state.copyWith(loading: true));

    try {
      // Fetch event model (already parsed into correct subclass)
      final ev = await repo.getEventById(eventId);

      // Raw firestore doc (for extra)
      final doc = await FirebaseFirestore.instance
          .collection('events')
          .doc(eventId)
          .get();
      final raw = doc.data();

      final Map<String, dynamic>? extra = raw?['extra'] is Map<String, dynamic>
          ? (raw!['extra'] as Map<String, dynamic>)
          : null;

      // ------------------------------------------------------------
      // Host info (stored on the event doc at create time)
      // ------------------------------------------------------------
      final hostName = (raw?['hostUsername'] as String?) ?? 'Event Host';
      final hostEmail = (raw?['hostEmail'] as String?) ?? '';

      // ------------------------------------------------------------
      // Build venueName / venueAddress from locationMeta
      // ------------------------------------------------------------
      final locMeta = extra?['locationMeta'];

      final venueName = (locMeta is Map && locMeta['name'] is String)
          ? locMeta['name'] as String
          : ev.location;

      final venueAddress = (locMeta is Map && locMeta['fullAddress'] is String)
          ? locMeta['fullAddress'] as String
          : ev.location;

      // ------------------------------------------------------------
      // Tickets → priceLabel
      // ------------------------------------------------------------
      final tickets = await repo.fetchTicketsOnce(eventId);

      final hasTickets = tickets.isNotEmpty;
      final hasFree = tickets.any((t) => (t.price ?? 0) == 0);
      final minPaid = repo.minPaidTicketPrice(tickets);

      final priceLabel = hasTickets
          ? (hasFree
              ? 'Free'
              : (minPaid != null ? _fmtMoney(minPaid) : 'From tickets'))
          : (ev.isFree
              ? 'Free'
              : (ev.price != null ? _fmtMoney(ev.price!) : 'From tickets'));

      // ------------------------------------------------------------
      // Host check
      // ------------------------------------------------------------
      final uid = auth.currentUser?.uid as String?;
      final isHost = uid != null && uid == ev.hostId;

      // ------------------------------------------------------------
      // Build details text
      // ------------------------------------------------------------
      final details = _composeDetails(ev, extra);

      // ------------------------------------------------------------
      // Event Activity (registered count + preview users)
      // ------------------------------------------------------------
      EventActivitySummary? activity;
      try {
        activity =
            await repo.fetchEventActivityOnce(eventId: eventId, limit: 12);
      } catch (_) {
        // Keep it non-blocking: detail page should still load.
        activity = null;
      }

      if (isClosed) return;

      emit(
        state.copyWith(
          loading: false,
          event: ev,
          priceLabel: priceLabel,
          isHost: isHost,
          isTicketed: hasTickets,
          extra: extra,
          detailsText: details,
          hostName: hostName,
          hostEmail: hostEmail,
          venueName: venueName,
          venueAddress: venueAddress,
          registeredCount: activity?.registeredCount ?? 0,
          activityUsers: activity?.users ?? const [],
        ),
      );
    } catch (err) {
      if (isClosed) return;
      emit(state.copyWith(loading: false));
      rethrow;
    }
  }

  // ------------------------------------------------------------
  // DETAILS BUILDER
  // ------------------------------------------------------------
  String _composeDetails(EventModel ev, Map<String, dynamic>? extra) {
    final b = StringBuffer();

    // -----------------------------
    // Description
    // -----------------------------
    final desc = ev.description.trim();
    if (desc.isNotEmpty) {
      b.writeln(desc);
      b.writeln();
    }

    // -----------------------------
    // Tournament
    // -----------------------------
    if (ev is TournamentEvent) {
      b.writeln('Tournament Format:');
      final fmt =
          ev.format.trim().isNotEmpty ? ev.format.trim() : 'Single elimination';
      b.writeln('• $fmt');
      if (ev.numberOfTeams > 0) b.writeln('• ${ev.numberOfTeams} teams');

      final rules = _asStringList(extra?['rules']);
      for (final r in rules) b.writeln('• $r');

      b.writeln();

      final bring = <String>[
        if (_asBool(extra?['bringShoes']) == true) 'Basketball shoes',
        if (_asBool(extra?['bringWater']) == true) 'Water bottle',
        if (_asBool(extra?['bringJersey']) == true) 'Team jersey (optional)',
      ];
      if (bring.isNotEmpty) {
        b.writeln('What to Bring:');
        for (final item in bring) b.writeln('• $item');
        b.writeln();
      }

      final hasPool = (ev.prizePool ?? 0) > 0;
      final prizes = _asStringList(extra?['prizes']);

      if (hasPool || prizes.isNotEmpty) {
        b.writeln('Prizes:');
        if (hasPool) b.writeln('• ${_fmtMoney(ev.prizePool!)} prize pool');
        for (final p in prizes) b.writeln('• $p');
        b.writeln();
      }

      b.writeln('Registration:');
      b.writeln(
        '• Deadline: ${DateFormat('MMM d, y • h:mm a').format(ev.registrationDeadline)}',
      );
      b.writeln();

      // Defaults if user saved no extra
      if ((extra == null || extra.isEmpty) &&
          bring.isEmpty &&
          prizes.isEmpty &&
          rules.isEmpty &&
          !(hasPool)) {
        b
          ..writeln('Tournament Format:')
          ..writeln('• Single elimination bracket')
          ..writeln('• 5v5 full court games')
          ..writeln('• 20-minute games')
          ..writeln('• Professional referees\n')
          ..writeln('What to Bring:')
          ..writeln('• Basketball shoes')
          ..writeln('• Water bottle')
          ..writeln('• Team jersey (optional)\n')
          ..writeln('Prizes:')
          ..writeln('• \$500 winning team')
          ..writeln('• \$200 runner-up')
          ..writeln('• MVP trophy\n');
      }
    }

    // -----------------------------
    // Pickup Run
    // -----------------------------
    else if (ev is PickupRunEvent) {
      b.writeln('Run Details:');
      if (ev.maxPlayers > 0) b.writeln('• ${ev.maxPlayers} player cap');
      if (ev.currentPlayers > 0)
        b.writeln('• ${ev.currentPlayers} currently joined');
      if (ev.skillLevel.trim().isNotEmpty)
        b.writeln('• Skill: ${ev.skillLevel}');
      b.writeln();

      final bring = <String>[
        if (_asBool(extra?['bringShoes']) == true) 'Basketball shoes',
        if (_asBool(extra?['bringWater']) == true) 'Water bottle',
      ];
      if (bring.isNotEmpty) {
        b.writeln('What to Bring:');
        for (final item in bring) b.writeln('• $item');
        b.writeln();
      }
    }

    // -----------------------------
    // Donation
    // -----------------------------
    else if (ev is DonationEvent) {
      b.writeln('Donation Info:');
      if (ev.donationGoal > 0)
        b.writeln('• Goal: ${_fmtMoney(ev.donationGoal)}');
      if (ev.currentAmount > 0)
        b.writeln('• Raised: ${_fmtMoney(ev.currentAmount)}');
      if (ev.beneficiary.trim().isNotEmpty)
        b.writeln('• Beneficiary: ${ev.beneficiary}');
      if (ev.hasTaxReceipts) b.writeln('• Tax receipts available');
      b.writeln();
    }

    // -----------------------------
    // Other event types
    // -----------------------------
    else {
      final ageRange = (extra?['ageRange'] as String?)?.trim();
      final days = _asInt(extra?['numberOfDays']);
      final level = (extra?['skillLevel'] as String?)?.trim();
      final coach = (extra?['coach'] as String?)?.trim();

      if ([ageRange, days, level, coach]
          .any((e) => e != null && e.toString().isNotEmpty)) {
        b.writeln('Details:');
        if (ageRange != null && ageRange.isNotEmpty)
          b.writeln('• Age range: $ageRange');
        if (days != null) b.writeln('• Duration: ${days} day(s)');
        if (level != null && level.isNotEmpty) b.writeln('• Skill: $level');
        if (coach != null && coach.isNotEmpty) b.writeln('• Coach: $coach');
        b.writeln();
      }
    }

    // -----------------------------
    // Notes
    // -----------------------------
    final notes = _asStringList(extra?['notes']);
    if (notes.isNotEmpty) {
      b.writeln('Good to Know:');
      for (final n in notes) b.writeln('• $n');
      b.writeln();
    }

    return b.toString().trimRight();
  }
}
