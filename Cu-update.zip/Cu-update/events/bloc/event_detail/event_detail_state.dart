// lib/features/events/bloc/event_detail/event_detail_state.dart

import '../../domain/models/event_model.dart';
import '../../domain/models/event_activity_model.dart';

class EventDetailState {
  final bool loading;
  final EventModel? event;

  // Price label (computed)
  final String? priceLabel;

  // Host info
  final bool isHost;
  final String? hostName;
  final String? hostEmail;

  // Ticketing
  final bool isTicketed;

  // Extra raw map from Firestore
  final Map<String, dynamic>? extra;

  // Composed description / details text
  final String detailsText;

  // Location meta parsed from either event.location OR extra.locationMeta
  final String? venueName;
  final String? venueAddress;

  // ---------------------------
  // Event Activity (NEW)
  // ---------------------------
  /// Total number of tickets sold (entitlements count)
  final int registeredCount;

  /// Preview users (deduped by userId, even if they bought multiple tickets)
  final List<EventActivityUser> activityUsers;

  const EventDetailState({
    this.loading = true,
    this.event,
    this.priceLabel,
    this.isHost = false,
    this.hostName,
    this.hostEmail,
    this.isTicketed = false,
    this.extra,
    this.detailsText = '',
    this.venueName,
    this.venueAddress,

    // NEW defaults
    this.registeredCount = 0,
    this.activityUsers = const [],
  });

  EventDetailState copyWith({
    bool? loading,
    EventModel? event,
    String? priceLabel,
    bool? isHost,
    String? hostName,
    String? hostEmail,
    bool? isTicketed,
    Map<String, dynamic>? extra,
    String? detailsText,
    String? venueName,
    String? venueAddress,

    // NEW
    int? registeredCount,
    List<EventActivityUser>? activityUsers,
  }) {
    return EventDetailState(
      loading: loading ?? this.loading,
      event: event ?? this.event,
      priceLabel: priceLabel ?? this.priceLabel,
      isHost: isHost ?? this.isHost,
      hostName: hostName ?? this.hostName,
      hostEmail: hostEmail ?? this.hostEmail,
      isTicketed: isTicketed ?? this.isTicketed,
      extra: extra ?? this.extra,
      detailsText: detailsText ?? this.detailsText,
      venueName: venueName ?? this.venueName,
      venueAddress: venueAddress ?? this.venueAddress,

      // NEW
      registeredCount: registeredCount ?? this.registeredCount,
      activityUsers: activityUsers ?? this.activityUsers,
    );
  }
}
