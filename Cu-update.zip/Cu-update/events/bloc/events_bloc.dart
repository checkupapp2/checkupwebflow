// lib/features/events/bloc/events_bloc.dart
import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../data/events_repository.dart';
import 'events_event.dart';
import 'events_state.dart';

class EventsBloc extends Bloc<EventsEvent, EventsState> {
  final EventsRepository repo;

  EventsBloc({required this.repo}) : super(const EventsInitial()) {
    on<CreateEventRequested>(_onCreate);
    on<UpdateEventRequested>(_onUpdate);
    on<LoadEventRequested>(_onLoad);
    on<DeleteEventRequested>(_onDelete);
  }

  Future<void> _onCreate(
    CreateEventRequested e,
    Emitter<EventsState> emit,
  ) async {
    emit(const EventsLoading());
    try {
      final id = await repo.createEvent(
        event: e.event,
        hostId: e.hostId,
        hostUsername: e.hostUsername, // 👈 add this
        hostEmail: e.hostEmail, // ←
        bannerFile: e.bannerFile,
        extra: e.extra, // ← NEW
      );

      // Persist tickets if provided
      if (e.tickets.isNotEmpty) {
        await repo.clearAndSetTickets(id, e.tickets);
      }

      emit(EventsSuccess(createdId: id, message: 'Event created'));
    } catch (err) {
      emit(EventsFailure(err.toString()));
    }
  }

  Future<void> _onUpdate(
    UpdateEventRequested e,
    Emitter<EventsState> emit,
  ) async {
    emit(const EventsLoading());
    try {
      await repo.updateEvent(e.eventId, e.patch, newBanner: e.newBanner);
      emit(const EventsSuccess(message: 'Event updated'));
    } catch (err) {
      emit(EventsFailure(err.toString()));
    }
  }

  Future<void> _onLoad(
    LoadEventRequested e,
    Emitter<EventsState> emit,
  ) async {
    emit(const EventsLoading());
    try {
      final event = await repo.getEventById(e.eventId);
      emit(EventLoaded(event));
    } catch (err) {
      emit(EventsFailure(err.toString()));
    }
  }

  Future<void> _onDelete(
    DeleteEventRequested e,
    Emitter<EventsState> emit,
  ) async {
    emit(const EventsLoading());
    try {
      await repo.deleteEvent(e.eventId);
      emit(const EventsSuccess(message: 'Event deleted'));
    } catch (err) {
      emit(EventsFailure(err.toString()));
    }
  }
}
