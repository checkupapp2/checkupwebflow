// lib/features/events/presentation/bloc/edit_event/edit_event_state.dart
import 'package:equatable/equatable.dart';
import '../../domain/models/event_model.dart';
import '../../domain/models/event_type.dart';
import '../../domain/models/location_model.dart';

class EditEventState extends Equatable {
  // Wizard step 0..5
  final int step;

  // Core fields
  final EventType? type;
  final String title;
  final String description;
  final DateTime? dateTime;

  // Visibility
  final bool eventPrivate;

  // Location
  final LocationModel? locationObj;
  final String locationText;
  final bool locationPrivate;

  // Pricing / tickets
  final bool isFree;
  final double? price;
  final int? capacity;
  final bool registrationOpen;

  // Tickets and custom questions
  final List<Map<String, dynamic>> ticketTypes;
  final bool hasCustomQuestions;
  final List<Map<String, dynamic>> customQuestions;

  // Early bird
  final bool hasEarlyBird;
  final double? earlyBirdPrice;
  final DateTime? earlyBirdDeadline;

  // Waiver
  final bool requiresWaiver;
  final String waiverText;
  final String? waiverTemplate;

  // Save status
  final bool saving;
  final bool success;
  final String? error;

  const EditEventState({
    required this.step,
    required this.type,
    required this.title,
    required this.description,
    required this.dateTime,
    required this.eventPrivate,
    required this.locationObj,
    required this.locationText,
    required this.locationPrivate,
    required this.isFree,
    required this.price,
    required this.capacity,
    required this.registrationOpen,
    required this.ticketTypes,
    required this.hasCustomQuestions,
    required this.customQuestions,
    required this.hasEarlyBird,
    required this.earlyBirdPrice,
    required this.earlyBirdDeadline,
    required this.requiresWaiver,
    required this.waiverText,
    required this.waiverTemplate,
    required this.saving,
    required this.success,
    required this.error,
  });

  factory EditEventState.initialFrom(EventModel ev) {
    return EditEventState(
      step: 0,
      type: _resolveTypeFromEvent(ev),
      title: ev.title,
      description: ev.description,
      dateTime: ev.dateTime,
      eventPrivate: false,
      locationObj: null,
      locationText: ev.location,
      locationPrivate: ev.locationHidden ?? false,
      isFree: ev.isFree,
      price: ev.isFree ? null : ev.price,
      capacity: null,
      registrationOpen: true,
      ticketTypes: const [],
      hasCustomQuestions: false,
      customQuestions: const [],
      hasEarlyBird: false,
      earlyBirdPrice: null,
      earlyBirdDeadline: null,
      requiresWaiver: false,
      waiverText: '',
      waiverTemplate: null,
      saving: false,
      success: false,
      error: null,
    );
  }

  EditEventState copyWith({
    int? step,
    EventType? type,
    String? title,
    String? description,
    DateTime? dateTime,
    bool? eventPrivate,
    LocationModel? locationObj,
    String? locationText,
    bool? locationPrivate,
    bool? isFree,
    double? price,
    int? capacity,
    bool? registrationOpen,
    List<Map<String, dynamic>>? ticketTypes,
    bool? hasCustomQuestions,
    List<Map<String, dynamic>>? customQuestions,
    bool? hasEarlyBird,
    double? earlyBirdPrice,
    DateTime? earlyBirdDeadline,
    bool? requiresWaiver,
    String? waiverText,
    String? waiverTemplate,
    bool? saving,
    bool? success,
    String? error,
  }) {
    return EditEventState(
      step: step ?? this.step,
      type: type ?? this.type,
      title: title ?? this.title,
      description: description ?? this.description,
      dateTime: dateTime ?? this.dateTime,
      eventPrivate: eventPrivate ?? this.eventPrivate,
      locationObj: locationObj ?? this.locationObj,
      locationText: locationText ?? this.locationText,
      locationPrivate: locationPrivate ?? this.locationPrivate,
      isFree: isFree ?? this.isFree,
      price: price ?? this.price,
      capacity: capacity ?? this.capacity,
      registrationOpen: registrationOpen ?? this.registrationOpen,
      ticketTypes: ticketTypes ?? this.ticketTypes,
      hasCustomQuestions: hasCustomQuestions ?? this.hasCustomQuestions,
      customQuestions: customQuestions ?? this.customQuestions,
      hasEarlyBird: hasEarlyBird ?? this.hasEarlyBird,
      earlyBirdPrice: earlyBirdPrice ?? this.earlyBirdPrice,
      earlyBirdDeadline: earlyBirdDeadline ?? this.earlyBirdDeadline,
      requiresWaiver: requiresWaiver ?? this.requiresWaiver,
      waiverText: waiverText ?? this.waiverText,
      waiverTemplate: waiverTemplate ?? this.waiverTemplate,
      saving: saving ?? this.saving,
      success: success ?? this.success,
      error: error,
    );
  }

  static EventType? _resolveTypeFromEvent(EventModel ev) {
    if (ev is PickupRunEvent) return EventType.pickupRun;
    if (ev is TournamentEvent) return EventType.tournament;
    if (ev is DonationEvent) return EventType.donationBased;
    return null;
    // add league/one-on-one if you have those types
  }

  @override
  List<Object?> get props => [
        step,
        type,
        title,
        description,
        dateTime,
        eventPrivate,
        locationObj,
        locationText,
        locationPrivate,
        isFree,
        price,
        capacity,
        registrationOpen,
        ticketTypes,
        hasCustomQuestions,
        customQuestions,
        hasEarlyBird,
        earlyBirdPrice,
        earlyBirdDeadline,
        requiresWaiver,
        waiverText,
        waiverTemplate,
        saving,
        success,
        error,
      ];
}
