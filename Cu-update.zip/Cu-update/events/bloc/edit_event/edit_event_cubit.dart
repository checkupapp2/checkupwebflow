// lib/features/events/presentation/bloc/edit_event/edit_event_cubit.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/models/event_model.dart';
import '../../domain/models/event_type.dart';
import '../../domain/models/location_model.dart';
import 'edit_event_state.dart';

class EditEventCubit extends Cubit<EditEventState> {
  final EventModel original;

  EditEventCubit({required this.original})
      : super(EditEventState.initialFrom(original));

  // Wizard nav
  void next() => emit(state.copyWith(step: (state.step + 1).clamp(0, 5)));
  void back() => emit(state.copyWith(step: (state.step - 1).clamp(0, 5)));

  // Core setters
  void setType(EventType? t) => emit(state.copyWith(type: t));
  void setTitle(String v) => emit(state.copyWith(title: v));
  void setDescription(String v) => emit(state.copyWith(description: v));
  void setDateTime(DateTime? v) => emit(state.copyWith(dateTime: v));

  // Visibility
  void setEventPrivate(bool v) => emit(state.copyWith(eventPrivate: v));

  // Location
  void setLocationText(String v) => emit(state.copyWith(locationText: v));
  void setLocationPrivate(bool v) => emit(state.copyWith(locationPrivate: v));
  void setLocationObj(LocationModel? loc) =>
      emit(state.copyWith(locationObj: loc));

  // Pricing / tickets
  void setIsFree(bool v) {
    emit(state.copyWith(isFree: v, price: v ? null : state.price));
  }

  void setPrice(double? v) => emit(state.copyWith(price: v));
  void setCapacity(int? v) => emit(state.copyWith(capacity: v));
  void setRegistrationOpen(bool v) => emit(state.copyWith(registrationOpen: v));

  // Tickets & questions
  void setTicketTypes(List<Map<String, dynamic>> v) =>
      emit(state.copyWith(ticketTypes: v));

  void setHasCustomQuestions(bool v) =>
      emit(state.copyWith(hasCustomQuestions: v));

  void setCustomQuestions(List<Map<String, dynamic>> v) =>
      emit(state.copyWith(customQuestions: v));

  // Early bird
  void setHasEarlyBird(bool v) => emit(state.copyWith(hasEarlyBird: v));
  void setEarlyBirdPrice(double? v) => emit(state.copyWith(earlyBirdPrice: v));
  void setEarlyBirdDeadline(DateTime? v) =>
      emit(state.copyWith(earlyBirdDeadline: v));

  // Waiver
  void setRequiresWaiver(bool v) => emit(state.copyWith(requiresWaiver: v));
  void setWaiverText(String v) => emit(state.copyWith(waiverText: v));
  void setWaiverTemplate(String? v) => emit(state.copyWith(waiverTemplate: v));

  // Submit
  Future<void> submitUpdate() async {
    if (state.saving) return;
    emit(state.copyWith(saving: true, error: null, success: false));

    try {
      // TODO: call your repository to persist the changes.
      // Build payload from state:
      final payload = {
        'id': original.id,
        'type': state.type?.name,
        'title': state.title,
        'description': state.description,
        'dateTime': state.dateTime?.toIso8601String(),
        'eventPrivate': state.eventPrivate,
        'locationPrivate': state.locationPrivate,
        'locationText': state.locationText,
        'locationObj': state.locationObj?.toMap(), // if you have toJson()
        'isFree': state.isFree && state.ticketTypes.isEmpty,
        'price': state.isFree ? null : state.price,
        'capacity': state.capacity,
        'registrationOpen': state.registrationOpen,
        'ticketTypes': state.ticketTypes,
        'hasCustomQuestions': state.hasCustomQuestions,
        'customQuestions': state.customQuestions,
        'hasEarlyBird': state.hasEarlyBird,
        'earlyBirdPrice': state.earlyBirdPrice,
        'earlyBirdDeadline': state.earlyBirdDeadline?.toIso8601String(),
        'requiresWaiver': state.requiresWaiver,
        'waiverText': state.waiverText,
        'waiverTemplate': state.waiverTemplate,
      };

      // await _repo.updateEvent(payload);

      // Simulate success
      await Future.delayed(const Duration(milliseconds: 500));
      emit(state.copyWith(saving: false, success: true));
    } catch (e) {
      emit(state.copyWith(
        saving: false,
        success: false,
        error: e.toString(),
      ));
    }
  }
}
