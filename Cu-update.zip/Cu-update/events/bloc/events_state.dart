import 'package:equatable/equatable.dart';
import '../domain/models/event_model.dart';

abstract class EventsState extends Equatable {
  const EventsState();
  @override
  List<Object?> get props => [];
}

class EventsInitial extends EventsState {
  const EventsInitial();
}

class EventsLoading extends EventsState {
  const EventsLoading();
}

class EventsFailure extends EventsState {
  final String message;
  const EventsFailure(this.message);
  @override
  List<Object?> get props => [message];
}

class EventsSuccess extends EventsState {
  final String? createdId; // set for create flow
  final String message;
  const EventsSuccess({this.createdId, this.message = 'OK'});
  @override
  List<Object?> get props => [createdId, message];
}

class EventLoaded extends EventsState {
  final EventModel event;
  const EventLoaded(this.event);
  @override
  List<Object?> get props => [event];
}
