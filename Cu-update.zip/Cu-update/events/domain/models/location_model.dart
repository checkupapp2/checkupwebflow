/// Model representing a location for events
class LocationModel {
  /// Unique identifier for the location
  final String id;

  /// Name of the location
  final String name;

  /// Address of the location
  final String address;

  /// City of the location
  final String city;

  /// State of the location
  final String state;

  /// ZIP code of the location
  final String zipCode;

  /// Latitude coordinate
  final double? latitude;

  /// Longitude coordinate
  final double? longitude;

  /// Type of venue (e.g., 'court', 'gym', 'park')
  final String venueType;

  /// Whether this is a popular location
  final bool isPopular;

  /// URL to an image of the location
  final String? imageUrl;

  /// Additional details about the location
  final String? description;

  const LocationModel({
    required this.id,
    required this.name,
    required this.address,
    required this.city,
    required this.state,
    required this.zipCode,
    this.latitude,
    this.longitude,
    required this.venueType,
    this.isPopular = false,
    this.imageUrl,
    this.description,
  });

  /// Full address representation
  String get fullAddress {
    final parts = [
      address,
      if (city.trim().isNotEmpty) city,
      if (state.trim().isNotEmpty) state,
      if (zipCode.trim().isNotEmpty) zipCode,
    ];
    // Join smartly: "addr, City, ST 12345"
    return parts.isEmpty
        ? ''
        : [
            address,
            [if (city.isNotEmpty) city, if (state.isNotEmpty) state]
                .where((e) => e.trim().isNotEmpty)
                .join(', '),
            zipCode
          ]
            .where((e) => e.trim().isNotEmpty)
            .join(' ')
            .replaceAll(RegExp(r'\s+'), ' ')
            .trim();
  }

  LocationModel copyWith({
    String? id,
    String? name,
    String? address,
    String? city,
    String? state,
    String? zipCode,
    double? latitude,
    double? longitude,
    String? venueType,
    bool? isPopular,
    String? imageUrl,
    String? description,
  }) {
    return LocationModel(
      id: id ?? this.id,
      name: name ?? this.name,
      address: address ?? this.address,
      city: city ?? this.city,
      state: state ?? this.state,
      zipCode: zipCode ?? this.zipCode,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      venueType: venueType ?? this.venueType,
      isPopular: isPopular ?? this.isPopular,
      imageUrl: imageUrl ?? this.imageUrl,
      description: description ?? this.description,
    );
  }

  /// Serialize for Firestore or JSON
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'address': address,
      'city': city,
      'state': state,
      'zipCode': zipCode,
      'latitude': latitude,
      'longitude': longitude,
      'venueType': venueType,
      'isPopular': isPopular,
      'imageUrl': imageUrl,
      'description': description,
      // convenience field for quicker UI reads
      'fullAddress': fullAddress,
    };
  }

  /// Safe factory from Map (Firestore or JSON)
  factory LocationModel.fromMap(Map<String, dynamic> map) {
    double? _asDouble(dynamic v) {
      if (v == null) return null;
      if (v is num) return v.toDouble();
      if (v is String) return double.tryParse(v);
      return null;
    }

    String _str(dynamic v) => (v ?? '').toString();

    return LocationModel(
      id: _str(map['id']),
      name: _str(map['name']),
      address: _str(map['address']),
      city: _str(map['city']),
      state: _str(map['state']),
      zipCode: _str(map['zipCode']),
      latitude: _asDouble(map['latitude']),
      longitude: _asDouble(map['longitude']),
      venueType:
          _str(map['venueType']).isEmpty ? 'custom' : _str(map['venueType']),
      isPopular: map['isPopular'] is bool
          ? map['isPopular'] as bool
          : _str(map['isPopular']).toLowerCase() == 'true',
      imageUrl: map['imageUrl'] == null || _str(map['imageUrl']).isEmpty
          ? null
          : _str(map['imageUrl']),
      description:
          map['description'] == null || _str(map['description']).isEmpty
              ? null
              : _str(map['description']),
    );
  }

  /// From Firestore Document data nested at `extra.locationMeta` for example
  static LocationModel? tryFrom(dynamic value) {
    if (value is Map<String, dynamic>) {
      return LocationModel.fromMap(value);
    }
    return null;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is LocationModel && other.id == id);

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() => 'LocationModel($name • $fullAddress)';
}
