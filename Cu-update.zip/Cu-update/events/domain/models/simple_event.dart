import 'event_model.dart';
import 'event_type.dart';

class SimpleEvent extends EventModel {
  SimpleEvent({
    super.id,
    super.hostId,
    required super.title,
    required super.description,
    required super.dateTime,
    required super.location,
    required super.locationHidden,
    super.bannerImageUrl,
    super.imageUrls = const [],
    required EventType type,
    required super.category,
    required super.isFree,
    super.price,
    RegistrationStatus registrationStatus = RegistrationStatus.pending,
  }) : super(
          eventType: type,
          registrationStatus: registrationStatus,
        );

  @override
  Map<String, dynamic> toMap() => {
        'id': id,
        'hostId': hostId,
        'title': title,
        'description': description,
        'dateTime': dateTime.toIso8601String(),
        'location': location,
        'locationHidden': locationHidden,
        'bannerImageUrl': bannerImageUrl,
        'images': imageUrls,
        'eventType': eventType.toString(),
        'category': category,
        'isFree': isFree,
        'price': price,
        'registrationStatus': registrationStatus.toString(),
      };

  @override
  SimpleEvent copyWith({
    String? id,
    String? hostId,
    String? title,
    String? description,
    DateTime? dateTime,
    String? location,
    bool? locationHidden,
    String? bannerImageUrl,
    List<String>? imageUrls,
    EventType? eventType,
    String? category,
    bool? isFree,
    double? price,
  }) {
    return SimpleEvent(
      id: id ?? this.id,
      hostId: hostId ?? this.hostId,
      title: title ?? this.title,
      description: description ?? this.description,
      dateTime: dateTime ?? this.dateTime,
      location: location ?? this.location,
      locationHidden: locationHidden ?? this.locationHidden,
      bannerImageUrl: bannerImageUrl ?? this.bannerImageUrl,
      imageUrls: imageUrls ?? this.imageUrls,
      type: eventType ?? this.eventType,
      category: category ?? this.category,
      isFree: isFree ?? this.isFree,
      price: price ?? this.price,
    );
  }
}
