/// Enum representing different types of events
enum EventType {
  // Runs category
  /// Pickup basketball game
  pickupRun,
  /// Open gym session
  openGym,
  /// 1v1 matchup
  oneVsOne,
  
  // Training category
  /// Camp event
  camp,
  /// Skill work/training event
  training,
  
  // Special Events category
  /// Special showcase event
  specialEvent,
  /// One-off special event
  oneOff,
  
  // Tournament category
  /// Tournament bracket play
  tournament,
  
  // Fundraiser category
  /// Donation/charity event
  donationBased,
}

/// Extension on EventType to provide additional functionality
extension EventTypeExtension on EventType {
  /// Get the display name of the event type
  String get displayName {
    switch (this) {
      case EventType.pickupRun:
        return 'Pickup';
      case EventType.openGym:
        return 'Open Gym';
      case EventType.oneVsOne:
        return '1v1';
      case EventType.camp:
        return 'Camps';
      case EventType.training:
        return 'Skill Work';
      case EventType.specialEvent:
        return 'Showcases';
      case EventType.oneOff:
        return 'One-offs';
      case EventType.tournament:
        return 'Bracket Play';
      case EventType.donationBased:
        return 'Charity Games';
    }
  }

  /// Get the description of the event type
  String get description {
    switch (this) {
      case EventType.pickupRun:
        return 'Casual pickup basketball game';
      case EventType.openGym:
        return 'Open basketball gym session';
      case EventType.oneVsOne:
        return 'One-on-one basketball matchup';
      case EventType.camp:
        return 'Multi-day basketball camp for skill development';
      case EventType.training:
        return 'Focused skill development and training session';
      case EventType.specialEvent:
        return 'Basketball showcase event';
      case EventType.oneOff:
        return 'Special one-time event';
      case EventType.tournament:
        return 'Organized tournament with bracket play';
      case EventType.donationBased:
        return 'Charity basketball event with donation goals';
    }
  }
}
