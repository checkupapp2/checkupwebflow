class EventActivityUser {
  final String userId;
  final String name;
  final String? photoUrl;
  final String distanceLabel; // keep simple for now
  final bool isOnline; // keep simple for now

  const EventActivityUser({
    required this.userId,
    required this.name,
    required this.photoUrl,
    required this.distanceLabel,
    required this.isOnline,
  });

  factory EventActivityUser.fromMap(Map<String, dynamic> m) {
    final rawName = (m['name'] ??
            m['displayName'] ??
            m['username'] ??
            m['fullName'] ??
            'User')
        .toString()
        .trim();

    final rawDistance = (m['distanceLabel'] ?? m['distance'] ?? '—').toString();

    return EventActivityUser(
      userId: (m['userId'] ?? '').toString(),
      name: rawName.isEmpty ? 'User' : rawName,
      photoUrl: (m['photoUrl'] as String?)?.toString(),
      distanceLabel: rawDistance.isEmpty ? '—' : rawDistance,
      isOnline: (m['isOnline'] == true),
    );
  }
}

class EventActivitySummary {
  final int registeredCount;
  final List<EventActivityUser> users;

  const EventActivitySummary({
    required this.registeredCount,
    required this.users,
  });

  factory EventActivitySummary.fromMap(Map<String, dynamic> m) {
    final rawUsers = (m['users'] as List?) ?? const [];

    // backend currently returns `ticketsSold`, older client expects `registeredCount`
    final rawCount = m['registeredCount'] ?? m['ticketsSold'] ?? 0;
    final count = rawCount is num
        ? rawCount.toInt()
        : int.tryParse(rawCount.toString()) ?? 0;

    return EventActivitySummary(
      registeredCount: count,
      users: rawUsers
          .whereType<Map>()
          .map((e) => EventActivityUser.fromMap(e.cast<String, dynamic>()))
          .toList(),
    );
  }
}
