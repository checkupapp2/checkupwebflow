import 'package:cloud_firestore/cloud_firestore.dart';

/// Model class for basketball courts
class CourtModel {
  /// Unique identifier for the court
  final String id;

  /// Name of the court
  final String name;

  /// Address of the court
  final String address;

  /// City where the court is located
  final String city;

  /// State where the court is located
  final String state;

  /// Zip code of the court location
  final String zipCode;

  /// URL for the court image
  final String? imageUrl;

  /// Rating of the court (0-5)
  final double rating;

  /// Number of hoops at the court
  final int hoopCount;

  /// Whether the court has lights for night play
  final bool hasLights;

  /// Whether the court is indoor or outdoor
  final bool isIndoor;

  /// Constructor
  const CourtModel({
    required this.id,
    required this.name,
    required this.address,
    required this.city,
    required this.state,
    required this.zipCode,
    this.imageUrl,
    required this.rating,
    required this.hoopCount,
    required this.hasLights,
    required this.isIndoor,
  });

  /// Get the full address as a string
  String get fullAddress => '$address, $city, $state $zipCode';
}

/// Sample court data
List<CourtModel> sampleCourts = [
  CourtModel(
    id: 'court1',
    name: 'Downtown Recreation Center',
    address: '123 Main Street',
    city: 'Chicago',
    state: 'IL',
    zipCode: '60601',
    imageUrl: 'assets/images/courts/downtown_rec.jpg',
    rating: 4.5,
    hoopCount: 6,
    hasLights: true,
    isIndoor: true,
  ),
  CourtModel(
    id: 'court2',
    name: 'Lakefront Park Courts',
    address: '500 Lake Shore Drive',
    city: 'Chicago',
    state: 'IL',
    zipCode: '60611',
    imageUrl: 'assets/images/courts/lakefront.jpg',
    rating: 4.8,
    hoopCount: 4,
    hasLights: true,
    isIndoor: false,
  ),
  CourtModel(
    id: 'court3',
    name: 'Westside Community Center',
    address: '789 West Madison St',
    city: 'Chicago',
    state: 'IL',
    zipCode: '60607',
    imageUrl: null, // No image available
    rating: 3.9,
    hoopCount: 2,
    hasLights: false,
    isIndoor: true,
  ),
  CourtModel(
    id: 'court4',
    name: 'Northside YMCA',
    address: '1234 North Clark St',
    city: 'Chicago',
    state: 'IL',
    zipCode: '60614',
    imageUrl: 'assets/images/courts/ymca.jpg',
    rating: 4.2,
    hoopCount: 4,
    hasLights: true,
    isIndoor: true,
  ),
  CourtModel(
    id: 'court5',
    name: 'Southside Park',
    address: '567 South State St',
    city: 'Chicago',
    state: 'IL',
    zipCode: '60605',
    imageUrl: 'assets/images/courts/southside.jpg',
    rating: 3.7,
    hoopCount: 8,
    hasLights: true,
    isIndoor: false,
  ),
];

extension CourtModelFirestore on CourtModel {
  static CourtModel fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    final addr = (d['address'] ?? '') as String;
    final city = (d['city'] ?? '') as String;
    final state = (d['state'] ?? '') as String;
    final zip = (d['zipCode'] ?? '') as String;

    return CourtModel(
      id: doc.id,
      name: (d['name'] ?? '') as String,
      address: addr,
      city: city,
      state: state,
      zipCode: zip,
      imageUrl: d['imageUrl'] as String?,
      rating: (d['rating'] as num?)?.toDouble() ?? 0.0,
      hoopCount: (d['hoopCount'] as num?)?.toInt() ?? 0,
      hasLights: (d['hasLights'] as bool?) ?? false,
      isIndoor: (d['isIndoor'] as bool?) ?? false,
    );
  }

  Map<String, dynamic> toFirestore() => {
        'name': name,
        'address': address,
        'city': city,
        'state': state,
        'zipCode': zipCode,
        'imageUrl': imageUrl,
        'rating': rating,
        'hoopCount': hoopCount,
        'hasLights': hasLights,
        'isIndoor': isIndoor,
      };
}
