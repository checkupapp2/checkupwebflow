import 'package:cloud_firestore/cloud_firestore.dart';
import 'event_model.dart';
import 'event_type.dart';
import 'simple_event.dart';

RegistrationStatus _statusOf(dynamic v) {
  final s = (v ?? 'pending') as String;
  switch (s) {
    case 'approved':
      return RegistrationStatus.approved;
    case 'rejected':
      return RegistrationStatus.rejected;
    default:
      return RegistrationStatus.pending;
  }
}

String _statusToString(RegistrationStatus s) {
  switch (s) {
    case RegistrationStatus.approved:
      return 'approved';
    case RegistrationStatus.rejected:
      return 'rejected';
    case RegistrationStatus.pending:
      return 'pending';
  }
}

EventModel eventFromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
  final d = doc.data() ?? {};

  // eventType is stored as plain string e.g. "camp", "pickupRun"
  final typeStr = (d['eventType'] ?? 'pickupRun') as String;
  final type = EventType.values.firstWhere(
    (e) => e.name == typeStr,
    orElse: () => EventType.pickupRun,
  );

  final hostId = d['hostId'] as String?;
  final locationHidden = d['locationHidden'] as bool? ?? false;

  // Date
  final ts = d['dateTime'];
  final dateTime = (ts is Timestamp)
      ? ts.toDate()
      : (ts is DateTime)
          ? ts
          : DateTime.now();

  // Images: unify `images` + `gallery`
  final imagesList = ((d['images'] as List?) ?? const [])
      .whereType<String>()
      .toList(growable: true);
  final galleryList = ((d['gallery'] as List?) ?? const [])
      .whereType<String>()
      .toList(growable: false);
  for (final g in galleryList) {
    if (!imagesList.contains(g)) imagesList.add(g);
  }

  // Extra map (may be empty / missing)
  final Map<String, dynamic> extra =
      (d['extra'] as Map?)?.cast<String, dynamic>() ?? const {};

  // Common base fields
  final title = (d['title'] as String?) ?? '';
  final description = (d['description'] as String?) ?? '';
  final location = (d['location'] as String?) ?? '';
  final banner = (d['bannerImageUrl'] as String?);
  final category = (d['category'] as String?) ?? '';
  final isFree = (d['isFree'] as bool?) ?? true;
  final price = (d['price'] as num?)?.toDouble();
  final regStatus = _statusOf(d['registrationStatus']);

  // Builders
  SimpleEvent _simple(EventType t, String defaultCategory) => SimpleEvent(
        id: doc.id,
        hostId: hostId,
        title: title,
        description: description,
        dateTime: dateTime,
        location: location,
        locationHidden: locationHidden,
        bannerImageUrl: banner,
        imageUrls: imagesList,
        category: category.isNotEmpty ? category : defaultCategory,
        isFree: isFree,
        price: price,
        type: t,
        registrationStatus: regStatus,
      );

  // Map per type
  switch (type) {
    case EventType.pickupRun:
      // Prefer `extra`, but fall back to historical top-level fields
      final maxPlayers = (extra['maxPlayers'] as num?)?.toInt() ??
          (d['maxPlayers'] as num?)?.toInt() ??
          10;
      final currentPlayers = (extra['currentPlayers'] as num?)?.toInt() ??
          (d['currentPlayers'] as num?)?.toInt() ??
          0;
      final skillLevel = (extra['skillLevel'] as String?) ??
          (d['skillLevel'] as String?) ??
          'Beginner';

      return PickupRunEvent(
        id: doc.id,
        hostId: hostId,
        title: title,
        description: description,
        dateTime: dateTime,
        location: location,
        locationHidden: locationHidden,
        bannerImageUrl: banner,
        imageUrls: imagesList,
        category: category.isNotEmpty ? category : 'Basketball',
        isFree: isFree,
        price: price,
        maxPlayers: maxPlayers,
        currentPlayers: currentPlayers,
        skillLevel: skillLevel,
        registrationStatus: regStatus,
      );

    case EventType.tournament:
      final numberOfTeams = (extra['numberOfTeams'] as num?)?.toInt() ?? 8;
      final format = (extra['format'] as String?) ?? 'Single Elimination';
      final prizePool = (extra['prizePool'] as num?)?.toDouble();
      final rd = extra['registrationDeadline'];
      final registrationDeadline = (rd is Timestamp)
          ? rd.toDate()
          : (rd is DateTime)
              ? rd
              : dateTime;

      return TournamentEvent(
        id: doc.id,
        hostId: hostId,
        title: title,
        description: description,
        dateTime: dateTime,
        location: location,
        locationHidden: locationHidden,
        bannerImageUrl: banner,
        imageUrls: imagesList,
        category: category.isNotEmpty ? category : 'Tournament',
        isFree: isFree,
        price: price,
        numberOfTeams: numberOfTeams,
        format: format,
        prizePool: prizePool,
        registrationDeadline: registrationDeadline,
        registrationStatus: regStatus,
      );

    case EventType.donationBased:
      final donationGoal = (extra['donationGoal'] as num?)?.toDouble() ?? 0.0;
      final currentAmount = (extra['currentAmount'] as num?)?.toDouble() ?? 0.0;
      final beneficiary = (extra['beneficiary'] as String?) ?? '';
      final hasTaxReceipts = (extra['hasTaxReceipts'] as bool?) ?? false;

      return DonationEvent(
        id: doc.id,
        hostId: hostId,
        title: title,
        description: description,
        dateTime: dateTime,
        location: location,
        locationHidden: locationHidden,
        bannerImageUrl: banner,
        imageUrls: imagesList,
        category: category.isNotEmpty ? category : 'Charity',
        isFree: isFree,
        price: price,
        donationGoal: donationGoal,
        currentAmount: currentAmount,
        beneficiary: beneficiary,
        hasTaxReceipts: hasTaxReceipts,
        registrationStatus: regStatus,
      );

    // All the others are “simple” – no subtype-specific fields required
    case EventType.camp:
      return _simple(EventType.camp, 'Camp');
    case EventType.training:
      return _simple(EventType.training, 'Training');
    case EventType.openGym:
      return _simple(EventType.openGym, 'Open Gym');
    case EventType.specialEvent:
      return _simple(EventType.specialEvent, 'Showcase');
    case EventType.oneOff:
      return _simple(EventType.oneOff, 'One-off');
    case EventType.oneVsOne:
      return _simple(EventType.oneVsOne, '1v1');
  }
}

Map<String, dynamic> eventToMap(EventModel e) {
  final base = <String, dynamic>{
    'title': e.title,
    'description': e.description,
    'dateTime': Timestamp.fromDate(e.dateTime),
    'location': e.location,
    'locationHidden': e.locationHidden,
    'bannerImageUrl': e.bannerImageUrl,
    'images': e.imageUrls,
    'eventType': e.eventType.name, // store plain string
    'category': e.category,
    'isFree': e.isFree,
    'price': e.price,
    'registrationStatus': _statusToString(e.registrationStatus),
  };

  Map<String, dynamic> extra = {};
  if (e is PickupRunEvent) {
    extra = {
      'maxPlayers': e.maxPlayers,
      'currentPlayers': e.currentPlayers,
      'skillLevel': e.skillLevel,
    };
  } else if (e is TournamentEvent) {
    extra = {
      'numberOfTeams': e.numberOfTeams,
      'format': e.format,
      'prizePool': e.prizePool,
      'registrationDeadline': Timestamp.fromDate(e.registrationDeadline),
    };
  } else if (e is DonationEvent) {
    extra = {
      'donationGoal': e.donationGoal,
      'currentAmount': e.currentAmount,
      'beneficiary': e.beneficiary,
      'hasTaxReceipts': e.hasTaxReceipts,
    };
  }

  base['extra'] = extra; // keep present even if empty for consistency
  return base;
}

class EventFirestore {
  static EventModel fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) =>
      eventFromDoc(doc);

  static Map<String, dynamic> toMap(EventModel e) => eventToMap(e);
}
