import 'event_type.dart';

enum RegistrationStatus { pending, approved, rejected }

abstract class EventModel {
  final String? id;
  final String? hostId;

  final String title;
  final String description;
  final DateTime dateTime;

  final String location;

  /// Hide location from public users (still visible to host/admin)
  final bool locationHidden;

  /// Banner image used in lists/headers.
  final String? bannerImageUrl;

  /// Full gallery for the event (0..n). First image is typically used as banner.
  final List<String> imageUrls;

  final EventType eventType;
  final String category;

  final bool isFree;
  final double? price;

  final RegistrationStatus registrationStatus;

  EventModel({
    this.id,
    this.hostId,
    required this.title,
    required this.description,
    required this.dateTime,
    required this.location,
    required this.locationHidden,
    this.bannerImageUrl,
    this.imageUrls = const [],
    required this.eventType,
    required this.category,
    required this.isFree,
    this.price,
    this.registrationStatus = RegistrationStatus.pending,
  });

  Map<String, dynamic> toMap();

  EventModel copyWith({
    String? id,
    String? hostId,
    String? title,
    String? description,
    DateTime? dateTime,
    String? location,
    bool? locationHidden,
    String? bannerImageUrl,
    List<String>? imageUrls,
    EventType? eventType,
    String? category,
    bool? isFree,
    double? price,
  });
}

// --------------------------------------------------
//                PickupRunEvent
// --------------------------------------------------
class PickupRunEvent extends EventModel {
  final int maxPlayers;
  final int currentPlayers;
  final String skillLevel;

  PickupRunEvent({
    super.id,
    super.hostId,
    required super.title,
    required super.description,
    required super.dateTime,
    required super.location,
    required super.locationHidden,
    super.bannerImageUrl,
    super.imageUrls = const [],
    required super.category,
    required super.isFree,
    super.price,
    required this.maxPlayers,
    this.currentPlayers = 0,
    required this.skillLevel,
    RegistrationStatus registrationStatus = RegistrationStatus.pending,
  }) : super(
          eventType: EventType.pickupRun,
          registrationStatus: registrationStatus,
        );

  @override
  Map<String, dynamic> toMap() => {
        'id': id,
        'hostId': hostId,
        'title': title,
        'description': description,
        'dateTime': dateTime.toIso8601String(),
        'location': location,
        'locationHidden': locationHidden,
        'bannerImageUrl': bannerImageUrl,
        'images': imageUrls,
        'eventType': eventType.toString(),
        'category': category,
        'isFree': isFree,
        'price': price,
        'maxPlayers': maxPlayers,
        'currentPlayers': currentPlayers,
        'skillLevel': skillLevel,
        'registrationStatus': registrationStatus.toString(),
      };

  @override
  PickupRunEvent copyWith({
    String? id,
    String? hostId,
    String? title,
    String? description,
    DateTime? dateTime,
    String? location,
    bool? locationHidden,
    String? bannerImageUrl,
    List<String>? imageUrls,
    EventType? eventType,
    String? category,
    bool? isFree,
    double? price,
    int? maxPlayers,
    int? currentPlayers,
    String? skillLevel,
  }) {
    return PickupRunEvent(
      id: id ?? this.id,
      hostId: hostId ?? this.hostId,
      title: title ?? this.title,
      description: description ?? this.description,
      dateTime: dateTime ?? this.dateTime,
      location: location ?? this.location,
      locationHidden: locationHidden ?? this.locationHidden,
      bannerImageUrl: bannerImageUrl ?? this.bannerImageUrl,
      imageUrls: imageUrls ?? this.imageUrls,
      category: category ?? this.category,
      isFree: isFree ?? this.isFree,
      price: price ?? this.price,
      maxPlayers: maxPlayers ?? this.maxPlayers,
      currentPlayers: currentPlayers ?? this.currentPlayers,
      skillLevel: skillLevel ?? this.skillLevel,
    );
  }
}

// --------------------------------------------------
//                TournamentEvent
// --------------------------------------------------
class TournamentEvent extends EventModel {
  final int numberOfTeams;
  final String format;
  final double? prizePool;
  final DateTime registrationDeadline;

  TournamentEvent({
    super.id,
    super.hostId,
    required super.title,
    required super.description,
    required super.dateTime,
    required super.location,
    required super.locationHidden,
    super.bannerImageUrl,
    super.imageUrls = const [],
    required super.category,
    required super.isFree,
    super.price,
    required this.numberOfTeams,
    required this.format,
    this.prizePool,
    required this.registrationDeadline,
    RegistrationStatus registrationStatus = RegistrationStatus.pending,
  }) : super(
          eventType: EventType.tournament,
          registrationStatus: registrationStatus,
        );

  @override
  Map<String, dynamic> toMap() => {
        'id': id,
        'hostId': hostId,
        'title': title,
        'description': description,
        'dateTime': dateTime.toIso8601String(),
        'location': location,
        'locationHidden': locationHidden,
        'bannerImageUrl': bannerImageUrl,
        'images': imageUrls,
        'eventType': eventType.toString(),
        'category': category,
        'isFree': isFree,
        'price': price,
        'numberOfTeams': numberOfTeams,
        'format': format,
        'prizePool': prizePool,
        'registrationDeadline': registrationDeadline.toIso8601String(),
        'registrationStatus': registrationStatus.toString(),
      };

  @override
  TournamentEvent copyWith({
    String? id,
    String? hostId,
    String? title,
    String? description,
    DateTime? dateTime,
    String? location,
    bool? locationHidden,
    String? bannerImageUrl,
    List<String>? imageUrls,
    EventType? eventType,
    String? category,
    bool? isFree,
    double? price,
    int? numberOfTeams,
    String? format,
    double? prizePool,
    DateTime? registrationDeadline,
  }) {
    return TournamentEvent(
      id: id ?? this.id,
      hostId: hostId ?? this.hostId,
      title: title ?? this.title,
      description: description ?? this.description,
      dateTime: dateTime ?? this.dateTime,
      location: location ?? this.location,
      locationHidden: locationHidden ?? this.locationHidden,
      bannerImageUrl: bannerImageUrl ?? this.bannerImageUrl,
      imageUrls: imageUrls ?? this.imageUrls,
      category: category ?? this.category,
      isFree: isFree ?? this.isFree,
      price: price ?? this.price,
      numberOfTeams: numberOfTeams ?? this.numberOfTeams,
      format: format ?? this.format,
      prizePool: prizePool ?? this.prizePool,
      registrationDeadline: registrationDeadline ?? this.registrationDeadline,
    );
  }
}

// --------------------------------------------------
//                DonationEvent
// --------------------------------------------------
class DonationEvent extends EventModel {
  final double donationGoal;
  final double currentAmount;
  final String beneficiary;
  final bool hasTaxReceipts;

  DonationEvent({
    super.id,
    super.hostId,
    required super.title,
    required super.description,
    required super.dateTime,
    required super.location,
    required super.locationHidden,
    super.bannerImageUrl,
    super.imageUrls = const [],
    required super.category,
    required super.isFree,
    super.price,
    required this.donationGoal,
    this.currentAmount = 0.0,
    required this.beneficiary,
    this.hasTaxReceipts = false,
    RegistrationStatus registrationStatus = RegistrationStatus.pending,
  }) : super(
          eventType: EventType.donationBased,
          registrationStatus: registrationStatus,
        );

  @override
  Map<String, dynamic> toMap() => {
        'id': id,
        'hostId': hostId,
        'title': title,
        'description': description,
        'dateTime': dateTime.toIso8601String(),
        'location': location,
        'locationHidden': locationHidden,
        'bannerImageUrl': bannerImageUrl,
        'images': imageUrls,
        'eventType': eventType.toString(),
        'category': category,
        'isFree': isFree,
        'price': price,
        'donationGoal': donationGoal,
        'currentAmount': currentAmount,
        'beneficiary': beneficiary,
        'hasTaxReceipts': hasTaxReceipts,
        'registrationStatus': registrationStatus.toString(),
      };

  @override
  DonationEvent copyWith({
    String? id,
    String? hostId,
    String? title,
    String? description,
    DateTime? dateTime,
    String? location,
    bool? locationHidden,
    String? bannerImageUrl,
    List<String>? imageUrls,
    EventType? eventType,
    String? category,
    bool? isFree,
    double? price,
    double? donationGoal,
    double? currentAmount,
    String? beneficiary,
    bool? hasTaxReceipts,
  }) {
    return DonationEvent(
      id: id ?? this.id,
      hostId: hostId ?? this.hostId,
      title: title ?? this.title,
      description: description ?? this.description,
      dateTime: dateTime ?? this.dateTime,
      location: location ?? this.location,
      locationHidden: locationHidden ?? this.locationHidden,
      bannerImageUrl: bannerImageUrl ?? this.bannerImageUrl,
      imageUrls: imageUrls ?? this.imageUrls,
      category: category ?? this.category,
      isFree: isFree ?? this.isFree,
      price: price ?? this.price,
      donationGoal: donationGoal ?? this.donationGoal,
      currentAmount: currentAmount ?? this.currentAmount,
      beneficiary: beneficiary ?? this.beneficiary,
      hasTaxReceipts: hasTaxReceipts ?? this.hasTaxReceipts,
    );
  }
}
