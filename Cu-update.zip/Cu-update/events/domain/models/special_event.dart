import 'event_model.dart';
import 'event_type.dart';

/// Model for special events
class SpecialEvent extends EventModel {
  /// Additional notes for the special event
  final String? additionalNotes;

  /// Constructor for SpecialEvent
  SpecialEvent({
    super.id,
    required super.title,
    required super.description,
    required super.dateTime,
    required super.location,
    super.bannerImageUrl,
    required super.category,
    required super.isFree,
    super.price,
    this.additionalNotes,
    required bool locationHidden,
  }) : super(
          eventType: EventType.specialEvent,
          locationHidden: locationHidden,
        );

  @override
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'dateTime': dateTime.toIso8601String(),
      'location': location,
      'bannerImageUrl': bannerImageUrl,
      'eventType': eventType.toString(),
      'category': category,
      'isFree': isFree,
      'price': price,
      'additionalNotes': additionalNotes,
    };
  }

  @override
  SpecialEvent copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? dateTime,
    String? location,
    String? bannerImageUrl,
    EventType? eventType,
    String? category,
    bool? isFree,
    double? price,
    String? hostId,
    List<String>? imageUrls,
    bool? locationHidden,
    String? additionalNotes,
  }) {
    return SpecialEvent(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      dateTime: dateTime ?? this.dateTime,
      location: location ?? this.location,
      bannerImageUrl: bannerImageUrl ?? this.bannerImageUrl,
      category: category ?? this.category,
      isFree: isFree ?? this.isFree,
      price: price ?? this.price,
      additionalNotes: additionalNotes ?? this.additionalNotes,
      locationHidden: locationHidden ?? this.locationHidden,
    );
  }
}
