import 'dart:math';
import 'package:check_up_app/features/events/domain/models/event_model.dart';

/// Service class for handling event-related operations
class EventService {
  /// Singleton instance
  static final EventService _instance = EventService._internal();

  /// Factory constructor
  factory EventService() => _instance;

  /// Internal constructor
  EventService._internal();

  /// Get all events that the user has registered for or created
  Future<List<EventModel>> getAllUserEvents() async {
    // TODO: Replace with actual API call
    // This is a mock implementation
    await Future.delayed(const Duration(milliseconds: 800));
    return _generateMockEvents();
  }

  /// Get events that the user is hosting
  Future<List<EventModel>> getHostedEvents() async {
    // TODO: Replace with actual API call
    // This is a mock implementation
    await Future.delayed(const Duration(milliseconds: 800));
    final allEvents = _generateMockEvents();
    // For mock purposes, assume the first half of events are hosted by the user
    return allEvents.sublist(0, allEvents.length ~/ 2);
  }

  /// Get events that the user is attending but not hosting
  Future<List<EventModel>> getAttendingEvents() async {
    // TODO: Replace with actual API call
    // This is a mock implementation
    await Future.delayed(const Duration(milliseconds: 800));
    final allEvents = _generateMockEvents();
    // For mock purposes, assume the second half of events are ones the user is attending
    return allEvents.sublist(allEvents.length ~/ 2);
  }

  /// Get upcoming events that the user is hosting
  Future<List<EventModel>> getUpcomingHostedEvents() async {
    final events = await getHostedEvents();
    final now = DateTime.now();
    return events.where((event) => event.dateTime.isAfter(now)).toList();
  }

  /// Get upcoming events that the user is attending but not hosting
  Future<List<EventModel>> getUpcomingAttendingEvents() async {
    final events = await getAttendingEvents();
    final now = DateTime.now();
    return events.where((event) => event.dateTime.isAfter(now)).toList();
  }

  /// Get past events that the user is hosting
  Future<List<EventModel>> getPastHostedEvents() async {
    final events = await getHostedEvents();
    final now = DateTime.now();
    return events.where((event) => event.dateTime.isBefore(now)).toList();
  }

  /// Get past events that the user is attending but not hosting
  Future<List<EventModel>> getPastAttendingEvents() async {
    final events = await getAttendingEvents();
    final now = DateTime.now();
    return events.where((event) => event.dateTime.isBefore(now)).toList();
  }

  /// Get events that the user has registered for or created
  Future<List<EventModel>> getUserEvents() async {
    // TODO: Replace with actual API call
    // This is a mock implementation
    await Future.delayed(const Duration(milliseconds: 800));
    return _generateMockEvents();
  }

  /// Get upcoming events that the user has registered for or created
  Future<List<EventModel>> getUpcomingUserEvents() async {
    final events = await getUserEvents();
    final now = DateTime.now();
    return events.where((event) => event.dateTime.isAfter(now)).toList();
  }

  /// Get past events that the user has registered for or created
  Future<List<EventModel>> getPastUserEvents() async {
    final events = await getUserEvents();
    final now = DateTime.now();
    return events.where((event) => event.dateTime.isBefore(now)).toList();
  }

  /// Generate mock events for testing
  List<EventModel> _generateMockEvents() {
    final random = Random();
    final now = DateTime.now();

    final List<EventModel> events = [];

    // Add some pickup run events
    for (int i = 0; i < 3; i++) {
      events.add(
        PickupRunEvent(
          id: 'pickup_$i',
          title: 'Pickup Game ${i + 1}',
          description: 'Join us for a casual pickup basketball game!',
          dateTime: now.add(Duration(days: random.nextInt(14) - 7)),
          location: 'Local Court ${i + 1}',
          locationHidden: random.nextBool(),
          bannerImageUrl:
              'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=1000',
          category: 'Basketball',
          isFree: random.nextBool(),
          price: random.nextDouble() * 10 + 5,
          maxPlayers: 10 + random.nextInt(10),
          currentPlayers: random.nextInt(10),
          skillLevel: [
            'Beginner',
            'Intermediate',
            'Advanced'
          ][random.nextInt(3)],
        ),
      );
    }

    // Add some tournament events
    for (int i = 0; i < 2; i++) {
      events.add(
        TournamentEvent(
          id: 'tournament_$i',
          title: '3v3 Tournament ${i + 1}',
          description: 'Compete in our exciting 3v3 basketball tournament!',
          dateTime: now.add(Duration(days: random.nextInt(30))),
          location: 'Sports Complex ${i + 1}',
          locationHidden: random.nextBool(),
          bannerImageUrl:
              'https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=1000',
          category: 'Tournament',
          isFree: false,
          price: random.nextDouble() * 50 + 20,
          numberOfTeams: 8 + random.nextInt(8),
          format: [
            'Single Elimination',
            'Double Elimination',
            'Round Robin'
          ][random.nextInt(3)],
          prizePool: random.nextDouble() * 500 + 100,
          registrationDeadline: now.add(Duration(days: random.nextInt(20))),
        ),
      );
    }

    // Add some donation events
    for (int i = 0; i < 2; i++) {
      events.add(
        DonationEvent(
          id: 'donation_$i',
          title: 'Charity Basketball Event ${i + 1}',
          description: 'Play basketball for a good cause!',
          dateTime: now.add(Duration(days: random.nextInt(40) - 20)),
          location: 'Community Center ${i + 1}',
          locationHidden: random.nextBool(),
          bannerImageUrl:
              'https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=1000',
          category: 'Charity',
          isFree: true,
          donationGoal: random.nextDouble() * 2000 + 500,
          currentAmount: random.nextDouble() * 500,
          beneficiary: 'Local Youth Basketball Program',
          hasTaxReceipts: random.nextBool(),
        ),
      );
    }

    return events;
  }
}
