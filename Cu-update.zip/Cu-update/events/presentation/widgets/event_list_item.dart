import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/domain/models/event_model.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';
import 'package:intl/intl.dart';

import 'dart:io' show File;
import 'package:flutter/foundation.dart' show kIsWeb;

/// A widget that displays an event item in a list
class EventListItem extends StatelessWidget {
  /// The event to display
  final EventModel event;

  /// Optional extra images (from creator preview or gallery)
  /// If provided and non-empty, these will be shown as a swipeable carousel.
  /// Otherwise we fall back to [event.bannerImageUrl].
  final List<String>? imageUrls;

  /// Optional tap handler for the image area (e.g., open picker or detail)
  final VoidCallback? onImageTap;

  const EventListItem({
    Key? key,
    required this.event,
    this.imageUrls,
    this.onImageTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildEventImage(),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildEventHeader(),
                const SizedBox(height: 12),
                _buildEventInfo(),
                const SizedBox(height: 16),
                _buildEventActions(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _imageFallback(double h) => Container(
        height: h,
        color: Colors.grey[800],
        alignment: Alignment.center,
        child: Icon(
          _getIconForEventType(),
          color: Colors.grey[600],
          size: 48,
        ),
      );

  Widget _mixedImage(
    String src, {
    double? height,
    double? width,
    BoxFit fit = BoxFit.cover,
  }) {
    // Web: treat all as network
    if (kIsWeb) {
      return Image.network(
        src,
        height: height,
        width: width,
        fit: fit,
        errorBuilder: (_, __, ___) => _imageFallback(height ?? 140),
      );
    }

    final uri = Uri.tryParse(src);

    // Remote URL
    if (uri != null && (uri.scheme == 'http' || uri.scheme == 'https')) {
      return Image.network(
        src,
        height: height,
        width: width,
        fit: fit,
        errorBuilder: (_, __, ___) => _imageFallback(height ?? 140),
      );
    }

    // file:// URI
    if (uri != null && uri.scheme == 'file') {
      return Image.file(
        File.fromUri(uri),
        height: height,
        width: width,
        fit: fit,
        errorBuilder: (_, __, ___) => _imageFallback(height ?? 140),
      );
    }

    // Plain local path
    return Image.file(
      File(src),
      height: height,
      width: width,
      fit: fit,
      errorBuilder: (_, __, ___) => _imageFallback(height ?? 140),
    );
  }

  Widget _buildEventImage() {
    // Build the list of URLs to show in the carousel:
    // priority: explicit imageUrls -> bannerImageUrl -> placeholder
    final List<String> urls = (imageUrls != null && imageUrls!.isNotEmpty)
        ? imageUrls!
        : (event.bannerImageUrl != null ? [event.bannerImageUrl!] : []);

    Widget content;

    if (urls.isNotEmpty) {
      content = ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        child: PageView.builder(
          itemCount: urls.length,
          allowImplicitScrolling: true,
          itemBuilder: (context, index) {
            return _mixedImage(
              urls[index],
              height: 140,
              width: double.infinity,
              fit: BoxFit.cover,
            );
          },
        ),
      );
    } else {
      content = ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        child: Container(
          height: 140,
          color: Colors.grey[800],
          alignment: Alignment.center,
          child: Icon(
            _getIconForEventType(),
            color: Colors.grey[600],
            size: 48,
          ),
        ),
      );
    }

    return Stack(
      children: [
        GestureDetector(onTap: onImageTap, child: content),

        // Left badge: event type
        Positioned(
          top: 12,
          left: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.7),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              event.eventType.displayName,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
        ),

        // Right badge: pickup players
        if (event is PickupRunEvent)
          Positioned(
            top: 12,
            right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.8),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '${(event as PickupRunEvent).currentPlayers}/${(event as PickupRunEvent).maxPlayers}',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ),

        // Right badge: tournament prize
        if (event is TournamentEvent &&
            (event as TournamentEvent).prizePool != null)
          Positioned(
            top: 12,
            right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.8),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '\$${(event as TournamentEvent).prizePool!.toStringAsFixed(0)} Prize',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildEventHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                event.title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  const Icon(
                    Icons.calendar_today,
                    color: Colors.grey,
                    size: 14,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatDate(event.dateTime),
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Icon(
                    Icons.access_time,
                    color: Colors.grey,
                    size: 14,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatTime(event.dateTime),
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        _buildEventPrice(),
      ],
    );
  }

  Widget _buildEventInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(
              Icons.location_on,
              color: Colors.grey,
              size: 16,
            ),
            const SizedBox(width: 4),
            Expanded(
              child: Text(
                event.location,
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 14,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          event.description,
          style: TextStyle(
            color: Colors.grey[300],
            fontSize: 14,
          ),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }

  Widget _buildEventActions() {
    final bool isUpcoming = event.dateTime.isAfter(DateTime.now());

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        if (isUpcoming)
          OutlinedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.calendar_today, size: 16),
            label: const Text('Reminder'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.orange,
              side: const BorderSide(color: Colors.orange),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          )
        else
          OutlinedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.replay, size: 16),
            label: const Text('View Recap'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.grey,
              side: const BorderSide(color: Colors.grey),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
        if (isUpcoming)
          ElevatedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.check_circle_outline, size: 16),
            label: const Text('Check In'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          )
        else
          OutlinedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.share, size: 16),
            label: const Text('Share'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: const BorderSide(color: Colors.white),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildEventPrice() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: event.isFree
            ? Colors.green.withOpacity(0.2)
            : Colors.orange.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: event.isFree ? Colors.green : Colors.orange,
        ),
      ),
      child: Text(
        event.isFree
            ? 'FREE'
            : '\$${event.price?.toStringAsFixed(2) ?? '0.00'}',
        style: TextStyle(
          color: event.isFree ? Colors.green : Colors.orange,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _formatDate(DateTime dateTime) {
    return DateFormat('MMM d, yyyy').format(dateTime);
  }

  String _formatTime(DateTime dateTime) {
    return DateFormat('h:mm a').format(dateTime);
  }

  IconData _getIconForEventType() {
    switch (event.eventType) {
      case EventType.pickupRun:
        return Icons.sports_basketball;
      case EventType.tournament:
        return Icons.emoji_events;
      case EventType.oneOff:
        return Icons.event;
      case EventType.camp:
        return Icons.cabin;
      case EventType.training:
        return Icons.fitness_center;
      case EventType.donationBased:
        return Icons.volunteer_activism;
      case EventType.specialEvent:
        return Icons.star;
      case EventType.openGym:
        return Icons.sports_handball;
      case EventType.oneVsOne:
        return Icons.people;
    }
  }
}
