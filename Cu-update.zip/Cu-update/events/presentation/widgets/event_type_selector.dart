import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';

/// A widget for selecting event types by category
class EventTypeSelector extends StatefulWidget {
  /// Currently selected event type
  final EventType? selectedType;
  
  /// Callback when an event type is selected
  final Function(EventType) onTypeSelected;

  /// Creates an [EventTypeSelector] widget
  const EventTypeSelector({
    Key? key,
    this.selectedType,
    required this.onTypeSelected,
  }) : super(key: key);

  @override
  State<EventTypeSelector> createState() => _EventTypeSelectorState();
}

class _EventTypeSelectorState extends State<EventTypeSelector> {
  String? selectedCategory;
  
  final Map<String, EventType> categories = {
    'Runs': EventType.pickupRun,
    'Tournament': EventType.tournament,
    'Training': EventType.training,
    'Camp': EventType.camp,
    'Fundraiser': EventType.donationBased,
    'Special Events': EventType.specialEvent,
  };
  
  final Map<String, String> categorySubtitles = {
    'Runs': 'Pickup, Open Gym, 1v1',
    'Tournament': 'Bracket Play',
    'Training': 'Skill Work',
    'Camp': 'Multi-day Basketball Camps',
    'Fundraiser': 'Charity Events',
    'Special Events': 'Showcases, One-offs',
  };
  
  final Map<String, IconData> categoryIcons = {
    'Runs': Icons.sports_basketball,
    'Tournament': Icons.emoji_events,
    'Training': Icons.fitness_center,
    'Camp': Icons.school,
    'Fundraiser': Icons.volunteer_activism,
    'Special Events': Icons.star,
  };
  
  @override
  void initState() {
    super.initState();
    // No need to set initial category since we're not using intermediate steps
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Vertical list of event types
            _buildVerticalEventTypeList(),
            
            const SizedBox(height: 20), // Bottom padding
          ],
        ),
      ),
    );
  }

  Widget _buildVerticalEventTypeList() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: categories.keys.map((category) {
        final bool isSelected = widget.selectedType == categories[category];
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 12),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () {
                widget.onTypeSelected(categories[category]!);
              },
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: isSelected ? [
                      Colors.orange.shade400.withOpacity(0.3),
                      Colors.deepOrange.shade600.withOpacity(0.2),
                      const Color(0xFF1A1A1A),
                      const Color(0xFF0A0A0A),
                    ] : [
                      const Color(0xFF3A3A3A),
                      const Color(0xFF2A2A2A),
                      const Color(0xFF1A1A1A),
                      const Color(0xFF0A0A0A),
                    ],
                    stops: const [0.0, 0.3, 0.7, 1.0],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: isSelected 
                        ? Colors.orange.withOpacity(0.5)
                        : Colors.white.withOpacity(0.08),
                    width: isSelected ? 2 : 0.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: isSelected 
                          ? Colors.orange.withOpacity(0.3)
                          : Colors.white.withOpacity(0.03),
                      blurRadius: isSelected ? 8 : 1,
                      offset: Offset(0, isSelected ? 4 : 1),
                    ),
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    // Icon
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.orange.shade400,
                            Colors.deepOrange.shade600,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.orange.withOpacity(0.3),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Icon(
                        categoryIcons[category]!,
                        color: Colors.white,
                        size: 22,
                      ),
                    ),
                    const SizedBox(width: 16),
                    // Text content
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            category,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              letterSpacing: 0.3,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            categorySubtitles[category]!,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                              color: Colors.white.withOpacity(0.7),
                              letterSpacing: 0.1,
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Selection indicator
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        gradient: isSelected 
                            ? LinearGradient(
                                colors: [
                                  Colors.orange.shade400,
                                  Colors.deepOrange.shade600,
                                ],
                              )
                            : null,
                        color: isSelected ? null : Colors.transparent,
                        borderRadius: BorderRadius.circular(14),
                        border: isSelected 
                            ? null 
                            : Border.all(
                                color: Colors.white.withOpacity(0.3),
                                width: 1,
                              ),
                      ),
                      child: Icon(
                        isSelected ? Icons.check_rounded : Icons.chevron_right,
                        color: isSelected 
                            ? Colors.white 
                            : Colors.white.withOpacity(0.6),
                        size: isSelected ? 18 : 22,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
