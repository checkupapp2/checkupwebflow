import 'package:flutter/material.dart';

class CalendarHeader extends StatelessWidget {
  final DateTime currentMonth;
  final bool expanded;
  final VoidCallback onToggle;
  final VoidCallback onPrev;
  final VoidCallback onNext;

  const CalendarHeader({
    super.key,
    required this.currentMonth,
    required this.expanded,
    required this.onToggle,
    required this.onPrev,
    required this.onNext,
  });

  String _monthName(int m) => const [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
      ][m - 1];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
      child: Row(
        children: [
          _navBtn(
              icon: Icons.chevron_left_rounded,
              enabled: expanded,
              onTap: onPrev),
          Expanded(
            child: GestureDetector(
              onTap: onToggle,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                margin: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF3A3A3A).withOpacity(0.6),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: const Color(0xFFFF9800).withOpacity(0.2)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '${_monthName(currentMonth.month)} ${currentMonth.year}',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF9800).withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        expanded
                            ? Icons.expand_less_rounded
                            : Icons.expand_more_rounded,
                        color: const Color(0xFFFF9800),
                        size: 20,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          _navBtn(
              icon: Icons.chevron_right_rounded,
              enabled: expanded,
              onTap: onNext),
        ],
      ),
    );
  }

  Widget _navBtn(
      {required IconData icon,
      required bool enabled,
      required VoidCallback onTap}) {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: enabled ? const Color(0xFF3A3A3A) : const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: enabled
              ? const Color(0xFFFF9800).withOpacity(0.3)
              : Colors.transparent,
        ),
      ),
      child: IconButton(
        padding: EdgeInsets.zero,
        onPressed: enabled ? onTap : null,
        icon: Icon(icon,
            color: enabled ? Colors.white : Colors.grey[500], size: 20),
      ),
    );
  }
}
