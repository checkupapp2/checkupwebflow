import 'package:flutter/material.dart';

class EventsCalendar extends StatelessWidget {
  final DateTime month;
  final bool expanded;
  final DateTime? selectedDate;
  final bool Function(DateTime date) hasEventsOn;
  final ValueChanged<DateTime> onSelect;

  const EventsCalendar({
    super.key,
    required this.month,
    required this.expanded,
    required this.selectedDate,
    required this.hasEventsOn,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final daysInMonth = DateTime(month.year, month.month + 1, 0).day;
    final firstDay = DateTime(month.year, month.month, 1);
    final firstWeekday = firstDay.weekday % 7; // 0 Sunday

    final List<Widget> cells = [];
    for (int i = 0; i < firstWeekday; i++) {
      cells.add(const SizedBox.shrink());
    }

    final daysToShow = expanded ? daysInMonth : (7 - firstWeekday).clamp(0, 7);
    for (int d = 1; d <= daysToShow; d++) {
      final date = DateTime(month.year, month.month, d);
      final isToday = date.year == now.year &&
          date.month == now.month &&
          date.day == now.day;
      final isSelected = selectedDate != null &&
          date.year == selectedDate!.year &&
          date.month == selectedDate!.month &&
          date.day == selectedDate!.day;
      final has = hasEventsOn(date);

      cells.add(
        GestureDetector(
          onTap: () => onSelect(date),
          child: Container(
            margin: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              gradient: isSelected
                  ? const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFFFF9800), Color(0xFFFF6F00)])
                  : isToday
                      ? LinearGradient(colors: [
                          const Color(0xFFFF9800).withOpacity(0.3),
                          const Color(0xFFFF6F00).withOpacity(0.2)
                        ])
                      : null,
              color: !isSelected && !isToday
                  ? const Color(0xFF3A3A3A).withOpacity(0.3)
                  : null,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: has && !isSelected
                    ? const Color(0xFFFF9800).withOpacity(0.4)
                    : Colors.transparent,
                width: 1.5,
              ),
            ),
            alignment: Alignment.center,
            child: Stack(
              children: [
                Center(
                  child: Text(
                    '$d',
                    style: TextStyle(
                      color: isSelected || isToday
                          ? Colors.white
                          : Colors.grey[300],
                      fontSize: 15,
                      fontWeight: isSelected || isToday
                          ? FontWeight.w700
                          : FontWeight.w500,
                    ),
                  ),
                ),
                if (has && !isSelected)
                  const Positioned(
                    bottom: 4,
                    right: 4,
                    child: SizedBox(
                      width: 6,
                      height: 6,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                            color: Color(0xFFFF9800), shape: BoxShape.circle),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 24, 16, 20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF2C2C2C), Color(0xFF1F1F1F), Color(0xFF0A0A0A)]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFFF9800).withOpacity(0.1)),
      ),
      child: Column(
        children: [
          // Day labels
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: const ['S', 'M', 'T', 'W', 'T', 'F', 'S']
                  .map((d) => SizedBox(
                        width: 36,
                        height: 36,
                        child: Center(
                          child: Text(
                            d,
                            style: TextStyle(
                                color: Color(0xFFFF9800),
                                fontSize: 13,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ))
                  .toList(),
            ),
          ),
          // Grid
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
            child: GridView.count(
              crossAxisCount: 7,
              childAspectRatio: 1,
              mainAxisSpacing: 4,
              crossAxisSpacing: 4,
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              children: cells,
            ),
          ),
        ],
      ),
    );
  }
}
