import 'package:flutter/material.dart';
import '../../../domain/models/event_model.dart';
import '../../pages/host_event_detail_page.dart';
import '../../pages/event_detail_page.dart';
import '../../pages/manage_event_page.dart';
import '../../pages/edit_event_page.dart';
import '../event_card.dart';
import '../../../../tickets/domain/models/ticket_model.dart';
import '../../../../tickets/presentation/pages/ticket_detail_page.dart';

/// Event list with same UI; exposes optional callbacks to let parent control navigation.
/// If a callback is not provided, it falls back to the original in-widget navigation.
class EventList extends StatelessWidget {
  final List<EventModel> events;
  final bool isHosting;

  final void Function(EventModel ev)? onOpen;
  final void Function(EventModel ev)? onEdit;
  final void Function(EventModel ev)? onManage;
  final void Function(EventModel ev)? onViewTickets;

  const EventList({
    super.key,
    required this.events,
    required this.isHosting,
    this.onOpen,
    this.onEdit,
    this.onManage,
    this.onViewTickets,
  });

  @override
  Widget build(BuildContext context) {
    if (events.isEmpty) return const SizedBox.shrink();

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: events.length,
      itemBuilder: (context, i) {
        final ev = events[i];
        return EventCard(
          event: ev,
          isAttending: !isHosting,
          onTap: () {
            if (onOpen != null) return onOpen!(ev);
            // default navigation (kept to match previous UX)
            if (isHosting) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      HostEventDetailPage(eventId: ev.id!, title: ev.title),
                ),
              );
            } else {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => EventDetailPage(
                    eventId: ev.id!,
                    title: ev.title,
                    eventType: ev.category,
                  ),
                ),
              );
            }
          },
          onEdit: isHosting
              ? () {
                  if (onEdit != null) return onEdit!(ev);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => EditEventPage(event: ev)),
                  );
                }
              : null,
          onViewTickets: isHosting
              ? () {
                  if (onManage != null) return onManage!(ev);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          ManageEventPage(eventId: ev.id!, title: ev.title),
                    ),
                  );
                }
              : () {
                  if (onViewTickets != null) return onViewTickets!(ev);
                  // final t =
                  //     TicketModel.getSampleTickets(ev.id ?? 'unknown', ev.title)
                  //         .first;
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(
                  //       builder: (_) => TicketDetailPage(ticket: t)),
                  // );
                },
        );
      },
    );
  }
}
