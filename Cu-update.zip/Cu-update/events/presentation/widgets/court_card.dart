import 'package:flutter/material.dart';
import '../../domain/models/court_model.dart';

/// A card widget to display court information with a square thumbnail and details
class CourtCard extends StatelessWidget {
  /// The court data to display
  final CourtModel court;
  
  /// Callback when the court card is tapped
  final VoidCallback? onTap;
  
  /// Constructor
  const CourtCard({
    super.key,
    required this.court,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Court Thumbnail
              _buildCourtThumbnail(),
              const SizedBox(width: 16),
              
              // Court Info
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildCourtName(),
                    const SizedBox(height: 4),
                    _buildCourtAddress(),
                    const SizedBox(height: 4),
                    _buildCourtDetails(),
                    const SizedBox(height: 4),
                    _buildCourtRating(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCourtThumbnail() {
    return Hero(
      tag: 'court_${court.id}',
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.grey[800],
        ),
        clipBehavior: Clip.antiAlias,
        child: court.imageUrl != null
            ? Image.asset(
                court.imageUrl!,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return _buildFallbackImage();
                },
              )
            : _buildFallbackImage(),
      ),
    );
  }

  Widget _buildFallbackImage() {
    return Container(
      color: Colors.grey[800],
      child: const Center(
        child: Icon(
          Icons.sports_basketball,
          size: 40,
          color: Colors.orange,
        ),
      ),
    );
  }

  Widget _buildCourtName() {
    return Text(
      court.name,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 16,
        fontWeight: FontWeight.bold,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildCourtAddress() {
    return Row(
      children: [
        Icon(
          Icons.location_on,
          size: 14,
          color: Colors.grey[400],
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            court.fullAddress,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 12,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildCourtDetails() {
    return Row(
      children: [
        // Indoor/Outdoor indicator
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: court.isIndoor ? Colors.blue.withOpacity(0.2) : Colors.green.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            court.isIndoor ? 'Indoor' : 'Outdoor',
            style: TextStyle(
              color: court.isIndoor ? Colors.blue[300] : Colors.green[300],
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        const SizedBox(width: 8),
        
        // Hoop count
        Row(
          children: [
            Icon(
              Icons.sports_basketball,
              size: 12,
              color: Colors.orange[300],
            ),
            const SizedBox(width: 2),
            Text(
              '${court.hoopCount} hoops',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 10,
              ),
            ),
          ],
        ),
        const SizedBox(width: 8),
        
        // Lights indicator
        if (court.hasLights)
          Row(
            children: [
              Icon(
                Icons.lightbulb,
                size: 12,
                color: Colors.amber[300],
              ),
              const SizedBox(width: 2),
              Text(
                'Lights',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 10,
                ),
              ),
            ],
          ),
      ],
    );
  }

  Widget _buildCourtRating() {
    return Row(
      children: [
        ...List.generate(5, (index) {
          return Icon(
            index < court.rating.floor() 
                ? Icons.star 
                : (index < court.rating ? Icons.star_half : Icons.star_border),
            size: 16,
            color: Colors.amber,
          );
        }),
        const SizedBox(width: 4),
        Text(
          court.rating.toString(),
          style: TextStyle(
            color: Colors.grey[300],
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
