import 'package:flutter/material.dart';

enum TournamentFormat {
  singleElimination,
  doubleElimination,
  roundRobin,
  poolToBracket,
}

class TournamentFormatData {
  final TournamentFormat format;
  final String title;
  final String description;
  final String detailedDescription;
  final IconData icon;
  final List<String> features;
  final int minTeams;
  final int maxTeams;

  const TournamentFormatData({
    required this.format,
    required this.title,
    required this.description,
    required this.detailedDescription,
    required this.icon,
    required this.features,
    required this.minTeams,
    required this.maxTeams,
  });
}

class TournamentFormatSelector extends StatefulWidget {
  final TournamentFormat? selectedFormat;
  final Function(TournamentFormat) onFormatSelected;

  const TournamentFormatSelector({
    Key? key,
    this.selectedFormat,
    required this.onFormatSelected,
  }) : super(key: key);

  @override
  State<TournamentFormatSelector> createState() => _TournamentFormatSelectorState();
}

class _TournamentFormatSelectorState extends State<TournamentFormatSelector> {
  static const List<TournamentFormatData> formats = [
    TournamentFormatData(
      format: TournamentFormat.singleElimination,
      title: 'Single Elimination',
      description: 'Classic knockout tournament - lose once, you\'re out',
      detailedDescription: 'Teams compete in head-to-head matches. One loss eliminates a team from the tournament. Fast-paced and exciting with clear winners.',
      icon: Icons.trending_up,
      features: ['Quick tournament', 'High stakes', 'Clear bracket path'],
      minTeams: 4,
      maxTeams: 64,
    ),
    TournamentFormatData(
      format: TournamentFormat.doubleElimination,
      title: 'Double Elimination',
      description: 'Second chances - teams need two losses to be eliminated',
      detailedDescription: 'Teams get a second chance with winner\'s and loser\'s brackets. More games and fairer results for all participants.',
      icon: Icons.refresh,
      features: ['Second chances', 'More games', 'Fairer results'],
      minTeams: 4,
      maxTeams: 32,
    ),
    TournamentFormatData(
      format: TournamentFormat.roundRobin,
      title: 'Round Robin',
      description: 'Everyone plays everyone - most wins takes the crown',
      detailedDescription: 'Every team plays every other team once. Winner determined by overall record. Great for smaller tournaments.',
      icon: Icons.loop,
      features: ['Everyone plays all', 'Most fair format', 'Best for small groups'],
      minTeams: 3,
      maxTeams: 12,
    ),
    TournamentFormatData(
      format: TournamentFormat.poolToBracket,
      title: 'Pool → Bracket',
      description: 'Group stage followed by knockout playoffs',
      detailedDescription: 'Teams are divided into pools for round-robin play, then top teams advance to single-elimination playoffs.',
      icon: Icons.account_tree,
      features: ['Group stage + playoffs', 'Balanced competition', 'Professional format'],
      minTeams: 8,
      maxTeams: 32,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF3A3A3A),
                const Color(0xFF2A2A2A),
                const Color(0xFF1A1A1A),
                const Color(0xFF0A0A0A),
              ],
              stops: const [0.0, 0.3, 0.7, 1.0],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 0.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.03),
                blurRadius: 1,
                offset: const Offset(0, 1),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.orange.shade400,
                      Colors.deepOrange.shade600,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.orange.withOpacity(0.3),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.emoji_events,
                  color: Colors.white,
                  size: 22,
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Choose Tournament Format',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Select the competition style that fits your event',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 24),
        
        // Format Cards
        ...formats.map((format) => _buildFormatCard(format)).toList(),
      ],
    );
  }

  Widget _buildFormatCard(TournamentFormatData format) {
    final isSelected = widget.selectedFormat == format.format;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => widget.onFormatSelected(format.format),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isSelected
                    ? [
                        Colors.orange.shade400.withOpacity(0.2),
                        Colors.deepOrange.shade600.withOpacity(0.1),
                        const Color(0xFF2A2A2A),
                        const Color(0xFF1A1A1A),
                      ]
                    : [
                        const Color(0xFF3A3A3A),
                        const Color(0xFF2A2A2A),
                        const Color(0xFF1A1A1A),
                        const Color(0xFF0A0A0A),
                      ],
                stops: const [0.0, 0.3, 0.7, 1.0],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: isSelected
                    ? Colors.orange.shade400.withOpacity(0.5)
                    : Colors.white.withOpacity(0.08),
                width: isSelected ? 2 : 0.5,
              ),
              boxShadow: [
                if (isSelected)
                  BoxShadow(
                    color: Colors.orange.withOpacity(0.2),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.03),
                  blurRadius: 1,
                  offset: const Offset(0, 1),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: isSelected
                              ? [
                                  Colors.orange.shade400,
                                  Colors.deepOrange.shade600,
                                ]
                              : [
                                  Colors.grey.shade600,
                                  Colors.grey.shade700,
                                ],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: (isSelected ? Colors.orange : Colors.grey)
                                .withOpacity(0.3),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Icon(
                        format.icon,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            format.title,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.3,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            format.description,
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (isSelected)
                      Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: Colors.orange.shade400,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check,
                          color: Colors.white,
                          size: 16,
                        ),
                      ),
                  ],
                ),
                
                const SizedBox(height: 16),
                
                // Features
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: format.features.map((feature) {
                    return Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? Colors.orange.shade400.withOpacity(0.2)
                            : Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isSelected
                              ? Colors.orange.shade400.withOpacity(0.3)
                              : Colors.white.withOpacity(0.1),
                          width: 0.5,
                        ),
                      ),
                      child: Text(
                        feature,
                        style: TextStyle(
                          color: isSelected ? Colors.orange.shade200 : Colors.white70,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    );
                  }).toList(),
                ),
                
                const SizedBox(height: 12),
                
                // Team count info
                Text(
                  '${format.minTeams}-${format.maxTeams} teams',
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
