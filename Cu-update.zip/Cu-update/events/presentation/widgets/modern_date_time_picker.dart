import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:intl/intl.dart';

/// A modern, mobile-friendly date and time picker widget
class ModernDateTimePicker extends StatefulWidget {
  /// The currently selected date and time
  final DateTime? selectedDateTime;
  
  /// Callback when date and time are selected
  final Function(DateTime) onDateTimeSelected;

  /// Creates a [ModernDateTimePicker] widget
  const ModernDateTimePicker({
    Key? key,
    this.selectedDateTime,
    required this.onDateTimeSelected,
  }) : super(key: key);

  @override
  State<ModernDateTimePicker> createState() => _ModernDateTimePickerState();
}

class _ModernDateTimePickerState extends State<ModernDateTimePicker> {
  late DateTime _selectedDate;
  late TimeOfDay _selectedTime;
  bool _isDatePickerVisible = false;
  bool _isTimePickerVisible = false;

  @override
  void initState() {
    super.initState();
    _selectedDate = widget.selectedDateTime ?? DateTime.now();
    _selectedTime = widget.selectedDateTime != null 
        ? TimeOfDay.fromDateTime(widget.selectedDateTime!) 
        : TimeOfDay.now();
  }

  void _updateDateTime() {
    final dateTime = DateTime(
      _selectedDate.year,
      _selectedDate.month,
      _selectedDate.day,
      _selectedTime.hour,
      _selectedTime.minute,
    );
    widget.onDateTimeSelected(dateTime);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(
        minHeight: 300, // Ensure minimum height for web
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 16),
          
          // Enhanced Date and time selection cards
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.03),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.1),
                width: 1,
              ),
            ),
            child: Row(
              children: [
              // Date selection card
              Expanded(
                child: _buildSelectionCard(
                  icon: Icons.calendar_month,
                  label: 'Date',
                  value: DateFormat('EEE, MMM d, yyyy').format(_selectedDate),
                  onTap: () {
                    setState(() {
                      _isDatePickerVisible = true;
                      _isTimePickerVisible = false;
                    });
                  },
                  isSelected: _isDatePickerVisible,
                ),
              ),
              const SizedBox(width: 8),
              // Time selection card
              Expanded(
                child: _buildSelectionCard(
                  icon: Icons.access_time,
                  label: 'Time',
                  value: _selectedTime.format(context),
                  onTap: () {
                    setState(() {
                      _isTimePickerVisible = true;
                      _isDatePickerVisible = false;
                    });
                  },
                  isSelected: _isTimePickerVisible,
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        
          // Date picker
          if (_isDatePickerVisible) ...[
            const SizedBox(height: 16),
            _buildDatePicker(),
          ],
          
          // Time picker
          if (_isTimePickerVisible) ...[
            const SizedBox(height: 16),
            _buildTimePicker(),
          ],
        ],
      ),
    );
  }

  Widget _buildSelectionCard({
    required IconData icon,
    required String label,
    required String value,
    required VoidCallback onTap,
    required bool isSelected,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(
          minHeight: 80, // Ensure minimum height for web
        ),
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        decoration: BoxDecoration(
          gradient: isSelected 
            ? LinearGradient(
                colors: [
                  AppColors.primaryOrange.withOpacity(0.15),
                  AppColors.primaryOrange.withOpacity(0.05),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
          color: isSelected ? null : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppColors.primaryOrange : Colors.white.withOpacity(0.1),
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected ? [
            BoxShadow(
              color: AppColors.primaryOrange.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ] : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: isSelected 
                      ? AppColors.primaryOrange.withOpacity(0.2)
                      : Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    icon,
                    color: isSelected ? AppColors.primaryOrange : Colors.white70,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: TextStyle(
                    color: isSelected ? AppColors.primaryOrange : Colors.white70,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              value,
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.3,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDatePicker() {
    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(
        minHeight: 300, // Ensure minimum height for web
      ),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.secondaryBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.darkGray),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Month and year selector
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                DateFormat('MMMM yyyy').format(_selectedDate),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Row(
                children: [
                  _buildIconButton(
                    icon: Icons.chevron_left,
                    onTap: () {
                      setState(() {
                        _selectedDate = DateTime(
                          _selectedDate.year,
                          _selectedDate.month - 1,
                          _selectedDate.day,
                        );
                      });
                    },
                  ),
                  const SizedBox(width: 8),
                  _buildIconButton(
                    icon: Icons.chevron_right,
                    onTap: () {
                      setState(() {
                        _selectedDate = DateTime(
                          _selectedDate.year,
                          _selectedDate.month + 1,
                          _selectedDate.day,
                        );
                      });
                    },
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Calendar grid
          _buildCalendarGrid(),
          
          const SizedBox(height: 16),
          
          // Done button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  _isDatePickerVisible = false;
                  _updateDateTime();
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.orangeGradientEnd,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text('Done'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCalendarGrid() {
    // Get the first day of the month
    final firstDayOfMonth = DateTime(_selectedDate.year, _selectedDate.month, 1);
    
    // Get the day of week for the first day (0 = Sunday, 1 = Monday, etc.)
    final firstDayWeekday = firstDayOfMonth.weekday;
    
    // Adjust to make Monday the first day of the week (0 = Monday, 6 = Sunday)
    final adjustedFirstDay = (firstDayWeekday - 1) % 7;
    
    // Get the number of days in the month
    final daysInMonth = DateTime(_selectedDate.year, _selectedDate.month + 1, 0).day;
    
    // Create the day labels for the week
    final dayLabels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    
    return Column(
      children: [
        // Day of week headers
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: dayLabels.map((day) => 
            SizedBox(
              width: 30,
              child: Text(
                day,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 12,
                ),
              ),
            )
          ).toList(),
        ),
        const SizedBox(height: 8),
        
        // Calendar days
        LayoutBuilder(
          builder: (context, constraints) {
            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7,
                childAspectRatio: 1,
                mainAxisSpacing: 4,
                crossAxisSpacing: 4,
              ),
              itemCount: adjustedFirstDay + daysInMonth,
              itemBuilder: (context, index) {
            if (index < adjustedFirstDay) {
              return const SizedBox(); // Empty space for days before the month starts
            }
            
            final day = index - adjustedFirstDay + 1;
            final date = DateTime(_selectedDate.year, _selectedDate.month, day);
            final isSelected = day == _selectedDate.day;
            final isToday = _isSameDay(date, DateTime.now());
            
            return GestureDetector(
              onTap: () {
                setState(() {
                  _selectedDate = DateTime(
                    _selectedDate.year,
                    _selectedDate.month,
                    day,
                  );
                });
              },
              child: Container(
                constraints: const BoxConstraints(
                  minWidth: 32,
                  minHeight: 32,
                ),
                margin: const EdgeInsets.all(1),
                decoration: BoxDecoration(
                  gradient: isSelected ? AppColors.orangeGradient : null,
                  color: isToday && !isSelected ? AppColors.darkGray : null,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    day.toString(),
                    style: TextStyle(
                      color: isSelected ? Colors.white : (isToday ? Colors.white : Colors.grey[300]),
                      fontWeight: isSelected || isToday ? FontWeight.bold : FontWeight.normal,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            );
            },
            );
          },
        ),
      ],
    );
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  Widget _buildTimePicker() {
    // Create time slots in 30-minute increments
    final timeSlots = <TimeOfDay>[];
    for (int hour = 0; hour < 24; hour++) {
      timeSlots.add(TimeOfDay(hour: hour, minute: 0));
      timeSlots.add(TimeOfDay(hour: hour, minute: 30));
    }
    
    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(
        minHeight: 300, // Ensure minimum height for web
      ),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.secondaryBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.darkGray),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Select Time',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          // Time slots grid
          LayoutBuilder(
            builder: (context, constraints) {
              return SizedBox(
                height: 200,
                child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: constraints.maxWidth > 600 ? 6 : 4, // More columns on wider screens
                    childAspectRatio: 2.5,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: timeSlots.length,
                  itemBuilder: (context, index) {
                final time = timeSlots[index];
                final isSelected = time.hour == _selectedTime.hour && 
                                  time.minute == _selectedTime.minute;
                
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedTime = time;
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: isSelected ? AppColors.orangeGradient : null,
                      color: isSelected ? null : AppColors.darkGray,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Text(
                        _formatTimeOfDay(time),
                        style: TextStyle(
                          color: isSelected ? Colors.white : Colors.grey[300],
                          fontSize: 12,
                          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ),
                  ),
                );
              },
                ),
              );
            },
          ),
          
          const SizedBox(height: 16),
          
          // Done button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  _isTimePickerVisible = false;
                  _updateDateTime();
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.orangeGradientEnd,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text('Done'),
            ),
          ),
        ],
      ),
    );
  }

  String _formatTimeOfDay(TimeOfDay time) {
    final hour = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
    final minute = time.minute.toString().padLeft(2, '0');
    final period = time.period == DayPeriod.am ? 'AM' : 'PM';
    return '$hour:$minute $period';
  }

  Widget _buildIconButton({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppColors.darkGray,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(
          icon,
          color: Colors.white,
          size: 16,
        ),
      ),
    );
  }

}
