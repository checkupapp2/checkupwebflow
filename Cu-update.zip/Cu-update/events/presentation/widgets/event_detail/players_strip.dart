import 'package:flutter/material.dart';

class PlayersStrip extends StatelessWidget {
  final int registeredCount;
  final List<(String name, String distance, bool isOnline)> players;
  final void Function(String name) onPlayerTap;

  const PlayersStrip({
    super.key,
    required this.registeredCount,
    required this.players,
    required this.onPlayerTap,
  });

  Widget _avatar(
      BuildContext context, String name, String distance, bool online) {
    return GestureDetector(
      onTap: () => onPlayerTap(name),
      child: Container(
        width: 80,
        margin: const EdgeInsets.only(right: 16),
        child: Column(
          children: [
            Stack(
              alignment: Alignment.bottomRight,
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.orange, width: 2),
                    color: Colors.orange[300],
                  ),
                  child: const Center(
                    child: Icon(Icons.sentiment_very_satisfied,
                        color: Colors.black, size: 40),
                  ),
                ),
                if (online)
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: Colors.green,
                      shape: BoxShape.circle,
                      border: Border.all(color: Color(0xFF1A1A1A), width: 2),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(name,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 12)),
            Text(distance,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[500], fontSize: 10)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFF9800), width: 1),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              child: const Icon(Icons.people_alt_outlined,
                  color: Colors.white, size: 16),
            ),
            const SizedBox(width: 12),
            const Text(
              'Event Activity',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Montserrat',
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Text('$registeredCount registered',
                style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 14,
                    fontFamily: 'Montserrat')),
            const SizedBox(width: 8),
            // Container(
            //     width: 4,
            //     height: 4,
            //     decoration: BoxDecoration(
            //         color: Colors.grey[600], shape: BoxShape.circle)),
            // const SizedBox(width: 8),
            // Text('8 spots left',
            //     style: TextStyle(
            //         color: Colors.grey[400],
            //         fontSize: 14,
            //         fontFamily: 'Montserrat')),
            // const Spacer(),
            // Container(
            //   padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            //   decoration: const BoxDecoration(
            //     gradient: LinearGradient(
            //       colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            //       begin: Alignment.centerLeft,
            //       end: Alignment.centerRight,
            //     ),
            //     borderRadius: BorderRadius.all(Radius.circular(16)),
            //   ),
            //   child: const Text('Join',
            //       style: TextStyle(
            //           color: Colors.white,
            //           fontWeight: FontWeight.w600,
            //           fontSize: 12,
            //           fontFamily: 'Montserrat')),
            // ),
          ],
        ),
        const SizedBox(height: 16),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: EdgeInsets.zero,
          child: Row(
            children: [
              for (final p in players) ...[
                _avatar(context, p.$1, p.$2, p.$3),
                const SizedBox(width: 12),
              ],
              const SizedBox(width: 4),
            ],
          ),
        ),
      ]),
    );
  }
}
