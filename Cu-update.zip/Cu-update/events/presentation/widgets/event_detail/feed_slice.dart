import 'package:flutter/material.dart';

class FeedSlice extends StatelessWidget {
  final Widget createPost;
  final List<Widget> posts;

  const FeedSlice({
    super.key,
    required this.createPost,
    required this.posts,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Header row
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Feed',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
              TextButton(
                onPressed: () {},
                child: Text('See All',
                    style: TextStyle(color: Colors.orange[400])),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // Create post
        createPost,
        const SizedBox(height: 16),

        // Posts
        ...posts.map((w) => Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: w,
            )),
      ],
    );
  }
}
