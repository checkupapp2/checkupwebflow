import 'package:flutter/material.dart';
import 'package:check_up_app/features/search/presentation/widgets/espn_score_card.dart';

class TournamentBracketPreview extends StatelessWidget {
  final VoidCallback onTap;
  const TournamentBracketPreview({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final matches = [
      {
        'team1': 'Lakers',
        'team2': 'Warriors',
        'score1': 92,
        'score2': 85,
        'isComplete': true,
        'winner': 'Lakers'
      },
      {
        'team1': 'Celtics',
        'team2': 'Heat',
        'score1': 78,
        'score2': 82,
        'isComplete': true,
        'winner': 'Heat'
      },
      {
        'team1': 'Nets',
        'team2': 'Knicks',
        'score1': null,
        'score2': null,
        'isComplete': false,
        'winner': null
      },
      {
        'team1': 'Bulls',
        'team2': 'Bucks',
        'score1': null,
        'score2': null,
        'isComplete': false,
        'winner': null
      },
    ];

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF3A3A3A),
              Color(0xFF2A2A2A),
              Color(0xFF1A1A1A),
              Color(0xFF0A0A0A)
            ],
            stops: [0.0, 0.3, 0.7, 1.0],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
          boxShadow: [
            BoxShadow(
                color: Colors.white.withOpacity(0.03),
                blurRadius: 1,
                offset: const Offset(0, 1)),
            BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 12,
                offset: const Offset(0, 4)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      Colors.orange.shade400,
                      Colors.deepOrange.shade600
                    ]),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.orange.withOpacity(0.3),
                          blurRadius: 6,
                          offset: const Offset(0, 2))
                    ],
                  ),
                  child: const Icon(Icons.account_tree,
                      color: Colors.white, size: 22),
                ),
                const SizedBox(width: 16),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Tournament Bracket',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Montserrat')),
                      SizedBox(height: 4),
                      Text('8 teams • Single Elimination',
                          style: TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                              fontFamily: 'Montserrat')),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)]),
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                  ),
                  child: const Text('Quarterfinals',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.2,
                          fontFamily: 'Montserrat')),
                ),
              ],
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 100,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: 4,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, i) {
                  final m = matches[i];
                  final winner = m['winner'] as String?;
                  final isComplete = m['isComplete'] as bool;

                  Color fg(bool win) =>
                      win ? Colors.orange.shade200 : Colors.white;
                  BoxDecoration tile(bool win) => BoxDecoration(
                        gradient: LinearGradient(
                          colors: win
                              ? [
                                  Colors.orange.shade400,
                                  Colors.deepOrange.shade600
                                ]
                              : [
                                  const Color(0xFF3A3A3A),
                                  const Color(0xFF2A2A2A)
                                ],
                        ),
                        borderRadius: BorderRadius.circular(4),
                      );

                  return Container(
                    width: 160,
                    height: 100,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                          colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)]),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isComplete
                            ? Colors.orange.shade400.withOpacity(0.3)
                            : Colors.white.withOpacity(0.08),
                        width: 0.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 4))
                      ],
                    ),
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // team 1
                        Row(
                          children: [
                            Container(
                                width: 20,
                                height: 20,
                                decoration: tile(winner == m['team1']),
                                child: const Icon(Icons.group,
                                    size: 10, color: Colors.white)),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                '${m['team1']}',
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: fg(winner == m['team1']),
                                  fontSize: 11,
                                  fontWeight: winner == m['team1']
                                      ? FontWeight.w700
                                      : FontWeight.w500,
                                  fontFamily: 'Montserrat',
                                ),
                              ),
                            ),
                            if (m['score1'] != null)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 4, vertical: 1),
                                decoration: BoxDecoration(
                                  color: winner == m['team1']
                                      ? Colors.orange.shade400.withOpacity(0.2)
                                      : Colors.white.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                                child: Text(
                                  '${m['score1']}',
                                  style: TextStyle(
                                    color: fg(winner == m['team1']),
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'Montserrat',
                                  ),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Container(
                            height: 0.5, color: Colors.white.withOpacity(0.1)),
                        const SizedBox(height: 4),
                        // team 2
                        Row(
                          children: [
                            Container(
                                width: 20,
                                height: 20,
                                decoration: tile(winner == m['team2']),
                                child: const Icon(Icons.group,
                                    size: 10, color: Colors.white)),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                '${m['team2']}',
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: fg(winner == m['team2']),
                                  fontSize: 11,
                                  fontWeight: winner == m['team2']
                                      ? FontWeight.w700
                                      : FontWeight.w500,
                                  fontFamily: 'Montserrat',
                                ),
                              ),
                            ),
                            if (m['score2'] != null)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 4, vertical: 1),
                                decoration: BoxDecoration(
                                  color: winner == m['team2']
                                      ? Colors.orange.shade400.withOpacity(0.2)
                                      : Colors.white.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                                child: Text(
                                  '${m['score2']}',
                                  style: TextStyle(
                                    color: fg(winner == m['team2']),
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'Montserrat',
                                  ),
                                ),
                              ),
                          ],
                        ),
                        if (!isComplete) ...[
                          const SizedBox(height: 4),
                          Text('Upcoming',
                              style: TextStyle(
                                  color: Colors.orange.shade400,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: 'Montserrat')),
                        ]
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LeagueStrip extends StatelessWidget {
  const LeagueStrip({super.key});

  @override
  Widget build(BuildContext context) {
    final scores = [
      {'team1': 'Lakers', 'team2': 'Warriors', 'score1': 108, 'score2': 112},
      {'team1': 'Celtics', 'team2': 'Heat', 'score1': 95, 'score2': 88},
      {'team1': 'Nets', 'team2': 'Knicks', 'score1': 102, 'score2': 99},
      {'team1': 'Bulls', 'team2': 'Bucks', 'score1': 87, 'score2': 94},
    ];

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // header
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                _GradientIconWrapper(icon: Icons.sports_basketball),
                SizedBox(width: 12),
                Text('League Games',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    )),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 220,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: scores.length,
              itemBuilder: (_, i) {
                final s = scores[i];
                return Container(
                  width: 280,
                  margin:
                      EdgeInsets.only(right: i < scores.length - 1 ? 16 : 0),
                  child: EspnScoreCard(
                    homeTeamName: s['team1'] as String,
                    awayTeamName: s['team2'] as String,
                    homeScore: s['score1'] as int,
                    awayScore: s['score2'] as int,
                    gameStatus: 'Final',
                    gameDateTime: DateTime.now(),
                    courtName: 'Rucker Park',
                    courtLocation: 'Harlem, NY',
                    hostName: 'Event Host',
                    leagueName: 'Basketball League',
                    homeTeamLogoUrl: null,
                    awayTeamLogoUrl: null,
                    onViewFullScore: () {},
                    onShare: () {},
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _GradientIconWrapper extends StatelessWidget {
  final IconData icon;
  const _GradientIconWrapper({required this.icon});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: [Colors.orange[400]!, Colors.deepOrange[700]!]),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(icon, color: Colors.white, size: 20),
    );
  }
}
