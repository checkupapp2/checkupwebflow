import 'package:flutter/material.dart';

class CollapsibleDetailsCard extends StatelessWidget {
  final bool expanded;
  final String previewText;
  final String detailsText;
  final VoidCallback onToggle;

  const CollapsibleDetailsCard({
    super.key,
    required this.expanded,
    required this.previewText,
    required this.detailsText,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    // If details is empty, fall back to preview
    final String fullText =
        (detailsText.trim().isNotEmpty ? detailsText : previewText).trim();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFF9800), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          InkWell(
            onTap: onToggle,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(8)),
                    ),
                    child: const Icon(Icons.description_outlined,
                        color: Colors.white, size: 16),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'Event Details',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Montserrat',
                    ),
                  ),
                ]),
                Icon(
                  expanded
                      ? Icons.keyboard_arrow_up
                      : Icons.keyboard_arrow_down,
                  color: Colors.orange,
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // Show preview ONLY when collapsed; show full ONLY when expanded
          AnimatedCrossFade(
            firstChild: Text(
              previewText,
              key: const ValueKey('preview'),
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 14,
                height: 1.4,
                fontFamily: 'Montserrat',
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              softWrap: true,
            ),
            secondChild: Text(
              fullText,
              key: const ValueKey('details'),
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 14,
                height: 1.4,
                fontFamily: 'Montserrat',
              ),
              softWrap: true,
            ),
            crossFadeState:
                expanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 250),
            sizeCurve: Curves.easeInOut,
          ),

          const SizedBox(height: 8),
          Text(
            expanded ? 'Tap to see less...' : 'Tap to see more details...',
            style: const TextStyle(
              color: Colors.orange,
              fontSize: 12,
              fontStyle: FontStyle.italic,
              fontFamily: 'Montserrat',
            ),
          ),
        ],
      ),
    );
  }
}
