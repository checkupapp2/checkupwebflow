import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../domain/models/event_model.dart';
import '../../domain/models/event_type.dart';

/// A card widget to display event information with a square thumbnail and details
class EventCard extends StatelessWidget {
  /// The event data to display
  final EventModel event;
  
  /// Callback when the event card is tapped
  final VoidCallback onTap;
  
  /// Callback when the edit button is tapped
  final VoidCallback? onEdit;
  
  /// Callback when the view tickets button is tapped
  final VoidCallback? onViewTickets;
  
  /// Callback when the share button is tapped
  final VoidCallback? onShare;
  
  /// Whether the user is attending this event (vs hosting)
  final bool isAttending;

  const EventCard({
    Key? key,
    required this.event,
    required this.onTap,
    this.onEdit,
    this.onViewTickets,
    this.onShare,
    this.isAttending = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Event Thumbnail
                  _buildEventThumbnail(),
                  const SizedBox(width: 16),
                  
                  // Event Info
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildEventTitle(),
                        const SizedBox(height: 4),
                        _buildEventDateTime(),
                        const SizedBox(height: 4),
                        _buildEventLocation(),
                        const SizedBox(height: 4),
                        _buildEventCategory(),
                      ],
                    ),
                  ),
                  
                  // Status Indicator (only for hosting events)
                  if (!isAttending) _buildStatusIndicator(),
                ],
              ),
            ),
            
            // Action buttons row
            Padding(
              padding: const EdgeInsets.only(top: 8.0, left: 8.0, right: 8.0, bottom: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: isAttending ? [
                  // Registration status indicator for Attending tab
                  _buildRegistrationStatusButton(),
                  _buildActionButton(
                    icon: Icons.confirmation_number,
                    label: 'My Tickets',
                    onPressed: onViewTickets ?? () {
                      // Default action if no callback provided
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('My tickets for ${event.title}')),
                      );
                    },
                  ),
                  _buildActionButton(
                    icon: Icons.share,
                    label: 'Share',
                    onPressed: onShare ?? () {
                      // Default action if no callback provided
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Sharing ${event.title}')),
                      );
                    },
                    statusColor: Colors.orange[700],
                  ),
                ] : [
                  // Buttons for Hosting tab
                  _buildActionButton(
                    icon: Icons.edit,
                    label: 'Edit',
                    onPressed: onEdit ?? () {
                      // Default action if no callback provided
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Edit ${event.title}')),
                      );
                    },
                  ),
                  _buildActionButton(
                    icon: Icons.confirmation_number,
                    label: 'Tickets',
                    onPressed: onViewTickets ?? () {
                      // Default action if no callback provided
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('View tickets for ${event.title}')),
                      );
                    },
                  ),
                  _buildActionButton(
                    icon: Icons.share,
                    label: 'Share',
                    onPressed: onShare ?? () {
                      // Default action if no callback provided
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Sharing ${event.title}')),
                      );
                    },
                    statusColor: Colors.orange[700],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    Color? statusColor,
  }) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        child: ElevatedButton.icon(
          onPressed: onPressed,
          icon: Icon(icon, size: 16),
          label: Text(label, style: const TextStyle(fontSize: 11)),
          style: ElevatedButton.styleFrom(
            backgroundColor: statusColor ?? Colors.grey[800],
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 8),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEventThumbnail() {
    return Hero(
      tag: 'event_${event.id}',
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.grey[800],
        ),
        clipBehavior: Clip.antiAlias,
        child: event.bannerImageUrl != null
            ? Image.network(
                event.bannerImageUrl!,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return _buildFallbackImage();
                },
              )
            : _buildFallbackImage(),
      ),
    );
  }

  Widget _buildFallbackImage() {
    IconData iconData;
    Color iconColor;
    
    switch (event.eventType) {
      case EventType.pickupRun:
        iconData = Icons.sports_basketball;
        iconColor = Colors.orange;
        break;
      case EventType.tournament:
        iconData = Icons.emoji_events;
        iconColor = Colors.amber;
        break;
      case EventType.donationBased:
        iconData = Icons.volunteer_activism;
        iconColor = Colors.red;
        break;
      case EventType.oneOff:
        iconData = Icons.event;
        iconColor = Colors.purple;
        break;
      case EventType.camp:
        iconData = Icons.landscape;
        iconColor = Colors.green;
        break;
      case EventType.training:
        iconData = Icons.fitness_center;
        iconColor = Colors.purple;
        break;
      default:
        iconData = Icons.event;
        iconColor = Colors.blue;
    }
    
    return Container(
      color: Colors.grey[800],
      child: Center(
        child: Icon(
          iconData,
          size: 40,
          color: iconColor,
        ),
      ),
    );
  }

  Widget _buildEventTitle() {
    return Text(
      event.title,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 16,
        fontWeight: FontWeight.bold,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildEventDateTime() {
    final formattedDate = DateFormat('E, MMM d • h:mm a').format(event.dateTime);
    return Row(
      children: [
        Icon(
          Icons.access_time,
          size: 14,
          color: Colors.grey[400],
        ),
        const SizedBox(width: 4),
        Text(
          formattedDate,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildEventLocation() {
    return Row(
      children: [
        Icon(
          Icons.location_on,
          size: 14,
          color: Colors.grey[400],
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            event.location,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 12,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildEventCategory() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: _getCategoryColor().withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        event.category,
        style: TextStyle(
          color: _getCategoryColor(),
          fontSize: 11,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Color _getCategoryColor() {
    switch (event.category.toLowerCase()) {
      case 'basketball':
        return Colors.orange;
      case 'volleyball':
        return Colors.green;
      case 'soccer':
        return Colors.blue;
      case 'charity':
        return Colors.pink;
      default:
        return Colors.purple;
    }
  }
  
  /// Get the status label based on the event registration status
  String _getStatusLabel() {
    // Use the registration status from the event model
    switch (event.registrationStatus) {
      case RegistrationStatus.approved:
        return 'Approved';
      case RegistrationStatus.pending:
        return 'Pending';
      case RegistrationStatus.rejected:
        return 'Rejected';
    }
  }
  
  /// Get the status color based on the event registration status
  Color _getStatusColor() {
    switch (event.registrationStatus) {
      case RegistrationStatus.approved:
        return Colors.green[700]!;
      case RegistrationStatus.pending:
        return Colors.orange[700]!;
      case RegistrationStatus.rejected:
        return Colors.red[700]!;
    }
  }

  Widget _buildRegistrationStatusButton() {
    // Get status from the event model
    Color statusColor;
    String statusText;
    
    switch (event.registrationStatus) {
      case RegistrationStatus.approved:
        statusColor = Colors.green[700]!;
        statusText = 'APPROVED';
        break;
      case RegistrationStatus.pending:
        statusColor = Colors.orange[700]!;
        statusText = 'PENDING';
        break;
      case RegistrationStatus.rejected:
        statusColor = Colors.red[700]!;
        statusText = 'REJECTED';
        break;
    }
    
    return Builder(
      builder: (BuildContext context) {
        return _buildActionButton(
          icon: Icons.app_registration,
          label: statusText,
          onPressed: () {
            // Default action if no callback provided
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Registration status: $statusText')),
            );
          },
          statusColor: statusColor,
        );
      },
    );
  }

  Widget _buildStatusIndicator() {
    // For attending events, show registration status
    if (isAttending) {
      Color statusColor;
      String statusText;
      
      // Get status from the event model
      switch (event.registrationStatus) {
        case RegistrationStatus.approved:
          statusColor = Colors.green[700]!;
          statusText = 'APPROVED';
          break;
        case RegistrationStatus.pending:
          statusColor = Colors.orange[700]!;
          statusText = 'PENDING';
          break;
        case RegistrationStatus.rejected:
          statusColor = Colors.red[700]!;
          statusText = 'REJECTED';
          break;
      }
      
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: statusColor.withOpacity(0.2),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: statusColor.withOpacity(0.5), width: 1),
        ),
        child: Text(
          statusText,
          style: TextStyle(
            color: statusColor,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    } else {
      // For hosting events, show past/upcoming status
      final bool isPast = event.dateTime.isBefore(DateTime.now());
      
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: isPast ? Colors.grey[700] : Colors.green[900],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          isPast ? 'Past' : 'Upcoming',
          style: TextStyle(
            color: isPast ? Colors.grey[300] : Colors.green[300],
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
    }
  }
}
