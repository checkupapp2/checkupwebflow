import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:check_up_app/features/events/domain/models/location_model.dart';

/// A modern location selector with search, nearby courts, and privacy options
class EnhancedLocationSelector extends StatefulWidget {
  /// The currently selected location
  final LocationModel? selectedLocation;
  
  /// Whether the location should be hidden for privacy
  final bool isLocationPrivate;
  
  /// Callback when a location is selected
  final Function(LocationModel?) onLocationSelected;
  
  /// Callback when privacy setting is changed
  final Function(bool) onPrivacyChanged;
  
  /// Text controller for custom location input
  final TextEditingController locationController;
  
  /// Whether to hide the location title
  final bool hideTitle;

  /// Creates an [EnhancedLocationSelector] widget
  const EnhancedLocationSelector({
    Key? key,
    this.selectedLocation,
    required this.isLocationPrivate,
    required this.onLocationSelected,
    required this.onPrivacyChanged,
    required this.locationController,
    this.hideTitle = false,
  }) : super(key: key);

  @override
  State<EnhancedLocationSelector> createState() => _EnhancedLocationSelectorState();
}

class _EnhancedLocationSelectorState extends State<EnhancedLocationSelector> with SingleTickerProviderStateMixin {
  // Search query
  String _searchQuery = '';
  
  // View mode
  bool _isSearchMode = false;
  bool _isCustomLocationMode = false;
  
  // Tab controller for nearby/popular courts
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  // Mock data for nearby and popular courts
  final List<LocationModel> _nearbyCourts = [
    LocationModel(
      id: '1',
      name: 'Rucker Park',
      address: '155th St & Frederick Douglass Blvd',
      city: 'New York',
      state: 'NY',
      zipCode: '10039',
      venueType: 'court',
      isPopular: true,
      imageUrl: 'https://example.com/rucker_park.jpg',
      description: 'Historic basketball court known for streetball tournaments',
    ),
    LocationModel(
      id: '2',
      name: 'West 4th Street Courts',
      address: 'W 4th St & 6th Ave',
      city: 'New York',
      state: 'NY',
      zipCode: '10012',
      venueType: 'court',
      isPopular: true,
      imageUrl: 'https://example.com/west4th.jpg',
      description: 'Famous cage court in Greenwich Village',
    ),
    LocationModel(
      id: '3',
      name: 'Central Park North Meadow',
      address: 'Central Park',
      city: 'New York',
      state: 'NY',
      zipCode: '10024',
      venueType: 'court',
      isPopular: false,
      imageUrl: 'https://example.com/central_park.jpg',
    ),
  ];
  
  final List<LocationModel> _popularCourts = [
    LocationModel(
      id: '4',
      name: 'Venice Beach Basketball Courts',
      address: '1800 Ocean Front Walk',
      city: 'Venice',
      state: 'CA',
      zipCode: '90291',
      venueType: 'court',
      isPopular: true,
      imageUrl: 'https://example.com/venice_beach.jpg',
      description: 'Famous outdoor courts on Venice Beach',
    ),
    LocationModel(
      id: '5',
      name: 'The Drew League',
      address: '1601 S Avalon Blvd',
      city: 'Los Angeles',
      state: 'CA',
      zipCode: '90011',
      venueType: 'gym',
      isPopular: true,
      imageUrl: 'https://example.com/drew_league.jpg',
      description: 'Premier summer basketball league',
    ),
    LocationModel(
      id: '6',
      name: 'Dyckman Park',
      address: 'Dyckman St & Nagle Ave',
      city: 'New York',
      state: 'NY',
      zipCode: '10040',
      venueType: 'court',
      isPopular: true,
      imageUrl: 'https://example.com/dyckman.jpg',
      description: 'Home to the Dyckman Basketball Tournament',
    ),
  ];
  
  List<LocationModel> get _filteredCourts {
    if (_searchQuery.isEmpty) return [];
    
    final query = _searchQuery.toLowerCase();
    return [..._nearbyCourts, ..._popularCourts]
        .where((court) => 
            court.name.toLowerCase().contains(query) || 
            court.address.toLowerCase().contains(query) ||
            court.city.toLowerCase().contains(query))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (!widget.hideTitle)
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF3A3A3A),
                  const Color(0xFF2A2A2A),
                  const Color(0xFF1A1A1A),
                  const Color(0xFF0A0A0A),
                ],
                stops: const [0.0, 0.3, 0.7, 1.0],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
                width: 0.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.white.withOpacity(0.03),
                  blurRadius: 1,
                  offset: const Offset(0, 1),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.orange.shade400,
                            Colors.deepOrange.shade600,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.orange.withOpacity(0.3),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.location_on_rounded,
                        color: Colors.white,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Event Location',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _buildPrivacyToggle(),
              ],
            ),
          ),
        // If we're hiding the title, still show the privacy toggle separately
        if (widget.hideTitle)
          Align(
            alignment: Alignment.centerRight,
            child: _buildPrivacyToggle(),
          ),
        const SizedBox(height: 12),
        
        // Search bar
        _buildSearchBar(),
        const SizedBox(height: 12),
        
        // Location selection modes
        if (_isSearchMode) ...[
          _buildSearchResults(),
        ] else if (_isCustomLocationMode) ...[
          _buildCustomLocationInput(),
        ] else ...[
          // Default view with nearby and popular courts
          _buildLocationModeSelector(),
          const SizedBox(height: 16),
          
          // Selected location display
          if (widget.selectedLocation != null && !widget.isLocationPrivate)
            _buildSelectedLocation(),
            
          // Tabbed courts sections
          _buildCourtsTabbedView(),
        ],
      ],
    );
  }

  Widget _buildPrivacyToggle() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 0.5,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Hide Location',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          Switch(
            value: widget.isLocationPrivate,
            onChanged: widget.onPrivacyChanged,
            activeColor: Colors.orange.shade400,
            activeTrackColor: Colors.orange.shade400.withOpacity(0.3),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.secondaryBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.darkGray),
      ),
      child: TextField(
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: 'Search for courts or enter address',
          hintStyle: TextStyle(color: Colors.grey[600]),
          prefixIcon: const Icon(Icons.search, color: Colors.grey),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear, color: Colors.grey),
                  onPressed: () {
                    setState(() {
                      _searchQuery = '';
                      _isSearchMode = false;
                    });
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
        onChanged: (value) {
          setState(() {
            _searchQuery = value;
            _isSearchMode = value.isNotEmpty;
            _isCustomLocationMode = false;
          });
        },
      ),
    );
  }

  Widget _buildLocationModeSelector() {
    return Row(
      children: [
        Expanded(
          child: _buildModeButton(
            icon: Icons.add_location_alt,
            label: 'Custom Location',
            onTap: () {
              setState(() {
                _isCustomLocationMode = true;
                _isSearchMode = false;
              });
            },
          ),
        ),
      ],
    );
  }

  Widget _buildModeButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.darkGray,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectedLocation() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: AppColors.orangeGradient,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.check_circle,
            color: Colors.white,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.selectedLocation!.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.selectedLocation!.fullAddress,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close, color: Colors.white),
            onPressed: () => widget.onLocationSelected(null),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        title,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildLocationList(List<LocationModel> locations) {
    return ListView.builder(
      shrinkWrap: true,
      // Use BouncingScrollPhysics for a more responsive scroll experience
      physics: const BouncingScrollPhysics(),
      itemCount: locations.length,
      padding: EdgeInsets.zero, // Remove default padding
      itemBuilder: (context, index) => Padding(
        padding: const EdgeInsets.only(bottom: 8.0),
        child: _buildLocationItem(locations[index]),
      ),
    );
  }
  
  Widget _buildCourtsTabbedView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Text(
            'Available Courts',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        
        // Tab Bar with custom styling
        Container(
          decoration: BoxDecoration(
            color: AppColors.secondaryBlack,
            borderRadius: BorderRadius.circular(10),
          ),
          child: TabBar(
            controller: _tabController,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey[400],
            labelStyle: const TextStyle(fontWeight: FontWeight.bold),
            indicator: BoxDecoration(
              gradient: AppColors.orangeGradient,
              borderRadius: BorderRadius.circular(10),
            ),
            indicatorSize: TabBarIndicatorSize.tab,
            dividerColor: Colors.transparent,
            tabs: const [
              Tab(text: 'Nearby'),
              Tab(text: 'Popular'),
            ],
          ),
        ),
        const SizedBox(height: 12),
        
        // Tab Content with fixed height for scrolling
        Container(
          height: 260, // Fixed height for scrollable content
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.2),
            borderRadius: BorderRadius.circular(10),
          ),
          child: TabBarView(
            controller: _tabController,
            children: [
              // Nearby Courts Tab
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: _buildLocationList(_nearbyCourts),
              ),
              
              // Popular Courts Tab
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: _buildLocationList(_popularCourts),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLocationItem(LocationModel location) {
    final isSelected = widget.selectedLocation?.id == location.id;
    
    return GestureDetector(
      onTap: () => widget.onLocationSelected(location),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.secondaryBlack,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            // Location image or icon
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: AppColors.darkGray,
                borderRadius: BorderRadius.circular(8),
                image: location.imageUrl != null
                    ? DecorationImage(
                        image: NetworkImage(location.imageUrl!),
                        fit: BoxFit.cover,
                      )
                    : null,
              ),
              child: location.imageUrl == null
                  ? const Icon(Icons.sports_basketball, color: Colors.white)
                  : null,
            ),
            const SizedBox(width: 12),
            
            // Location details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          location.name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (location.isPopular)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            gradient: AppColors.orangeGradient,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text(
                            'Popular',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    location.fullAddress,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 12,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (location.description != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      location.description!,
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 11,
                        fontStyle: FontStyle.italic,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ],
              ),
            ),
            
            // Selection indicator
            if (isSelected)
              const Icon(
                Icons.check_circle,
                color: AppColors.orangeGradientEnd,
                size: 20,
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchResults() {
    if (_filteredCourts.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        alignment: Alignment.center,
        child: Column(
          children: [
            Icon(
              Icons.search_off,
              color: Colors.grey[600],
              size: 40,
            ),
            const SizedBox(height: 12),
            Text(
              'No courts found matching "$_searchQuery"',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () {
                setState(() {
                  _isCustomLocationMode = true;
                  _isSearchMode = false;
                  widget.locationController.text = _searchQuery;
                });
              },
              child: Text(
                'Add as custom location',
                style: TextStyle(
                  color: AppColors.orangeGradientEnd,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      );
    }
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Search Results',
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 8),
        ..._filteredCourts.map((location) => _buildLocationItem(location)),
      ],
    );
  }

  Widget _buildCustomLocationInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Custom Location',
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 8),
        
        // Name field
        TextFormField(
          controller: widget.locationController,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Enter location name or address',
            hintStyle: TextStyle(color: Colors.grey[600]),
            filled: true,
            fillColor: AppColors.secondaryBlack,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.darkGray),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.darkGray),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.orangeGradientEnd),
            ),
          ),
        ),
        const SizedBox(height: 16),
        
        // Save button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () {
              if (widget.locationController.text.isNotEmpty) {
                // Create a custom location from the input
                final customLocation = LocationModel(
                  id: 'custom-${DateTime.now().millisecondsSinceEpoch}',
                  name: widget.locationController.text,
                  address: widget.locationController.text,
                  city: '',
                  state: '',
                  zipCode: '',
                  venueType: 'custom',
                );
                
                widget.onLocationSelected(customLocation);
                
                setState(() {
                  _isCustomLocationMode = false;
                });
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.orangeGradientEnd,
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              'Save Custom Location',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        
        // Cancel button
        SizedBox(
          width: double.infinity,
          child: TextButton(
            onPressed: () {
              setState(() {
                _isCustomLocationMode = false;
              });
            },
            child: Text(
              'Cancel',
              style: TextStyle(
                color: Colors.grey[400],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
