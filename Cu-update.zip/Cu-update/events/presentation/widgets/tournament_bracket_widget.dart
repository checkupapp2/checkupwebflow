import 'package:flutter/material.dart';
import 'tournament_format_selector.dart';

class TournamentBracketWidget extends StatefulWidget {
  final TournamentFormat format;
  final List<Map<String, dynamic>> teams;
  final Function(List<Map<String, dynamic>>) onBracketUpdated;

  const TournamentBracketWidget({
    Key? key,
    required this.format,
    required this.teams,
    required this.onBracketUpdated,
  }) : super(key: key);

  @override
  State<TournamentBracketWidget> createState() => _TournamentBracketWidgetState();
}

class _TournamentBracketWidgetState extends State<TournamentBracketWidget> {
  late List<List<Map<String, dynamic>>> _rounds;
  bool _isSeeded = false;

  @override
  void initState() {
    super.initState();
    _generateBracket();
  }

  @override
  void didUpdateWidget(TournamentBracketWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.teams != widget.teams || oldWidget.format != widget.format) {
      _generateBracket();
    }
  }

  void _generateBracket() {
    switch (widget.format) {
      case TournamentFormat.singleElimination:
        _generateSingleEliminationBracket();
        break;
      case TournamentFormat.doubleElimination:
        _generateDoubleEliminationBracket();
        break;
      case TournamentFormat.roundRobin:
        _generateRoundRobinBracket();
        break;
      case TournamentFormat.poolToBracket:
        _generatePoolToBracketBracket();
        break;
    }
  }

  void _generateSingleEliminationBracket() {
    if (widget.teams.isEmpty) {
      _rounds = [];
      return;
    }

    final teams = List<Map<String, dynamic>>.from(widget.teams);
    
    // Pad to next power of 2
    final nextPowerOf2 = _getNextPowerOf2(teams.length);
    while (teams.length < nextPowerOf2) {
      teams.add({'name': 'BYE', 'isBye': true});
    }

    _rounds = [];
    List<Map<String, dynamic>> currentRound = teams;
    
    while (currentRound.length > 1) {
      List<Map<String, dynamic>> nextRound = [];
      
      for (int i = 0; i < currentRound.length; i += 2) {
        final team1 = currentRound[i];
        final team2 = i + 1 < currentRound.length ? currentRound[i + 1] : null;
        
        Map<String, dynamic> match = {
          'team1': team1,
          'team2': team2,
          'winner': null,
          'score1': null,
          'score2': null,
          'isComplete': false,
        };
        
        // Handle BYE automatically
        if (team1['isBye'] == true && team2 != null) {
          match['winner'] = team2;
          match['isComplete'] = true;
          nextRound.add(team2);
        } else if (team2?['isBye'] == true) {
          match['winner'] = team1;
          match['isComplete'] = true;
          nextRound.add(team1);
        } else if (team2 == null) {
          match['winner'] = team1;
          match['isComplete'] = true;
          nextRound.add(team1);
        } else {
          nextRound.add({'name': 'TBD', 'isTbd': true});
        }
      }
      
      _rounds.add(_createMatchesFromTeams(currentRound));
      currentRound = nextRound;
    }
  }

  void _generateDoubleEliminationBracket() {
    // Simplified double elimination - just create winner's bracket for now
    _generateSingleEliminationBracket();
  }

  void _generateRoundRobinBracket() {
    if (widget.teams.length < 2) {
      _rounds = [];
      return;
    }

    List<Map<String, dynamic>> matches = [];
    
    for (int i = 0; i < widget.teams.length; i++) {
      for (int j = i + 1; j < widget.teams.length; j++) {
        matches.add({
          'team1': widget.teams[i],
          'team2': widget.teams[j],
          'winner': null,
          'score1': null,
          'score2': null,
          'isComplete': false,
        });
      }
    }
    
    _rounds = [matches];
  }

  void _generatePoolToBracketBracket() {
    // For now, treat as single elimination
    _generateSingleEliminationBracket();
  }

  List<Map<String, dynamic>> _createMatchesFromTeams(List<Map<String, dynamic>> teams) {
    List<Map<String, dynamic>> matches = [];
    
    for (int i = 0; i < teams.length; i += 2) {
      final team1 = teams[i];
      final team2 = i + 1 < teams.length ? teams[i + 1] : null;
      
      matches.add({
        'team1': team1,
        'team2': team2,
        'winner': null,
        'score1': null,
        'score2': null,
        'isComplete': false,
      });
    }
    
    return matches;
  }

  int _getNextPowerOf2(int n) {
    int power = 1;
    while (power < n) {
      power *= 2;
    }
    return power;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.teams.isEmpty) {
      return _buildEmptyBracket();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildBracketHeader(),
        const SizedBox(height: 20),
        Expanded(
          child: _buildBracketView(),
        ),
      ],
    );
  }

  Widget _buildEmptyBracket() {
    return Container(
      padding: const EdgeInsets.all(40),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF3A3A3A),
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
            const Color(0xFF0A0A0A),
          ],
          stops: const [0.0, 0.3, 0.7, 1.0],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 0.5,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.account_tree,
            color: Colors.orange.shade400,
            size: 64,
          ),
          const SizedBox(height: 16),
          const Text(
            'Add Teams to Generate Bracket',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Your tournament bracket will appear here once you add teams',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildBracketHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF3A3A3A),
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
            const Color(0xFF0A0A0A),
          ],
          stops: const [0.0, 0.3, 0.7, 1.0],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 0.5,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.orange.shade400,
                  Colors.deepOrange.shade600,
                ],
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.account_tree,
              color: Colors.white,
              size: 22,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${_getFormatName()} Bracket',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${widget.teams.length} teams registered',
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          if (!_isSeeded && widget.teams.length > 1)
            ElevatedButton(
              onPressed: _seedTeams,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange.shade400,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text(
                'Seed Teams',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildBracketView() {
    if (widget.format == TournamentFormat.roundRobin) {
      return _buildRoundRobinView();
    }
    
    return _buildEliminationBracketView();
  }

  Widget _buildRoundRobinView() {
    if (_rounds.isEmpty) return const SizedBox();
    
    final matches = _rounds[0];
    
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Round Robin Matches',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          ...matches.map((match) => _buildMatchCard(match)).toList(),
        ],
      ),
    );
  }

  Widget _buildEliminationBracketView() {
    if (_rounds.isEmpty) return const SizedBox();
    
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: _rounds.asMap().entries.map((entry) {
          final roundIndex = entry.key;
          final matches = entry.value;
          
          return Container(
            width: 250,
            margin: const EdgeInsets.only(right: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _getRoundName(roundIndex),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 12),
                ...matches.map((match) => _buildMatchCard(match)).toList(),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildMatchCard(Map<String, dynamic> match) {
    final team1 = match['team1'] as Map<String, dynamic>;
    final team2 = match['team2'] as Map<String, dynamic>?;
    final isComplete = match['isComplete'] as bool;
    final winner = match['winner'] as Map<String, dynamic>?;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isComplete 
              ? Colors.orange.shade400.withOpacity(0.3)
              : Colors.white.withOpacity(0.08),
          width: 0.5,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: team2 != null && !isComplete ? () => _showScoreDialog(match) : null,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _buildTeamRow(team1, match['score1'], winner == team1),
                if (team2 != null) ...[
                  const SizedBox(height: 8),
                  Container(
                    height: 1,
                    color: Colors.white.withOpacity(0.1),
                  ),
                  const SizedBox(height: 8),
                  _buildTeamRow(team2, match['score2'], winner == team2),
                ],
                if (!isComplete && team2 != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(
                      'Tap to enter score',
                      style: TextStyle(
                        color: Colors.orange.shade400,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTeamRow(Map<String, dynamic> team, int? score, bool isWinner) {
    final isBye = team['isBye'] == true;
    final isTbd = team['isTbd'] == true;
    
    return Row(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isWinner
                  ? [Colors.orange.shade400, Colors.deepOrange.shade600]
                  : isBye || isTbd
                      ? [Colors.grey.shade600, Colors.grey.shade700]
                      : [const Color(0xFF3A3A3A), const Color(0xFF2A2A2A)],
            ),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            isBye ? Icons.close : Icons.group,
            color: Colors.white,
            size: 16,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            team['name'] ?? 'Unknown Team',
            style: TextStyle(
              color: isWinner ? Colors.orange.shade200 : Colors.white,
              fontSize: 14,
              fontWeight: isWinner ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
        if (score != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: isWinner 
                  ? Colors.orange.shade400.withOpacity(0.2)
                  : Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              score.toString(),
              style: TextStyle(
                color: isWinner ? Colors.orange.shade200 : Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
      ],
    );
  }

  String _getFormatName() {
    switch (widget.format) {
      case TournamentFormat.singleElimination:
        return 'Single Elimination';
      case TournamentFormat.doubleElimination:
        return 'Double Elimination';
      case TournamentFormat.roundRobin:
        return 'Round Robin';
      case TournamentFormat.poolToBracket:
        return 'Pool to Bracket';
    }
  }

  String _getRoundName(int roundIndex) {
    final totalRounds = _rounds.length;
    final roundsFromEnd = totalRounds - roundIndex;
    
    switch (roundsFromEnd) {
      case 1:
        return 'Final';
      case 2:
        return 'Semifinals';
      case 3:
        return 'Quarterfinals';
      default:
        return 'Round ${roundIndex + 1}';
    }
  }

  void _seedTeams() {
    // TODO: Implement team seeding dialog
    setState(() {
      _isSeeded = true;
    });
  }

  void _showScoreDialog(Map<String, dynamic> match) {
    final team1 = match['team1'] as Map<String, dynamic>;
    final team2 = match['team2'] as Map<String, dynamic>;
    
    final score1Controller = TextEditingController();
    final score2Controller = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF2A2A2A),
        title: const Text(
          'Enter Game Score',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildScoreInput(team1['name'], score1Controller),
            const SizedBox(height: 16),
            _buildScoreInput(team2['name'], score2Controller),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final score1 = int.tryParse(score1Controller.text) ?? 0;
              final score2 = int.tryParse(score2Controller.text) ?? 0;
              
              setState(() {
                match['score1'] = score1;
                match['score2'] = score2;
                match['winner'] = score1 > score2 ? team1 : team2;
                match['isComplete'] = true;
              });
              
              Navigator.pop(context);
              _updateBracketProgression();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange.shade400,
            ),
            child: const Text('Save Score'),
          ),
        ],
      ),
    );
  }

  Widget _buildScoreInput(String teamName, TextEditingController controller) {
    return Row(
      children: [
        Expanded(
          child: Text(
            teamName,
            style: const TextStyle(color: Colors.white),
          ),
        ),
        const SizedBox(width: 16),
        SizedBox(
          width: 80,
          child: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              filled: true,
              fillColor: const Color(0xFF1A1A1A),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide.none,
              ),
              hintText: '0',
              hintStyle: const TextStyle(color: Colors.white60),
            ),
          ),
        ),
      ],
    );
  }

  void _updateBracketProgression() {
    // TODO: Implement bracket progression logic
    widget.onBracketUpdated(_rounds.expand((round) => round).toList());
  }
}
