import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../bloc/edit_event/edit_event_cubit.dart';
import '../../../bloc/edit_event/edit_event_state.dart';

class StepInfo extends StatelessWidget {
  const StepInfo({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<EditEventCubit, EditEventState>(
      builder: (context, state) {
        final cubit = context.read<EditEventCubit>();
        final titleCtrl = TextEditingController(text: state.title);
        final descCtrl = TextEditingController(text: state.description);

        return SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              _header(
                  icon: Icons.edit_note_rounded,
                  title: 'Tell us about your event'),

              const SizedBox(height: 40),

              // Event Title Card (exact UI)
              _glassCard(
                leadingIcon: Icons.title_rounded,
                title: 'Event Title',
                child: TextField(
                  controller: titleCtrl,
                  onChanged: cubit.setTitle,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                  decoration: _input(
                    'Give your event an exciting name...',
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // Visibility Card
              _glassCard(
                leadingIcon: state.eventPrivate
                    ? Icons.lock_rounded
                    : Icons.public_rounded,
                title: 'Event Visibility',
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: state.eventPrivate
                          ? AppColors.primaryOrange.withOpacity(0.3)
                          : Colors.green.withOpacity(0.3),
                    ),
                  ),
                  child: SwitchListTile(
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    title: Text(
                      state.eventPrivate ? 'Private Event' : 'Public Event',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                    subtitle: Text(
                      state.eventPrivate
                          ? 'Only invited people can see and join'
                          : 'Anyone can discover and join this event',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 14,
                      ),
                    ),
                    value: !state.eventPrivate,
                    onChanged: (v) => cubit.setEventPrivate(!v),
                    activeColor: Colors.green,
                    inactiveThumbColor: AppColors.primaryOrange,
                    inactiveTrackColor:
                        AppColors.primaryOrange.withOpacity(0.3),
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // Description Card
              _glassCard(
                leadingIcon: Icons.description_rounded,
                title: 'Event Description',
                child: TextField(
                  controller: descCtrl,
                  maxLines: 4,
                  onChanged: cubit.setDescription,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    height: 1.5,
                  ),
                  decoration: _input(
                    'Share what makes your event special...\n\n• What should attendees expect?\n• Any special requirements?',
                  ),
                ),
              ),

              const SizedBox(height: 40),
            ],
          ),
        );
      },
    );
  }

  Widget _header({required IconData icon, required String title}) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.withOpacity(0.3),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Icon(icon, color: Colors.white, size: 28),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
              height: 1.2,
            ),
          ),
        ),
      ],
    );
  }

  Widget _glassCard(
      {required IconData leadingIcon,
      required String title,
      required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: _glass(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            _badgeIcon(leadingIcon),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.3,
              ),
            ),
          ]),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }

  BoxDecoration _glass() => BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF3A3A3A),
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
            Color(0xFF0A0A0A)
          ],
          stops: [0.0, 0.3, 0.7, 1.0],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
        boxShadow: [
          BoxShadow(
              color: Colors.white.withOpacity(0.03),
              blurRadius: 1,
              offset: Offset(0, 1)),
          BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 12,
              offset: Offset(0, 4)),
        ],
      );

  Widget _badgeIcon(IconData icon) => Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [Colors.orange.shade400, Colors.deepOrange.shade600]),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
                color: Colors.orange.withOpacity(0.3),
                blurRadius: 6,
                offset: Offset(0, 2))
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 18),
      );

  InputDecoration _input(String hint) => InputDecoration(
        hintText: hint,
        hintStyle:
            TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 16),
        filled: true,
        fillColor: Colors.white.withOpacity(0.08),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide:
              const BorderSide(color: AppColors.primaryOrange, width: 2),
        ),
        contentPadding: const EdgeInsets.all(16),
      );
}
