import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:check_up_app/features/events/presentation/widgets/event_type_selector.dart';
import '../../../bloc/edit_event/edit_event_cubit.dart';
import '../../../bloc/edit_event/edit_event_state.dart';
import '../../../domain/models/event_type.dart';
import '../../../../../core/theme/app_colors.dart';

class StepType extends StatelessWidget {
  final VoidCallback onPicked;
  const StepType({super.key, required this.onPicked});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<EditEventCubit, EditEventState>(
      builder: (context, state) {
        final cubit = context.read<EditEventCubit>();

        // same container & spacing as your monolithic selector step
        return Container(
          width: double.infinity,
          constraints: const BoxConstraints(minHeight: 400),
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: EventTypeSelector(
            selectedType: state.type,
            onTypeSelected: (EventType t) {
              cubit.setType(t);
              onPicked(); // move to next step immediately (original UX)
            },
          ),
        );
      },
    );
  }
}
