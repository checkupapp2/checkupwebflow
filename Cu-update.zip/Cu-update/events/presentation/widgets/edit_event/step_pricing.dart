import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../bloc/edit_event/edit_event_cubit.dart';
import '../../../bloc/edit_event/edit_event_state.dart';
import 'package:check_up_app/features/events/presentation/widgets/registration_pricing_form.dart';

class StepPricing extends StatelessWidget {
  const StepPricing({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<EditEventCubit, EditEventState>(
      builder: (context, state) {
        final cubit = context.read<EditEventCubit>();

        // controllers seeded from state (same as your page)
        final capCtrl =
            TextEditingController(text: state.capacity?.toString() ?? '');
        final tName = TextEditingController();
        final tPrice = TextEditingController();
        final tQty = TextEditingController();
        final ebPrice = TextEditingController(
          text: state.earlyBirdPrice != null
              ? state.earlyBirdPrice!.toString()
              : '',
        );
        final waiverTxt = TextEditingController(text: state.waiverText);
        final qText = TextEditingController();
        final qOpts = TextEditingController();

        return SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              _header(),
              const SizedBox(height: 8),
              Container(
                constraints: const BoxConstraints(minHeight: 400),
                child: RegistrationPricingForm(
                  capacityController: capCtrl
                    ..addListener(() {
                      cubit.setCapacity(int.tryParse(capCtrl.text));
                    }),
                  isRegistrationOpen: state.registrationOpen,
                  onRegistrationStatusChanged: cubit.setRegistrationOpen,
                  ticketTypes: state.ticketTypes,
                  onTicketTypesUpdated: cubit.setTicketTypes,
                  ticketNameController: tName,
                  ticketPriceController: tPrice,
                  ticketQuantityController: tQty,
                  hasCustomQuestions: state.hasCustomQuestions,
                  onCustomQuestionsChanged: cubit.setHasCustomQuestions,
                  customQuestions: state.customQuestions,
                  onCustomQuestionsUpdated: cubit.setCustomQuestions,
                  questionTextController: qText,
                  questionOptionsController: qOpts,
                  hasEarlyBirdPricing: state.hasEarlyBird,
                  onEarlyBirdPricingChanged: cubit.setHasEarlyBird,
                  earlyBirdPriceController: ebPrice
                    ..addListener(() {
                      cubit.setEarlyBirdPrice(double.tryParse(ebPrice.text));
                    }),
                  earlyBirdDeadline: state.earlyBirdDeadline,
                  onEarlyBirdDeadlineSelected: cubit.setEarlyBirdDeadline,
                  requiresWaiver: state.requiresWaiver,
                  onWaiverRequirementChanged: cubit.setRequiresWaiver,
                  waiverTextController: waiverTxt
                    ..addListener(() {
                      cubit.setWaiverText(waiverTxt.text);
                    }),
                  selectedWaiverTemplate: state.waiverTemplate,
                  onWaiverTemplateSelected: cubit.setWaiverTemplate,
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  Widget _header() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.withOpacity(0.3),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: const Icon(Icons.confirmation_number_rounded,
              color: Colors.white, size: 28),
        ),
        const SizedBox(width: 16),
        const Expanded(
          child: Text(
            'Event Pricing',
            style: TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
              height: 1.2,
            ),
          ),
        ),
      ],
    );
  }
}
