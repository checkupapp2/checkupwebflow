import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../bloc/edit_event/edit_event_cubit.dart';
import '../../../bloc/edit_event/edit_event_state.dart';

class StepDateTime extends StatelessWidget {
  const StepDateTime({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<EditEventCubit, EditEventState>(
      builder: (context, state) {
        final cubit = context.read<EditEventCubit>();

        return SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              _header(),

              const SizedBox(height: 40),

              // Date card (exact UI)
              _dateCard(
                context: context,
                label: 'Event Date',
                valueText: state.dateTime != null
                    ? '${_monthName(state.dateTime!.month)} ${state.dateTime!.day}, ${state.dateTime!.year}'
                    : 'Tap to select date',
                isSelected: state.dateTime != null,
                onTap: () => _showModernDatePicker(context, state, cubit),
              ),

              const SizedBox(height: 20),

              // Time card (exact UI)
              _timeCard(
                context: context,
                label: 'Event Time',
                valueText: state.dateTime != null
                    ? _formatTime12Hour(state.dateTime!)
                    : 'Tap to select time',
                isSelected: state.dateTime != null,
                onTap: () => _showModernTimePicker(context, state, cubit),
              ),

              const SizedBox(height: 40),
            ],
          ),
        );
      },
    );
  }

  // header identical
  Widget _header() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.withOpacity(0.3),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child:
              const Icon(Icons.schedule_rounded, color: Colors.white, size: 28),
        ),
        const SizedBox(width: 16),
        const Expanded(
          child: Text(
            'When is your event?',
            style: TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
              height: 1.2,
            ),
          ),
        ),
      ],
    );
  }

  Widget _dateCard({
    required BuildContext context,
    required String label,
    required String valueText,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return _glassCard(
      onTap: onTap,
      leading: Icons.calendar_today,
      title: label,
      trailingChevron: true,
      child: Text(
        valueText,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.white.withOpacity(0.7),
          fontSize: isSelected ? 20 : 16,
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
        ),
      ),
    );
  }

  Widget _timeCard({
    required BuildContext context,
    required String label,
    required String valueText,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return _glassCard(
      onTap: onTap,
      leading: Icons.access_time,
      title: label,
      trailingChevron: true,
      child: Text(
        valueText,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.white.withOpacity(0.7),
          fontSize: isSelected ? 20 : 16,
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
        ),
      ),
    );
  }

  Widget _glassCard({
    required VoidCallback onTap,
    required IconData leading,
    required String title,
    required Widget child,
    bool trailingChevron = false,
  }) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF3A3A3A),
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
            Color(0xFF0A0A0A)
          ],
          stops: [0.0, 0.3, 0.7, 1.0],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
        boxShadow: [
          BoxShadow(
              color: Colors.white.withOpacity(0.03),
              blurRadius: 1,
              offset: Offset(0, 1)),
          BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 12,
              offset: Offset(0, 4)),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  _badgeIcon(leading),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const Spacer(),
                  if (trailingChevron)
                    Icon(Icons.arrow_forward_ios,
                        color: Colors.white.withOpacity(0.6), size: 16),
                ]),
                const SizedBox(height: 16),
                child,
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _badgeIcon(IconData icon) => Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [Colors.orange.shade400, Colors.deepOrange.shade600]),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
                color: Colors.orange.withOpacity(0.3),
                blurRadius: 6,
                offset: Offset(0, 2))
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 18),
      );

  // Bottom sheets (identical look), write through cubit
  void _showModernDatePicker(
      BuildContext context, EditEventState state, EditEventCubit cubit) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.6,
        decoration: const BoxDecoration(
          color: AppColors.primaryBlack,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(24), topRight: Radius.circular(24)),
        ),
        child: Column(
          children: [
            _handleBar(),
            _sheetHeader(context, 'Select Date'),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: _modernCalendar(state, cubit),
              ),
            ),
            _doneButton(context),
          ],
        ),
      ),
    );
  }

  void _showModernTimePicker(
      BuildContext context, EditEventState state, EditEventCubit cubit) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: const BoxDecoration(
          color: AppColors.primaryBlack,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(24), topRight: Radius.circular(24)),
        ),
        child: Column(
          children: [
            _handleBar(),
            _sheetHeader(context, 'Select Time'),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: _modernTimeSlots(state, cubit),
              ),
            ),
            _doneButton(context),
          ],
        ),
      ),
    );
  }

  Widget _handleBar() => Container(
        margin: const EdgeInsets.only(top: 12),
        width: 40,
        height: 4,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.3),
          borderRadius: BorderRadius.circular(2),
        ),
      );

  Widget _sheetHeader(BuildContext context, String title) => Padding(
        padding: const EdgeInsets.all(24),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold)),
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20)),
              child: const Icon(Icons.close, color: Colors.white, size: 20),
            ),
          ),
        ]),
      );

  Widget _doneButton(BuildContext context) => Padding(
        padding: const EdgeInsets.all(24),
        child: SizedBox(
          width: double.infinity,
          child: Container(
            decoration: BoxDecoration(
              gradient: AppColors.orangeGradient,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withOpacity(0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                shadowColor: Colors.transparent,
              ),
              child: const Text('Done',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ),
      );

  Widget _modernCalendar(EditEventState state, EditEventCubit cubit) {
    final now = DateTime.now();
    final selected = state.dateTime ?? now;
    final firstDayOfMonth = DateTime(selected.year, selected.month, 1);
    final lastDayOfMonth = DateTime(selected.year, selected.month + 1, 0);
    final firstWeekday = (firstDayOfMonth.weekday - 1) % 7;
    final daysInMonth = lastDayOfMonth.day;

    return Column(
      children: [
        // Month navigation
        Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            _navBtn(Icons.chevron_left, () {
              final newDate = DateTime(selected.year, selected.month - 1, 1);
              final cur = state.dateTime;
              final next = cur != null
                  ? DateTime(newDate.year, newDate.month, cur.day, cur.hour,
                      cur.minute)
                  : newDate;
              cubit.setDateTime(next);
            }),
            Text('${_monthName(selected.month)} ${selected.year}',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)),
            _navBtn(Icons.chevron_right, () {
              final newDate = DateTime(selected.year, selected.month + 1, 1);
              final cur = state.dateTime;
              final next = cur != null
                  ? DateTime(newDate.year, newDate.month, cur.day, cur.hour,
                      cur.minute)
                  : newDate;
              cubit.setDateTime(next);
            }),
          ]),
        ),

        // Day labels
        Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: const ['S', 'M', 'T', 'W', 'T', 'F', 'S']
                .map((d) => Text(d,
                    style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                        fontWeight: FontWeight.w600)))
                .toList(),
          ),
        ),

        // Grid
        Expanded(
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              childAspectRatio: 1,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
            ),
            itemCount: firstWeekday + daysInMonth,
            itemBuilder: (context, index) {
              if (index < firstWeekday) return const SizedBox();
              final day = index - firstWeekday + 1;
              final date = DateTime(selected.year, selected.month, day);
              final isSelected = state.dateTime != null &&
                  state.dateTime!.year == date.year &&
                  state.dateTime!.month == date.month &&
                  state.dateTime!.day == date.day;
              final isToday = date.year == now.year &&
                  date.month == now.month &&
                  date.day == now.day;
              final isPast =
                  date.isBefore(DateTime(now.year, now.month, now.day));

              return GestureDetector(
                onTap: isPast
                    ? null
                    : () {
                        final cur = state.dateTime;
                        final next = cur != null
                            ? DateTime(date.year, date.month, date.day,
                                cur.hour, cur.minute)
                            : DateTime(date.year, date.month, date.day, 12, 0);
                        cubit.setDateTime(next);
                      },
                child: Container(
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isToday && !isSelected
                        ? Colors.white.withOpacity(0.15)
                        : isPast
                            ? null
                            : Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(12),
                    border: isSelected
                        ? Border.all(color: Colors.white, width: 2)
                        : isToday && !isSelected
                            ? Border.all(
                                color: const Color(0xFFFF9800), width: 2)
                            : Border.all(
                                color: Colors.white.withOpacity(0.1), width: 1),
                    boxShadow: isSelected
                        ? [
                            BoxShadow(
                                color: const Color(0xFFFF9800).withOpacity(0.5),
                                blurRadius: 8,
                                offset: Offset(0, 2))
                          ]
                        : null,
                  ),
                  child: Center(
                    child: Text(
                      '$day',
                      style: TextStyle(
                        color: isPast
                            ? Colors.white.withOpacity(0.3)
                            : isSelected
                                ? Colors.white
                                : isToday
                                    ? const Color(0xFFFF9800)
                                    : Colors.white.withOpacity(0.9),
                        fontSize: isSelected ? 18 : 16,
                        fontWeight: isSelected
                            ? FontWeight.w900
                            : (isToday ? FontWeight.bold : FontWeight.w500),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _navBtn(IconData icon, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: Colors.white),
        ),
      );

  Widget _modernTimeSlots(EditEventState state, EditEventCubit cubit) {
    final slots = <Map<String, dynamic>>[];
    for (int hour = 6; hour < 24; hour++) {
      for (int minute = 0; minute < 60; minute += 15) {
        final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
        final period = hour >= 12 ? 'PM' : 'AM';
        final timeString =
            '$displayHour:${minute.toString().padLeft(2, '0')} $period';
        slots.add({'display': timeString, 'hour': hour, 'minute': minute});
      }
    }

    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 2.2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
      ),
      itemCount: slots.length,
      itemBuilder: (context, i) {
        final s = slots[i];
        final hour = s['hour'] as int;
        final minute = s['minute'] as int;
        final isSelected = state.dateTime != null &&
            state.dateTime!.hour == hour &&
            state.dateTime!.minute == minute;

        return GestureDetector(
          onTap: () {
            final cur = state.dateTime ?? DateTime.now();
            final next = DateTime(cur.year, cur.month, cur.day, hour, minute);
            cubit.setDateTime(next);
          },
          child: Container(
            decoration: BoxDecoration(
              gradient: isSelected ? AppColors.orangeGradient : null,
              color: isSelected ? null : Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected
                    ? Colors.transparent
                    : Colors.white.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Center(
              child: Text(
                s['display'] as String,
                style: TextStyle(
                  color:
                      isSelected ? Colors.white : Colors.white.withOpacity(0.8),
                  fontSize: 14,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  String _monthName(int m) => const [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
      ][m - 1];

  String _formatTime12Hour(DateTime dt) {
    final h = dt.hour, m = dt.minute;
    final displayHour = h > 12 ? h - 12 : (h == 0 ? 12 : h);
    final period = h >= 12 ? 'PM' : 'AM';
    return '$displayHour:${m.toString().padLeft(2, '0')} $period';
  }
}
