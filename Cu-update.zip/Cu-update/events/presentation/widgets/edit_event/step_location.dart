import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../bloc/edit_event/edit_event_cubit.dart';
import '../../../bloc/edit_event/edit_event_state.dart';
import 'package:check_up_app/features/events/presentation/widgets/enhanced_location_selector.dart';

class StepLocation extends StatelessWidget {
  const StepLocation({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<EditEventCubit, EditEventState>(
      builder: (context, state) {
        final cubit = context.read<EditEventCubit>();
        final ctrl = TextEditingController(text: state.locationText);

        return SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              _header(),
              const SizedBox(height: 40),
              EnhancedLocationSelector(
                selectedLocation: state.locationObj,
                isLocationPrivate: state.locationPrivate,
                onLocationSelected: (loc) => cubit.setLocationObj(loc),
                onPrivacyChanged: cubit.setLocationPrivate,
                locationController: ctrl
                  ..addListener(() => cubit.setLocationText(ctrl.text)),
              ),
              const SizedBox(height: 40),
            ],
          ),
        );
      },
    );
  }

  Widget _header() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.withOpacity(0.3),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: const Icon(Icons.location_on_rounded,
              color: Colors.white, size: 28),
        ),
        const SizedBox(width: 16),
        const Expanded(
          child: Text(
            'Where is your event taking place?',
            style: TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
              height: 1.2,
            ),
          ),
        ),
      ],
    );
  }
}
