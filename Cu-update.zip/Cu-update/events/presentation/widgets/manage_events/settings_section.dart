import 'package:flutter/material.dart';
import '../../../../../core/theme/app_colors.dart';

class SettingsSection extends StatelessWidget {
  const SettingsSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Registration & check-in
      _card(
        icon: Icons.event_available_rounded,
        title: 'Registration & check-in',
        child: Column(children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Allow new registrations',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500)),
            subtitle: Text('Players can still join this event from the app.',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.7), fontSize: 12)),
            value: true,
            onChanged: (v) {},
            activeColor: AppColors.primaryOrange,
            inactiveThumbColor: Colors.white,
            inactiveTrackColor: Colors.white.withOpacity(0.3),
          ),
          const Divider(color: Colors.white24, height: 24),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Enable QR code check-in',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500)),
            subtitle: Text(
                'Scan tickets at the gate to mark attendees as checked in.',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.7), fontSize: 12)),
            value: true,
            onChanged: (v) {},
            activeColor: AppColors.primaryOrange,
            inactiveThumbColor: Colors.white,
            inactiveTrackColor: Colors.white.withOpacity(0.3),
          ),
        ]),
      ),
      const SizedBox(height: 16),

      // Visibility & privacy
      _card(
        icon: Icons.visibility_rounded,
        title: 'Visibility & privacy',
        child: Column(children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Show event in Discover',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500)),
            subtitle: Text(
                'Event will appear in local Discover and search results.',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.7), fontSize: 12)),
            value: true,
            onChanged: (v) {},
            activeColor: AppColors.primaryOrange,
            inactiveThumbColor: Colors.white,
            inactiveTrackColor: Colors.white.withOpacity(0.3),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Hide exact location until approved',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500)),
            subtitle: Text('Only approved players see the full address.',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.7), fontSize: 12)),
            value: false,
            onChanged: (v) {},
            activeColor: AppColors.primaryOrange,
            inactiveThumbColor: Colors.white,
            inactiveTrackColor: Colors.white.withOpacity(0.3),
          ),
        ]),
      ),
      const SizedBox(height: 16),

      // Danger zone
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF2A1515),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.red.withOpacity(0.5), width: 0.8),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8)),
              child: const Icon(Icons.warning_rounded,
                  color: Colors.redAccent, size: 18),
            ),
            const SizedBox(width: 10),
            const Text('Danger zone',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w600)),
          ]),
          const SizedBox(height: 12),
          Text('Close registrations, pause the event, or cancel it entirely.',
              style: TextStyle(
                  color: Colors.white.withOpacity(0.75), fontSize: 13)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () {},
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: Colors.orangeAccent.withOpacity(0.8)),
                  foregroundColor: Colors.orangeAccent,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('Close registrations',
                    style:
                        TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('Cancel event',
                    style:
                        TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              ),
            ),
          ]),
        ]),
      ),
    ]);
  }

  Widget _card(
      {required IconData icon, required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF3A3A3A), Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(8)),
            child: Icon(icon, color: Colors.white, size: 16),
          ),
          const SizedBox(width: 12),
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 12),
        child,
      ]),
    );
  }
}
