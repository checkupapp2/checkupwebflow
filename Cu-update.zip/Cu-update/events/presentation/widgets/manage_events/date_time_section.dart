import 'package:flutter/material.dart';

class DateTimeSection extends StatelessWidget {
  final DateTime? startDateTime;
  final DateTime? endDateTime;
  final void Function(DateTime? start, DateTime? end) onChanged;

  const DateTimeSection({
    super.key,
    required this.startDateTime,
    required this.endDateTime,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _combined(
        title: 'Event Date',
        icon: Icons.calendar_today,
        start: startDateTime,
        end: endDateTime,
        isDate: true,
      ),
      const SizedBox(height: 16),
      _combined(
        title: 'Event Time',
        icon: Icons.access_time,
        start: startDateTime,
        end: endDateTime,
        isDate: false,
      ),
    ]);
  }

  Widget _combined({
    required String title,
    required IconData icon,
    required DateTime? start,
    required DateTime? end,
    required bool isDate,
  }) {
    final hasStart = start != null;
    final hasEnd = end != null;
    final hasAny = hasStart || hasEnd;

    String monthName(int m) => const [
          'Jan',
          'Feb',
          'Mar',
          'Apr',
          'May',
          'Jun',
          'Jul',
          'Aug',
          'Sep',
          'Oct',
          'Nov',
          'Dec'
        ][(m - 1).clamp(0, 11)];
    String t12(DateTime dt) {
      var h = dt.hour;
      final m = dt.minute.toString().padLeft(2, '0');
      final p = h >= 12 ? 'PM' : 'AM';
      h = h % 12;
      if (h == 0) h = 12;
      return '$h:$m $p';
    }

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: hasAny
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.orange.shade400.withOpacity(0.2),
                  Colors.deepOrange.shade600.withOpacity(0.2),
                  const Color(0xFF2A2A2A),
                  const Color(0xFF1A1A1A),
                ],
                stops: const [0.0, 0.15, 0.5, 1.0],
              )
            : const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF3A3A3A),
                  Color(0xFF2A2A2A),
                  Color(0xFF1A1A1A),
                  Color(0xFF0A0A0A)
                ],
                stops: [0.0, 0.3, 0.7, 1.0],
              ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: hasAny
              ? Colors.orange.withOpacity(0.3)
              : Colors.white.withOpacity(0.08),
          width: hasAny ? 1.5 : 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: hasAny
                ? Colors.orange.withOpacity(0.15)
                : Colors.white.withOpacity(0.03),
            blurRadius: hasAny ? 8 : 1,
            offset: Offset(0, hasAny ? 3 : 1),
          ),
          BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 12,
              offset: const Offset(0, 4)),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: hasAny
                    ? LinearGradient(colors: [
                        Colors.orange.shade400,
                        Colors.deepOrange.shade600
                      ])
                    : LinearGradient(
                        colors: [Colors.grey.shade600, Colors.grey.shade700]),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                    color: hasAny
                        ? Colors.orange.withOpacity(0.3)
                        : Colors.black.withOpacity(0.2),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 16),
            ),
            const SizedBox(width: 12),
            Text(title,
                style: TextStyle(
                    color:
                        hasAny ? Colors.white : Colors.white.withOpacity(0.9),
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.3)),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(
              child: _box(
                label: 'Start',
                value: hasStart
                    ? (isDate
                        ? '${monthName(start!.month)} ${start.day}'
                        : t12(start))
                    : (isDate ? 'Select date' : 'Select time'),
                highlighted: hasStart,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _box(
                label: 'End',
                value: hasEnd
                    ? (isDate
                        ? '${monthName(end!.month)} ${end.day}'
                        : t12(end))
                    : (isDate ? 'Select date' : 'Select time'),
                highlighted: hasEnd,
              ),
            ),
          ]),
        ]),
      ),
    );
  }

  Widget _box(
      {required String label,
      required String value,
      required bool highlighted}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: highlighted
            ? Colors.orange.withOpacity(0.1)
            : Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: highlighted
                ? Colors.orange.withOpacity(0.3)
                : Colors.white.withOpacity(0.1),
            width: 1),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label,
            style: TextStyle(
                color: Colors.white.withOpacity(0.7),
                fontSize: 12,
                fontWeight: FontWeight.w500)),
        const SizedBox(height: 4),
        Text(value,
            style: TextStyle(
              color: highlighted ? Colors.white : Colors.white.withOpacity(0.6),
              fontSize: highlighted ? 16 : 14,
              fontWeight: highlighted ? FontWeight.w600 : FontWeight.normal,
            )),
      ]),
    );
  }
}
