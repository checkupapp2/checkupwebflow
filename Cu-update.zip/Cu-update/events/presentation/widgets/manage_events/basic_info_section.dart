import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:flutter/material.dart';

class BasicInfoSection extends StatelessWidget {
  final String titleText;
  final List<String> eventImageUrls;
  final VoidCallback onTapManageImages;
  final ValueChanged<String> onTitleChanged;

  const BasicInfoSection({
    super.key,
    required this.titleText,
    required this.eventImageUrls,
    required this.onTapManageImages,
    required this.onTitleChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Event Images
      _card(
        headerIcon: Icons.image_rounded,
        header: 'Event Images',
        trailing: Text('${eventImageUrls.length}/4',
            style:
                TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12)),
        child: AspectRatio(
          aspectRatio: 1.0,
          child: GestureDetector(
            onTap: onTapManageImages,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: eventImageUrls.isNotEmpty
                  ? PageView.builder(
                      itemCount: eventImageUrls.length,
                      itemBuilder: (_, i) =>
                          Image.network(eventImageUrls[i], fit: BoxFit.cover),
                    )
                  : Container(
                      decoration: BoxDecoration(
                          color: AppColors.darkGray,
                          borderRadius: BorderRadius.circular(12)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.image_outlined,
                              color: Colors.white.withOpacity(0.5), size: 40),
                          const SizedBox(height: 8),
                          const Text('Tap to add event images',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500)),
                          const SizedBox(height: 4),
                          Text('${eventImageUrls.length}/4 selected',
                              style: TextStyle(
                                  color: Colors.white.withOpacity(0.6),
                                  fontSize: 11)),
                        ],
                      ),
                    ),
            ),
          ),
        ),
      ),
      const SizedBox(height: 16),

      // Title
      _card(
        headerIcon: Icons.edit_rounded,
        header: 'Event Title',
        child: TextField(
          controller: TextEditingController(text: titleText),
          onChanged: onTitleChanged,
          style: const TextStyle(color: Colors.white, fontSize: 16),
          decoration: InputDecoration(
            hintText: 'Enter event title...',
            hintStyle:
                TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 14),
            filled: true,
            fillColor: Colors.white.withOpacity(0.08),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide:
                  const BorderSide(color: AppColors.primaryOrange, width: 2),
            ),
            contentPadding: const EdgeInsets.all(12),
          ),
        ),
      ),
      const SizedBox(height: 16),

      // Skill & visibility (static demo exactly as before)
      _card(
        headerIcon: Icons.sports_basketball_rounded,
        header: 'Skill level & visibility',
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                  gradient: AppColors.orangeGradient,
                  borderRadius: BorderRadius.circular(20)),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.bolt_rounded, color: Colors.white, size: 14),
                SizedBox(width: 6),
                Text('Advanced / Pro',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600)),
              ]),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withOpacity(0.1)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.lock_open_rounded,
                    color: Colors.white.withOpacity(0.8), size: 14),
                const SizedBox(width: 6),
                Text('Public event',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: 12,
                        fontWeight: FontWeight.w500)),
              ]),
            ),
          ]),
          const SizedBox(height: 12),
          Text(
            'Players of all positions welcome. Competitive run aimed at experienced hoopers.',
            style:
                TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 13),
          ),
        ]),
      ),
    ]);
  }

  Widget _card({
    required IconData headerIcon,
    required String header,
    Widget? trailing,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF3A3A3A), Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(8)),
            child: Icon(headerIcon, color: Colors.white, size: 16),
          ),
          const SizedBox(width: 12),
          Text(header,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600)),
          const Spacer(),
          if (trailing != null) trailing,
        ]),
        const SizedBox(height: 12),
        child,
      ]),
    );
  }
}
