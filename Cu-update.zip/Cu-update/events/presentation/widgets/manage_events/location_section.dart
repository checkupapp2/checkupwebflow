import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/domain/models/location_model.dart';
import 'package:check_up_app/features/events/presentation/widgets/enhanced_location_selector.dart';

class LocationSection extends StatelessWidget {
  final LocationModel? selectedLocation;
  final bool isLocationPrivate;
  final TextEditingController locationController;
  final ValueChanged<LocationModel?> onLocationSelected;
  final ValueChanged<bool> onPrivacyChanged;

  const LocationSection({
    super.key,
    required this.selectedLocation,
    required this.isLocationPrivate,
    required this.locationController,
    required this.onLocationSelected,
    required this.onPrivacyChanged,
  });

  @override
  Widget build(BuildContext context) {
    return EnhancedLocationSelector(
      selectedLocation: selectedLocation,
      isLocationPrivate: isLocationPrivate,
      onLocationSelected: onLocationSelected,
      onPrivacyChanged: onPrivacyChanged,
      locationController: locationController,
    );
  }
}
