import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/presentation/widgets/registration_pricing_form.dart';

class TicketsSection extends StatelessWidget {
  final TextEditingController capacityController;
  final bool isRegistrationOpen;
  final ValueChanged<bool> onRegistrationStatusChanged;

  final List<Map<String, dynamic>> ticketTypes;
  final ValueChanged<List<Map<String, dynamic>>> onTicketTypesUpdated;
  final TextEditingController ticketNameController;
  final TextEditingController ticketPriceController;
  final TextEditingController ticketQuantityController;

  final bool hasCustomQuestions;
  final ValueChanged<bool> onCustomQuestionsChanged;
  final List<Map<String, dynamic>> customQuestions;
  final ValueChanged<List<Map<String, dynamic>>> onCustomQuestionsUpdated;
  final TextEditingController questionTextController;
  final TextEditingController questionOptionsController;

  final bool hasEarlyBirdPricing;
  final ValueChanged<bool> onEarlyBirdPricingChanged;
  final TextEditingController earlyBirdPriceController;
  final DateTime? earlyBirdDeadline;
  final ValueChanged<DateTime?> onEarlyBirdDeadlineSelected;

  final bool requiresWaiver;
  final ValueChanged<bool> onWaiverRequirementChanged;
  final TextEditingController waiverTextController;
  final String? selectedWaiverTemplate;
  final ValueChanged<String?> onWaiverTemplateSelected;

  const TicketsSection({
    super.key,
    required this.capacityController,
    required this.isRegistrationOpen,
    required this.onRegistrationStatusChanged,
    required this.ticketTypes,
    required this.onTicketTypesUpdated,
    required this.ticketNameController,
    required this.ticketPriceController,
    required this.ticketQuantityController,
    required this.hasCustomQuestions,
    required this.onCustomQuestionsChanged,
    required this.customQuestions,
    required this.onCustomQuestionsUpdated,
    required this.questionTextController,
    required this.questionOptionsController,
    required this.hasEarlyBirdPricing,
    required this.onEarlyBirdPricingChanged,
    required this.earlyBirdPriceController,
    required this.earlyBirdDeadline,
    required this.onEarlyBirdDeadlineSelected,
    required this.requiresWaiver,
    required this.onWaiverRequirementChanged,
    required this.waiverTextController,
    required this.selectedWaiverTemplate,
    required this.onWaiverTemplateSelected,
  });

  @override
  Widget build(BuildContext context) {
    // This embeds your original RegistrationPricingForm exactly as before.
    return RegistrationPricingForm(
      capacityController: capacityController,
      isRegistrationOpen: isRegistrationOpen,
      onRegistrationStatusChanged: onRegistrationStatusChanged,
      ticketTypes: ticketTypes,
      onTicketTypesUpdated: onTicketTypesUpdated,
      ticketNameController: ticketNameController,
      ticketPriceController: ticketPriceController,
      ticketQuantityController: ticketQuantityController,
      hasCustomQuestions: hasCustomQuestions,
      onCustomQuestionsChanged: onCustomQuestionsChanged,
      customQuestions: customQuestions,
      onCustomQuestionsUpdated: onCustomQuestionsUpdated,
      questionTextController: questionTextController,
      questionOptionsController: questionOptionsController,
      hasEarlyBirdPricing: hasEarlyBirdPricing,
      onEarlyBirdPricingChanged: onEarlyBirdPricingChanged,
      earlyBirdPriceController: earlyBirdPriceController,
      earlyBirdDeadline: earlyBirdDeadline,
      onEarlyBirdDeadlineSelected: onEarlyBirdDeadlineSelected,
      requiresWaiver: requiresWaiver,
      onWaiverRequirementChanged: onWaiverRequirementChanged,
      waiverTextController: waiverTextController,
      selectedWaiverTemplate: selectedWaiverTemplate,
      onWaiverTemplateSelected: onWaiverTemplateSelected,
    );
  }
}
