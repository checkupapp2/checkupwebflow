import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:flutter/material.dart';
import '../../pages/attendee_registration_details_page.dart';
import '../../pages/team_registration_details_page.dart';

class AttendanceSection extends StatefulWidget {
  final String eventTitle;
  const AttendanceSection({super.key, required this.eventTitle});

  @override
  State<AttendanceSection> createState() => _AttendanceSectionState();
}

class _AttendanceSectionState extends State<AttendanceSection> {
  String _attendanceFilter = 'all';
  bool _isRequestedExpanded = false;

  @override
  Widget build(BuildContext context) {
    // ——— same sample data as original ———
    final attendees = <Map<String, dynamic>>[
      {
        'name': 'Michael Jordan',
        'email': 'mjordan@example.com',
        'status': 'joined',
        'ticketType': 'VIP',
        'profileImage': 'https://randomuser.me/api/portraits/men/32.jpg',
        'checkedIn': true,
        'isRegistered': true,
        'joinedDate': 'Nov 10, 2024',
        'type': 'individual',
      },
      {
        'name': 'LeBron James',
        'email': 'ljames@example.com',
        'status': 'joined',
        'ticketType': 'Regular',
        'profileImage': 'https://randomuser.me/api/portraits/men/42.jpg',
        'checkedIn': false,
        'isRegistered': true,
        'joinedDate': 'Nov 12, 2024',
        'type': 'individual',
      },
      {
        'name': 'Lakers Elite',
        'email': 'contact@lakerselite.com',
        'status': 'requested',
        'ticketType': 'Team',
        'profileImage': null,
        'checkedIn': false,
        'isRegistered': true,
        'requestedDate': 'Nov 15, 2024',
        'type': 'team',
        'teamSize': 8,
        'captain': 'John Smith',
        'captainPhone': '+1 (555) 123-4567',
      },
      {
        'name': 'Warriors Squad',
        'email': 'info@warriorssquad.com',
        'status': 'requested',
        'ticketType': 'Team',
        'profileImage': null,
        'checkedIn': false,
        'isRegistered': true,
        'requestedDate': 'Nov 16, 2024',
        'type': 'team',
        'teamSize': 10,
        'captain': 'Mike Johnson',
        'captainPhone': '+1 (555) 987-6543',
      },
      {
        'name': 'Bulls United',
        'email': 'team@bullsunited.org',
        'status': 'joined',
        'ticketType': 'Team',
        'profileImage': null,
        'checkedIn': true,
        'isRegistered': true,
        'joinedDate': 'Nov 12, 2024',
        'type': 'team',
        'teamSize': 12,
        'captain': 'Sarah Wilson',
        'captainPhone': '+1 (555) 456-7890',
      },
      {
        'name': 'Stephen Curry',
        'email': 'scurry@example.com',
        'status': 'joined',
        'ticketType': 'VIP',
        'profileImage': 'https://randomuser.me/api/portraits/men/45.jpg',
        'checkedIn': true,
        'isRegistered': false,
        'joinedDate': 'Nov 14, 2024',
        'type': 'individual',
      },
      {
        'name': 'Kevin Durant',
        'email': 'kdurant@example.com',
        'status': 'invited',
        'ticketType': 'VIP',
        'profileImage': 'https://randomuser.me/api/portraits/men/50.jpg',
        'checkedIn': false,
        'isRegistered': true,
        'invitedDate': 'Nov 8, 2024',
        'type': 'individual',
      },
    ];

    final joined = attendees.where((a) => a['status'] == 'joined').length;
    final invited = attendees.where((a) => a['status'] == 'invited').length;
    final requested = attendees.where((a) => a['status'] == 'requested').length;
    final checkedIn = attendees.where((a) => a['checkedIn'] == true).length;
    final total = attendees.length;

    final filtered = attendees.where((a) {
      return _attendanceFilter == 'all' || a['status'] == _attendanceFilter;
    }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _stats(total, joined, invited, requested, checkedIn),
        const SizedBox(height: 12),
        _searchBar(),
        const SizedBox(height: 12),
        _tabs(total, joined, invited, requested, (f) {
          setState(() => _attendanceFilter = f);
        }),
        const SizedBox(height: 12),
        _list(filtered),
      ],
    );
  }

  // ---- The helpers below are the same UI you had, moved here 1:1 ----

  Widget _stats(
      int total, int joined, int invited, int requested, int checkedIn) {
    return Container(
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.grey[900]!,
              Colors.black,
            ]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Expanded(child: _stat('Total', total, Icons.people)),
          Container(width: 1, height: 30, color: Colors.grey[700]),
          Expanded(child: _stat('Joined', joined, Icons.check_circle)),
          Container(width: 1, height: 30, color: Colors.grey[700]),
          Expanded(child: _stat('Invited', invited, Icons.mail)),
          Container(width: 1, height: 30, color: Colors.grey[700]),
          Expanded(child: _stat('Requests', requested, Icons.person_add)),
        ],
      ),
    );
  }

  Widget _stat(String label, int count, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: AppColors.primaryOrange, size: 18),
        const SizedBox(height: 4),
        Text('$count',
            style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold)),
        Text(label,
            style: TextStyle(
                color: Colors.grey[400],
                fontSize: 11,
                fontWeight: FontWeight.w500)),
      ],
    );
  }

  Widget _searchBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.grey[850],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[700]!),
      ),
      child: Row(
        children: [
          Icon(Icons.search, color: Colors.grey[400], size: 20),
          const SizedBox(width: 12),
          const Expanded(
            child: TextField(
              style: TextStyle(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Search attendees...',
                hintStyle: TextStyle(color: Color(0xFF9E9E9E), fontSize: 14),
                border: InputBorder.none,
                contentPadding: EdgeInsets.zero,
                isDense: true,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabs(int total, int joined, int invited, int requested,
      Function(String) update) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[700]!),
      ),
      child: Row(
        children: [
          Expanded(child: _tab('All', 'all', total, update)),
          Expanded(child: _tab('Joined', 'joined', joined, update)),
          Expanded(child: _tab('Invited', 'invited', invited, update)),
          Expanded(child: _tab('Requests', 'requested', requested, update)),
        ],
      ),
    );
  }

  Widget _tab(String label, String value, int count, Function(String) update) {
    final isSelected = _attendanceFilter == value;
    return GestureDetector(
      onTap: () => update(value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          gradient: isSelected ? AppColors.orangeGradient : null,
          borderRadius: BorderRadius.circular(12),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                      color: AppColors.primaryOrange.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2))
                ]
              : null,
        ),
        child: Column(
          children: [
            Text('$count',
                style: TextStyle(
                    color: isSelected ? Colors.white : Colors.grey[400],
                    fontSize: 18,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text(label,
                style: TextStyle(
                    color: isSelected ? Colors.white : Colors.grey[500],
                    fontSize: 12,
                    fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  Widget _list(List<Map<String, dynamic>> filtered) {
    if (filtered.isEmpty) return _empty();

    final grouped = <String, List<Map<String, dynamic>>>{};
    for (final a in filtered) {
      grouped.putIfAbsent(a['status'] as String, () => []).add(a);
    }

    return Column(children: [
      if (grouped['requested']?.isNotEmpty == true) ...[
        _sectionHeader(
            'Pending Requests', grouped['requested']!.length, Icons.person_add),
        ...grouped['requested']!.map(_card).toList(),
        const SizedBox(height: 16),
      ],
      if (grouped['joined']?.isNotEmpty == true) ...[
        _sectionHeader('Confirmed Attendees', grouped['joined']!.length,
            Icons.check_circle),
        ...grouped['joined']!.map(_card).toList(),
        const SizedBox(height: 16),
      ],
      if (grouped['invited']?.isNotEmpty == true) ...[
        _sectionHeader('Invited', grouped['invited']!.length, Icons.mail),
        ...grouped['invited']!.map(_card).toList(),
      ],
    ]);
  }

  Widget _sectionHeader(String title, int count, IconData icon) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.grey[800]!,
              Colors.black,
            ]),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primaryOrange, size: 16),
          const SizedBox(width: 8),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(8)),
            child: Text('$count',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _card(Map<String, dynamic> attendee) {
    final isTeam = attendee['type'] == 'team';

    Color statusColor = AppColors.primaryOrange;
    IconData statusIcon = Icons.info;
    switch (attendee['status']) {
      case 'joined':
        statusIcon = Icons.check_circle;
        break;
      case 'invited':
        statusIcon = Icons.mail;
        break;
      case 'requested':
        statusIcon = Icons.person_add;
        break;
    }

    final ticketType = attendee['ticketType'] ?? 'Regular';
    final ticketColor = isTeam
        ? AppColors.primaryOrange
        : (ticketType == 'VIP' ? Colors.amber : Colors.blue);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.grey[850]!,
              Colors.black,
            ]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.primaryOrange.withOpacity(0.2)),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            if (isTeam) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => TeamRegistrationDetailsPage(
                      team: attendee, eventTitle: widget.eventTitle),
                ),
              );
            } else {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AttendeeRegistrationDetailsPage(
                      attendee: attendee, eventTitle: widget.eventTitle),
                ),
              );
            }
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // avatar / group
                Stack(children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: statusColor, width: 2),
                      image: (!isTeam &&
                              attendee['isRegistered'] &&
                              attendee['profileImage'] != null)
                          ? DecorationImage(
                              image: NetworkImage(attendee['profileImage']),
                              fit: BoxFit.cover)
                          : null,
                      color: isTeam
                          ? AppColors.primaryOrange.withOpacity(0.2)
                          : (attendee['isRegistered']
                              ? null
                              : Colors.amber.withOpacity(0.2)),
                    ),
                    child: isTeam
                        ? Icon(Icons.groups,
                            color: AppColors.primaryOrange, size: 20)
                        : (attendee['isRegistered'] &&
                                attendee['profileImage'] != null
                            ? null
                            : const Icon(Icons.person_outline,
                                color: Colors.amber, size: 20)),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: statusColor,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.black, width: 1),
                      ),
                      child: Icon(statusIcon, color: Colors.white, size: 6),
                    ),
                  ),
                ]),
                const SizedBox(width: 12),

                // info
                Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Expanded(
                            child: Text(attendee['name'] ?? 'Unknown User',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600)),
                          ),
                          if (isTeam)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 4, vertical: 1),
                              decoration: BoxDecoration(
                                color: AppColors.primaryOrange.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(
                                    color: AppColors.primaryOrange
                                        .withOpacity(0.5)),
                              ),
                              child: const Text('TEAM',
                                  style: TextStyle(
                                      color: AppColors.primaryOrange,
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold)),
                            )
                          else if (!(attendee['isRegistered'] == true))
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 4, vertical: 1),
                              decoration: BoxDecoration(
                                color: Colors.amber.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(
                                    color: Colors.amber.withOpacity(0.5)),
                              ),
                              child: const Text('GUEST',
                                  style: TextStyle(
                                      color: Colors.amber,
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold)),
                            ),
                        ]),
                        const SizedBox(height: 4),
                        Text(
                          isTeam
                              ? 'Captain: ${attendee['captain'] ?? 'Unknown'} • ${attendee['teamSize'] ?? 0} players'
                              : attendee['email'] ?? 'No email',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style:
                              TextStyle(color: Colors.grey[400], fontSize: 12),
                        ),
                        const SizedBox(height: 8),
                        Row(children: [
                          _pill(
                              (attendee['status'] ?? 'unknown')
                                  .toString()
                                  .toUpperCase(),
                              statusColor),
                          const SizedBox(width: 8),
                          _pill(ticketType, ticketColor),
                          if (attendee['checkedIn'] == true) ...[
                            const SizedBox(width: 8),
                            _pill('IN', AppColors.primaryOrange),
                          ],
                        ]),
                      ]),
                ),

                // actions
                if (attendee['status'] == 'requested') ...[
                  _squareBtn(Icons.check, AppColors.primaryOrange, () {}),
                  const SizedBox(width: 6),
                  _squareBtn(Icons.close,
                      AppColors.primaryOrange.withOpacity(0.7), () {}),
                ] else if (attendee['status'] == 'joined' &&
                    !(attendee['checkedIn'] == true)) ...[
                  _squareBtn(Icons.login, AppColors.primaryOrange, () {}),
                ] else ...[
                  Icon(Icons.chevron_right,
                      color: AppColors.primaryOrange.withOpacity(0.6),
                      size: 20),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _squareBtn(IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: color.withOpacity(0.2),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.5)),
        ),
        child: Icon(icon, color: color, size: 20),
      ),
    );
  }

  Widget _pill(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Text(label,
          style: TextStyle(
              color: color, fontSize: 9, fontWeight: FontWeight.bold)),
    );
  }

  Widget _empty() {
    return Container(
      margin: const EdgeInsets.all(32),
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.grey[850],
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey[700]!),
      ),
      child: Column(
        children: [
          Icon(Icons.people_outline, color: Colors.grey[500], size: 64),
          const SizedBox(height: 16),
          Text('No attendees found',
              style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 18,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Text('Try adjusting your filters or search terms',
              style: TextStyle(color: Colors.grey[500], fontSize: 14)),
        ],
      ),
    );
  }
}
