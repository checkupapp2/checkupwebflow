import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';

import 'dart:io' show File;
import 'package:flutter/foundation.dart' show kIsWeb;

/// A widget that displays a preview of the event being created
class EventPreview extends StatelessWidget {
  /// The event title
  final String title;

  /// The event date and time
  final DateTime? dateTime;

  /// The event location
  final String location;

  /// The event type
  final EventType? eventType;

  /// Whether the event is free
  final bool isFree;

  /// The event price if not free
  final double? price;

  /// Whether the event is private
  final bool isPrivate;

  /// List of ticket types for the event
  final List<Map<String, dynamic>>? ticketTypes;

  /// Optional list of image URLs to display for the event preview
  final List<String>? imageUrls;

  /// Optional callback when the main image area is tapped
  final VoidCallback? onImageTap;

  /// Optional count of currently selected images
  final int? imageCount;

  /// Optional maximum number of images allowed
  final int? maxImages;

  /// Creates an [EventPreview] widget
  const EventPreview({
    Key? key,
    required this.title,
    this.dateTime,
    required this.location,
    this.eventType,
    required this.isFree,
    this.price,
    this.isPrivate = false,
    this.ticketTypes,
    this.imageUrls,
    this.onImageTap,
    this.imageCount,
    this.maxImages,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Event Preview',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: AppColors.secondaryBlack,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.darkGray),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildEventImage(),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(child: _buildEventTitle()),
                        _buildPrivacyBadge(),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildEventDetails(),
                    const SizedBox(height: 12),
                    _buildEventLocation(),
                    const SizedBox(height: 12),
                    _buildEventPrice(),
                    // Always show tickets section for preview (with mock data if no tickets provided)
                    const SizedBox(height: 16),
                    _buildTicketsSection(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMixedImage(String src) {
    // Web: treat everything as network (image_picker on web returns blob URLs)
    if (kIsWeb) {
      return Image.network(src, fit: BoxFit.cover);
    }

    final uri = Uri.tryParse(src);

    // Remote URL
    if (uri != null && (uri.scheme == 'http' || uri.scheme == 'https')) {
      return Image.network(src, fit: BoxFit.cover);
    }

    // file:// URI
    if (uri != null && uri.scheme == 'file') {
      return Image.file(File.fromUri(uri), fit: BoxFit.cover);
    }

    // Plain path
    return Image.file(File(src), fit: BoxFit.cover);
  }

  Widget _buildEventImage() {
    Widget content;

    // If images are provided, show the first one as the main preview image
    if (imageUrls != null && imageUrls!.isNotEmpty) {
      content = ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        child: PageView.builder(
          itemCount: imageUrls!.length,
          itemBuilder: (context, index) {
            final url = imageUrls![index];
            return _buildMixedImage(url);
          },
        ),
      );
    } else {
      // Fallback placeholder when no images are provided
      content = Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: AppColors.darkGray,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              _getIconForEventType(),
              color: Colors.white.withOpacity(0.5),
              size: 40,
            ),
            const SizedBox(height: 8),
            const Text(
              'Tap to add event images',
              style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
            if (imageCount != null && maxImages != null) ...[
              const SizedBox(height: 4),
              Text(
                '${imageCount}/${maxImages} selected',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.6),
                  fontSize: 11,
                ),
              ),
            ],
          ],
        ),
      );
    }

    return AspectRatio(
      aspectRatio: 1.0,
      child: GestureDetector(
        onTap: onImageTap,
        child: content,
      ),
    );
  }

  Widget _buildEventTitle() {
    return Text(
      title.isEmpty ? 'Event Title' : title,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 20,
        fontWeight: FontWeight.bold,
      ),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildPrivacyBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isPrivate ? Colors.grey[800] : AppColors.orangeGradientStart,
        borderRadius: BorderRadius.circular(12),
        gradient: isPrivate ? null : AppColors.orangeGradient,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isPrivate ? Icons.lock : Icons.public,
            color: Colors.white,
            size: 16,
          ),
          const SizedBox(width: 4),
          Text(
            isPrivate ? 'Private' : 'Public',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEventDetails() {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            eventType != null ? eventType!.displayName : 'Event',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(width: 8),
        const Icon(
          Icons.calendar_today,
          color: Colors.white,
          size: 14,
        ),
        const SizedBox(width: 4),
        Text(
          dateTime != null ? _formatDateTime(dateTime!) : 'Date & Time',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _buildEventLocation() {
    return Row(
      children: [
        const Icon(
          Icons.location_on,
          color: Colors.white,
          size: 16,
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            location.isNotEmpty ? location : 'Location',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildEventPrice() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: isFree
            ? Colors.green.withOpacity(0.2)
            : AppColors.orangeGradientStart.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isFree ? Colors.green : AppColors.orangeGradientEnd,
        ),
      ),
      child: Text(
        isFree ? 'FREE' : '\$${price?.toStringAsFixed(2) ?? '0.00'}',
        style: TextStyle(
          color: isFree ? Colors.green : AppColors.orangeGradientEnd,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  IconData _getIconForEventType() {
    if (eventType == null) {
      return Icons.event;
    }

    switch (eventType!) {
      case EventType.pickupRun:
        return Icons.sports_basketball;
      case EventType.tournament:
        return Icons.emoji_events;
      case EventType.oneOff:
        return Icons.sports_score;
      case EventType.camp:
        return Icons.cabin;
      case EventType.training:
        return Icons.fitness_center;
      case EventType.donationBased:
        return Icons.volunteer_activism;
      case EventType.specialEvent:
        return Icons.star;
      case EventType.oneVsOne:
        return Icons.people;
      case EventType.openGym:
        return Icons.sports_handball;
    }
  }

  String _formatDateTime(DateTime dateTime) {
    final month = _getMonthName(dateTime.month);
    final day = dateTime.day;
    final hour = dateTime.hour > 12 ? dateTime.hour - 12 : dateTime.hour;
    final period = dateTime.hour >= 12 ? 'PM' : 'AM';
    final minute = dateTime.minute.toString().padLeft(2, '0');

    return '$month $day, $hour:$minute $period';
  }

  Widget _buildTicketsSection() {
    if (ticketTypes == null || ticketTypes!.isEmpty) {
      return const SizedBox.shrink(); // nothing to preview yet
    }

    final tickets = ticketTypes!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(color: AppColors.darkGray),
        const SizedBox(height: 12),
        Row(
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Icon(Icons.confirmation_number,
                  color: Colors.white, size: 14),
            ),
            const SizedBox(width: 8),
            const Text(
              'Available Tickets',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                '${tickets.length}',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...tickets.map((ticket) => _buildTicketPreviewCard(ticket)).toList(),
      ],
    );
  }

  Widget _buildTicketPreviewCard(Map<String, dynamic> ticket) {
    final bool isFreeTicket = ticket['price'] == 0;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.primaryOrange.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          // Ticket icon
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              gradient: AppColors.orangeGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.confirmation_number,
              color: Colors.white,
              size: 16,
            ),
          ),
          const SizedBox(width: 12),

          // Ticket info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ticket['name'] ?? 'Ticket',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    // Price badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        gradient: isFreeTicket
                            ? LinearGradient(
                                colors: [
                                  Colors.green.shade600,
                                  Colors.green.shade800
                                ],
                              )
                            : AppColors.orangeGradient,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        isFreeTicket
                            ? 'FREE'
                            : '\$${ticket['price']?.toString() ?? '0'}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),

                    // Quantity badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.secondaryBlack.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: AppColors.primaryOrange.withOpacity(0.3),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.people,
                            color: AppColors.primaryOrange,
                            size: 10,
                          ),
                          const SizedBox(width: 2),
                          Text(
                            '${ticket['quantity'] ?? '∞'}',
                            style: TextStyle(
                              color: Colors.grey[300],
                              fontSize: 9,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getMonthName(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }
}
