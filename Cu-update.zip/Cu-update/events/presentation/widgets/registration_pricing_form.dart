import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';

/// A form for event registration, pricing, and waiver settings
class RegistrationPricingForm extends StatefulWidget {
  /// Builder function for event-specific details section
  final Widget Function()? eventSpecificDetailsBuilder;

  /// Controller for the registration capacity
  final TextEditingController capacityController;

  /// Whether registration is open or closed
  final bool isRegistrationOpen;

  /// Callback when registration status changes
  final Function(bool) onRegistrationStatusChanged;

  /// List of ticket types
  final List<Map<String, dynamic>> ticketTypes;

  /// Callback when ticket types are updated
  final Function(List<Map<String, dynamic>>) onTicketTypesUpdated;

  /// Controller for ticket name input
  final TextEditingController ticketNameController;

  /// Controller for ticket price input
  final TextEditingController ticketPriceController;

  /// Controller for ticket quantity input
  final TextEditingController ticketQuantityController;

  /// Whether early bird pricing is enabled
  final bool hasEarlyBirdPricing;

  /// Callback when early bird pricing status changes
  final Function(bool) onEarlyBirdPricingChanged;

  /// Controller for the early bird price
  final TextEditingController earlyBirdPriceController;

  /// Early bird deadline date
  final DateTime? earlyBirdDeadline;

  /// Callback when early bird deadline is selected
  final Function(DateTime) onEarlyBirdDeadlineSelected;

  /// Whether a waiver is required
  final bool requiresWaiver;

  /// Callback when waiver requirement changes
  final Function(bool) onWaiverRequirementChanged;

  /// Controller for custom waiver text
  final TextEditingController waiverTextController;

  /// Selected waiver template
  final String? selectedWaiverTemplate;

  /// Callback when waiver template is selected
  final Function(String) onWaiverTemplateSelected;

  /// Whether custom questions are enabled
  final bool hasCustomQuestions;

  /// Callback when custom questions toggle changes
  final Function(bool) onCustomQuestionsChanged;

  /// List of custom questions
  final List<Map<String, dynamic>> customQuestions;

  /// Callback when custom questions are updated
  final Function(List<Map<String, dynamic>>) onCustomQuestionsUpdated;

  /// Controller for question text input
  final TextEditingController questionTextController;

  /// Controller for question options input
  final TextEditingController questionOptionsController;

  /// Constructor for RegistrationPricingForm
  const RegistrationPricingForm({
    Key? key,
    this.eventSpecificDetailsBuilder,
    required this.capacityController,
    required this.isRegistrationOpen,
    required this.onRegistrationStatusChanged,

    // Ticket types parameters
    required this.ticketTypes,
    required this.onTicketTypesUpdated,
    required this.ticketNameController,
    required this.ticketPriceController,
    required this.ticketQuantityController,

    // Legacy pricing parameters
    required this.hasEarlyBirdPricing,
    required this.onEarlyBirdPricingChanged,
    required this.earlyBirdPriceController,
    required this.earlyBirdDeadline,
    required this.onEarlyBirdDeadlineSelected,
    required this.requiresWaiver,
    required this.onWaiverRequirementChanged,
    required this.waiverTextController,
    required this.selectedWaiverTemplate,
    required this.onWaiverTemplateSelected,
    required this.hasCustomQuestions,
    required this.onCustomQuestionsChanged,
    required this.customQuestions,
    required this.onCustomQuestionsUpdated,
    required this.questionTextController,
    required this.questionOptionsController,
  }) : super(key: key);

  @override
  State<RegistrationPricingForm> createState() =>
      _RegistrationPricingFormState();
}

class _RegistrationPricingFormState extends State<RegistrationPricingForm> {
  // State variables to track form selections
  String _selectedQuestionType = 'text';
  // Ticket description (local)
  final TextEditingController _ticketDescCtrl = TextEditingController();

  // List to manage multiple choice options dynamically
  List<TextEditingController> _optionControllers = [];
  List<String> _currentOptions = [];

  // Track question text for validation
  String _questionText = '';

  // Price and quantity picker state
  double _selectedPrice = 0.0;
  int _selectedQuantity = 0;

  @override
  void initState() {
    super.initState();
    // Initialize with current text value
    _questionText = widget.questionTextController.text;

    // Initialize price and quantity from controllers
    _selectedPrice = double.tryParse(widget.ticketPriceController.text) ?? 0.0;
    _selectedQuantity = int.tryParse(widget.ticketQuantityController.text) ?? 0;

    // Listen to question text changes for real-time validation
    widget.questionTextController.addListener(() {
      setState(() {
        _questionText = widget.questionTextController.text;
      });
    });
  }

  @override
  void dispose() {
    // Dispose all option controllers
    for (var controller in _optionControllers) {
      controller.dispose();
    }
    _ticketDescCtrl.dispose();
    super.dispose();
  }

  bool _canAddTicket() {
    final nameOk = widget.ticketNameController.text.trim().isNotEmpty;

    final price = double.tryParse(
      widget.ticketPriceController.text.trim() == 'FREE' ||
              widget.ticketPriceController.text.trim().isEmpty
          ? '0'
          : widget.ticketPriceController.text.trim(),
    );

    final qtyText = widget.ticketQuantityController.text.trim();
    final qty = qtyText.isEmpty ? 0 : int.tryParse(qtyText);

    final qtyOk = qty != null && qty >= 0;

    return nameOk && price != null && price >= 0 && qtyOk;
  }

  void _addTicket() {
    if (!_canAddTicket()) {
      _showValidationMessage(
        'Please complete ticket name, valid price, and quantity.',
      );
      return;
    }

    final price = double.tryParse(
      widget.ticketPriceController.text.trim().isEmpty
          ? '0'
          : widget.ticketPriceController.text.trim(),
    )!;

    final qtyText = widget.ticketQuantityController.text.trim();
    final quantity = qtyText.isEmpty ? null : int.parse(qtyText);

    final newTicket = <String, dynamic>{
      'name': widget.ticketNameController.text.trim(),
      'description': _ticketDescCtrl.text.trim(),
      'price': price,
      'quantity': quantity,
      'requiresWaiver': false,
      'hasCustomQuestions': false,
      'isExpanded': false,
    };

    final updated = List<Map<String, dynamic>>.from(widget.ticketTypes)
      ..add(newTicket);

    widget.onTicketTypesUpdated(updated);

    widget.ticketNameController.clear();
    widget.ticketPriceController.clear();
    widget.ticketQuantityController.clear();
    _ticketDescCtrl.clear();

    setState(() {
      _selectedPrice = 0.0;
      _selectedQuantity = 0;
    });

    _showSuccessMessage(
      'Ticket added. Total: ${updated.length}',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),

        // Event-specific details section (if provided)
        if (widget.eventSpecificDetailsBuilder != null) ...[
          widget.eventSpecificDetailsBuilder!(),
          const SizedBox(height: 24),
        ],

        // Ticket types section with integrated waiver and questions
        _buildPricingSection(),
      ],
    );
  }

  Widget _buildRegistrationSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader('Registration Settings', Icons.app_registration),
        const SizedBox(height: 16),
        _buildToggleOption(
          'Registration',
          widget.isRegistrationOpen ? 'Open' : 'Closed',
          widget.isRegistrationOpen,
          widget.onRegistrationStatusChanged,
        ),
      ],
    );
  }

  // Registration capacity section removed as requested

  Widget _buildPricingSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Ticket types list
        if (widget.ticketTypes.isNotEmpty) ...[
          _buildTicketTypesList(),
          const SizedBox(height: 16),
        ],

        // Basic ticket form (simplified version)
        _buildBasicTicketForm(),
      ],
    );
  }

  Widget _buildBasicTicketForm() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF3A3A3A),
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 0.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  gradient: AppColors.orangeGradient,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.local_activity_rounded,
                  color: Colors.white,
                  size: 16,
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                'Ticket Name',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: widget.ticketNameController,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
            decoration: InputDecoration(
              hintText: 'e.g., General Admission, VIP, Early Bird',
              hintStyle: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 14,
              ),
              filled: true,
              fillColor: Colors.white.withOpacity(0.08),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: AppColors.primaryOrange,
                  width: 2,
                ),
              ),
              contentPadding: const EdgeInsets.all(12),
            ),
          ),
          const SizedBox(height: 16),
          // Ticket Description
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  gradient: AppColors.orangeGradient,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.description_rounded,
                  color: Colors.white,
                  size: 16,
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                'Ticket Description',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _ticketDescCtrl,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              height: 1.4,
            ),
            maxLines: 3,
            decoration: InputDecoration(
              hintText: 'Describe what this ticket includes...',
              hintStyle: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 13,
              ),
              filled: true,
              fillColor: Colors.white.withOpacity(0.08),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: AppColors.primaryOrange,
                  width: 2,
                ),
              ),
              contentPadding: const EdgeInsets.all(12),
            ),
          ),
          const SizedBox(height: 16),
          // Price Section
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      gradient: AppColors.orangeGradient,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(
                      Icons.attach_money_rounded,
                      color: Colors.white,
                      size: 14,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'Price',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _buildPricePicker(),
            ],
          ),
          const SizedBox(height: 16),
          // Quantity Section
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      gradient: AppColors.orangeGradient,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(
                      Icons.people_rounded,
                      color: Colors.white,
                      size: 14,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'Quantity',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _buildQuantityPicker(),
            ],
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: _canAddTicket() ? _addTicket : null,
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
                backgroundColor: Colors.transparent,
                disabledBackgroundColor: Colors.grey.shade700,
              ),
              child: Ink(
                decoration: BoxDecoration(
                  gradient: _canAddTicket() ? AppColors.orangeGradient : null,
                  color: _canAddTicket() ? null : Colors.grey.shade700,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Text(
                    'Add Ticket',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 16),

          // Custom Questions Toggle
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SwitchListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              title: const Text(
                'Custom Questions',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
              subtitle: Text(
                widget.hasCustomQuestions ? 'Enabled' : 'Disabled',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 12,
                ),
              ),
              value: widget.hasCustomQuestions,
              onChanged: widget.onCustomQuestionsChanged,
              activeColor: AppColors.primaryOrange,
              inactiveThumbColor: Colors.white,
              inactiveTrackColor: Colors.white.withOpacity(0.3),
            ),
          ),

          // Custom Questions Content (shown directly under toggle when enabled)
          if (widget.hasCustomQuestions) ...[
            const SizedBox(height: 16),
            _buildQuestionsList(),
            const SizedBox(height: 16),
            _buildAddQuestionForm(),
          ],

          const SizedBox(height: 16),
          // Require Waiver Toggle
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SwitchListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              title: const Text(
                'Require Waiver',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
              subtitle: Text(
                widget.requiresWaiver ? 'Required' : 'Not Required',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 12,
                ),
              ),
              value: widget.requiresWaiver,
              onChanged: widget.onWaiverRequirementChanged,
              activeColor: AppColors.primaryOrange,
              inactiveThumbColor: Colors.white,
              inactiveTrackColor: Colors.white.withOpacity(0.3),
            ),
          ),

          // Waiver Content (shown directly under toggle when enabled)
          if (widget.requiresWaiver) ...[
            const SizedBox(height: 16),
            _buildWaiverTemplateSelector(),
            const SizedBox(height: 16),
            _buildWaiverPreview(),
          ],
        ],
      ),
    );
  }

  Widget _buildTicketTypesList() {
    return Column(
      children: widget.ticketTypes.asMap().entries.map((entry) {
        final int index = entry.key;
        final Map<String, dynamic> ticket = entry.value;
        final bool isFree = ticket['price'] == 0;

        // Track expanded state for each ticket
        final bool isExpanded = ticket['isExpanded'] ?? false;

        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF2A2A2A),
                const Color(0xFF1A1A1A),
                const Color(0xFF0A0A0A),
              ],
              stops: const [0.0, 0.5, 1.0],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: AppColors.primaryOrange.withOpacity(0.15),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryOrange.withOpacity(0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 16,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            children: [
              // Ticket header with expand/collapse toggle
              InkWell(
                onTap: () {
                  // Toggle expanded state
                  final updatedTickets =
                      List<Map<String, dynamic>>.from(widget.ticketTypes);
                  final updatedTicket = Map<String, dynamic>.from(ticket);
                  updatedTicket['isExpanded'] = !isExpanded;
                  updatedTickets[index] = updatedTicket;
                  widget.onTicketTypesUpdated(updatedTickets);
                },
                borderRadius: BorderRadius.circular(20),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      // Main ticket info row
                      Row(
                        children: [
                          // Ticket icon
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              gradient: AppColors.orangeGradient,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(
                              Icons.confirmation_number,
                              color: Colors.white,
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),

                          // Ticket name and price
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  ticket['name'] ?? 'Unnamed Ticket',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                // Ticket description
                                if (ticket['description'] != null &&
                                    ticket['description'].toString().isNotEmpty)
                                  Text(
                                    ticket['description'],
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.7),
                                      fontSize: 13,
                                      fontStyle: FontStyle.italic,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                if (ticket['description'] != null &&
                                    ticket['description'].toString().isNotEmpty)
                                  const SizedBox(height: 4),
                                Row(
                                  children: [
                                    // Price
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 4),
                                      decoration: BoxDecoration(
                                        gradient: isFree
                                            ? LinearGradient(
                                                colors: [
                                                  Colors.green.shade600,
                                                  Colors.green.shade800
                                                ],
                                              )
                                            : AppColors.orangeGradient,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        isFree
                                            ? 'FREE'
                                            : '\$${ticket['price']?.toString() ?? '0'}',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),

                                    // Quantity
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: AppColors.secondaryBlack
                                            .withOpacity(0.6),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(
                                          color: AppColors.primaryOrange
                                              .withOpacity(0.3),
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(
                                            Icons.people,
                                            color: AppColors.primaryOrange,
                                            size: 12,
                                          ),
                                          const SizedBox(width: 4),
                                          Text(
                                            '${ticket['quantity'] ?? '∞'}',
                                            style: TextStyle(
                                              color: Colors.grey[300],
                                              fontSize: 11,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),

                          // Action buttons
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Expand button
                              Container(
                                width: 32,
                                height: 32,
                                decoration: BoxDecoration(
                                  color:
                                      AppColors.secondaryBlack.withOpacity(0.6),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: AppColors.primaryOrange
                                        .withOpacity(0.3),
                                  ),
                                ),
                                child: Icon(
                                  isExpanded
                                      ? Icons.expand_less
                                      : Icons.expand_more,
                                  color: AppColors.primaryOrange,
                                  size: 18,
                                ),
                              ),
                              const SizedBox(width: 8),

                              // Edit button
                              Container(
                                width: 32,
                                height: 32,
                                decoration: BoxDecoration(
                                  gradient: AppColors.orangeGradient,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: IconButton(
                                  icon: const Icon(Icons.edit),
                                  color: Colors.white,
                                  iconSize: 16,
                                  padding: EdgeInsets.zero,
                                  onPressed: () {
                                    // Pre-fill form with this ticket's data for editing
                                    widget.ticketNameController.text =
                                        ticket['name'] ?? '';
                                    widget.ticketPriceController.text =
                                        ticket['price'].toString();
                                    widget.ticketQuantityController.text =
                                        ticket['quantity']?.toString() ?? '';

                                    // Remove this ticket (will be re-added with updated values)
                                    final updatedTickets =
                                        List<Map<String, dynamic>>.from(
                                            widget.ticketTypes);
                                    updatedTickets.removeAt(index);
                                    widget.onTicketTypesUpdated(updatedTickets);
                                  },
                                ),
                              ),
                              const SizedBox(width: 8),

                              // Delete button
                              Container(
                                width: 32,
                                height: 32,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.red.shade400,
                                      Colors.red.shade600
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: IconButton(
                                  icon: const Icon(Icons.delete),
                                  color: Colors.white,
                                  iconSize: 16,
                                  padding: EdgeInsets.zero,
                                  onPressed: () {
                                    final updatedTickets =
                                        List<Map<String, dynamic>>.from(
                                            widget.ticketTypes);
                                    updatedTickets.removeAt(index);
                                    widget.onTicketTypesUpdated(updatedTickets);
                                  },
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              // Expanded section for ticket-specific settings
              if (isExpanded)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Divider(color: AppColors.darkGray),
                      const SizedBox(height: 8),

                      // Ticket-specific waiver toggle
                      _buildToggleOption(
                        'Require Waiver',
                        ticket['requiresWaiver'] ?? false
                            ? 'Required'
                            : 'Not Required',
                        ticket['requiresWaiver'] ?? false,
                        (value) {
                          final updatedTickets =
                              List<Map<String, dynamic>>.from(
                                  widget.ticketTypes);
                          final updatedTicket =
                              Map<String, dynamic>.from(ticket);
                          updatedTicket['requiresWaiver'] = value;
                          updatedTickets[index] = updatedTicket;
                          widget.onTicketTypesUpdated(updatedTickets);
                        },
                      ),

                      // Ticket-specific registration questions toggle
                      const SizedBox(height: 16),
                      _buildToggleOption(
                        'Custom Questions',
                        ticket['hasCustomQuestions'] ?? false
                            ? 'Enabled'
                            : 'Disabled',
                        ticket['hasCustomQuestions'] ?? false,
                        (value) {
                          final updatedTickets =
                              List<Map<String, dynamic>>.from(
                                  widget.ticketTypes);
                          final updatedTicket =
                              Map<String, dynamic>.from(ticket);
                          updatedTicket['hasCustomQuestions'] = value;
                          updatedTickets[index] = updatedTicket;
                          widget.onTicketTypesUpdated(updatedTickets);
                        },
                      ),
                    ],
                  ),
                ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildQuestionsList() {
    if (widget.customQuestions.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.secondaryBlack.withOpacity(0.3),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: AppColors.darkGray.withOpacity(0.5),
          ),
        ),
        child: Column(
          children: [
            Icon(
              Icons.quiz_outlined,
              color: Colors.grey[500],
              size: 48,
            ),
            const SizedBox(height: 12),
            Text(
              'No custom questions added yet',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Add questions below to collect additional information',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Questions count header
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.quiz,
                color: Colors.white,
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(
                '${widget.customQuestions.length} Question${widget.customQuestions.length != 1 ? 's' : ''} Added',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // Questions list
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF2A2A2A),
                const Color(0xFF1A1A1A),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 0.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: widget.customQuestions.length,
            separatorBuilder: (context, index) => const Divider(
              color: AppColors.darkGray,
              height: 1,
            ),
            itemBuilder: (context, index) {
              final question = widget.customQuestions[index];
              final questionType = question['type'] == 'text'
                  ? 'Text'
                  : question['type'] == 'boolean'
                      ? 'Yes/No'
                      : 'Multiple Choice';

              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.secondaryBlack.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: AppColors.primaryOrange.withOpacity(0.2),
                  ),
                ),
                child: ListTile(
                  leading: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      gradient: AppColors.orangeGradient,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Center(
                      child: Text(
                        '${index + 1}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                  title: Text(
                    question['text'] ?? '',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.primaryOrange.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          questionType,
                          style: const TextStyle(
                            color: AppColors.primaryOrange,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      if (question['type'] == 'multiple_choice') ...[
                        const SizedBox(height: 4),
                        Text(
                          'Options: ${(question['options'] as List<String>).join(', ')}',
                          style: TextStyle(
                            color: Colors.grey[400],
                            fontSize: 12,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ],
                  ),
                  trailing: IconButton(
                    icon: Icon(Icons.delete_outline,
                        color: AppColors.primaryOrange),
                    onPressed: () {
                      final updatedQuestions = List<Map<String, dynamic>>.from(
                          widget.customQuestions);
                      updatedQuestions.removeAt(index);
                      widget.onCustomQuestionsUpdated(updatedQuestions);
                      _showSuccessMessage(
                          'Question removed. Total: ${updatedQuestions.length} questions');
                    },
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildAddQuestionForm() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Add New Question',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          // Question Text with icon in orange container
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: AppColors.orangeGradient,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.help_outline,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              const Padding(
                padding: EdgeInsets.only(top: 10),
                child: Text(
                  'Question Text',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Question text input field
          TextField(
            controller: widget.questionTextController,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Enter your question',
              hintStyle: TextStyle(color: Colors.grey[500]),
              filled: true,
              fillColor: AppColors.secondaryBlack,
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppColors.darkGray),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppColors.primaryOrange),
              ),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Question Type',
            style: TextStyle(color: Colors.white, fontSize: 16),
          ),
          const SizedBox(height: 12),
          // Question type selection with pill buttons
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildQuestionTypeChip(
                    context, 'Text Answer', 'text', _selectedQuestionType,
                    (type) {
                  setState(() => _selectedQuestionType = type);
                }),
                _buildQuestionTypeChip(
                    context, 'Yes/No', 'boolean', _selectedQuestionType,
                    (type) {
                  setState(() => _selectedQuestionType = type);
                }),
                _buildQuestionTypeChip(context, 'Multiple Choice',
                    'multiple_choice', _selectedQuestionType, (type) {
                  setState(() => _selectedQuestionType = type);
                }),
              ],
            ),
          ),
          if (_selectedQuestionType == 'multiple_choice') ...[
            const SizedBox(height: 16),
            _buildMultipleChoiceOptions(),
          ],
          const SizedBox(height: 20),
          // Add Question button with orange gradient
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: _canAddQuestion()
                  ? () {
                      // Validate question text
                      if (widget.questionTextController.text.trim().isEmpty) {
                        _showValidationMessage('Please enter a question text');
                        return;
                      }

                      final newQuestion = <String, dynamic>{
                        'text': widget.questionTextController.text.trim(),
                        'type': _selectedQuestionType,
                      };

                      // Validate multiple choice options
                      if (_selectedQuestionType == 'multiple_choice') {
                        final options =
                            _currentOptions.where((e) => e.isNotEmpty).toList();

                        if (options.length < 2) {
                          _showValidationMessage(
                              'Multiple choice questions need at least 2 options');
                          return;
                        }
                        newQuestion['options'] = options;
                      }

                      final updatedQuestions = List<Map<String, dynamic>>.from(
                          widget.customQuestions);
                      updatedQuestions.add(newQuestion);
                      widget.onCustomQuestionsUpdated(updatedQuestions);

                      // Clear controllers and show success
                      widget.questionTextController.clear();
                      widget.questionOptionsController.clear();
                      _clearAllOptions();

                      // Show enhanced success message with question details
                      final questionType = _selectedQuestionType == 'text'
                          ? 'Text'
                          : _selectedQuestionType == 'boolean'
                              ? 'Yes/No'
                              : 'Multiple Choice';
                      _showSuccessMessage(
                          '✅ $questionType question added! Total: ${updatedQuestions.length} questions');
                    }
                  : null,
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
              ),
              child: Ink(
                decoration: BoxDecoration(
                  gradient: _canAddQuestion() ? AppColors.orangeGradient : null,
                  color: _canAddQuestion() ? null : Colors.grey.shade700,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    'Add Question',
                    style: TextStyle(
                      color: _canAddQuestion()
                          ? Colors.white
                          : Colors.grey.shade400,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuestionTypeChip(BuildContext context, String label,
      String value, String selectedValue, Function(String) onSelected) {
    final isSelected = value == selectedValue;

    return GestureDetector(
      onTap: () => onSelected(value),
      child: Container(
        margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: isSelected ? AppColors.orangeGradient : null,
          color: isSelected ? null : AppColors.secondaryBlack,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color:
                isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey[400],
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildWaiverPreview() {
    // Sample waiver text based on selected template
    String previewText = '';

    switch (widget.selectedWaiverTemplate) {
      case 'Standard Sports Liability':
        previewText =
            'I understand and acknowledge that participation in sports activities involves inherent risks that may result in injury. I voluntarily assume all such risks and release the organizers from liability...';
        break;
      case 'Comprehensive Release':
        previewText =
            'I hereby release, waive, discharge and covenant not to sue the organizers, sponsors, their officers, agents, and employees from any and all liability, claims, demands, actions, and causes of action whatsoever...';
        break;
      case 'Youth Participation':
        previewText =
            'As the parent/guardian of the participant, I hereby consent to their participation and acknowledge the risks involved. I assume all risks and hazards incidental to such participation...';
        break;
      case 'Custom':
        previewText = widget.waiverTextController.text.isNotEmpty
            ? widget.waiverTextController.text
            : 'Custom waiver text will appear here...';
        break;
      default:
        previewText = 'No waiver template selected.';
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: AppColors.orangeGradient,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.preview_outlined,
                  color: Colors.white,
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'Waiver Preview',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.black26,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
                width: 0.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Text(
              previewText,
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 14,
              ),
              maxLines: 5,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWaiverTemplateSelector() {
    final waiverTemplates = [
      'Standard Sports Liability',
      'Comprehensive Release',
      'Youth Participation',
      'Custom'
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Select Waiver Template',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF2A2A2A),
                const Color(0xFF1A1A1A),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 0.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
            child: Row(
              children: waiverTemplates.map((template) {
                final isSelected = widget.selectedWaiverTemplate == template;
                return GestureDetector(
                  onTap: () => widget.onWaiverTemplateSelected(template),
                  child: Container(
                    margin: const EdgeInsets.only(right: 12),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.primaryOrange
                          : AppColors.secondaryBlack,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isSelected
                            ? AppColors.primaryOrange
                            : AppColors.darkGray,
                      ),
                    ),
                    child: Text(
                      template,
                      style: TextStyle(
                        color: isSelected ? Colors.white : Colors.grey[400],
                        fontWeight:
                            isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
        if (widget.selectedWaiverTemplate == 'Custom') ...[
          const SizedBox(height: 16),
          _buildFormField(
            label: 'Custom Waiver Text',
            controller: widget.waiverTextController,
            hintText: 'Enter your custom waiver text',
            icon: Icons.edit_note,
            maxLines: 5,
          ),
        ],
      ],
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.orange[400]!,
                Colors.deepOrange[700]!,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: Colors.white,
            size: 20,
          ),
        ),
        const SizedBox(width: 12),
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildToggleOption(
    String label,
    String value,
    bool isEnabled,
    Function(bool) onChanged,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 14,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Switch(
            value: isEnabled,
            onChanged: onChanged,
            activeColor: Colors.orange.shade400,
            activeTrackColor: Colors.orange.shade400.withOpacity(0.3),
          ),
        ],
      ),
    );
  }

  Widget _buildFormField({
    required String label,
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    String? prefix,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.orange.shade400,
                    Colors.deepOrange.shade600,
                  ],
                ),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                    color: Colors.orange.withOpacity(0.3),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Icon(
                icon,
                color: Colors.white,
                size: 16,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          style: const TextStyle(color: Colors.white),
          keyboardType: keyboardType,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: TextStyle(color: Colors.grey[600]),
            prefixText: prefix,
            prefixStyle: const TextStyle(color: Colors.white),
            filled: true,
            fillColor: const Color(0xFF1A1A1A),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.1)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.1)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.orange.shade400, width: 2),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDateSelector({
    required String label,
    required DateTime? selectedDate,
    required Function(DateTime) onDateSelected,
  }) {
    return Builder(
      builder: (BuildContext context) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.orange.shade400,
                        Colors.deepOrange.shade600,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.orange.withOpacity(0.3),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.calendar_today,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () async {
                final now = DateTime.now();
                final date = await showDatePicker(
                  context: context,
                  initialDate: selectedDate ?? now,
                  firstDate: now,
                  lastDate: now.add(const Duration(days: 365)),
                  builder: (BuildContext dialogContext, Widget? child) {
                    return Theme(
                      data: Theme.of(dialogContext).copyWith(
                        colorScheme: ColorScheme.dark(
                          primary: AppColors.orangeGradientEnd,
                          onPrimary: Colors.white,
                          surface: AppColors.secondaryBlack,
                          onSurface: Colors.white,
                        ),
                        dialogBackgroundColor: AppColors.secondaryBlack,
                      ),
                      child: child!,
                    );
                  },
                );
                if (date != null) {
                  onDateSelected(date);
                }
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      const Color(0xFF2A2A2A),
                      const Color(0xFF1A1A1A),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.08),
                    width: 0.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      selectedDate != null
                          ? '${selectedDate.day}/${selectedDate.month}/${selectedDate.year}'
                          : 'Select a date',
                      style: TextStyle(
                        color: selectedDate != null
                            ? Colors.white
                            : Colors.grey[600],
                      ),
                    ),
                    const Icon(
                      Icons.arrow_drop_down,
                      color: Colors.white,
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // Build modern multiple choice options interface
  Widget _buildMultipleChoiceOptions() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF2A2A2A),
            const Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with icon
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: AppColors.orangeGradient,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.list_alt,
                  color: Colors.white,
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'Multiple Choice Options',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Display existing options
          if (_currentOptions.isNotEmpty) ...[
            Column(
              children: _currentOptions.asMap().entries.map((entry) {
                final int index = entry.key;
                final String option = entry.value;

                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: AppColors.darkGray.withOpacity(0.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          color: AppColors.primaryOrange.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: Text(
                            '${index + 1}',
                            style: const TextStyle(
                              color: AppColors.primaryOrange,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          option,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => _removeOption(index),
                        icon: const Icon(
                          Icons.close,
                          color: AppColors.primaryOrange,
                          size: 18,
                        ),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(
                          minWidth: 24,
                          minHeight: 24,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
          ],

          // Add new option input
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: widget.questionOptionsController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Enter option text',
                    hintStyle: TextStyle(color: Colors.grey[500]),
                    filled: true,
                    fillColor: AppColors.secondaryBlack,
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: AppColors.darkGray),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: AppColors.primaryOrange),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                  ),
                  onSubmitted: (value) => _addOption(),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                decoration: BoxDecoration(
                  gradient: AppColors.orangeGradient,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primaryOrange.withOpacity(0.3),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: IconButton(
                  onPressed: _addOption,
                  icon: const Icon(
                    Icons.add,
                    color: Colors.white,
                    size: 20,
                  ),
                  padding: const EdgeInsets.all(8),
                  constraints: const BoxConstraints(
                    minWidth: 36,
                    minHeight: 36,
                  ),
                ),
              ),
            ],
          ),

          // Helper text
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _currentOptions.isEmpty
                      ? 'Add at least 2 options for multiple choice questions'
                      : _currentOptions.length == 1
                          ? 'Add 1 more option to complete the question'
                          : '${_currentOptions.length} options added',
                  style: TextStyle(
                    color: _currentOptions.length >= 2
                        ? AppColors.primaryOrange
                        : Colors.grey[500],
                    fontSize: 12,
                    fontWeight: _currentOptions.length >= 2
                        ? FontWeight.w500
                        : FontWeight.normal,
                  ),
                ),
                if (_currentOptions.length >= 2 && _questionText.trim().isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      'Scroll up to enter the question text',
                      style: TextStyle(
                        color: Colors.orange[300],
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Check if question can be added (validation)
  bool _canAddQuestion() {
    // Must have question text
    if (_questionText.trim().isEmpty) {
      // print('DEBUG: Question text is empty: "${_questionText}"');
      return false;
    }

    // For multiple choice, must have at least 2 options
    if (_selectedQuestionType == 'multiple_choice') {
      final options = _currentOptions.where((e) => e.isNotEmpty).toList();
      print(
          'DEBUG: Multiple choice - options count: ${options.length}, options: $options');
      return options.length >= 2;
    }

    // For other question types, just need question text
    print(
        'DEBUG: Question can be added - text: "${_questionText}", type: $_selectedQuestionType');
    return true;
  }

  // Add a new option to the list
  void _addOption() {
    final optionText = widget.questionOptionsController.text.trim();
    if (optionText.isNotEmpty && !_currentOptions.contains(optionText)) {
      setState(() {
        _currentOptions.add(optionText);
      });
      widget.questionOptionsController.clear();
    }
  }

  // Remove an option from the list
  void _removeOption(int index) {
    setState(() {
      if (index >= 0 && index < _currentOptions.length) {
        _currentOptions.removeAt(index);
      }
    });
  }

  // Clear all options
  void _clearAllOptions() {
    setState(() {
      _currentOptions.clear();
    });
    // Dispose all option controllers
    for (var controller in _optionControllers) {
      controller.dispose();
    }
    _optionControllers.clear();
  }

  // Show validation message to user
  void _showValidationMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.red.shade800,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.red.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              const Icon(
                Icons.error_outline,
                color: Colors.white,
                size: 20,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  message,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // Show success message to user
  void _showSuccessMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryOrange.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              const Icon(
                Icons.check_circle_outline,
                color: Colors.white,
                size: 20,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  message,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Widget _buildPricePicker() {
    return Container(
      height: 70,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF4A4A4A),
            const Color(0xFF3A3A3A),
            const Color(0xFF2A2A2A),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppColors.primaryOrange.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          // Decrease button
          GestureDetector(
            onTap: () {
              setState(() {
                if (_selectedPrice > 0) {
                  _selectedPrice = (_selectedPrice - 1).clamp(0, 999);
                  widget.ticketPriceController.text =
                      _selectedPrice.toStringAsFixed(0);
                }
              });
            },
            child: Container(
              width: 60,
              height: 70,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(16),
                  bottomLeft: Radius.circular(16),
                ),
              ),
              child: Icon(
                Icons.remove,
                color: Colors.white.withOpacity(0.8),
                size: 24,
              ),
            ),
          ),
          // Price display
          Expanded(
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '\$',
                      style: TextStyle(
                        color: AppColors.primaryOrange,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(width: 4),
                    GestureDetector(
                      onTap: () => _showPriceInputDialog(),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: AppColors.orangeGradient,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _selectedPrice == 0
                                  ? 'FREE'
                                  : _selectedPrice.toStringAsFixed(0),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 12,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Increase button
          GestureDetector(
            onTap: () {
              setState(() {
                _selectedPrice = (_selectedPrice + 1).clamp(0, 999);
                widget.ticketPriceController.text =
                    _selectedPrice.toStringAsFixed(0);
              });
            },
            child: Container(
              width: 60,
              height: 70,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                ),
              ),
              child: Icon(
                Icons.add,
                color: Colors.white.withOpacity(0.8),
                size: 24,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuantityPicker() {
    return Container(
      height: 70,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF4A4A4A),
            const Color(0xFF3A3A3A),
            const Color(0xFF2A2A2A),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppColors.primaryOrange.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          // Decrease button
          GestureDetector(
            onTap: () {
              setState(() {
                if (_selectedQuantity > 0) {
                  _selectedQuantity = (_selectedQuantity - 1).clamp(0, 9999);
                  widget.ticketQuantityController.text = _selectedQuantity == 0
                      ? ''
                      : _selectedQuantity.toString();
                }
              });
            },
            child: Container(
              width: 60,
              height: 70,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(16),
                  bottomLeft: Radius.circular(16),
                ),
              ),
              child: Icon(
                Icons.remove,
                color: Colors.white.withOpacity(0.8),
                size: 24,
              ),
            ),
          ),
          // Quantity display
          Expanded(
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.people_rounded,
                      color: AppColors.primaryOrange,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () => _showQuantityInputDialog(),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: AppColors.orangeGradient,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _selectedQuantity == 0
                                  ? '∞'
                                  : _selectedQuantity.toString(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 12,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Increase button
          GestureDetector(
            onTap: () {
              setState(() {
                _selectedQuantity = (_selectedQuantity + 1).clamp(0, 9999);
                widget.ticketQuantityController.text =
                    _selectedQuantity.toString();
              });
            },
            child: Container(
              width: 60,
              height: 70,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                ),
              ),
              child: Icon(
                Icons.add,
                color: Colors.white.withOpacity(0.8),
                size: 24,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showPriceInputDialog() {
    final TextEditingController priceController = TextEditingController(
      text: _selectedPrice == 0 ? '' : _selectedPrice.toStringAsFixed(0),
    );

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF3A3A3A),
                  const Color(0xFF2A2A2A),
                  const Color(0xFF1A1A1A),
                  const Color(0xFF0A0A0A),
                ],
                stops: const [0.0, 0.3, 0.7, 1.0],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: AppColors.primaryOrange.withOpacity(0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primaryOrange.withOpacity(0.2),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  blurRadius: 30,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header with icon
                Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        gradient: AppColors.orangeGradient,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.attach_money_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Enter Price',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                // Input field
                TextField(
                  controller: priceController,
                  keyboardType: TextInputType.number,
                  autofocus: true,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Enter price (0 for free)',
                    hintStyle: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 14,
                    ),
                    prefixText: '\$ ',
                    prefixStyle: TextStyle(
                      color: AppColors.primaryOrange,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.08),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: AppColors.primaryOrange,
                        width: 2,
                      ),
                    ),
                    contentPadding: const EdgeInsets.all(16),
                  ),
                ),
                const SizedBox(height: 24),
                // Action buttons
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        style: TextButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                            side: BorderSide(
                              color: Colors.white.withOpacity(0.2),
                            ),
                          ),
                        ),
                        child: const Text(
                          'Cancel',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          final double? newPrice =
                              double.tryParse(priceController.text);
                          if (newPrice != null && newPrice >= 0) {
                            setState(() {
                              _selectedPrice = newPrice.clamp(0, 999);
                              widget.ticketPriceController.text =
                                  _selectedPrice.toStringAsFixed(0);
                            });
                          }
                          Navigator.of(context).pop();
                        },
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ).copyWith(
                          backgroundColor:
                              MaterialStateProperty.all(Colors.transparent),
                        ),
                        child: Ink(
                          decoration: BoxDecoration(
                            gradient: AppColors.orangeGradient,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            alignment: Alignment.center,
                            child: const Text(
                              'Set Price',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showQuantityInputDialog() {
    final TextEditingController quantityController = TextEditingController(
      text: _selectedQuantity == 0 ? '' : _selectedQuantity.toString(),
    );

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF3A3A3A),
                  const Color(0xFF2A2A2A),
                  const Color(0xFF1A1A1A),
                  const Color(0xFF0A0A0A),
                ],
                stops: const [0.0, 0.3, 0.7, 1.0],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: AppColors.primaryOrange.withOpacity(0.3),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primaryOrange.withOpacity(0.2),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.8),
                  blurRadius: 30,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header with icon
                Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        gradient: AppColors.orangeGradient,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.people_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Enter Quantity',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                // Input field
                TextField(
                  controller: quantityController,
                  keyboardType: TextInputType.number,
                  autofocus: true,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Enter quantity (0 for unlimited)',
                    hintStyle: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 14,
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.08),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: AppColors.primaryOrange,
                        width: 2,
                      ),
                    ),
                    contentPadding: const EdgeInsets.all(16),
                  ),
                ),
                const SizedBox(height: 24),
                // Action buttons
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        style: TextButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                            side: BorderSide(
                              color: Colors.white.withOpacity(0.2),
                            ),
                          ),
                        ),
                        child: const Text(
                          'Cancel',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          final int? newQuantity =
                              int.tryParse(quantityController.text);
                          if (newQuantity != null && newQuantity >= 0) {
                            setState(() {
                              _selectedQuantity = newQuantity.clamp(0, 9999);
                              widget.ticketQuantityController.text =
                                  _selectedQuantity == 0
                                      ? ''
                                      : _selectedQuantity.toString();
                            });
                          } else if (quantityController.text.isEmpty) {
                            setState(() {
                              _selectedQuantity = 0;
                              widget.ticketQuantityController.text = '';
                            });
                          }
                          Navigator.of(context).pop();
                        },
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ).copyWith(
                          backgroundColor:
                              MaterialStateProperty.all(Colors.transparent),
                        ),
                        child: Ink(
                          decoration: BoxDecoration(
                            gradient: AppColors.orangeGradient,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            alignment: Alignment.center,
                            child: const Text(
                              'Set Quantity',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
