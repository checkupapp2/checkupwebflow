import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/domain/models/event_model.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';
import 'package:intl/intl.dart';

/// A modern card widget for displaying events with admin controls
class AdminEventCard extends StatelessWidget {
  /// The event to display
  final EventModel event;
  
  /// Callback when edit button is pressed
  final Function(EventModel)? onEdit;
  
  /// Callback when delete button is pressed
  final Function(EventModel)? onDelete;
  
  /// Callback when card is tapped
  final Function(EventModel) onTap;
  
  /// Callback when share button is pressed
  final Function(EventModel) onShare;

  /// Whether the user is hosting this event (determines if admin controls are shown)
  final bool isHosting;

  /// Creates an [AdminEventCard] widget
  const AdminEventCard({
    Key? key,
    required this.event,
    this.onEdit,
    this.onDelete,
    required this.onTap,
    required this.onShare,
    this.isHosting = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isUpcoming = event.dateTime.isAfter(DateTime.now());
    
    return GestureDetector(
      onTap: () => onTap(event),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCardHeader(isUpcoming),
            _buildCardBody(),
            _buildCardFooter(isUpcoming),
          ],
        ),
      ),
    );
  }

  Widget _buildCardHeader(bool isUpcoming) {
    return Stack(
      children: [
        // Event image or color background with icon
        ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
          child: event.bannerImageUrl != null
              ? Image.network(
                  event.bannerImageUrl!,
                  height: 120,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => _buildPlaceholder(),
                )
              : _buildPlaceholder(),
        ),
        
        // Status indicator
        Positioned(
          top: 12,
          left: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: isUpcoming ? Colors.green : Colors.grey,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              isUpcoming ? 'UPCOMING' : 'PAST',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
        ),
        
        // Event type badge
        Positioned(
          top: 12,
          right: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _getEventTypeColor(),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  _getEventTypeIcon(),
                  color: Colors.white,
                  size: 14,
                ),
                const SizedBox(width: 4),
                Text(
                  event.eventType.displayName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
        
        // Admin controls
        if (isHosting)
          Positioned(
            bottom: 0,
            right: 0,
            child: Row(
              children: [
                if (onEdit != null)
                  _buildAdminButton(
                    Icons.edit,
                    Colors.blue,
                    () => onEdit!(event),
                  ),
                if (onDelete != null)
                  _buildAdminButton(
                    Icons.delete,
                    Colors.red,
                    () => onDelete!(event),
                  ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      height: 120,
      width: double.infinity,
      color: _getEventTypeColor().withOpacity(0.3),
      child: Center(
        child: Icon(
          _getEventTypeIcon(),
          color: _getEventTypeColor(),
          size: 48,
        ),
      ),
    );
  }

  Widget _buildAdminButton(IconData icon, Color color, VoidCallback onPressed) {
    return Container(
      margin: const EdgeInsets.only(right: 8, bottom: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        shape: BoxShape.circle,
      ),
      child: IconButton(
        onPressed: onPressed,
        icon: Icon(icon, color: color),
        iconSize: 20,
        padding: const EdgeInsets.all(8),
        constraints: const BoxConstraints(
          minWidth: 36,
          minHeight: 36,
        ),
      ),
    );
  }

  Widget _buildCardBody() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      event.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    _buildInfoRow(
                      Icons.calendar_today,
                      '${_formatDate(event.dateTime)} at ${_formatTime(event.dateTime)}',
                    ),
                    const SizedBox(height: 4),
                    _buildInfoRow(
                      Icons.location_on,
                      event.location,
                    ),
                  ],
                ),
              ),
              _buildPriceTag(),
            ],
          ),
          const SizedBox(height: 12),
          _buildEventSpecificInfo(),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text) {
    return Row(
      children: [
        Icon(
          icon,
          color: Colors.grey,
          size: 16,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildPriceTag() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: event.isFree
            ? Colors.green.withOpacity(0.2)
            : Colors.orange.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: event.isFree ? Colors.green : Colors.orange,
        ),
      ),
      child: Text(
        event.isFree ? 'FREE' : '\$${event.price?.toStringAsFixed(2) ?? '0.00'}',
        style: TextStyle(
          color: event.isFree ? Colors.green : Colors.orange,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildEventSpecificInfo() {
    if (event is PickupRunEvent) {
      final pickupEvent = event as PickupRunEvent;
      return _buildInfoChips([
        '${pickupEvent.currentPlayers}/${pickupEvent.maxPlayers} Players',
        pickupEvent.skillLevel,
      ]);
    } else if (event is TournamentEvent) {
      final tournamentEvent = event as TournamentEvent;
      return _buildInfoChips([
        '${tournamentEvent.numberOfTeams} Teams',
        tournamentEvent.format,
        tournamentEvent.prizePool != null
            ? '\$${tournamentEvent.prizePool!.toStringAsFixed(0)} Prize'
            : null,
      ]);
    } else if (event is DonationEvent) {
      final donationEvent = event as DonationEvent;
      final goalPercentage = donationEvent.donationGoal > 0
          ? (donationEvent.currentAmount / donationEvent.donationGoal * 100).toStringAsFixed(0)
          : '0';
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'For: ${donationEvent.beneficiary}',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: donationEvent.donationGoal > 0
                        ? donationEvent.currentAmount / donationEvent.donationGoal
                        : 0,
                    backgroundColor: Colors.grey[800],
                    color: Colors.green,
                    minHeight: 8,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '$goalPercentage%',
                style: const TextStyle(
                  color: Colors.green,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      );
    }
    return const SizedBox.shrink();
  }

  Widget _buildInfoChips(List<String?> items) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: items
          .where((item) => item != null)
          .map((item) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.grey[800],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  item!,
                  style: TextStyle(
                    color: Colors.grey[300],
                    fontSize: 12,
                  ),
                ),
              ))
          .toList(),
    );
  }

  Widget _buildCardFooter(bool isUpcoming) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          OutlinedButton.icon(
            onPressed: () => onShare(event),
            icon: const Icon(Icons.share, size: 16),
            label: const Text('Share'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: const BorderSide(color: Colors.white),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
          if (isUpcoming)
            ElevatedButton.icon(
              onPressed: () => onTap(event),
              icon: const Icon(Icons.visibility, size: 16),
              label: const Text('Manage'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            )
          else
            OutlinedButton.icon(
              onPressed: () => onTap(event),
              icon: const Icon(Icons.bar_chart, size: 16),
              label: const Text('Analytics'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.blue,
                side: const BorderSide(color: Colors.blue),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
        ],
      ),
    );
  }

  String _formatDate(DateTime dateTime) {
    return DateFormat('MMM d, yyyy').format(dateTime);
  }

  String _formatTime(DateTime dateTime) {
    return DateFormat('h:mm a').format(dateTime);
  }

  IconData _getEventTypeIcon() {
    switch (event.eventType) {
      case EventType.pickupRun:
        return Icons.sports_basketball;
      case EventType.tournament:
        return Icons.emoji_events;
      case EventType.oneOff:
        return Icons.sports_score;
      case EventType.camp:
        return Icons.cabin;
      case EventType.training:
        return Icons.fitness_center;
      case EventType.donationBased:
        return Icons.volunteer_activism;
      case EventType.specialEvent:
        return Icons.star;
      case EventType.openGym:
        return Icons.sports_handball;
      case EventType.oneVsOne:
        return Icons.people;
    }
  }

  Color _getEventTypeColor() {
    switch (event.eventType) {
      case EventType.pickupRun:
        return Colors.orange;
      case EventType.tournament:
        return Colors.purple;
      case EventType.oneOff:
        return Colors.blue;
      case EventType.camp:
        return Colors.green;
      case EventType.training:
        return Colors.teal;
      case EventType.donationBased:
        return Colors.pink;
      case EventType.specialEvent:
        return Colors.amber;
      case EventType.openGym:
        return Colors.indigo;
      case EventType.oneVsOne:
        return Colors.red;
    }
  }
}
