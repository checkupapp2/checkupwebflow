import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/domain/models/event_model.dart';

/// A widget that displays event statistics in a dashboard-like header
class EventStatsHeader extends StatelessWidget {
  /// List of all events
  final List<EventModel> events;
  
  /// List of upcoming events
  final List<EventModel> upcomingEvents;
  
  /// List of past events
  final List<EventModel> pastEvents;
  
  /// Callback when add button is pressed
  final VoidCallback? onAddPressed;

  /// Creates an [EventStatsHeader] widget
  const EventStatsHeader({
    Key? key,
    required this.events,
    required this.upcomingEvents,
    required this.pastEvents,
    this.onAddPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Colors.grey.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Event Dashboard',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
              ),
              if (onAddPressed != null)
                OutlinedButton.icon(
                  onPressed: onAddPressed,
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Add Event'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.orange,
                    side: const BorderSide(color: Colors.orange, width: 1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    textStyle: const TextStyle(fontSize: 13),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              _buildStatCard(
                'Total Events',
                events.length.toString(),
                Icons.event,
                Colors.blue,
              ),
              const SizedBox(width: 12),
              _buildStatCard(
                'Upcoming',
                upcomingEvents.length.toString(),
                Icons.upcoming,
                Colors.green,
              ),
              const SizedBox(width: 12),
              _buildStatCard(
                'Past',
                pastEvents.length.toString(),
                Icons.history,
                Colors.orange,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: Colors.grey.withOpacity(0.1),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  icon,
                  color: color,
                  size: 16,
                ),
                const SizedBox(width: 6),
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
