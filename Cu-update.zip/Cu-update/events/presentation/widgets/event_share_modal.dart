import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../../core/theme/app_colors.dart';
import '../pages/host_event_detail_page.dart';

/// A modal bottom sheet that displays sharing options for an event
class EventShareModal extends StatelessWidget {
  /// The event ID to share
  final String eventId;
  
  /// The event title or content preview to share
  final String? eventContent;
  
  /// The URL to share
  final String? shareUrl;
  
  /// Callback when the modal is closed
  final VoidCallback? onClose;

  /// Constructor
  const EventShareModal({
    Key? key,
    required this.eventId,
    this.eventContent,
    this.shareUrl,
    this.onClose,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: AppColors.blackGradient,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildHeader(context),
              if (eventContent != null && eventContent!.isNotEmpty)
                _buildEventPreview(context),
              _buildConnectionsShareSection(context),
              _buildShareOptions(context),
              _buildAdditionalOptions(context),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildEventPreview(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.darkGray.withOpacity(0.3),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: AppColors.darkGray,
            width: 1,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: AppColors.orangeGradient,
                    ),
                    child: Center(
                      child: Icon(
                        Icons.event,
                        color: AppColors.white,
                        size: 14,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      shareUrl ?? 'https://checkup.app/event/$eventId',
                      style: TextStyle(
                        color: AppColors.lightGray,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              if (eventContent != null && eventContent!.isNotEmpty) ...[  
                const SizedBox(height: 8),
                Text(
                  eventContent!,
                  style: TextStyle(
                    color: AppColors.white,
                    fontSize: 14,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Column(
      children: [
        // Drag handle
        Container(
          margin: const EdgeInsets.only(top: 12, bottom: 8),
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        // Header with title and close button
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ShaderMask(
                shaderCallback: (bounds) => AppColors.orangeGradient.createShader(bounds),
                child: const Text(
                  'Share Event',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    Navigator.pop(context);
                    if (onClose != null) {
                      onClose!();
                    }
                  },
                  borderRadius: BorderRadius.circular(50),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppColors.darkGray.withOpacity(0.5),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.close,
                      color: AppColors.white,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildShareOptions(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 20, bottom: 12),
            child: Text(
              'Share to',
              style: TextStyle(
                color: AppColors.lightGray,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                _buildShareOption(
                  context,
                  'Messages',
                  Icons.message,
                  Colors.green,
                  () => _handleShare('messages'),
                ),
                _buildShareOption(
                  context,
                  'WhatsApp',
                  Icons.chat_bubble,
                  Colors.green,
                  () => _handleShare('whatsapp'),
                ),
                _buildShareOption(
                  context,
                  'Telegram',
                  Icons.send,
                  Colors.blue,
                  () => _handleShare('telegram'),
                ),
                _buildShareOption(
                  context,
                  'Instagram',
                  Icons.camera_alt,
                  Colors.purple,
                  () => _handleShare('instagram'),
                ),
                _buildShareOption(
                  context,
                  'Copy Link',
                  Icons.link,
                  Colors.orange,
                  () => _copyLink(context),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildConnectionsShareSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20, top: 16, bottom: 12),
          child: Text(
            'Share with',
            style: TextStyle(
              color: AppColors.lightGray,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        SizedBox(
          height: 100,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            scrollDirection: Axis.horizontal,
            children: [
              _buildConnectionShareItem(
                context: context,
                name: 'Friends',
                icon: Icons.people,
                gradient: AppColors.orangeGradient,
                onTap: () => _showConnectionsList(context, 'Friends'),
              ),
              _buildConnectionShareItem(
                context: context,
                name: 'Groups',
                icon: Icons.group_work,
                gradient: const LinearGradient(
                  colors: [Color(0xFF4CAF50), Color(0xFF2E7D32)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => _showConnectionsList(context, 'Groups'),
              ),
              _buildConnectionShareItem(
                context: context,
                name: 'Teams',
                icon: Icons.sports_basketball,
                gradient: const LinearGradient(
                  colors: [Color(0xFF2196F3), Color(0xFF0D47A1)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => _showConnectionsList(context, 'Teams'),
              ),
              _buildConnectionShareItem(
                context: context,
                name: 'Repost',
                icon: Icons.repeat,
                gradient: const LinearGradient(
                  colors: [Color(0xFFE040FB), Color(0xFF7B1FA2)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => _handleRepost(context),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildConnectionShareItem({
    required BuildContext context,
    required String name,
    required IconData icon,
    required Gradient gradient,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onTap,
              borderRadius: BorderRadius.circular(16),
              splashColor: AppColors.primaryOrange.withOpacity(0.2),
              child: Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  gradient: gradient,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Center(
                  child: Icon(
                    icon,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            name,
            style: TextStyle(
              color: AppColors.white,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShareOption(
    BuildContext context,
    String label,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onTap,
              borderRadius: BorderRadius.circular(50),
              splashColor: color.withOpacity(0.2),
              child: Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: AppColors.darkGray.withOpacity(0.5),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Icon(
                  icon,
                  color: color,
                  size: 24,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: AppColors.white,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
  
  void _showConnectionsList(BuildContext context, String type) {
    final List<Map<String, dynamic>> mockConnections = [
      {'id': '1', 'name': '${type == 'Teams' ? 'Chicago Bulls' : type == 'Groups' ? 'Pickup Games' : 'John Smith'}', 'avatar': null},
      {'id': '2', 'name': '${type == 'Teams' ? 'LA Lakers' : type == 'Groups' ? 'Weekend Warriors' : 'Sarah Johnson'}', 'avatar': null},
      {'id': '3', 'name': '${type == 'Teams' ? 'Brooklyn Nets' : type == 'Groups' ? 'Basketball Lovers' : 'Mike Williams'}', 'avatar': null},
    ];
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: BoxDecoration(
          gradient: AppColors.blackGradient,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Share event with $type',
                    style: TextStyle(
                      color: AppColors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.close, color: AppColors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            Divider(color: AppColors.darkGray),
            Expanded(
              child: ListView.builder(
                itemCount: mockConnections.length,
                itemBuilder: (context, index) {
                  final connection = mockConnections[index];
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppColors.primaryOrange,
                      child: Text(
                        connection['name'][0],
                        style: TextStyle(color: AppColors.white),
                      ),
                    ),
                    title: Text(
                      connection['name'],
                      style: TextStyle(color: AppColors.white),
                    ),
                    trailing: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _shareWithConnection(connection['id'], connection['name'], type);
                      },
                      style: ElevatedButton.styleFrom(
                        foregroundColor: AppColors.white,
                        backgroundColor: AppColors.primaryOrange,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      child: Text('Share'),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  void _shareWithConnection(String id, String name, String type) {
    print('Sharing event with $type: $name (ID: $id)');
  }
  
  void _handleRepost(BuildContext context) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Event shared to your feed'),
        backgroundColor: AppColors.darkGray,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Widget _buildAdditionalOptions(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20, top: 16, bottom: 8),
          child: Text(
            'Additional Options',
            style: TextStyle(
              color: AppColors.lightGray,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        _buildActionTile(
          context: context,
          icon: Icons.visibility_outlined,
          title: 'View event',
          onTap: () {
            Navigator.pop(context);
            _navigateToEventDetails(context);
          },
        ),
      ],
    );
  }
  
  Widget _buildActionTile({
    required BuildContext context,
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          splashColor: AppColors.primaryOrange.withOpacity(0.1),
          highlightColor: AppColors.primaryOrange.withOpacity(0.05),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        AppColors.darkGray.withOpacity(0.8),
                        AppColors.darkGray.withOpacity(0.4),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Icon(
                    icon,
                    color: AppColors.white,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 16),
                Text(
                  title,
                  style: TextStyle(
                    color: AppColors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _handleShare(String platform) {
    print('Sharing event to $platform: $eventId');
  }

  void _copyLink(BuildContext context) {
    final link = shareUrl ?? 'https://checkup.app/event/$eventId';
    Clipboard.setData(ClipboardData(text: link));
    
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Event link copied to clipboard'),
        backgroundColor: AppColors.darkGray,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _navigateToEventDetails(BuildContext context) {
    // Debug output
    print('🎯 Navigating to HostEventDetailPage with eventId: $eventId');
    print('🎯 Event content: $eventContent');
    
    // Extract title from event content
    final title = eventContent?.split(' - ').first ?? 'Event Details';
    print('🎯 Extracted title: $title');
    
    // Navigate to the host event details page
    try {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => HostEventDetailPage(
            eventId: eventId,
            title: title,
          ),
        ),
      );
      print('✅ Navigation to HostEventDetailPage initiated successfully');
    } catch (e) {
      print('❌ Error navigating to HostEventDetailPage: $e');
      // Fallback: show a snackbar with the error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Navigation error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  /// Shows the event share modal as a bottom sheet
  static Future<void> show({
    required BuildContext context,
    required String eventId,
    String? eventContent,
    String? shareUrl,
    VoidCallback? onClose,
  }) async {
    HapticFeedback.mediumImpact();
    
    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      enableDrag: true,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (context) => EventShareModal(
        eventId: eventId,
        eventContent: eventContent,
        shareUrl: shareUrl,
        onClose: onClose,
      ),
    ).then((_) {
      if (onClose != null) {
        onClose();
      }
    });
  }
}
