import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/domain/models/event_model.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';

/// A widget that displays analytics summary for events
class EventAnalyticsSummary extends StatelessWidget {
  /// List of all events
  final List<EventModel> events;

  /// Creates an [EventAnalyticsSummary] widget
  const EventAnalyticsSummary({
    Key? key,
    required this.events,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Calculate analytics data
    final eventsByType = _calculateEventsByType();
    final upcomingCount = events.where((e) => e.dateTime.isAfter(DateTime.now())).length;
    final pastCount = events.length - upcomingCount;
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Event Analytics',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          _buildEventDistributionBar(eventsByType),
          const SizedBox(height: 16),
          _buildLegend(eventsByType),
          const SizedBox(height: 16),
          _buildTimeDistribution(upcomingCount, pastCount),
        ],
      ),
    );
  }

  Map<EventType, int> _calculateEventsByType() {
    final result = <EventType, int>{};
    
    for (final event in events) {
      result[event.eventType] = (result[event.eventType] ?? 0) + 1;
    }
    
    return result;
  }

  Widget _buildEventDistributionBar(Map<EventType, int> eventsByType) {
    if (events.isEmpty) {
      return Container(
        height: 24,
        decoration: BoxDecoration(
          color: Colors.grey[800],
          borderRadius: BorderRadius.circular(12),
        ),
      );
    }
    
    final total = events.length;
    final segments = <Widget>[];
    
    eventsByType.forEach((type, count) {
      final percentage = count / total;
      segments.add(
        Flexible(
          flex: (percentage * 100).round(),
          child: Container(
            height: 24,
            decoration: BoxDecoration(
              color: _getEventTypeColor(type),
              borderRadius: segments.isEmpty
                  ? const BorderRadius.horizontal(left: Radius.circular(12))
                  : (segments.length == eventsByType.length - 1
                      ? const BorderRadius.horizontal(right: Radius.circular(12))
                      : null),
            ),
          ),
        ),
      );
    });
    
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Row(children: segments),
    );
  }

  Widget _buildLegend(Map<EventType, int> eventsByType) {
    return Wrap(
      spacing: 16,
      runSpacing: 8,
      children: eventsByType.entries.map((entry) {
        final type = entry.key;
        final count = entry.value;
        final percentage = (count / events.length * 100).toStringAsFixed(0);
        
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                color: _getEventTypeColor(type),
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 4),
            Text(
              '${type.displayName} ($percentage%)',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 12,
              ),
            ),
          ],
        );
      }).toList(),
    );
  }

  Widget _buildTimeDistribution(int upcomingCount, int pastCount) {
    final total = upcomingCount + pastCount;
    if (total == 0) return const SizedBox.shrink();
    
    final upcomingPercentage = upcomingCount / total;
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Time Distribution',
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Stack(
          children: [
            // Background
            Container(
              height: 8,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            // Upcoming portion
            FractionallySizedBox(
              widthFactor: upcomingPercentage,
              child: Container(
                height: 8,
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 4),
                Text(
                  'Upcoming (${(upcomingPercentage * 100).toStringAsFixed(0)}%)',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.grey[600],
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 4),
                Text(
                  'Past (${((1 - upcomingPercentage) * 100).toStringAsFixed(0)}%)',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Color _getEventTypeColor(EventType type) {
    switch (type) {
      case EventType.pickupRun:
        return Colors.orange;
      case EventType.tournament:
        return Colors.purple;
      case EventType.oneOff:
        return Colors.blue;
      case EventType.camp:
        return Colors.green;
      case EventType.training:
        return Colors.teal;
      case EventType.donationBased:
        return Colors.pink;
      case EventType.specialEvent:
        return Colors.amber;
      case EventType.openGym:
        return Colors.indigo;
      case EventType.oneVsOne:
        return Colors.red;
    }
  }
}
