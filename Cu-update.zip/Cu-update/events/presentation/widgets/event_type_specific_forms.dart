import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';

// Local abstractions (new small helpers)
import 'abstractions/event_type_specific_forms/field_builders.dart';
import 'abstractions/event_type_specific_forms/validators.dart';

import 'tournament_configuration.dart';

/// Widget that displays event type-specific forms based on the selected event type.
/// Now supports lightweight validation with per-field inline error messages.
class EventTypeSpecificForms extends StatefulWidget {
  final EventType eventType;
  final Map<String, dynamic> formData;
  final Function(Map<String, dynamic>) onFormDataChanged;
  final VoidCallback? onNextStep;
  final VoidCallback? onPreviousStep;

  /// Dates from the Create Event flow, used by Camp to compute number of days.
  final DateTime? startDateTime;
  final DateTime? endDateTime;

  const EventTypeSpecificForms({
    Key? key,
    required this.eventType,
    required this.formData,
    required this.onFormDataChanged,
    this.onNextStep,
    this.onPreviousStep,
    this.startDateTime,
    this.endDateTime,
  }) : super(key: key);

  @override
  State<EventTypeSpecificForms> createState() => _EventTypeSpecificFormsState();
}

class _EventTypeSpecificFormsState extends State<EventTypeSpecificForms>
    with TickerProviderStateMixin {
  late Map<String, dynamic> _formData;

  // Per-field error messages. null means no error.
  final Map<String, String?> _errors = {};

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _formData = Map<String, dynamic>.from(widget.formData);

    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    // Compute "numberOfDays" for Camp after first frame (dates come from parent)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _updateDaysFromDates();
    });

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic),
    );

    _animationController.forward();
  }

  @override
  void didUpdateWidget(EventTypeSpecificForms oldWidget) {
    super.didUpdateWidget(oldWidget);
    // If dates changed in the parent, recompute for Camp
    if (oldWidget.startDateTime != widget.startDateTime ||
        oldWidget.endDateTime != widget.endDateTime) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _updateDaysFromDates();
      });
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  // ---------- Validation helpers ----------
  void _setError(String key, String? message) {
    if (!mounted) return;
    setState(() => _errors[key] = message);
  }

  // ---------- Data helpers ----------
  void _updateFormData(String key, dynamic value) {
    if (!mounted) return;
    if (_formData[key] == value) return;
    setState(() {
      _formData[key] = value;
    });
    widget.onFormDataChanged(_formData);
  }

  // ---------- Camp day calculation ----------
  void _updateDaysFromDates() {
    if (!mounted) return;
    if (widget.startDateTime != null && widget.endDateTime != null) {
      final diff =
          widget.endDateTime!.difference(widget.startDateTime!).inDays + 1;
      _updateFormData('numberOfDays', diff.toString());
    } else if (widget.startDateTime != null) {
      _updateFormData('numberOfDays', '1');
    }
  }

  // ---------- UI ----------
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isTablet = width > 768;
    final isMobile = width < 600;

    return FadeTransition(
      opacity: _fadeAnimation,
      child: SlideTransition(
        position: _slideAnimation,
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: isMobile ? 16 : 24,
            vertical: 16,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(isMobile),
              SizedBox(height: isMobile ? 24 : 32),
              _buildEventTypeForm(isMobile, isTablet),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(bool isMobile) {
    return Container(
      padding: EdgeInsets.all(isMobile ? 20 : 24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF3A3A3A),
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
            Color(0xFF0A0A0A),
          ],
          stops: [0.0, 0.3, 0.7, 1.0],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
        boxShadow: [
          BoxShadow(
            color: Colors.white.withOpacity(0.03),
            blurRadius: 1,
            offset: const Offset(0, 1),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.orange.shade400, Colors.deepOrange.shade600],
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.3),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Icon(_getEventTypeIcon(), color: Colors.white, size: 22),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Configure your ${widget.eventType.displayName}',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isMobile ? 22 : 28,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _getEventTypeSubtitle(),
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: isMobile ? 14 : 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  IconData _getEventTypeIcon() {
    switch (widget.eventType) {
      case EventType.pickupRun:
      case EventType.openGym:
        return Icons.sports_basketball;
      case EventType.camp:
      case EventType.training:
        return Icons.school;
      case EventType.specialEvent:
      case EventType.oneOff:
        return Icons.star;
      case EventType.tournament:
        return Icons.emoji_events;
      case EventType.donationBased:
        return Icons.favorite;
      case EventType.oneVsOne:
        return Icons.person_4;
      default:
        return Icons.event;
    }
  }

  String _getEventTypeSubtitle() {
    switch (widget.eventType) {
      case EventType.pickupRun:
      case EventType.openGym:
        return 'Set up your casual basketball game';
      case EventType.camp:
        return 'Configure your basketball camp details';
      case EventType.training:
        return 'Configure your training session details';
      case EventType.specialEvent:
      case EventType.oneOff:
        return 'Make your special event memorable';
      case EventType.tournament:
        return 'Design your tournament structure';
      case EventType.donationBased:
        return 'Set up your charity fundraiser';
      case EventType.oneVsOne:
        return 'Configure your 1v1 matchup';
      default:
        return 'Set specific details for your event';
    }
  }

  Widget _buildEventTypeForm(bool isMobile, bool isTablet) {
    switch (widget.eventType) {
      case EventType.pickupRun:
      case EventType.openGym:
        return _buildRunsForm(isMobile);
      case EventType.camp:
        return _buildCampForm(isMobile);
      case EventType.training:
        return _buildTrainingForm(isMobile);
      case EventType.specialEvent:
      case EventType.oneOff:
        return _buildSpecialEventForm(isMobile);
      case EventType.tournament:
        return _buildTournamentForm();
      case EventType.donationBased:
        return _buildFundraiserForm(isMobile);
      case EventType.oneVsOne:
        return _buildOneVsOneForm(isMobile);
      default:
        return const SizedBox.shrink();
    }
  }

  // ---------- Pickup/Open Gym ----------
  Widget _buildRunsForm(bool isMobile) {
    return buildModernCard(
      isMobile: isMobile,
      title: 'Game Setup',
      subtitle: 'Configure your pickup game details',
      children: [
        buildModernFormField(
          label: 'Maximum Players',
          hint: 'e.g., 10',
          value: (_formData['maxPlayers']?.toString() ?? ''),
          onChanged: (text) {
            final err = validatePositiveInt(text, min: 2, max: 200);
            _setError('maxPlayers', err);
            // keep text when invalid; parse when valid
            if (err == null) {
              _updateFormData('maxPlayers', int.parse(text.trim()));
            } else {
              _updateFormData('maxPlayers', text);
            }
          },
          keyboardType: TextInputType.number,
          icon: Icons.group,
          isMobile: isMobile,
          errorText: _errors['maxPlayers'],
        ),
        SizedBox(height: isMobile ? 16 : 20),
        buildModernDropdownField(
          label: 'Skill Level Required',
          value: _formData['skillLevel'] as String?,
          items: const ['Beginner', 'Intermediate', 'Advanced', 'All Levels'],
          onChanged: (value) => _updateFormData('skillLevel', value),
          icon: Icons.trending_up,
          isMobile: isMobile,
        ),
        SizedBox(height: isMobile ? 16 : 20),
        buildModernSwitchField(
          label: 'Bring Your Own Ball',
          subtitle: 'Players should bring their own basketball',
          value: _formData['bringOwnBall'] as bool? ?? false,
          onChanged: (v) => _updateFormData('bringOwnBall', v),
          icon: Icons.sports_basketball,
          isMobile: isMobile,
        ),
      ],
    );
  }

  // ---------- Camp ----------
  Widget _buildCampForm(bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildModernCard(
          isMobile: isMobile,
          title: 'Camp Information',
          subtitle: 'Configure your basketball camp details',
          children: [
            buildModernDropdownField(
              label: 'Skill Level',
              value: _formData['skillLevel'] as String?,
              items: const [
                'All Skill Levels',
                'Beginner',
                'Intermediate',
                'Advanced',
                'Elite'
              ],
              onChanged: (value) => _updateFormData('skillLevel', value),
              icon: Icons.trending_up,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            _buildDaysComputedBox(isMobile),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernFormField(
              label: 'Age Range',
              hint: 'e.g., 8-16 years old',
              value: _formData['ageRange'] as String? ?? '',
              onChanged: (value) {
                _updateFormData('ageRange', value);
                _setError('ageRange', validateAgeRange(value));
              },
              icon: Icons.child_care,
              isMobile: isMobile,
              errorText: _errors['ageRange'],
            ),
          ],
        ),
        SizedBox(height: isMobile ? 20 : 24),
        buildModernCard(
          isMobile: isMobile,
          title: 'Daily Training Schedule',
          subtitle: 'Configure what happens each day of camp',
          children: _buildDynamicScheduleFields(isMobile),
        ),
      ],
    );
  }

  Widget _buildDaysComputedBox(bool isMobile) {
    final display = _getCalculatedDays();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.calendar_today, color: Colors.grey.shade400, size: 20),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Number of Days',
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                display,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Calculated from event dates',
                style: TextStyle(
                  color: Colors.grey.shade500,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getCalculatedDays() {
    if (widget.startDateTime != null && widget.endDateTime != null) {
      final diff =
          widget.endDateTime!.difference(widget.startDateTime!).inDays + 1;
      return '$diff days';
    }
    if (widget.startDateTime != null) return '1 day';
    final saved = _formData['numberOfDays'] as String?;
    if (saved != null && saved.isNotEmpty) return '$saved days';
    return '5 days (default)';
  }

  int _getNumberOfDays() {
    if (widget.startDateTime != null && widget.endDateTime != null) {
      return widget.endDateTime!.difference(widget.startDateTime!).inDays + 1;
    }
    if (widget.startDateTime != null) return 1;
    final saved = _formData['numberOfDays'] as String?;
    if (saved != null && saved.isNotEmpty) {
      return int.tryParse(saved) ?? 5;
    }
    return 5;
  }

  List<Widget> _buildDynamicScheduleFields(bool isMobile) {
    final days = _getNumberOfDays();
    final List<Widget> fields = [];

    final defaults = [
      'Fundamentals & Skills Assessment',
      'Shooting & Ball Handling',
      'Defense & Rebounding',
      'Team Play & Strategy',
      'Scrimmage & Awards',
      'Advanced Techniques',
      'Game Situations',
      'Final Tournament',
    ];

    for (int i = 1; i <= days; i++) {
      if (fields.isNotEmpty) fields.add(SizedBox(height: isMobile ? 12 : 16));
      final hint = i <= defaults.length
          ? 'e.g., ${defaults[i - 1]}'
          : 'e.g., Day $i Activities';
      final key = 'day${i}Activities';

      fields.add(Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Day $i',
            style: TextStyle(
              color: Colors.orange.shade300,
              fontSize: 14,
              fontWeight: FontWeight.w600,
              fontFamily: 'Montserrat',
            ),
          ),
          const SizedBox(height: 8),
          buildModernFormField(
            label: 'Activities',
            hint: hint,
            value: _formData[key] as String? ?? '',
            onChanged: (v) => _updateFormData(key, v),
            maxLines: 2,
            icon: Icons.schedule,
            isMobile: isMobile,
          ),
        ],
      ));
    }
    return fields;
  }

  // ---------- Training ----------
  Widget _buildTrainingForm(bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildModernCard(
          isMobile: isMobile,
          title: 'Training Setup',
          subtitle: 'Configure your training session details',
          children: [
            buildModernDropdownField(
              label: 'Training Focus',
              value: _formData['trainingFocus'] as String?,
              items: const [
                'Shooting',
                'Ball Handling',
                'Defense',
                'Conditioning',
                'Fundamentals',
                'Game Situations'
              ],
              onChanged: (v) => _updateFormData('trainingFocus', v),
              icon: Icons.fitness_center,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernDropdownField(
              label: 'Experience Level',
              value: _formData['experienceLevel'] as String?,
              items: const [
                'Youth (Under 12)',
                'Teen (13-17)',
                'Adult (18+)',
                'All Ages'
              ],
              onChanged: (v) => _updateFormData('experienceLevel', v),
              icon: Icons.bar_chart,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernFormField(
              label: 'Equipment Needed',
              hint: 'List any equipment participants should bring',
              value: _formData['equipmentNeeded'] as String? ?? '',
              onChanged: (v) => _updateFormData('equipmentNeeded', v),
              maxLines: 2,
              icon: Icons.sports,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernSwitchField(
              label: 'Certification Provided',
              subtitle: 'Will participants receive a certificate',
              value: _formData['certificationProvided'] as bool? ?? false,
              onChanged: (v) => _updateFormData('certificationProvided', v),
              icon: Icons.verified,
              isMobile: isMobile,
            ),
          ],
        ),
        SizedBox(height: isMobile ? 20 : 24),
        buildModernCard(
          isMobile: isMobile,
          title: 'Instructor Details',
          subtitle: 'Information about the training leader',
          children: [
            buildModernFormField(
              label: 'Instructor/Coach Name',
              hint: 'Who will be leading this training',
              value: _formData['instructorName'] as String? ?? '',
              onChanged: (v) => _updateFormData('instructorName', v),
              icon: Icons.person,
              isMobile: isMobile,
            ),
          ],
        ),
      ],
    );
  }

  // ---------- Special / One-off ----------
  Widget _buildSpecialEventForm(bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildModernCard(
          isMobile: isMobile,
          title: 'Event Configuration',
          subtitle: 'Make your special event memorable',
          children: [
            buildModernDropdownField(
              label: 'Event Category',
              value: _formData['eventCategory'] as String?,
              items: const [
                'Showcase',
                'Exhibition',
                'Community Event',
                'Celebrity Game',
                'Charity Match',
                'Awards Ceremony'
              ],
              onChanged: (v) => _updateFormData('eventCategory', v),
              icon: Icons.category,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernFormField(
              label: 'Special Guests',
              hint: 'Any special guests or featured players',
              value: _formData['specialGuests'] as String? ?? '',
              onChanged: (v) => _updateFormData('specialGuests', v),
              maxLines: 2,
              icon: Icons.star_border,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernSwitchField(
              label: 'Media Coverage',
              subtitle: 'Will this event be recorded or livestreamed',
              value: _formData['mediaCoverage'] as bool? ?? false,
              onChanged: (v) => _updateFormData('mediaCoverage', v),
              icon: Icons.videocam,
              isMobile: isMobile,
            ),
          ],
        ),
        SizedBox(height: isMobile ? 20 : 24),
        buildModernCard(
          isMobile: isMobile,
          title: 'Event Details',
          subtitle: 'Additional event specifications',
          children: [
            buildModernFormField(
              label: 'Dress Code',
              hint: 'Any specific attire requirements',
              value: _formData['dressCode'] as String? ?? '',
              onChanged: (v) => _updateFormData('dressCode', v),
              icon: Icons.checkroom,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernFormField(
              label: 'Awards/Prizes',
              hint: 'What awards or prizes will be given',
              value: _formData['awards'] as String? ?? '',
              onChanged: (v) => _updateFormData('awards', v),
              maxLines: 2,
              icon: Icons.emoji_events,
              isMobile: isMobile,
            ),
          ],
        ),
      ],
    );
  }

  // ---------- Tournament ----------
  Widget _buildTournamentForm() {
    return TournamentConfiguration(
      formData: _formData,
      onFormDataChanged: (data) {
        setState(() => _formData = data);
        widget.onFormDataChanged(_formData);
      },
      onNextStep: widget.onNextStep,
      onPreviousStep: widget.onPreviousStep,
    );
  }

  // ---------- Fundraiser ----------
  Widget _buildFundraiserForm(bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildModernCard(
          isMobile: isMobile,
          title: 'Fundraising Goals',
          subtitle: 'Set up your charity event details',
          children: [
            buildModernFormField(
              label: 'Fundraising Goal',
              hint: 'Target amount to raise',
              value: _formData['fundraisingGoal'] as String? ?? '',
              onChanged: (value) {
                final err = validateMoney(value);
                _setError('fundraisingGoal', err);
                _updateFormData('fundraisingGoal', value);
              },
              keyboardType: TextInputType.number,
              prefixText: '\$',
              icon: Icons.track_changes,
              isMobile: isMobile,
              errorText: _errors['fundraisingGoal'],
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernFormField(
              label: 'Beneficiary/Charity',
              hint: 'Who will receive the funds',
              value: _formData['beneficiary'] as String? ?? '',
              onChanged: (v) => _updateFormData('beneficiary', v),
              icon: Icons.volunteer_activism,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernFormField(
              label: 'Cause Description',
              hint: 'Describe the cause you are supporting',
              value: _formData['causeDescription'] as String? ?? '',
              onChanged: (v) => _updateFormData('causeDescription', v),
              maxLines: 3,
              icon: Icons.description,
              isMobile: isMobile,
            ),
          ],
        ),
        SizedBox(height: isMobile ? 20 : 24),
        buildModernCard(
          isMobile: isMobile,
          title: 'Sponsorship & Donations',
          subtitle: 'Configure donation and sponsorship options',
          children: [
            buildModernSwitchField(
              label: 'Accept Sponsorships',
              subtitle: 'Allow businesses to sponsor this event',
              value: _formData['acceptSponsorships'] as bool? ?? true,
              onChanged: (v) => _updateFormData('acceptSponsorships', v),
              icon: Icons.business,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernSwitchField(
              label: 'Provide Tax Receipts',
              subtitle: 'Issue tax-deductible donation receipts',
              value: _formData['provideTaxReceipts'] as bool? ?? false,
              onChanged: (v) => _updateFormData('provideTaxReceipts', v),
              icon: Icons.receipt,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernDropdownField(
              label: 'Donation Method',
              value: _formData['donationMethod'] as String?,
              items: const [
                'Entry Fee Donation',
                'Separate Donations',
                'Auction Items',
                'Raffle Tickets'
              ],
              onChanged: (v) => _updateFormData('donationMethod', v),
              icon: Icons.payment,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernFormField(
              label: 'Sponsor Recognition',
              hint: 'How will sponsors be recognized',
              value: _formData['sponsorRecognition'] as String? ?? '',
              onChanged: (v) => _updateFormData('sponsorRecognition', v),
              maxLines: 2,
              icon: Icons.campaign,
              isMobile: isMobile,
            ),
          ],
        ),
      ],
    );
  }

  // ---------- 1v1 ----------
  Widget _buildOneVsOneForm(bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildModernCard(
          isMobile: isMobile,
          title: 'Matchup Setup',
          subtitle: 'Configure your one-on-one game',
          children: [
            buildModernFormField(
              label: 'Opponent Name',
              hint: 'Who are you playing against',
              value: _formData['opponentName'] as String? ?? '',
              onChanged: (v) => _updateFormData('opponentName', v),
              icon: Icons.person_outline,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernDropdownField(
              label: 'Game Format',
              value: _formData['gameFormat'] as String?,
              items: const [
                'First to 11',
                'First to 15',
                'First to 21',
                'Timed Game (20 min)',
                'Best of 3 Games'
              ],
              onChanged: (v) => _updateFormData('gameFormat', v),
              icon: Icons.timer,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernFormField(
              label: 'Stakes/Prize',
              hint: 'What is on the line (optional)',
              value: _formData['stakes'] as String? ?? '',
              onChanged: (v) => _updateFormData('stakes', v),
              icon: Icons.emoji_events,
              isMobile: isMobile,
            ),
          ],
        ),
        SizedBox(height: isMobile ? 20 : 24),
        buildModernCard(
          isMobile: isMobile,
          title: 'Game Settings',
          subtitle: 'Additional matchup configurations',
          children: [
            buildModernSwitchField(
              label: 'Winner Take All',
              subtitle: 'Winner takes the entire prize or stakes',
              value: _formData['winnerTakeAll'] as bool? ?? false,
              onChanged: (v) => _updateFormData('winnerTakeAll', v),
              icon: Icons.military_tech,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernSwitchField(
              label: 'Allow Spectators',
              subtitle: 'Can people watch this matchup',
              value: _formData['allowSpectators'] as bool? ?? true,
              onChanged: (v) => _updateFormData('allowSpectators', v),
              icon: Icons.visibility,
              isMobile: isMobile,
            ),
            SizedBox(height: isMobile ? 16 : 20),
            buildModernFormField(
              label: 'Special Rules',
              hint: 'Any house rules or special conditions',
              value: _formData['specialRules'] as String? ?? '',
              onChanged: (v) => _updateFormData('specialRules', v),
              maxLines: 2,
              icon: Icons.rule,
              isMobile: isMobile,
            ),
          ],
        ),
      ],
    );
  }
}
