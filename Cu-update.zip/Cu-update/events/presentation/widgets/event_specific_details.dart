import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';

/// A widget that displays event-specific details based on event type
/// This is used in the pricing step to show details before the tickets section
class EventSpecificDetails extends StatelessWidget {
  /// The selected event type
  final EventType eventType;
  
  // Common fields
  /// Controller for maximum participants
  final TextEditingController? maxParticipantsController;
  
  /// Registration deadline
  final DateTime? registrationDeadline;
  
  /// Callback when registration deadline is selected
  final Function(DateTime)? onRegistrationDeadlineSelected;
  
  // Camp fields
  /// Controller for number of days (reusing numberOfTeamsController)
  final TextEditingController? numberOfDaysController;
  
  // Tournament fields
  /// Controller for number of teams
  final TextEditingController? numberOfTeamsController;
  
  /// Selected tournament format
  final String? selectedFormat;
  
  /// Callback when format is selected
  final Function(String)? onFormatSelected;
  
  /// Controller for prize pool
  final TextEditingController? prizePoolController;
  
  /// Whether the user wants to add teams now
  final bool? wantToAddTeams;
  
  /// Callback when the add teams toggle changes
  final Function(bool)? onWantToAddTeamsChanged;
  
  // Training fields
  /// Selected skill level
  final String? selectedSkillLevel;
  
  /// Callback when skill level is selected
  final Function(String)? onSkillLevelSelected;
  
  // Donation fields
  /// Controller for donation goal
  final TextEditingController? donationGoalController;
  
  /// Controller for beneficiary
  final TextEditingController? beneficiaryController;
  
  /// Whether tax receipts are available
  final bool? hasTaxReceipts;
  
  /// Callback when tax receipts status changes
  final Function(bool)? onTaxReceiptsChanged;
  
  // League Games fields
  /// Selected season
  final String? selectedSeason;
  
  /// Callback when season is selected
  final Function(String)? onSeasonSelected;
  
  /// Selected game type
  final String? selectedGameType;
  
  /// Callback when game type is selected
  final Function(String)? onGameTypeSelected;

  /// Creates an [EventSpecificDetails] widget
  const EventSpecificDetails({
    Key? key,
    required this.eventType,
    // Common fields
    this.maxParticipantsController,
    this.registrationDeadline,
    this.onRegistrationDeadlineSelected,
    // Camp fields
    this.numberOfDaysController,
    // Tournament fields
    this.numberOfTeamsController,
    this.selectedFormat,
    this.onFormatSelected,
    this.prizePoolController,
    this.wantToAddTeams,
    this.onWantToAddTeamsChanged,
    // Training fields
    this.selectedSkillLevel,
    this.onSkillLevelSelected,
    // Donation fields
    this.donationGoalController,
    this.beneficiaryController,
    this.hasTaxReceipts,
    this.onTaxReceiptsChanged,
    // League Games fields
    this.selectedSeason,
    this.onSeasonSelected,
    this.selectedGameType,
    this.onGameTypeSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    switch (eventType) {
      case EventType.camp:
        return _buildCampDetails(context);
      case EventType.training:
        return _buildTrainingDetails(context);
      case EventType.tournament:
        return _buildTournamentDetails(context);
      case EventType.donationBased:
        return _buildDonationDetails();
      case EventType.oneOff:
        return _buildLeagueGamesDetails(context);
      case EventType.pickupRun:
        return _buildPickupRunDetails();
      case EventType.specialEvent:
        return const SizedBox.shrink(); // No specific details for special events
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildCampDetails(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Camp Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Number of Days',
          controller: numberOfDaysController,
          keyboardType: TextInputType.number,
          hintText: 'Enter number of days',
          icon: Icons.calendar_today,
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Maximum Participants',
          controller: maxParticipantsController,
          keyboardType: TextInputType.number,
          hintText: 'Enter maximum number of participants',
          icon: Icons.group,
        ),
        const SizedBox(height: 16),
        _buildRegistrationDeadlinePicker(context),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildTrainingDetails(BuildContext context) {
    final skillLevels = ['Beginner', 'Intermediate', 'Advanced', 'All Levels'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Training Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Maximum Participants',
          controller: maxParticipantsController,
          keyboardType: TextInputType.number,
          hintText: 'Enter maximum number of participants',
          icon: Icons.group,
        ),
        const SizedBox(height: 20),
        const Text(
          'Skill Level',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: skillLevels.map((level) {
              final isSelected = selectedSkillLevel == level;
              
              return GestureDetector(
                onTap: () {
                  if (onSkillLevelSelected != null) {
                    onSkillLevelSelected!(level);
                  }
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    level,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildTournamentDetails(BuildContext context) {
    final formats = ['Single Elimination', 'Double Elimination', 'Round Robin'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Tournament Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Number of Teams',
          controller: numberOfTeamsController,
          keyboardType: TextInputType.number,
          hintText: 'Enter number of teams',
          icon: Icons.group,
        ),
        const SizedBox(height: 20),
        const Text(
          'Tournament Format',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: formats.map((format) {
              final isSelected = selectedFormat == format;
              
              return GestureDetector(
                onTap: () {
                  if (onFormatSelected != null) {
                    onFormatSelected!(format);
                  }
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    format,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 20),
        _buildFormField(
          label: 'Prize Pool',
          controller: prizePoolController,
          keyboardType: TextInputType.number,
          hintText: 'Enter prize pool amount',
          icon: Icons.attach_money,
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            const Text(
              'Add Teams Now',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(width: 12),
            Switch(
              value: wantToAddTeams ?? false,
              onChanged: (value) {
                if (onWantToAddTeamsChanged != null) {
                  onWantToAddTeamsChanged!(value);
                }
              },
            ),
          ],
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildDonationDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Donation Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Donation Goal',
          controller: donationGoalController,
          keyboardType: TextInputType.number,
          hintText: 'Enter donation goal amount',
          icon: Icons.attach_money,
        ),
        const SizedBox(height: 20),
        _buildFormField(
          label: 'Beneficiary',
          controller: beneficiaryController,
          keyboardType: TextInputType.text,
          hintText: 'Enter beneficiary name',
          icon: Icons.person,
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            const Text(
              'Tax Receipts Available',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(width: 12),
            Switch(
              value: hasTaxReceipts ?? false,
              onChanged: (value) {
                if (onTaxReceiptsChanged != null) {
                  onTaxReceiptsChanged!(value);
                }
              },
            ),
          ],
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildLeagueGamesDetails(BuildContext context) {
    final seasons = ['Spring', 'Summer', 'Fall', 'Winter'];
    final gameTypes = ['Soccer', 'Basketball', 'Volleyball', 'Tennis'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'League Games Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'Season',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: seasons.map((season) {
              final isSelected = selectedSeason == season;
              
              return GestureDetector(
                onTap: () {
                  if (onSeasonSelected != null) {
                    onSeasonSelected!(season);
                  }
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    season,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 20),
        const Text(
          'Game Type',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: gameTypes.map((gameType) {
              final isSelected = selectedGameType == gameType;
              
              return GestureDetector(
                onTap: () {
                  if (onGameTypeSelected != null) {
                    onGameTypeSelected!(gameType);
                  }
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    gameType,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildPickupRunDetails() {
    final skillLevels = ['Beginner', 'Intermediate', 'Advanced', 'All Levels'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Pickup Run Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Maximum Players',
          controller: maxParticipantsController,
          keyboardType: TextInputType.number,
          hintText: 'Enter maximum number of players',
          icon: Icons.group,
        ),
        const SizedBox(height: 20),
        const Text(
          'Skill Level',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: skillLevels.map((level) {
              final isSelected = selectedSkillLevel == level;
              
              return GestureDetector(
                onTap: () {
                  if (onSkillLevelSelected != null) {
                    onSkillLevelSelected!(level);
                  }
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    level,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildFormField({
    required String label,
    required TextEditingController? controller,
    required String hintText,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    String? prefix,
  }) {
    if (controller == null) return const SizedBox.shrink();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.secondaryBlack,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.darkGray),
          ),
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: hintText,
              hintStyle: TextStyle(color: Colors.grey[600]),
              prefixIcon: Icon(icon, color: Colors.grey),
              prefixText: prefix,
              prefixStyle: const TextStyle(color: Colors.white),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRegistrationDeadlinePicker(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Registration Deadline',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: () => _selectDate(context),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: AppColors.secondaryBlack,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.darkGray),
            ),
            child: Row(
              children: [
                const Icon(Icons.calendar_today, color: Colors.grey),
                const SizedBox(width: 12),
                Text(
                  registrationDeadline != null
                      ? _formatDate(registrationDeadline!)
                      : 'Select registration deadline',
                  style: TextStyle(
                    color: registrationDeadline != null ? Colors.white : Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    if (onRegistrationDeadlineSelected == null) return;
    
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: registrationDeadline ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.dark(
              primary: AppColors.orangeGradientStart,
              onPrimary: Colors.white,
              surface: AppColors.secondaryBlack,
              onSurface: Colors.white,
            ),
            dialogBackgroundColor: AppColors.primaryBlack,
          ),
          child: child!,
        );
      },
    );
    
    if (picked != null) {
      onRegistrationDeadlineSelected!(picked);
    }
  }

  String _formatDate(DateTime dateTime) {
    return '${dateTime.month}/${dateTime.day}/${dateTime.year}';
  }
}
