import 'package:flutter/material.dart';

String? validatePositiveInt(String value, {int min = 1, int max = 200}) {
  final n = int.tryParse(value.trim());
  if (n == null) return 'Enter a valid number';
  if (n < min) return 'Must be at least $min';
  if (n > max) return 'Must be ≤ $max';
  return null;
}

String? validateMoney(String value) {
  final cleaned = value.trim().replaceAll(',', '');
  final n = double.tryParse(cleaned);
  if (n == null) return 'Enter a valid amount';
  if (n < 0) return 'Must be ≥ 0';
  return null;
}

// Accepts "8-16", "8 – 16", "8 - 16", optionally with "years old"
String? validateAgeRange(String value) {
  final v = value.trim().toLowerCase();
  final reg = RegExp(
      r'^\s*(\d{1,2})\s*[-–]\s*(\d{1,2})(?:\s*(?:years?)?\s*(?:old)?)?\s*$');
  final m = reg.firstMatch(v);
  if (m == null) return 'Use format like 8-16';
  final min = int.parse(m.group(1)!);
  final max = int.parse(m.group(2)!);
  if (min < 3 || max > 80) return 'Keep ages between 3 and 80';
  if (min >= max) return 'Min must be less than max';
  return null;
}
