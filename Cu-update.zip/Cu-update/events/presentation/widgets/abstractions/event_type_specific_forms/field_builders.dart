import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';

Widget buildModernCard({
  required bool isMobile,
  required String title,
  required String subtitle,
  required List<Widget> children,
}) {
  return Container(
    width: double.infinity,
    padding: EdgeInsets.all(isMobile ? 20 : 24),
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFF3A3A3A),
          Color(0xFF2A2A2A),
          Color(0xFF1A1A1A),
          Color(0xFF0A0A0A),
        ],
        stops: [0.0, 0.3, 0.7, 1.0],
      ),
      borderRadius: BorderRadius.circular(isMobile ? 16 : 20),
      border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
      boxShadow: [
        BoxShadow(
          color: Colors.white.withOpacity(0.03),
          blurRadius: 1,
          offset: const Offset(0, 1),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(0.4),
          blurRadius: 12,
          offset: const Offset(0, 4),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: EdgeInsets.symmetric(
            horizontal: isMobile ? 12 : 16,
            vertical: isMobile ? 8 : 10,
          ),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.orange.shade400, Colors.deepOrange.shade600],
            ),
            borderRadius: BorderRadius.circular(isMobile ? 8 : 10),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.withOpacity(0.3),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Text(
            title,
            style: TextStyle(
              color: Colors.white,
              fontSize: isMobile ? 16 : 18,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ),
        SizedBox(height: isMobile ? 12 : 16),
        Text(
          subtitle,
          style: TextStyle(
            color: Colors.white.withOpacity(0.8),
            fontSize: isMobile ? 13 : 14,
            fontWeight: FontWeight.w400,
            letterSpacing: 0.2,
          ),
        ),
        SizedBox(height: isMobile ? 20 : 24),
        ...children,
      ],
    ),
  );
}

Widget buildModernFormField({
  required String label,
  required String hint,
  required String value,
  required Function(String) onChanged,
  required IconData icon,
  required bool isMobile,
  TextInputType? keyboardType,
  int maxLines = 1,
  String? prefixText,
  String? errorText,
}) {
  return Container(
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
      ),
      borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
      border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.3),
          blurRadius: 8,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(
            isMobile ? 16 : 20,
            isMobile ? 16 : 20,
            isMobile ? 16 : 20,
            8,
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.orange.shade400.withOpacity(0.3),
                      Colors.deepOrange.shade600.withOpacity(0.2),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  icon,
                  color: Colors.orange.shade400,
                  size: isMobile ? 16 : 18,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: isMobile ? 15 : 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: EdgeInsets.fromLTRB(
            isMobile ? 16 : 20,
            0,
            isMobile ? 16 : 20,
            isMobile ? 16 : 20,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: TextEditingController(text: value)
                  ..selection = TextSelection.fromPosition(
                    TextPosition(offset: value.length),
                  ),
                onChanged: onChanged,
                keyboardType: keyboardType,
                maxLines: maxLines,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: isMobile ? 15 : 16,
                ),
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: isMobile ? 14 : 15,
                  ),
                  prefixText: prefixText,
                  prefixStyle: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: isMobile ? 15 : 16,
                  ),
                  filled: true,
                  fillColor: Colors.transparent,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
                    borderSide:
                        BorderSide(color: Colors.orange.shade400, width: 2),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
                    borderSide: BorderSide(
                      color: Colors.white.withOpacity(0.2),
                      width: 1,
                    ),
                  ),
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: isMobile ? 14 : 16,
                    vertical: isMobile ? 12 : 14,
                  ),
                ),
              ),
              if (errorText != null) ...[
                const SizedBox(height: 6),
                Text(
                  errorText,
                  style: TextStyle(
                    color: Colors.redAccent.shade200,
                    fontSize: isMobile ? 12 : 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
    ),
  );
}

Widget buildModernDropdownField({
  required String label,
  required String? value,
  required List<String> items,
  required Function(String?) onChanged,
  required IconData icon,
  required bool isMobile,
}) {
  return Container(
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
      ),
      borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
      border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.3),
          blurRadius: 8,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(
            isMobile ? 16 : 20,
            isMobile ? 16 : 20,
            isMobile ? 16 : 20,
            8,
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.orange.shade400.withOpacity(0.3),
                      Colors.deepOrange.shade600.withOpacity(0.2),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  icon,
                  color: Colors.orange.shade400,
                  size: isMobile ? 16 : 18,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: isMobile ? 15 : 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: EdgeInsets.fromLTRB(
            isMobile ? 16 : 20,
            0,
            isMobile ? 16 : 20,
            isMobile ? 16 : 20,
          ),
          child: DropdownButtonFormField<String>(
            value: value,
            onChanged: onChanged,
            style: TextStyle(
              color: Colors.white,
              fontSize: isMobile ? 15 : 16,
            ),
            dropdownColor: AppColors.secondaryBlack,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
                borderSide: BorderSide(color: Colors.orange.shade400, width: 2),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
                borderSide: BorderSide(
                  color: Colors.white.withOpacity(0.2),
                  width: 1,
                ),
              ),
              contentPadding: EdgeInsets.symmetric(
                horizontal: isMobile ? 14 : 16,
                vertical: isMobile ? 12 : 14,
              ),
            ),
            items: items
                .map((item) => DropdownMenuItem<String>(
                      value: item,
                      child: Text(
                        item,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: isMobile ? 14 : 15,
                        ),
                      ),
                    ))
                .toList(),
          ),
        ),
      ],
    ),
  );
}

Widget buildModernSwitchField({
  required String label,
  required String subtitle,
  required bool value,
  required Function(bool) onChanged,
  required IconData icon,
  required bool isMobile,
}) {
  return Container(
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
      ),
      borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
      border: Border.all(
        color: value
            ? AppColors.primaryOrange.withOpacity(0.5)
            : AppColors.primaryOrange.withOpacity(0.2),
        width: value ? 2 : 1.5,
      ),
      boxShadow: [
        BoxShadow(
          color: value
              ? AppColors.primaryOrange.withOpacity(0.2)
              : AppColors.primaryOrange.withOpacity(0.1),
          blurRadius: value ? 12 : 8,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
        onTap: () => onChanged(!value),
        child: Padding(
          padding: EdgeInsets.all(isMobile ? 16 : 20),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: value
                      ? AppColors.primaryOrange.withOpacity(0.2)
                      : Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  icon,
                  color: value
                      ? AppColors.primaryOrange
                      : Colors.white.withOpacity(0.6),
                  size: isMobile ? 16 : 18,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: isMobile ? 15 : 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: isMobile ? 13 : 14,
                      ),
                    ),
                  ],
                ),
              ),
              Transform.scale(
                scale: isMobile ? 0.9 : 1.0,
                child: Switch(
                  value: value,
                  onChanged: onChanged,
                  activeColor: AppColors.primaryOrange,
                  activeTrackColor: AppColors.primaryOrange.withOpacity(0.3),
                  inactiveThumbColor: Colors.white.withOpacity(0.6),
                  inactiveTrackColor: Colors.white.withOpacity(0.2),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
