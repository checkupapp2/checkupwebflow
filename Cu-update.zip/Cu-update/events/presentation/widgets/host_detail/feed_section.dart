import 'package:flutter/material.dart';
import 'package:check_up_app/features/feed/presentation/widgets/create_post_widget.dart';
import 'package:check_up_app/features/feed/presentation/widgets/feed_post.dart';
import 'package:check_up_app/features/feed/domain/models/feed_post_model.dart';
import 'package:check_up_app/features/feed/data/feed_data_provider.dart';
import 'package:check_up_app/features/feed/presentation/widgets/share_modal.dart';

class FeedSection extends StatefulWidget {
  const FeedSection({super.key});

  @override
  State<FeedSection> createState() => _FeedSectionState();
}

class _FeedSectionState extends State<FeedSection> {
  late List<FeedPostModel> _feedPosts;

  @override
  void initState() {
    super.initState();
    final provider = FeedDataProvider();
    _feedPosts = provider.getFeedPosts();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Feed',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)),
            TextButton(
              onPressed: () {},
              child:
                  Text('See All', style: TextStyle(color: Colors.orange[400])),
            ),
          ],
        ),
        const SizedBox(height: 12),
        CreatePostWidget(
          placeholder: "What's happening?",
          profileImagePath: 'assets/images/main_btn.png',
          isAssetImage: true,
          onTap: () {},
          onCameraTap: () {},
        ),
        const SizedBox(height: 16),
        ..._feedPosts.map((post) => Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: FeedPost(
                post: post,
                onLikeTap: () {},
                onCommentTap: () {},
                onRepostTap: () {},
                onShareTap: () {
                  ShareModal.show(
                    context: context,
                    postId: post.id,
                    postContent: post.content,
                    shareUrl: 'https://checkup.app/posts/${post.id}',
                  );
                },
              ),
            )),
      ],
    );
  }
}
