import 'package:flutter/material.dart';

class EventActivitySection extends StatelessWidget {
  const EventActivitySection({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFF9800), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)]),
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              child: const Icon(Icons.people_alt_outlined,
                  color: Colors.white, size: 16),
            ),
            const SizedBox(width: 12),
            const Text('Event Activity',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Montserrat')),
          ]),
          const SizedBox(height: 12),
          Row(
            children: [
              Text('24 registered',
                  style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                      fontFamily: 'Montserrat')),
              const SizedBox(width: 8),
              Container(
                  width: 4,
                  height: 4,
                  decoration: BoxDecoration(
                      color: Colors.grey[600], shape: BoxShape.circle)),
              const SizedBox(width: 8),
              Text('8 spots left',
                  style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                      fontFamily: 'Montserrat')),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)]),
                  borderRadius: BorderRadius.all(Radius.circular(16)),
                ),
                child: const Text('Manage',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                        fontFamily: 'Montserrat')),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.zero,
            child: Row(
              children: const [
                _PlayerAvatar(
                    name: 'Michael J.', distance: '0.5 mi', isOnline: true),
                SizedBox(width: 12),
                _PlayerAvatar(
                    name: 'Kobe B.', distance: '1.2 mi', isOnline: true),
                SizedBox(width: 12),
                _PlayerAvatar(
                    name: 'LeBron J.', distance: '0.8 mi', isOnline: true),
                SizedBox(width: 12),
                _PlayerAvatar(
                    name: 'Stephen C.', distance: '1.5 mi', isOnline: false),
                SizedBox(width: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PlayerAvatar extends StatelessWidget {
  final String name;
  final String distance;
  final bool isOnline;

  const _PlayerAvatar(
      {required this.name, required this.distance, required this.isOnline});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 80,
      child: Column(
        children: [
          Stack(
            alignment: Alignment.bottomRight,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.orange, width: 2),
                  image: DecorationImage(
                    image: NetworkImage('https://i.pravatar.cc/150?u=$name'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              if (isOnline)
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                    border:
                        Border.all(color: const Color(0xFF1A1A1A), width: 2),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          Text(name,
              style: const TextStyle(color: Colors.white, fontSize: 12),
              textAlign: TextAlign.center),
          Text(distance,
              style: TextStyle(color: Colors.grey[500], fontSize: 10),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
