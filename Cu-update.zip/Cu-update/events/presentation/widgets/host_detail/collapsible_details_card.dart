// lib/features/events/presentation/widgets/host_detail/collapsible_details_card.dart
import 'package:flutter/material.dart';

class CollapsibleDetailsCard extends StatefulWidget {
  /// Preview text when collapsed (usually 1–2 lines).
  final String? previewText;

  /// Full detail text when expanded.
  final String? detailsText;

  /// Start expanded?
  final bool initiallyExpanded;

  const CollapsibleDetailsCard({
    super.key,
    this.previewText,
    this.detailsText,
    this.initiallyExpanded = false,
  });

  @override
  State<CollapsibleDetailsCard> createState() => _CollapsibleDetailsCardState();
}

class _CollapsibleDetailsCardState extends State<CollapsibleDetailsCard> {
  late bool _expanded;

  @override
  void initState() {
    super.initState();
    _expanded = widget.initiallyExpanded;
  }

  @override
  Widget build(BuildContext context) {
    // Exact same UI; just use provided text if available, else fallback to the original placeholder copy.
    final preview = (widget.previewText != null &&
            widget.previewText!.trim().isNotEmpty)
        ? widget.previewText!.trim()
        : 'Join us for an exciting 3v3 basketball tournament at the legendary Rucker Park! This event is perfect for players of all skill levels.';

    final details =
        (widget.detailsText != null && widget.detailsText!.trim().isNotEmpty)
            ? widget.detailsText!.trim()
            : '''
Join us for an exciting 3v3 basketball tournament at the legendary Rucker Park! This event is perfect for players of all skill levels looking to compete in a fun, energetic environment.

Tournament Format:
• Single elimination bracket
• 10-minute games
• First team to 21 points wins
• Win by 2 points
• 1 and 2-point scoring

Prizes:
• 1st Place: \$300 + Championship Trophies
• 2nd Place: \$150
• MVP Award: Custom Basketball
''';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFF9800), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(8)),
                    ),
                    child: const Icon(Icons.description_outlined,
                        color: Colors.white, size: 16),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'Event Details',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Montserrat',
                    ),
                  ),
                ]),
                Icon(
                  _expanded
                      ? Icons.keyboard_arrow_up
                      : Icons.keyboard_arrow_down,
                  color: Colors.orange,
                ),
              ],
            ),
          ),

          // Content
          AnimatedCrossFade(
            firstChild: Container(
              margin: const EdgeInsets.only(top: 12),
              child: Text(
                preview,
                style: TextStyle(
                  color: Colors.grey[300],
                  fontSize: 14,
                  height: 1.5,
                  fontFamily: 'Montserrat',
                ),
              ),
            ),
            secondChild: Container(
              margin: const EdgeInsets.only(top: 12),
              child: _RichDetails(details: details),
            ),
            crossFadeState: _expanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 300),
          ),

          if (!_expanded)
            Container(
              margin: const EdgeInsets.only(top: 8),
              child: const Text(
                'Tap to see more details...',
                style: TextStyle(
                  color: Colors.orange,
                  fontSize: 12,
                  fontStyle: FontStyle.italic,
                  fontFamily: 'Montserrat',
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Keeps the exact styling of your original expanded content block.
/// It prints headings in white bold, body lines in grey.
/// If a caller passes a custom detailsText, we render it as a single grey block
/// while preserving the same visual tone.
class _RichDetails extends StatelessWidget {
  final String details;
  const _RichDetails({required this.details});

  bool get _isDefaultBlock =>
      details.contains('Tournament Format:') && details.contains('Prizes:');

  @override
  Widget build(BuildContext context) {
    if (!_isDefaultBlock) {
      // Custom details: render as one block, same typography.
      return Text(
        details,
        style: const TextStyle(
          color: Colors.grey,
          fontSize: 14,
          height: 1.5,
          fontFamily: 'Montserrat',
        ),
      );
    }

    // Default structured block (exact same look)
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Join us for an exciting 3v3 basketball tournament at the legendary Rucker Park! This event is perfect for players of all skill levels looking to compete in a fun, energetic environment.',
          style: TextStyle(
            color: Colors.grey,
            fontSize: 14,
            height: 1.5,
            fontFamily: 'Montserrat',
          ),
        ),
        SizedBox(height: 12),
        Text(
          'Tournament Format:',
          style: TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.bold,
            fontFamily: 'Montserrat',
          ),
        ),
        SizedBox(height: 8),
        Text(
          '• Single elimination bracket\n• 10-minute games\n• First team to 21 points wins\n• Win by 2 points\n• 1 and 2-point scoring',
          style: TextStyle(
            color: Colors.grey,
            fontSize: 14,
            height: 1.5,
            fontFamily: 'Montserrat',
          ),
        ),
        SizedBox(height: 12),
        Text(
          'Prizes:',
          style: TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.bold,
            fontFamily: 'Montserrat',
          ),
        ),
        SizedBox(height: 8),
        Text(
          '• 1st Place: \$300 + Championship Trophies\n• 2nd Place: \$150\n• MVP Award: Custom Basketball',
          style: TextStyle(
            color: Colors.grey,
            fontSize: 14,
            height: 1.5,
            fontFamily: 'Montserrat',
          ),
        ),
        SizedBox(height: 12),
        Text(
          'Tap to see less...',
          style: TextStyle(
            color: Colors.orange,
            fontSize: 12,
            fontStyle: FontStyle.italic,
            fontFamily: 'Montserrat',
          ),
        ),
      ],
    );
  }
}
