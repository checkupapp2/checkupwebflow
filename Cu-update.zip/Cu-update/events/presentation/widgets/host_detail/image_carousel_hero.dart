// lib/features/events/presentation/widgets/host_detail/image_carousel_hero.dart
import 'dart:async';
import 'package:flutter/material.dart';

class ImageCarouselHero extends StatefulWidget {
  /// Optional image URLs from DB; falls back to sample images if empty.
  final List<String>? images;

  /// Small pill at the bottom-left (e.g., "3v3 Tournament").
  final String gameTypeText;

  /// Auto-scroll interval.
  final Duration interval;

  const ImageCarouselHero({
    super.key,
    this.images,
    this.gameTypeText = '3v3 Tournament',
    this.interval = const Duration(seconds: 5),
  });

  @override
  State<ImageCarouselHero> createState() => _ImageCarouselHeroState();
}

class _ImageCarouselHeroState extends State<ImageCarouselHero> {
  late final PageController _pageController;
  int _currentPage = 0;
  Timer? _timer;

  static const _fallbackImages = <String>[
    'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=1000',
    'https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=1000',
    'https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=1000',
    'https://images.unsplash.com/photo-1505666287802-931dc83a5dc7?q=80&w=1000',
  ];

  List<String> get _images {
    final list =
        (widget.images ?? []).where((e) => e.trim().isNotEmpty).toList();
    return list.isNotEmpty ? list : _fallbackImages;
  }

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: 0);
    _timer = Timer.periodic(widget.interval, (_) {
      if (!mounted) return;
      final len = _images.length;
      if (len == 0) return;
      _currentPage = (_currentPage + 1) % len;
      if (_pageController.hasClients) {
        _pageController.animateToPage(
          _currentPage,
          duration: const Duration(milliseconds: 800),
          curve: Curves.easeInOut,
        );
      }
      setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final images = _images;

    return AspectRatio(
      aspectRatio: 1.0,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Stack(
          children: [
            PageView.builder(
              controller: _pageController,
              onPageChanged: (page) => setState(() => _currentPage = page),
              itemCount: images.length,
              itemBuilder: (_, index) => Image.network(
                images[index],
                fit: BoxFit.cover,
                loadingBuilder: (_, child, loadingProgress) =>
                    loadingProgress == null
                        ? child
                        : Container(
                            color: Colors.grey[900],
                            child: const Center(
                              child: CircularProgressIndicator(
                                  color: Colors.orange),
                            ),
                          ),
                errorBuilder: (_, __, ___) => Container(
                  color: Colors.grey[900],
                  child: const Center(
                    child: Icon(Icons.error_outline,
                        color: Colors.orange, size: 50),
                  ),
                ),
              ),
            ),

            // Bottom gradient
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              height: 100,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black.withOpacity(0.8), Colors.transparent],
                  ),
                ),
              ),
            ),

            // HOST badge (top-left)
            Positioned(
              top: 16,
              left: 16,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      blurRadius: 10,
                      spreadRadius: 1,
                      offset: const Offset(0, 3),
                    ),
                  ],
                  border: Border.all(
                      color: Colors.white.withOpacity(0.3), width: 1),
                ),
                child: const Text(
                  'HOST',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    letterSpacing: 0.8,
                    shadows: [
                      Shadow(
                          offset: Offset(0, 1),
                          blurRadius: 2,
                          color: Color(0x80000000)),
                    ],
                  ),
                ),
              ),
            ),

            // Game-type pill (bottom-left)
            Positioned(
              bottom: 16,
              left: 16,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  widget.gameTypeText,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ),

            // Dots
            Positioned(
              bottom: 16,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(images.length, (i) {
                  final isActive = _currentPage == i;
                  return Container(
                    width: 8,
                    height: 8,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isActive
                          ? Colors.orange
                          : Colors.white.withOpacity(0.5),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
