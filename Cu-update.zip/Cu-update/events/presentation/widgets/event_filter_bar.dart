import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';

/// A widget that displays advanced filtering options for events
class EventFilterBar extends StatelessWidget {
  /// Currently selected filter
  final String? selectedFilter;
  
  /// Callback when a filter is selected
  final Function(String?) onFilterSelected;
  
  /// Callback when sort button is pressed
  final VoidCallback onSortPressed;
  
  /// Callback when search button is pressed
  final VoidCallback onSearchPressed;

  /// Creates an [EventFilterBar] widget
  const EventFilterBar({
    Key? key,
    this.selectedFilter,
    required this.onFilterSelected,
    required this.onSortPressed,
    required this.onSearchPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildFilterChip('All', null),
                  _buildFilterChip('Pickup', EventType.pickupRun.name),
                  _buildFilterChip('Tournament', EventType.tournament.name),
                  _buildFilterChip('Tournament', EventType.tournament.name),
                  _buildFilterChip('Camp', EventType.camp.name),
                  _buildFilterChip('Training', EventType.training.name),
                  _buildFilterChip('Charity', EventType.donationBased.name),
                  _buildFilterChip('Special', EventType.specialEvent.name),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          _buildIconButton(Icons.sort, onSortPressed),
          const SizedBox(width: 8),
          _buildIconButton(Icons.search, onSearchPressed),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, String? filterValue) {
    final bool isSelected = selectedFilter == filterValue;
    
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        selected: isSelected,
        label: Text(label),
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : Colors.grey[300],
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
        backgroundColor: Colors.grey[800],
        selectedColor: Colors.orange,
        checkmarkColor: Colors.white,
        onSelected: (_) => onFilterSelected(filterValue),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 4),
      ),
    );
  }
  
  Widget _buildIconButton(IconData icon, VoidCallback onPressed) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[850],
        borderRadius: BorderRadius.circular(8),
      ),
      child: IconButton(
        onPressed: onPressed,
        icon: Icon(
          icon,
          color: Colors.grey[400],
        ),
        iconSize: 20,
        constraints: const BoxConstraints(
          minWidth: 40,
          minHeight: 40,
        ),
        padding: EdgeInsets.zero,
      ),
    );
  }
}
