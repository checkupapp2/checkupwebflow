import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';

/// A utility class that provides styling information for event cards based on event type
class EventTypeCardStyle {
  /// Get the appropriate icon for an event type
  static IconData getIconForType(EventType type) {
    switch (type) {
      case EventType.pickupRun:
        return Icons.sports_basketball;
      case EventType.tournament:
        return Icons.emoji_events;
      case EventType.oneOff:
        return Icons.event;
      case EventType.camp:
        return Icons.school;
      case EventType.training:
        return Icons.fitness_center;
      case EventType.donationBased:
        return Icons.volunteer_activism;
      case EventType.specialEvent:
        return Icons.celebration;
      case EventType.oneVsOne:
        return Icons.people;
      case EventType.openGym:
        return Icons.sports_handball;
    }
  }

  /// Get the appropriate accent color for an event type - always orange for consistency
  static Color getAccentColorForType(EventType type) {
    // Using orange for all event types as requested
    return Colors.orange;
  }

  /// Get the appropriate gradient for an event type - always orange gradient for consistency
  static LinearGradient getGradientForType(EventType type) {
    // Using orange gradient for all event types as requested
    return LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Colors.orange[400]!,
        Colors.deepOrange[700]!,
      ],
    );
  }

  /// Get the appropriate background decoration for the event type pill - always orange-based for consistency
  static BoxDecoration getPillDecorationForType(EventType type) {
    // Using orange-based decoration for all event types as requested
    return BoxDecoration(
      color: Colors.black.withOpacity(0.7),
      borderRadius: BorderRadius.circular(20),
    );
  }
}
