import 'package:flutter/material.dart';
import 'dart:math';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:check_up_app/features/events/domain/models/event_type.dart';
import 'package:check_up_app/features/search/domain/models/team_model.dart';

/// A widget that displays form fields specific to the selected event type
class DynamicEventFormFields extends StatefulWidget {
  /// The selected event type
  final EventType eventType;
  
  // Pickup Run fields
  /// Controller for max players
  final TextEditingController? maxPlayersController;
  
  /// Selected skill level
  final String? selectedSkillLevel;
  
  /// Callback when skill level is selected
  final Function(String)? onSkillLevelSelected;
  
  // Tournament fields
  /// Controller for number of teams
  final TextEditingController? numberOfTeamsController;
  
  /// Selected tournament format
  final String? selectedFormat;
  
  /// Callback when format is selected
  final Function(String)? onFormatSelected;
  
  /// Controller for prize pool
  final TextEditingController? prizePoolController;
  
  /// Selected registration deadline
  final DateTime? registrationDeadline;
  
  /// Callback when registration deadline is selected
  final Function(DateTime)? onRegistrationDeadlineSelected;
  
  /// Whether the user wants to add teams now
  final bool? wantToAddTeams;
  
  /// Callback when the add teams toggle changes
  final Function(bool)? onWantToAddTeamsChanged;
  
  /// Whether to use manual team input instead of search
  final bool? useManualTeamInput;
  
  /// Callback when the manual team input toggle changes
  final Function(bool)? onUseManualTeamInputChanged;
  
  /// List of selected teams
  final List<TeamModel>? selectedTeams;
  
  /// Callback when teams are selected
  final Function(List<TeamModel>)? onTeamsSelected;
  
  // One-on-One fields
  /// Controller for player 1
  final TextEditingController? player1Controller;
  
  /// Controller for player 2
  final TextEditingController? player2Controller;
  
  /// Selected game format
  final String? selectedGameFormat;
  
  /// Callback when game format is selected
  final Function(String)? onGameFormatSelected;
  
  // Donation fields
  /// Controller for donation goal
  final TextEditingController? donationGoalController;
  
  /// Controller for beneficiary
  final TextEditingController? beneficiaryController;
  
  /// Whether tax receipts are available
  final bool? hasTaxReceipts;
  
  /// Callback when tax receipts status changes
  final Function(bool)? onTaxReceiptsChanged;

  /// Creates a [DynamicEventFormFields] widget
  const DynamicEventFormFields({
    Key? key,
    required this.eventType,
    // Pickup Run fields
    this.maxPlayersController,
    this.selectedSkillLevel,
    this.onSkillLevelSelected,
    // Tournament fields
    this.numberOfTeamsController,
    this.selectedFormat,
    this.onFormatSelected,
    this.prizePoolController,
    this.registrationDeadline,
    this.onRegistrationDeadlineSelected,
    // Team selection fields
    this.wantToAddTeams,
    this.onWantToAddTeamsChanged,
    this.useManualTeamInput,
    this.onUseManualTeamInputChanged,
    this.selectedTeams,
    this.onTeamsSelected,
    // One-on-One fields
    this.player1Controller,
    this.player2Controller,
    this.selectedGameFormat,
    this.onGameFormatSelected,
    // Donation fields
    this.donationGoalController,
    this.beneficiaryController,
    this.hasTaxReceipts,
    this.onTaxReceiptsChanged,
  }) : super(key: key);
  
  @override
  State<DynamicEventFormFields> createState() => _DynamicEventFormFieldsState();
}

class _DynamicEventFormFieldsState extends State<DynamicEventFormFields> {
  // Mock team data for search results
  final List<TeamModel> _mockTeams = [
    TeamModel(
      id: '1',
      name: 'Chicago Bulls',
      handle: '@chicagobulls',
      logoUrl: 'https://content.sportslogos.net/logos/6/221/thumbs/hj3gmh82w9hffmeh3fjm5h874.gif',
      description: 'Professional basketball team based in Chicago',
      membersCount: 15,
      followers: 2500,
      sport: 'Basketball',
      location: 'Chicago, IL',
      isFollowing: false,
    ),
    TeamModel(
      id: '2',
      name: 'LA Lakers',
      handle: '@lalakers',
      logoUrl: 'https://content.sportslogos.net/logos/6/237/thumbs/uig7aiht8jnpl1szbi57zzlsh.gif',
      description: 'Professional basketball team based in Los Angeles',
      membersCount: 14,
      followers: 3200,
      sport: 'Basketball',
      location: 'Los Angeles, CA',
      isFollowing: true,
    ),
    TeamModel(
      id: '3',
      name: 'Golden State Warriors',
      handle: '@warriors',
      logoUrl: 'https://content.sportslogos.net/logos/6/235/thumbs/23531522020.gif',
      description: 'Professional basketball team based in San Francisco',
      membersCount: 15,
      followers: 2800,
      sport: 'Basketball',
      location: 'San Francisco, CA',
      isFollowing: false,
    ),
    TeamModel(
      id: '4',
      name: 'Miami Heat',
      handle: '@miamiheat',
      logoUrl: 'https://content.sportslogos.net/logos/6/214/thumbs/burm5gh2wvjti3xhei5h16k8e.gif',
      description: 'Professional basketball team based in Miami',
      membersCount: 14,
      followers: 2100,
      sport: 'Basketball',
      location: 'Miami, FL',
      isFollowing: false,
    ),
    TeamModel(
      id: '5',
      name: 'Boston Celtics',
      handle: '@celtics',
      logoUrl: 'https://content.sportslogos.net/logos/6/213/thumbs/slhg02hbef3j1ov4lsnwyol5o.gif',
      description: 'Professional basketball team based in Boston',
      membersCount: 15,
      followers: 2700,
      sport: 'Basketball',
      location: 'Boston, MA',
      isFollowing: true,
    ),
  ];
  
  // State variables for team search and selection
  List<TeamModel> _filteredTeams = [];
  String _searchQuery = '';
  final _manualTeamController = TextEditingController();
  
  // Controllers for form fields
  final TextEditingController maxPlayersController = TextEditingController();
  final TextEditingController numberOfTeamsController = TextEditingController();
  final TextEditingController prizePoolController = TextEditingController();
  final TextEditingController player1Controller = TextEditingController();
  final TextEditingController player2Controller = TextEditingController();
  final TextEditingController donationGoalController = TextEditingController();
  final TextEditingController beneficiaryController = TextEditingController();
  
  // State variables for selections
  String? selectedSkillLevel;
  String? selectedFormat;
  String? selectedGameFormat;
  DateTime? registrationDeadline;
  bool hasTaxReceipts = false;
  
  @override
  void initState() {
    super.initState();
    _filteredTeams = List.from(_mockTeams);
  }
  
  @override
  void dispose() {
    // Dispose all controllers
    _manualTeamController.dispose();
    maxPlayersController.dispose();
    numberOfTeamsController.dispose();
    prizePoolController.dispose();
    player1Controller.dispose();
    player2Controller.dispose();
    donationGoalController.dispose();
    beneficiaryController.dispose();
    super.dispose();
  }
  
  /// Builds event-specific details for the pricing step
  /// This method is called from the pricing step to show event-specific details
  /// before the tickets section
  Widget buildEventSpecificDetails(BuildContext context) {
    switch (widget.eventType) {
      case EventType.camp:
        return _buildCampFields(context);
      case EventType.training:
        return _buildTrainingFields();
      case EventType.tournament:
        return _buildTournamentFields(context);
      default:
        return const SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    // We've moved all event-specific details to the pricing step
    // This method now returns empty widgets for all event types
    // The actual event-specific details are now built in EventSpecificDetails widget
    return const SizedBox.shrink();
  }

  Widget _buildPickupRunFields() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text(
          'Pickup Run Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        // Skill level has been moved to CommonEventFormFields
      ],
    );
  }

  Widget _buildTournamentFields(BuildContext context) {
    final formats = ['Single Elimination', 'Double Elimination', 'Round Robin', 'Group Stage + Knockout'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text(
          'Tournament Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Number of Teams',
          controller: numberOfTeamsController,
          keyboardType: TextInputType.number,
          hintText: 'Enter number of teams',
          icon: Icons.groups,
        ),
        const SizedBox(height: 20),
        const Text(
          'Tournament Format',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: formats.map((format) {
              final isSelected = selectedFormat == format;
              
              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedFormat = format;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    format,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Prize Pool (Optional)',
          controller: prizePoolController,
          keyboardType: TextInputType.number,
          hintText: 'Enter prize pool amount',
          icon: Icons.attach_money,
          prefix: '\$',
        ),
        const SizedBox(height: 16),
        _buildRegistrationDeadlinePicker(context),
        const SizedBox(height: 24),
        _buildTeamSelectionSection(),
      ],
    );
  }
  
  Widget _buildTeamSelectionSection() {
    if (widget.onWantToAddTeamsChanged == null) {
      return const SizedBox.shrink();
    }
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(color: Colors.grey),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: AppColors.orangeGradient,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.group_add,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                const Text(
                  'Want to add teams now?',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            Switch(
              value: widget.wantToAddTeams ?? false,
              onChanged: (value) {
                if (widget.onWantToAddTeamsChanged != null) {
                  widget.onWantToAddTeamsChanged?.call(value);
                }
              },
              activeColor: AppColors.orangeGradientEnd,
              activeTrackColor: AppColors.orangeGradientStart.withOpacity(0.5),
              inactiveThumbColor: Colors.grey,
              inactiveTrackColor: Colors.grey.withOpacity(0.5),
            ),
          ],
        ),
        if (widget.wantToAddTeams ?? false) ...[  
          const SizedBox(height: 16),
          _buildTeamSelectionOptions(),
        ],
      ],
    );
  }
  
  Widget _buildTeamSelectionOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Toggle between search and manual input
        Row(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () {
                  if (widget.onUseManualTeamInputChanged != null) {
                    widget.onUseManualTeamInputChanged?.call(false);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    gradient: !(widget.useManualTeamInput ?? false) ? AppColors.orangeGradient : null,
                    color: !(widget.useManualTeamInput ?? false) ? null : AppColors.secondaryBlack,
                    borderRadius: const BorderRadius.horizontal(left: Radius.circular(12)),
                  ),
                  child: Center(
                    child: Text(
                      'Search Teams',
                      style: TextStyle(
                        color: !(widget.useManualTeamInput ?? false) ? Colors.white : Colors.grey[400],
                        fontWeight: !(widget.useManualTeamInput ?? false) ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: GestureDetector(
                onTap: () {
                  if (widget.onUseManualTeamInputChanged != null) {
                    widget.onUseManualTeamInputChanged?.call(true);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    gradient: (widget.useManualTeamInput ?? false) ? AppColors.orangeGradient : null,
                    color: (widget.useManualTeamInput ?? false) ? null : AppColors.secondaryBlack,
                    borderRadius: const BorderRadius.horizontal(right: Radius.circular(12)),
                  ),
                  child: Center(
                    child: Text(
                      'Manual Input',
                      style: TextStyle(
                        color: (widget.useManualTeamInput ?? false) ? Colors.white : Colors.grey[400],
                        fontWeight: (widget.useManualTeamInput ?? false) ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        
        // Show either search or manual input based on selection
        if (widget.useManualTeamInput ?? false)
          _buildManualTeamInput()
        else
          _buildTeamSearch(),
          
        // Display selected teams
        if ((widget.selectedTeams?.isNotEmpty ?? false)) ...[  
          const SizedBox(height: 20),
          const Text(
            'Selected Teams',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          _buildSelectedTeamsList(),
        ],
      ],
    );
  }
  
  Widget _buildTeamSearch() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration: BoxDecoration(
            color: AppColors.secondaryBlack,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.darkGray),
          ),
          child: TextField(
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Search for teams by name, location, or sport',
              hintStyle: TextStyle(color: Colors.grey[600]),
              prefixIcon: const Icon(Icons.search, color: Colors.grey),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
            onChanged: (value) {
              setState(() {
                _searchQuery = value.toLowerCase();
                _filteredTeams = _mockTeams.where((team) {
                  return team.name.toLowerCase().contains(_searchQuery) ||
                      (team.location?.toLowerCase().contains(_searchQuery) ?? false) ||
                      (team.sport?.toLowerCase().contains(_searchQuery) ?? false);
                }).toList();
              });
            },
          ),
        ),
        const SizedBox(height: 16),
        _buildSearchResults(),
        const SizedBox(height: 12),
        if (_searchQuery.isEmpty)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.secondaryBlack,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.darkGray),
            ),
            child: const Center(
              child: Text(
                'Search for teams to add them to your tournament',
                style: TextStyle(color: Colors.grey),
                textAlign: TextAlign.center,
              ),
            ),
          )
        else
          _buildSearchResults(),
      ],
    );
  }
  
  Widget _buildSearchResults() {
    if (_filteredTeams.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.secondaryBlack,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.darkGray),
        ),
        child: const Center(
          child: Text(
            'No teams found matching your search',
            style: TextStyle(color: Colors.grey),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    
    return Container(
      decoration: BoxDecoration(
        color: AppColors.secondaryBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.darkGray),
      ),
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _filteredTeams.length,
        separatorBuilder: (context, index) => Divider(
          color: AppColors.darkGray,
          height: 1,
        ),
        itemBuilder: (context, index) {
          final team = _filteredTeams[index];
          final isSelected = widget.selectedTeams?.any((t) => t.id == team.id) ?? false;
          
          return ListTile(
            leading: CircleAvatar(
              backgroundColor: AppColors.orangeGradientStart,
              backgroundImage: team.logoUrl != null ? NetworkImage(team.logoUrl!) : null,
              child: team.logoUrl == null
                  ? const Icon(Icons.sports_basketball, color: Colors.white)
                  : null,
            ),
            title: Text(
              team.name,
              style: const TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              team.location ?? '',
              style: TextStyle(color: Colors.grey[400]),
            ),
            trailing: IconButton(
              icon: Icon(
                isSelected ? Icons.remove_circle : Icons.add_circle,
                color: isSelected ? AppColors.primaryOrange : AppColors.orangeGradientEnd,
              ),
              onPressed: () {
                if (widget.onTeamsSelected != null) {
                  List<TeamModel> updatedTeams = List<TeamModel>.from(widget.selectedTeams ?? []);
                  
                  if (isSelected) {
                    // Remove team
                    updatedTeams.removeWhere((t) => t.id == team.id);
                  } else {
                    // Add team
                    updatedTeams.add(team);
                  }
                  
                  widget.onTeamsSelected?.call(updatedTeams);
                }
              },
            ),
          );
        },
      ),
    );
  }
  
  // This section was moved to the top of the class
  
  Widget _buildManualTeamInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration: BoxDecoration(
            color: AppColors.secondaryBlack,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.darkGray),
          ),
          child: TextField(
            controller: _manualTeamController,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Enter team name and press Enter',
              hintStyle: TextStyle(color: Colors.grey[600]),
              prefixIcon: const Icon(Icons.add_circle_outline, color: Colors.grey),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              suffixIcon: IconButton(
                icon: const Icon(Icons.add, color: AppColors.orangeGradientEnd),
                onPressed: _addManualTeam,
              ),
            ),
            onSubmitted: (_) => _addManualTeam(),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Add multiple teams by pressing Enter after each team name',
          style: TextStyle(color: Colors.grey[500], fontSize: 12),
        ),
      ],
    );
  }
  
  void _addManualTeam() {
    final teamName = _manualTeamController.text.trim();
    if (teamName.isEmpty) return;
    
    if (widget.onTeamsSelected != null) {
      // Create a new team with the entered name
      final newTeam = TeamModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(), // Generate a unique ID
        name: teamName,
        handle: '@${teamName.toLowerCase().replaceAll(' ', '')}'.substring(0, min(15, teamName.length + 1)),
        sport: 'Custom',
        location: 'Manual Entry',
      );
      
      // Add to selected teams
      final updatedTeams = List<TeamModel>.from(widget.selectedTeams ?? []);
      updatedTeams.add(newTeam);
      widget.onTeamsSelected?.call(updatedTeams);
      
      // Clear the text field
      _manualTeamController.clear();
    }
  }
  
  Widget _buildSelectedTeamsList() {
    if (widget.selectedTeams == null || widget.selectedTeams!.isEmpty) {
      return const SizedBox.shrink();
    }
    
    return Container(
      decoration: BoxDecoration(
        color: AppColors.secondaryBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.darkGray),
      ),
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: widget.selectedTeams!.length,
        separatorBuilder: (context, index) => Divider(
          color: AppColors.darkGray,
          height: 1,
        ),
        itemBuilder: (context, index) {
          final team = widget.selectedTeams![index];
          return ListTile(
            leading: CircleAvatar(
              backgroundColor: AppColors.orangeGradientStart,
              backgroundImage: team.logoUrl != null ? NetworkImage(team.logoUrl!) : null,
              child: team.logoUrl == null
                  ? const Icon(Icons.sports_basketball, color: Colors.white)
                  : null,
            ),
            title: Text(
              team.name,
              style: const TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              team.location ?? '',
              style: TextStyle(color: Colors.grey[400]),
            ),
            trailing: IconButton(
              icon: Icon(Icons.remove_circle_outline, color: AppColors.primaryOrange),
              onPressed: () {
                // Remove team from selection
                if (widget.onTeamsSelected != null) {
                  final updatedTeams = List<TeamModel>.from(widget.selectedTeams!)
                    ..removeAt(index);
                  widget.onTeamsSelected?.call(updatedTeams);
                }
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildOneOnOneFields() {
    final gameFormats = ['First to 11', 'First to 21', 'Best of 3', 'Best of 5'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text(
          'One-on-One Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Player 1',
          controller: player1Controller,
          hintText: 'Enter player 1 name',
          icon: Icons.person,
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Player 2',
          controller: player2Controller,
          hintText: 'Enter player 2 name',
          icon: Icons.person,
        ),
        const SizedBox(height: 20),
        const Text(
          'Game Format',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: gameFormats.map((format) {
              final isSelected = selectedGameFormat == format;
              
              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedGameFormat = format;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    format,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildDonationFields() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text(
          'Donation Event Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Donation Goal',
          controller: donationGoalController,
          keyboardType: TextInputType.number,
          hintText: 'Enter donation goal amount',
          icon: Icons.monetization_on,
          prefix: '\$',
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Beneficiary',
          controller: beneficiaryController,
          hintText: 'Enter beneficiary name or organization',
          icon: Icons.business,
        ),
        const SizedBox(height: 16),
        _buildTaxReceiptsToggle(),
      ],
    );
  }
  
  Widget _buildCampFields(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text(
          'Camp Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Number of Days',
          controller: numberOfTeamsController, // Reusing the numberOfTeamsController for days
          keyboardType: TextInputType.number,
          hintText: 'Enter number of days',
          icon: Icons.calendar_today,
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Maximum Participants',
          controller: maxPlayersController, // Reusing maxPlayersController
          keyboardType: TextInputType.number,
          hintText: 'Enter maximum number of participants',
          icon: Icons.group,
        ),
        const SizedBox(height: 16),
        _buildRegistrationDeadlinePicker(context),
      ],
    );
  }

  Widget _buildTrainingFields() {
    final skillLevels = ['Beginner', 'Intermediate', 'Advanced', 'All Levels'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text(
          'Training Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        _buildFormField(
          label: 'Maximum Participants',
          controller: maxPlayersController,
          keyboardType: TextInputType.number,
          hintText: 'Enter maximum number of participants',
          icon: Icons.group,
        ),
        const SizedBox(height: 20),
        const Text(
          'Skill Level',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: skillLevels.map((level) {
              final isSelected = selectedSkillLevel == level;
              
              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedSkillLevel = level;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    level,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildSpecialEventFields() {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 20),
        Text(
          'Special Event Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 16),
        Text(
          'No additional fields required for special events.',
          style: TextStyle(
            color: Colors.grey,
            fontSize: 16,
          ),
        ),
      ],
    );
  }
  
  Widget _buildLeagueGamesFields(BuildContext context) {
    // Mock seasons data
    final seasons = ['2024-2025', '2023-2024', '2022-2023', 'Custom Season'];
    
    // Mock game types
    final gameTypes = ['Regular Season', 'Playoffs', 'Championship', 'All-Star', 'Exhibition'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        const Text(
          'League Games Details',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        
        // Season Selection
        const Text(
          'Season',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: seasons.map((season) {
              final isSelected = selectedFormat == season;
              
              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedFormat = season;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    season,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        
        const SizedBox(height: 20),
        
        // Game Type Selection
        const Text(
          'Game Type',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: gameTypes.map((type) {
              final isSelected = selectedGameFormat == type;
              
              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedGameFormat = type;
                  });
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    type,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        
        const SizedBox(height: 20),
        
        // Registration Deadline
        _buildRegistrationDeadlinePicker(context),
        
        const SizedBox(height: 24),
        
        // Team Selection Section
        _buildTeamSelectionSection(),
      ],
    );
  }

  Widget _buildFormField({
    required String label,
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    String? prefix,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                color: Colors.white,
                size: 16,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          style: const TextStyle(color: Colors.white),
          keyboardType: keyboardType,
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: TextStyle(color: Colors.grey[600]),
            filled: true,
            fillColor: AppColors.secondaryBlack,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.darkGray),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.darkGray),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.orangeGradientEnd),
            ),
            prefixIcon: prefix != null
                ? Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text(
                      prefix,
                      style: const TextStyle(color: Colors.white, fontSize: 18),
                    ),
                  )
                : null,
            prefixIconConstraints:
                prefix != null ? const BoxConstraints(minWidth: 0, minHeight: 0) : null,
          ),
        ),
      ],
    );
  }

  Widget _buildRegistrationDeadlinePicker(BuildContext context) {
    final deadlineText = registrationDeadline != null
        ? _formatDate(registrationDeadline!)
        : 'Select registration deadline';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.event_busy,
                color: Colors.white,
                size: 16,
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'Registration Deadline',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        InkWell(
          onTap: () => _selectDate(context),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            decoration: BoxDecoration(
              color: AppColors.secondaryBlack,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.darkGray),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  deadlineText,
                  style: TextStyle(
                    color: registrationDeadline != null ? Colors.white : Colors.grey[600],
                    fontSize: 16,
                  ),
                ),
                const Icon(
                  Icons.arrow_drop_down,
                  color: Colors.white,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTaxReceiptsToggle() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Tax Receipts Available',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Switch(
              value: hasTaxReceipts,
              onChanged: (value) {
                setState(() {
                  hasTaxReceipts = value;
                });
              },
              activeColor: AppColors.orangeGradientEnd,
              activeTrackColor: AppColors.orangeGradientStart.withOpacity(0.5),
              inactiveThumbColor: Colors.grey,
              inactiveTrackColor: Colors.grey.withOpacity(0.5),
            ),
            const SizedBox(width: 8),
            Text(
              hasTaxReceipts ? 'Yes' : 'No',
              style: const TextStyle(color: Colors.white),
            ),
          ],
        ),
        if (hasTaxReceipts)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              'Donors will receive tax receipts for their contributions',
              style: TextStyle(color: Colors.grey[400], fontSize: 14),
            ),
          ),
      ],
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final initialDate = registrationDeadline ?? DateTime.now();
    
    final date = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.dark(
              primary: AppColors.orangeGradientEnd,
              onPrimary: Colors.white,
              surface: AppColors.secondaryBlack,
              onSurface: Colors.white,
            ),
            dialogBackgroundColor: AppColors.primaryBlack,
          ),
          child: child!,
        );
      },
    );
    
    if (date != null) {
      setState(() {
        registrationDeadline = date;
      });
    }
  }

  String _formatDate(DateTime dateTime) {
    return '${dateTime.month}/${dateTime.day}/${dateTime.year}';
  }
}
