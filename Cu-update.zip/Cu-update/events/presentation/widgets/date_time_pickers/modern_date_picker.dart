import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';

class ModernDatePicker {
  /// Opens the modern bottom-sheet date picker and returns the picked DateTime (date part only).
  /// If [current] is provided, its hour/minute won’t be used; caller should merge after.
  static Future<DateTime?> show(
    BuildContext context, {
    DateTime? current,
    DateTime? initialViewingDate,
  }) async {
    DateTime? calendarViewingDate = initialViewingDate ?? DateTime.now();
    DateTime? result;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          final now = DateTime.now();
          calendarViewingDate ??= now;
          final viewing = calendarViewingDate!;
          final firstDayOfMonth = DateTime(viewing.year, viewing.month, 1);
          final lastDayOfMonth = DateTime(viewing.year, viewing.month + 1, 0);
          final firstDayWeekday = (firstDayOfMonth.weekday - 1) % 7;
          final daysInMonth = lastDayOfMonth.day;

          String monthName(int m) => const [
                'January',
                'February',
                'March',
                'April',
                'May',
                'June',
                'July',
                'August',
                'September',
                'October',
                'November',
                'December'
              ][m - 1];

          return Container(
            height: MediaQuery.of(context).size.height * 0.6,
            decoration: const BoxDecoration(
              color: AppColors.primaryBlack,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
            ),
            child: Column(
              children: [
                // Handle
                Container(
                  margin: const EdgeInsets.only(top: 12),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),

                // Header
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Select Date',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          )),
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Icon(Icons.close,
                              color: Colors.white, size: 20),
                        ),
                      ),
                    ],
                  ),
                ),

                // Month switcher
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _navBtn(
                          icon: Icons.chevron_left,
                          onTap: () {
                            calendarViewingDate =
                                DateTime(viewing.year, viewing.month - 1, 1);
                            setModalState(() {});
                          }),
                      Text('${monthName(viewing.month)} ${viewing.year}',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold)),
                      _navBtn(
                          icon: Icons.chevron_right,
                          onTap: () {
                            calendarViewingDate =
                                DateTime(viewing.year, viewing.month + 1, 1);
                            setModalState(() {});
                          }),
                    ],
                  ),
                ),

                // Day labels
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: ['S', 'M', 'T', 'W', 'T', 'F', 'S']
                        .map((d) => Text(d,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.6),
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            )))
                        .toList(),
                  ),
                ),

                // Calendar grid
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: GridView.builder(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 7,
                              childAspectRatio: 1,
                              mainAxisSpacing: 8,
                              crossAxisSpacing: 8),
                      itemCount: firstDayWeekday + daysInMonth,
                      itemBuilder: (context, index) {
                        if (index < firstDayWeekday) return const SizedBox();

                        final day = index - firstDayWeekday + 1;
                        final date = DateTime(viewing.year, viewing.month, day);
                        final isToday = DateUtils.isSameDay(date, now);
                        final isPast = date
                            .isBefore(DateTime(now.year, now.month, now.day));

                        return GestureDetector(
                          onTap: isPast
                              ? null
                              : () {
                                  result =
                                      DateTime(date.year, date.month, date.day);
                                  setModalState(
                                      () {}); // for visual selection feedback (optional)
                                },
                          child: Container(
                            decoration: BoxDecoration(
                              color: result != null &&
                                      DateUtils.isSameDay(result, date)
                                  ? null
                                  : (isToday
                                      ? Colors.orange.withOpacity(0.2)
                                      : Colors.white.withOpacity(0.05)),
                              gradient: (result != null &&
                                      DateUtils.isSameDay(result, date))
                                  ? LinearGradient(colors: [
                                      Colors.orange.shade400,
                                      Colors.deepOrange.shade600,
                                    ])
                                  : null,
                              borderRadius: BorderRadius.circular(12),
                              border: (result != null &&
                                      DateUtils.isSameDay(result, date))
                                  ? Border.all(color: Colors.white, width: 2)
                                  : (isToday
                                      ? Border.all(
                                          color: const Color(0xFFFF9800),
                                          width: 2)
                                      : Border.all(
                                          color: Colors.white.withOpacity(0.1),
                                          width: 1)),
                            ),
                            child: Center(
                              child: Text(
                                '$day',
                                style: TextStyle(
                                  color: isPast
                                      ? Colors.white.withOpacity(0.3)
                                      : (result != null &&
                                              DateUtils.isSameDay(result, date))
                                          ? Colors.white
                                          : isToday
                                              ? const Color(0xFFFF9800)
                                              : Colors.white.withOpacity(0.9),
                                  fontSize: (result != null &&
                                          DateUtils.isSameDay(result, date))
                                      ? 18
                                      : 16,
                                  fontWeight: (result != null &&
                                          DateUtils.isSameDay(result, date))
                                      ? FontWeight.w900
                                      : isToday
                                          ? FontWeight.bold
                                          : FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),

                // Done button
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: SizedBox(
                    width: double.infinity,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: AppColors.orangeGradient,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFFF9800).withOpacity(0.4),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16)),
                          shadowColor: Colors.transparent,
                        ),
                        child: const Text('Done',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            )),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

    return result;
  }

  static Widget _navBtn({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: Colors.white),
      ),
    );
  }
}
