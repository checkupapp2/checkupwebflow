import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';

class ModernTimePicker {
  /// Opens the modern bottom-sheet time picker and returns a TimeOfDay.
  static Future<TimeOfDay?> show(BuildContext context,
      {TimeOfDay? initial}) async {
    TimeOfDay? result;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          final slots = <Map<String, dynamic>>[];
          for (int hour = 6; hour < 24; hour++) {
            for (int minute = 0; minute < 60; minute += 15) {
              final displayHour =
                  hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
              final period = hour >= 12 ? 'PM' : 'AM';
              slots.add({
                'label':
                    '${displayHour}:${minute.toString().padLeft(2, '0')} $period',
                'hour': hour,
                'minute': minute,
              });
            }
          }

          bool isSelected(int h, int m) => result != null
              ? (result!.hour == h && result!.minute == m)
              : (initial != null && initial.hour == h && initial.minute == m);

          return Container(
            height: MediaQuery.of(context).size.height * 0.7,
            decoration: const BoxDecoration(
              color: AppColors.primaryBlack,
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24), topRight: Radius.circular(24)),
            ),
            child: Column(
              children: [
                // Handle
                Container(
                  margin: const EdgeInsets.only(top: 12),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),

                // Header
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Select Time',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold)),
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Icon(Icons.close,
                              color: Colors.white, size: 20),
                        ),
                      ),
                    ],
                  ),
                ),

                // Grid
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: GridView.builder(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3,
                              childAspectRatio: 2.2,
                              mainAxisSpacing: 12,
                              crossAxisSpacing: 12),
                      itemCount: slots.length,
                      itemBuilder: (context, i) {
                        final h = slots[i]['hour'] as int;
                        final m = slots[i]['minute'] as int;
                        final label = slots[i]['label'] as String;
                        final selected = isSelected(h, m);

                        return GestureDetector(
                          onTap: () {
                            result = TimeOfDay(hour: h, minute: m);
                            setModalState(() {});
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: selected
                                  ? LinearGradient(colors: [
                                      Colors.orange.shade300,
                                      Colors.orange.shade500,
                                      Colors.deepOrange.shade600
                                    ])
                                  : null,
                              color: selected ? null : Colors.grey.shade800,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: selected
                                    ? Colors.orange.shade400
                                    : Colors.white.withOpacity(0.2),
                                width: selected ? 2 : 1,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: selected
                                      ? Colors.orange.withOpacity(0.5)
                                      : Colors.black.withOpacity(0.3),
                                  blurRadius: selected ? 8 : 4,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Center(
                              child: Text(
                                label,
                                style: TextStyle(
                                  color: selected
                                      ? Colors.white
                                      : Colors.white.withOpacity(0.8),
                                  fontSize: 14,
                                  fontWeight: selected
                                      ? FontWeight.bold
                                      : FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),

                // Done
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: SizedBox(
                    width: double.infinity,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: AppColors.orangeGradient,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFFF9800).withOpacity(0.4),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16)),
                          shadowColor: Colors.transparent,
                        ),
                        child: const Text('Done',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

    return result;
  }
}
