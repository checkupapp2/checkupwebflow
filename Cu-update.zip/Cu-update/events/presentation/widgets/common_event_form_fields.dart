import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'package:check_up_app/features/events/domain/models/location_model.dart';
import 'package:check_up_app/features/events/presentation/widgets/modern_date_time_picker.dart';
import 'package:check_up_app/features/events/presentation/widgets/enhanced_location_selector.dart';

/// A widget for common event form fields
class CommonEventFormFields extends StatelessWidget {
  /// The title controller
  final TextEditingController titleController;
  
  /// The description controller
  final TextEditingController descriptionController;
  
  /// The selected date and time
  final DateTime? selectedDateTime;
  
  /// The location controller
  final TextEditingController locationController;
  
  /// The selected location model
  final LocationModel? selectedLocation;
  
  /// Whether the location should be private
  final bool isLocationPrivate;
  
  /// Whether the event should be private
  final bool isEventPrivate;
  
  /// Whether the event is free
  final bool isFree;
  
  /// The price controller
  final TextEditingController priceController;
  
  /// Callback when date and time are selected
  final Function(DateTime) onDateTimeSelected;
  
  /// Callback when location is selected
  final Function(LocationModel?) onLocationSelected;
  
  /// Callback when location privacy is changed
  final Function(bool) onLocationPrivacyChanged;
  
  /// Callback when event privacy is changed
  final Function(bool) onEventPrivacyChanged;
  
  /// Callback when isFree is changed
  final Function(bool) onIsFreeChanged;



  /// Selected skill level
  final String? selectedSkillLevel;
  
  /// Callback when skill level is selected
  final Function(String)? onSkillLevelSelected;

  /// Creates a [CommonEventFormFields] instance
  const CommonEventFormFields({
    Key? key,
    required this.titleController,
    required this.descriptionController,
    this.selectedDateTime,
    required this.locationController,
    this.selectedLocation,
    required this.isLocationPrivate,
    required this.isEventPrivate,
    required this.isFree,
    required this.priceController,
    required this.onDateTimeSelected,
    required this.onLocationSelected,
    required this.onLocationPrivacyChanged,
    required this.onEventPrivacyChanged,
    required this.onIsFreeChanged,
    this.selectedSkillLevel,
    this.onSkillLevelSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildEventBanner(),
        const SizedBox(height: 20),
        _buildTitleField(),
        const SizedBox(height: 16),
        _buildEventPrivacyToggle(),
        const SizedBox(height: 16),
        _buildSkillLevelSelector(),
        const SizedBox(height: 16),
        _buildDescriptionField(),
        const SizedBox(height: 16),
        _buildDateTimePicker(context),
        const SizedBox(height: 16),
        _buildLocationField(),
      ],
    );
  }

  Widget _buildEventBanner() {
    return Container(
      height: 180,
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppColors.secondaryBlack,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.darkGray),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.camera_alt,
                color: Colors.white,
                size: 32,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Add Event Banner',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTitleField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text(
                'T',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'What would you like to call your event?',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: titleController,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Enter event title',
            hintStyle: TextStyle(color: Colors.grey[600]),
            filled: true,
            fillColor: AppColors.secondaryBlack,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.darkGray),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.darkGray),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.orangeGradientEnd),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDescriptionField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.description,
                color: Colors.white,
                size: 16,
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'How would you describe your event?',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: descriptionController,
          style: const TextStyle(color: Colors.white),
          maxLines: 4,
          decoration: InputDecoration(
            hintText: 'Enter event description',
            hintStyle: TextStyle(color: Colors.grey[600]),
            filled: true,
            fillColor: AppColors.secondaryBlack,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.darkGray),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.darkGray),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: AppColors.orangeGradientEnd),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDateTimePicker(BuildContext context) {
    return ModernDateTimePicker(
      selectedDateTime: selectedDateTime,
      onDateTimeSelected: onDateTimeSelected,
    );
  }

  Widget _buildLocationField() {
    return EnhancedLocationSelector(
      selectedLocation: selectedLocation,
      isLocationPrivate: isLocationPrivate,
      onLocationSelected: onLocationSelected,
      onPrivacyChanged: onLocationPrivacyChanged,
      locationController: locationController,
    );
  }
  
  Widget _buildEventPrivacyToggle() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.visibility,
                color: Colors.white,
                size: 16,
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'Who can see and join your event?',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () {
                  if (isEventPrivate) {
                    onEventPrivacyChanged(false);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    gradient: !isEventPrivate ? AppColors.orangeGradient : null,
                    color: !isEventPrivate ? null : AppColors.secondaryBlack,
                    borderRadius: const BorderRadius.horizontal(
                      left: Radius.circular(12),
                    ),
                    border: Border.all(
                      color: !isEventPrivate ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.public,
                        color: !isEventPrivate ? Colors.white : Colors.grey[400],
                        size: 16,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Public',
                        style: TextStyle(
                          color: !isEventPrivate ? Colors.white : Colors.grey[400],
                          fontWeight: !isEventPrivate ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Expanded(
              child: GestureDetector(
                onTap: () {
                  if (!isEventPrivate) {
                    onEventPrivacyChanged(true);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    gradient: isEventPrivate ? AppColors.orangeGradient : null,
                    color: isEventPrivate ? null : AppColors.secondaryBlack,
                    borderRadius: const BorderRadius.horizontal(
                      right: Radius.circular(12),
                    ),
                    border: Border.all(
                      color: isEventPrivate ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.lock,
                        color: isEventPrivate ? Colors.white : Colors.grey[400],
                        size: 16,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Private',
                        style: TextStyle(
                          color: isEventPrivate ? Colors.white : Colors.grey[400],
                          fontWeight: isEventPrivate ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          isEventPrivate
              ? 'Only invited people can see this event'
              : 'Anyone can discover and view this event',
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildSkillLevelSelector() {
    final skillLevels = ['Beginner', 'Intermediate', 'Advanced', 'All Levels'];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: AppColors.orangeGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.fitness_center,
                color: Colors.white,
                size: 16,
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'Skill Level',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: skillLevels.map((level) {
              final isSelected = selectedSkillLevel == level;
              
              return GestureDetector(
                onTap: () {
                  if (onSkillLevelSelected != null) {
                    onSkillLevelSelected!(level);
                  }
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: isSelected ? AppColors.orangeGradient : null,
                    color: isSelected ? null : AppColors.secondaryBlack,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? AppColors.orangeGradientEnd : AppColors.darkGray,
                    ),
                  ),
                  child: Text(
                    level,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}
