// import 'package:flutter/material.dart';
// import 'package:check_up_app/core/theme/app_colors.dart';
// import 'package:check_up_app/features/events/domain/models/event_type.dart';
// import 'tournament_configuration.dart';

// /// Widget that displays event type-specific forms based on the selected event type
// class EventTypeSpecificForms extends StatefulWidget {
//   final EventType eventType;
//   final Map<String, dynamic> formData;
//   final Function(Map<String, dynamic>) onFormDataChanged;
//   final VoidCallback? onNextStep;
//   final VoidCallback? onPreviousStep;
//   final DateTime? startDateTime;
//   final DateTime? endDateTime;

//   const EventTypeSpecificForms({
//     Key? key,
//     required this.eventType,
//     required this.formData,
//     required this.onFormDataChanged,
//     this.onNextStep,
//     this.onPreviousStep,
//     this.startDateTime,
//     this.endDateTime,
//   }) : super(key: key);

//   @override
//   State<EventTypeSpecificForms> createState() => _EventTypeSpecificFormsState();
// }

// class _EventTypeSpecificFormsState extends State<EventTypeSpecificForms>
//     with TickerProviderStateMixin {
//   late Map<String, dynamic> _formData;
//   late AnimationController _animationController;
//   late Animation<double> _fadeAnimation;
//   late Animation<Offset> _slideAnimation;

//   @override
//   void initState() {
//     super.initState();
//     _formData = Map<String, dynamic>.from(widget.formData);
    
//     _animationController = AnimationController(
//       duration: const Duration(milliseconds: 600),
//       vsync: this,
//     );
    
//     // Update number of days based on dates after the first frame
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       _updateDaysFromDates();
//     });
    
//     _fadeAnimation = Tween<double>(
//       begin: 0.0,
//       end: 1.0,
//     ).animate(CurvedAnimation(
//       parent: _animationController,
//       curve: Curves.easeInOut,
//     ));
    
//     _slideAnimation = Tween<Offset>(
//       begin: const Offset(0, 0.3),
//       end: Offset.zero,
//     ).animate(CurvedAnimation(
//       parent: _animationController,
//       curve: Curves.easeOutCubic,
//     ));
    
//     _animationController.forward();
//   }

//   @override
//   void didUpdateWidget(EventTypeSpecificForms oldWidget) {
//     super.didUpdateWidget(oldWidget);
//     // Update days if dates changed - defer to avoid setState during build
//     if (oldWidget.startDateTime != widget.startDateTime || 
//         oldWidget.endDateTime != widget.endDateTime) {
//       WidgetsBinding.instance.addPostFrameCallback((_) {
//         _updateDaysFromDates();
//       });
//     }
//   }

//   @override
//   void dispose() {
//     _animationController.dispose();
//     super.dispose();
//   }
  
//   void _updateDaysFromDates() {
//     // Only update if widget is still mounted
//     if (!mounted) return;
    
//     // Update form data with calculated days (safe to call setState here)
//     if (widget.startDateTime != null && widget.endDateTime != null) {
//       final difference = widget.endDateTime!.difference(widget.startDateTime!).inDays + 1;
//       _updateFormData('numberOfDays', difference.toString());
//     } else if (widget.startDateTime != null) {
//       _updateFormData('numberOfDays', '1');
//     }
//   }

//   void _updateFormData(String key, dynamic value) {
//     // Only update if the value actually changed and widget is mounted
//     if (mounted && _formData[key] != value) {
//       setState(() {
//         _formData[key] = value;
//       });
//       widget.onFormDataChanged(_formData);
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final screenWidth = MediaQuery.of(context).size.width;
//     final isTablet = screenWidth > 768;
//     final isMobile = screenWidth < 600;
    
//     return AnimatedBuilder(
//       animation: _animationController,
//       builder: (context, child) {
//         return FadeTransition(
//           opacity: _fadeAnimation,
//           child: SlideTransition(
//             position: _slideAnimation,
//             child: Padding(
//               padding: EdgeInsets.symmetric(
//                 horizontal: isMobile ? 16.0 : 24.0,
//                 vertical: 16.0,
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   _buildHeader(isMobile),
//                   SizedBox(height: isMobile ? 24 : 32),
//                   _buildEventTypeForm(isMobile, isTablet),
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   Widget _buildHeader(bool isMobile) {
//     return Container(
//       padding: EdgeInsets.all(isMobile ? 20 : 24),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             const Color(0xFF3A3A3A),
//             const Color(0xFF2A2A2A),
//             const Color(0xFF1A1A1A),
//             const Color(0xFF0A0A0A),
//           ],
//           stops: const [0.0, 0.3, 0.7, 1.0],
//         ),
//         borderRadius: BorderRadius.circular(20),
//         border: Border.all(
//           color: Colors.white.withOpacity(0.08),
//           width: 0.5,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.white.withOpacity(0.03),
//             blurRadius: 1,
//             offset: const Offset(0, 1),
//           ),
//           BoxShadow(
//             color: Colors.black.withOpacity(0.4),
//             blurRadius: 12,
//             offset: const Offset(0, 4),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Container(
//                 width: 44,
//                 height: 44,
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [
//                       Colors.orange.shade400,
//                       Colors.deepOrange.shade600,
//                     ],
//                   ),
//                   borderRadius: BorderRadius.circular(12),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 6,
//                       offset: const Offset(0, 2),
//                     ),
//                   ],
//                 ),
//                 child: Icon(
//                   _getEventTypeIcon(),
//                   color: Colors.white,
//                   size: 22,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       'Configure your ${widget.eventType.displayName}',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: isMobile ? 22 : 28,
//                         fontWeight: FontWeight.bold,
//                         letterSpacing: 0.5,
//                       ),
//                     ),
//                     const SizedBox(height: 4),
//                     Text(
//                       _getEventTypeSubtitle(),
//                       style: TextStyle(
//                         color: Colors.white.withOpacity(0.7),
//                         fontSize: isMobile ? 14 : 16,
//                         fontWeight: FontWeight.w400,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   IconData _getEventTypeIcon() {
//     switch (widget.eventType) {
//       case EventType.pickupRun:
//       case EventType.openGym:
//         return Icons.sports_basketball;
//       case EventType.camp:
//       case EventType.training:
//         return Icons.school;
//       case EventType.specialEvent:
//       case EventType.oneOff:
//         return Icons.star;
//       case EventType.tournament:
//         return Icons.emoji_events;
//       case EventType.donationBased:
//         return Icons.favorite;
//       case EventType.oneVsOne:
//         return Icons.person_4;
//       default:
//         return Icons.event;
//     }
//   }

//   String _getEventTypeSubtitle() {
//     switch (widget.eventType) {
//       case EventType.pickupRun:
//       case EventType.openGym:
//         return 'Set up your casual basketball game';
//       case EventType.camp:
//         return 'Configure your basketball camp details';
//       case EventType.training:
//         return 'Configure your training session details';
//       case EventType.specialEvent:
//       case EventType.oneOff:
//         return 'Make your special event memorable';
//       case EventType.tournament:
//         return 'Design your tournament structure';
//       case EventType.donationBased:
//         return 'Set up your charity fundraiser';
//       case EventType.oneVsOne:
//         return 'Configure your 1v1 matchup';
//       default:
//         return 'Let\'s set up the specific details for your event';
//     }
//   }

//   Widget _buildEventTypeForm(bool isMobile, bool isTablet) {
//     switch (widget.eventType) {
//       case EventType.pickupRun:
//       case EventType.openGym:
//         return _buildRunsForm(isMobile, isTablet);
//       case EventType.camp:
//         return _buildCampForm(isMobile, isTablet);
//       case EventType.training:
//         return _buildTrainingForm(isMobile, isTablet);
//       case EventType.specialEvent:
//       case EventType.oneOff:
//         return _buildSpecialEventForm(isMobile, isTablet);
//       case EventType.tournament:
//         return _buildTournamentForm(isMobile, isTablet);
//       case EventType.donationBased:
//         return _buildFundraiserForm(isMobile, isTablet);
//       case EventType.oneVsOne:
//         return _buildOneVsOneForm(isMobile, isTablet);
//       default:
//         return const SizedBox.shrink();
//     }
//   }

//   Widget _buildRunsForm(bool isMobile, bool isTablet) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '🏀 Game Setup',
//           subtitle: 'Configure your pickup game details',
//           children: [
//             _buildModernFormField(
//               label: 'Maximum Players',
//               hint: 'e.g., 10 players',
//               value: _formData['maxPlayers']?.toString() ?? '',
//               onChanged: (value) => _updateFormData('maxPlayers', int.tryParse(value) ?? 0),
//               keyboardType: TextInputType.number,
//               icon: Icons.group,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernDropdownField(
//               label: 'Skill Level Required',
//               value: _formData['skillLevel'] as String?,
//               items: ['Beginner', 'Intermediate', 'Advanced', 'All Levels'],
//               onChanged: (value) => _updateFormData('skillLevel', value),
//               icon: Icons.trending_up,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernSwitchField(
//               label: 'Bring Your Own Ball',
//               subtitle: 'Players should bring their own basketball',
//               value: _formData['bringOwnBall'] as bool? ?? false,
//               onChanged: (value) => _updateFormData('bringOwnBall', value),
//               icon: Icons.sports_basketball,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
        
//         SizedBox(height: isMobile ? 20 : 24),
        
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '📝 Additional Details',
//           subtitle: 'Any special information for players',
//           children: [
//             _buildModernFormField(
//               label: 'Additional Notes',
//               hint: 'Any special rules or requirements...',
//               value: _formData['additionalNotes'] as String? ?? '',
//               onChanged: (value) => _updateFormData('additionalNotes', value),
//               maxLines: 3,
//               icon: Icons.note_alt,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildCampForm(bool isMobile, bool isTablet) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '🏫 Camp Information',
//           subtitle: 'Configure your basketball camp details',
//           children: [
//             _buildModernDropdownField(
//               label: 'Skill Level',
//               value: _formData['skillLevel'] as String?,
//               items: ['All Skill Levels', 'Beginner', 'Intermediate', 'Advanced', 'Elite'],
//               onChanged: (value) => _updateFormData('skillLevel', value),
//               icon: Icons.trending_up,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             Container(
//               padding: const EdgeInsets.all(16),
//               decoration: BoxDecoration(
//                 color: Colors.grey.withOpacity(0.1),
//                 borderRadius: BorderRadius.circular(12),
//                 border: Border.all(color: Colors.grey.withOpacity(0.3)),
//               ),
//               child: Row(
//                 children: [
//                   Icon(Icons.calendar_today, color: Colors.grey.shade400, size: 20),
//                   const SizedBox(width: 12),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Number of Days',
//                         style: TextStyle(
//                           color: Colors.grey.shade400,
//                           fontSize: 14,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                       const SizedBox(height: 4),
//                       Text(
//                         _getCalculatedDays(),
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontSize: 16,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                       Text(
//                         'Calculated from event dates',
//                         style: TextStyle(
//                           color: Colors.grey.shade500,
//                           fontSize: 12,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernFormField(
//               label: 'Age Range',
//               hint: 'e.g., 8-16 years old',
//               value: _formData['ageRange'] as String? ?? '',
//               onChanged: (value) => _updateFormData('ageRange', value),
//               icon: Icons.child_care,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
        
//         SizedBox(height: isMobile ? 20 : 24),
        
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '📅 Daily Training Schedule',
//           subtitle: 'Configure what happens each day of camp',
//           children: _buildDynamicScheduleFields(isMobile),
//         ),
        
//       ],
//     );
//   }
  
//   String _getCalculatedDays() {
//     // Use dates passed from the create event page
//     if (widget.startDateTime != null && widget.endDateTime != null) {
//       final difference = widget.endDateTime!.difference(widget.startDateTime!).inDays + 1;
//       // Don't call _updateFormData during build - just return the display value
//       return '$difference days';
//     }
    
//     // Fallback to single day if only start date is set
//     if (widget.startDateTime != null) {
//       return '1 day';
//     }
    
//     // Default fallback
//     final savedDays = _formData['numberOfDays'] as String?;
//     if (savedDays != null && savedDays.isNotEmpty) {
//       return '$savedDays days';
//     }
    
//     return '5 days (default)';
//   }
  
//   int _getNumberOfDays() {
//     // Use dates passed from the create event page
//     if (widget.startDateTime != null && widget.endDateTime != null) {
//       return widget.endDateTime!.difference(widget.startDateTime!).inDays + 1;
//     }
    
//     // Fallback to single day if only start date is set
//     if (widget.startDateTime != null) {
//       return 1;
//     }
    
//     final savedDays = _formData['numberOfDays'] as String?;
//     if (savedDays != null && savedDays.isNotEmpty) {
//       return int.tryParse(savedDays) ?? 5;
//     }
    
//     return 5; // Default to 5 days
//   }
  
//   List<Widget> _buildDynamicScheduleFields(bool isMobile) {
//     final numberOfDays = _getNumberOfDays();
//     final List<Widget> scheduleFields = [];
    
//     final defaultActivities = [
//       'Fundamentals & Skills Assessment',
//       'Shooting & Ball Handling', 
//       'Defense & Rebounding',
//       'Team Play & Strategy',
//       'Scrimmage & Awards',
//       'Advanced Techniques',
//       'Game Situations',
//       'Final Tournament',
//     ];
    
//     for (int i = 1; i <= numberOfDays; i++) {
//       if (scheduleFields.isNotEmpty) {
//         scheduleFields.add(SizedBox(height: isMobile ? 12 : 16));
//       }
      
//       final defaultHint = i <= defaultActivities.length 
//           ? 'e.g., ${defaultActivities[i - 1]}'
//           : 'e.g., Day $i Activities';
      
//       scheduleFields.add(
//         _buildDayScheduleField(
//           'Day $i', 
//           'day${i}Activities', 
//           defaultHint, 
//           isMobile
//         )
//       );
//     }
    
//     return scheduleFields;
//   }

//   Widget _buildDayScheduleField(String dayLabel, String fieldKey, String hint, bool isMobile) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(
//           dayLabel,
//           style: TextStyle(
//             color: Colors.orange.shade300,
//             fontSize: 14,
//             fontWeight: FontWeight.w600,
//             fontFamily: 'Montserrat',
//           ),
//         ),
//         const SizedBox(height: 8),
//         _buildModernFormField(
//           label: 'Activities',
//           hint: hint,
//           value: _formData[fieldKey] as String? ?? '',
//           onChanged: (value) => _updateFormData(fieldKey, value),
//           maxLines: 2,
//           icon: Icons.schedule,
//           isMobile: isMobile,
//         ),
//       ],
//     );
//   }

//   Widget _buildTrainingForm(bool isMobile, bool isTablet) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '🎯 Training Setup',
//           subtitle: 'Configure your training session details',
//           children: [
//             _buildModernDropdownField(
//               label: 'Training Focus',
//               value: _formData['trainingFocus'] as String?,
//               items: ['Shooting', 'Ball Handling', 'Defense', 'Conditioning', 'Fundamentals', 'Game Situations'],
//               onChanged: (value) => _updateFormData('trainingFocus', value),
//               icon: Icons.fitness_center,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernDropdownField(
//               label: 'Experience Level',
//               value: _formData['experienceLevel'] as String?,
//               items: ['Youth (Under 12)', 'Teen (13-17)', 'Adult (18+)', 'All Ages'],
//               onChanged: (value) => _updateFormData('experienceLevel', value),
//               icon: Icons.bar_chart,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernFormField(
//               label: 'Equipment Needed',
//               hint: 'List any equipment participants should bring...',
//               value: _formData['equipmentNeeded'] as String? ?? '',
//               onChanged: (value) => _updateFormData('equipmentNeeded', value),
//               maxLines: 2,
//               icon: Icons.sports,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernSwitchField(
//               label: 'Certification Provided',
//               subtitle: 'Will participants receive a certificate?',
//               value: _formData['certificationProvided'] as bool? ?? false,
//               onChanged: (value) => _updateFormData('certificationProvided', value),
//               icon: Icons.verified,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
        
//         SizedBox(height: isMobile ? 20 : 24),
        
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '👨‍🏫 Instructor Details',
//           subtitle: 'Information about the training leader',
//           children: [
//             _buildModernFormField(
//               label: 'Instructor/Coach Name',
//               hint: 'Who will be leading this training?',
//               value: _formData['instructorName'] as String? ?? '',
//               onChanged: (value) => _updateFormData('instructorName', value),
//               icon: Icons.person,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildSpecialEventForm(bool isMobile, bool isTablet) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '⭐ Event Configuration',
//           subtitle: 'Make your special event memorable',
//           children: [
//             _buildModernDropdownField(
//               label: 'Event Category',
//               value: _formData['eventCategory'] as String?,
//               items: ['Showcase', 'Exhibition', 'Community Event', 'Celebrity Game', 'Charity Match', 'Awards Ceremony'],
//               onChanged: (value) => _updateFormData('eventCategory', value),
//               icon: Icons.category,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernFormField(
//               label: 'Special Guests',
//               hint: 'Any special guests or featured players?',
//               value: _formData['specialGuests'] as String? ?? '',
//               onChanged: (value) => _updateFormData('specialGuests', value),
//               maxLines: 2,
//               icon: Icons.star_border,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernSwitchField(
//               label: 'Media Coverage',
//               subtitle: 'Will this event be recorded or livestreamed?',
//               value: _formData['mediaCoverage'] as bool? ?? false,
//               onChanged: (value) => _updateFormData('mediaCoverage', value),
//               icon: Icons.videocam,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
        
//         SizedBox(height: isMobile ? 20 : 24),
        
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '🎭 Event Details',
//           subtitle: 'Additional event specifications',
//           children: [
//             _buildModernFormField(
//               label: 'Dress Code',
//               hint: 'Any specific attire requirements?',
//               value: _formData['dressCode'] as String? ?? '',
//               onChanged: (value) => _updateFormData('dressCode', value),
//               icon: Icons.checkroom,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernFormField(
//               label: 'Awards/Prizes',
//               hint: 'What awards or prizes will be given?',
//               value: _formData['awards'] as String? ?? '',
//               onChanged: (value) => _updateFormData('awards', value),
//               maxLines: 2,
//               icon: Icons.emoji_events,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildTournamentForm(bool isMobile, bool isTablet) {
//     return TournamentConfiguration(
//       formData: _formData,
//       onFormDataChanged: (data) {
//         setState(() {
//           _formData = data;
//         });
//         widget.onFormDataChanged(_formData);
//       },
//       onNextStep: widget.onNextStep,
//       onPreviousStep: widget.onPreviousStep,
//     );
//   }

//   Widget _buildFundraiserForm(bool isMobile, bool isTablet) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '💝 Fundraising Goals',
//           subtitle: 'Set up your charity event details',
//           children: [
//             _buildModernFormField(
//               label: 'Fundraising Goal',
//               hint: 'Target amount to raise',
//               value: _formData['fundraisingGoal'] as String? ?? '',
//               onChanged: (value) => _updateFormData('fundraisingGoal', value),
//               keyboardType: TextInputType.number,
//               prefixText: '\$',
//               icon: Icons.track_changes,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernFormField(
//               label: 'Beneficiary/Charity',
//               hint: 'Who will receive the funds?',
//               value: _formData['beneficiary'] as String? ?? '',
//               onChanged: (value) => _updateFormData('beneficiary', value),
//               icon: Icons.volunteer_activism,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernFormField(
//               label: 'Cause Description',
//               hint: 'Describe the cause you\'re supporting...',
//               value: _formData['causeDescription'] as String? ?? '',
//               onChanged: (value) => _updateFormData('causeDescription', value),
//               maxLines: 3,
//               icon: Icons.description,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
        
//         SizedBox(height: isMobile ? 20 : 24),
        
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '🎆 Sponsorship & Donations',
//           subtitle: 'Configure donation and sponsorship options',
//           children: [
//             _buildModernSwitchField(
//               label: 'Accept Sponsorships',
//               subtitle: 'Allow businesses to sponsor this event',
//               value: _formData['acceptSponsorships'] as bool? ?? true,
//               onChanged: (value) => _updateFormData('acceptSponsorships', value),
//               icon: Icons.business,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernSwitchField(
//               label: 'Provide Tax Receipts',
//               subtitle: 'Issue tax-deductible donation receipts',
//               value: _formData['provideTaxReceipts'] as bool? ?? false,
//               onChanged: (value) => _updateFormData('provideTaxReceipts', value),
//               icon: Icons.receipt,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernDropdownField(
//               label: 'Donation Method',
//               value: _formData['donationMethod'] as String?,
//               items: ['Entry Fee Donation', 'Separate Donations', 'Auction Items', 'Raffle Tickets'],
//               onChanged: (value) => _updateFormData('donationMethod', value),
//               icon: Icons.payment,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernFormField(
//               label: 'Sponsor Recognition',
//               hint: 'How will sponsors be recognized?',
//               value: _formData['sponsorRecognition'] as String? ?? '',
//               onChanged: (value) => _updateFormData('sponsorRecognition', value),
//               maxLines: 2,
//               icon: Icons.campaign,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildOneVsOneForm(bool isMobile, bool isTablet) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '🎯 Matchup Setup',
//           subtitle: 'Configure your one-on-one game',
//           children: [
//             _buildModernFormField(
//               label: 'Opponent Name',
//               hint: 'Who are you playing against?',
//               value: _formData['opponentName'] as String? ?? '',
//               onChanged: (value) => _updateFormData('opponentName', value),
//               icon: Icons.person_outline,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernDropdownField(
//               label: 'Game Format',
//               value: _formData['gameFormat'] as String?,
//               items: ['First to 11', 'First to 15', 'First to 21', 'Timed Game (20 min)', 'Best of 3 Games'],
//               onChanged: (value) => _updateFormData('gameFormat', value),
//               icon: Icons.timer,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernFormField(
//               label: 'Stakes/Prize',
//               hint: 'What\'s on the line? (optional)',
//               value: _formData['stakes'] as String? ?? '',
//               onChanged: (value) => _updateFormData('stakes', value),
//               icon: Icons.emoji_events,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
        
//         SizedBox(height: isMobile ? 20 : 24),
        
//         _buildModernCard(
//           isMobile: isMobile,
//           title: '🎮 Game Settings',
//           subtitle: 'Additional matchup configurations',
//           children: [
//             _buildModernSwitchField(
//               label: 'Winner Take All',
//               subtitle: 'Winner takes the entire prize/stakes',
//               value: _formData['winnerTakeAll'] as bool? ?? false,
//               onChanged: (value) => _updateFormData('winnerTakeAll', value),
//               icon: Icons.military_tech,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernSwitchField(
//               label: 'Allow Spectators',
//               subtitle: 'Can people watch this matchup?',
//               value: _formData['allowSpectators'] as bool? ?? true,
//               onChanged: (value) => _updateFormData('allowSpectators', value),
//               icon: Icons.visibility,
//               isMobile: isMobile,
//             ),
            
//             SizedBox(height: isMobile ? 16 : 20),
            
//             _buildModernFormField(
//               label: 'Special Rules',
//               hint: 'Any house rules or special conditions?',
//               value: _formData['specialRules'] as String? ?? '',
//               onChanged: (value) => _updateFormData('specialRules', value),
//               maxLines: 2,
//               icon: Icons.rule,
//               isMobile: isMobile,
//             ),
//           ],
//         ),
//       ],
//     );
//   }

//   Widget _buildModernCard({
//     required bool isMobile,
//     required String title,
//     required String subtitle,
//     required List<Widget> children,
//   }) {
//     return Container(
//       width: double.infinity,
//       padding: EdgeInsets.all(isMobile ? 20 : 24),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             const Color(0xFF3A3A3A),
//             const Color(0xFF2A2A2A),
//             const Color(0xFF1A1A1A),
//             const Color(0xFF0A0A0A),
//           ],
//           stops: const [0.0, 0.3, 0.7, 1.0],
//         ),
//         borderRadius: BorderRadius.circular(isMobile ? 16 : 20),
//         border: Border.all(
//           color: Colors.white.withOpacity(0.08),
//           width: 0.5,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.white.withOpacity(0.03),
//             blurRadius: 1,
//             offset: const Offset(0, 1),
//           ),
//           BoxShadow(
//             color: Colors.black.withOpacity(0.4),
//             blurRadius: 12,
//             offset: const Offset(0, 4),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Container(
//             padding: EdgeInsets.symmetric(
//               horizontal: isMobile ? 12 : 16,
//               vertical: isMobile ? 8 : 10,
//             ),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 colors: [
//                   Colors.orange.shade400,
//                   Colors.deepOrange.shade600,
//                 ],
//               ),
//               borderRadius: BorderRadius.circular(isMobile ? 8 : 10),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.orange.withOpacity(0.3),
//                   blurRadius: 6,
//                   offset: const Offset(0, 2),
//                 ),
//               ],
//             ),
//             child: Text(
//               title,
//               style: TextStyle(
//                 color: Colors.white,
//                 fontSize: isMobile ? 16 : 18,
//                 fontWeight: FontWeight.w700,
//                 letterSpacing: 0.5,
//               ),
//             ),
//           ),
//           SizedBox(height: isMobile ? 12 : 16),
//           Text(
//             subtitle,
//             style: TextStyle(
//               color: Colors.white.withOpacity(0.8),
//               fontSize: isMobile ? 13 : 14,
//               fontWeight: FontWeight.w400,
//               letterSpacing: 0.2,
//             ),
//           ),
//           SizedBox(height: isMobile ? 20 : 24),
//           ...children,
//         ],
//       ),
//     );
//   }

//   Widget _buildModernFormField({
//     required String label,
//     required String hint,
//     required String value,
//     required Function(String) onChanged,
//     required IconData icon,
//     required bool isMobile,
//     TextInputType? keyboardType,
//     int maxLines = 1,
//     String? prefixText,
//   }) {
//     return Container(
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             const Color(0xFF2A2A2A),
//             const Color(0xFF1A1A1A),
//           ],
//         ),
//         borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
//         border: Border.all(
//           color: Colors.white.withOpacity(0.08),
//           width: 0.5,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.3),
//             blurRadius: 8,
//             offset: const Offset(0, 3),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Padding(
//             padding: EdgeInsets.fromLTRB(
//               isMobile ? 16 : 20,
//               isMobile ? 16 : 20,
//               isMobile ? 16 : 20,
//               8,
//             ),
//             child: Row(
//               children: [
//                 Container(
//                   padding: const EdgeInsets.all(8),
//                   decoration: BoxDecoration(
//                     gradient: LinearGradient(
//                       colors: [
//                         Colors.orange.shade400.withOpacity(0.3),
//                         Colors.deepOrange.shade600.withOpacity(0.2),
//                       ],
//                     ),
//                     borderRadius: BorderRadius.circular(8),
//                   ),
//                   child: Icon(
//                     icon,
//                     color: Colors.orange.shade400,
//                     size: isMobile ? 16 : 18,
//                   ),
//                 ),
//                 const SizedBox(width: 12),
//                 Text(
//                   label,
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: isMobile ? 15 : 16,
//                     fontWeight: FontWeight.w600,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Padding(
//             padding: EdgeInsets.fromLTRB(
//               isMobile ? 16 : 20,
//               0,
//               isMobile ? 16 : 20,
//               isMobile ? 16 : 20,
//             ),
//             child: TextField(
//               controller: TextEditingController(text: value)..selection = TextSelection.fromPosition(TextPosition(offset: value.length)),
//               onChanged: onChanged,
//               keyboardType: keyboardType,
//               maxLines: maxLines,
//               style: TextStyle(
//                 color: Colors.white,
//                 fontSize: isMobile ? 15 : 16,
//               ),
//               decoration: InputDecoration(
//                 hintText: hint,
//                 hintStyle: TextStyle(
//                   color: Colors.white.withOpacity(0.5),
//                   fontSize: isMobile ? 14 : 15,
//                 ),
//                 prefixText: prefixText,
//                 prefixStyle: TextStyle(
//                   color: Colors.white.withOpacity(0.7),
//                   fontSize: isMobile ? 15 : 16,
//                 ),
//                 filled: true,
//                 fillColor: Colors.transparent,
//                 border: OutlineInputBorder(
//                   borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
//                   borderSide: BorderSide.none,
//                 ),
//                 focusedBorder: OutlineInputBorder(
//                   borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
//                   borderSide: BorderSide(
//                     color: Colors.orange.shade400,
//                     width: 2,
//                   ),
//                 ),
//                 enabledBorder: OutlineInputBorder(
//                   borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
//                   borderSide: BorderSide(
//                     color: Colors.white.withOpacity(0.2),
//                     width: 1,
//                   ),
//                 ),
//                 contentPadding: EdgeInsets.symmetric(
//                   horizontal: isMobile ? 14 : 16,
//                   vertical: isMobile ? 12 : 14,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildModernDropdownField({
//     required String label,
//     required String? value,
//     required List<String> items,
//     required Function(String?) onChanged,
//     required IconData icon,
//     required bool isMobile,
//   }) {
//     return Container(
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             const Color(0xFF2A2A2A),
//             const Color(0xFF1A1A1A),
//           ],
//         ),
//         borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
//         border: Border.all(
//           color: Colors.white.withOpacity(0.08),
//           width: 0.5,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.3),
//             blurRadius: 8,
//             offset: const Offset(0, 3),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Padding(
//             padding: EdgeInsets.fromLTRB(
//               isMobile ? 16 : 20,
//               isMobile ? 16 : 20,
//               isMobile ? 16 : 20,
//               8,
//             ),
//             child: Row(
//               children: [
//                 Container(
//                   padding: const EdgeInsets.all(8),
//                   decoration: BoxDecoration(
//                     gradient: LinearGradient(
//                       colors: [
//                         Colors.orange.shade400.withOpacity(0.3),
//                         Colors.deepOrange.shade600.withOpacity(0.2),
//                       ],
//                     ),
//                     borderRadius: BorderRadius.circular(8),
//                   ),
//                   child: Icon(
//                     icon,
//                     color: Colors.orange.shade400,
//                     size: isMobile ? 16 : 18,
//                   ),
//                 ),
//                 const SizedBox(width: 12),
//                 Text(
//                   label,
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: isMobile ? 15 : 16,
//                     fontWeight: FontWeight.w600,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Padding(
//             padding: EdgeInsets.fromLTRB(
//               isMobile ? 16 : 20,
//               0,
//               isMobile ? 16 : 20,
//               isMobile ? 16 : 20,
//             ),
//             child: Container(
//               decoration: BoxDecoration(
//                 color: Colors.transparent,
//                 borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
//               ),
//               child: DropdownButtonFormField<String>(
//                 value: value,
//                 onChanged: onChanged,
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: isMobile ? 15 : 16,
//                 ),
//                 dropdownColor: AppColors.secondaryBlack,
//                 decoration: InputDecoration(
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
//                     borderSide: BorderSide.none,
//                   ),
//                   focusedBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
//                     borderSide: BorderSide(
//                       color: Colors.orange.shade400,
//                       width: 2,
//                     ),
//                   ),
//                   enabledBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
//                     borderSide: BorderSide(
//                       color: Colors.white.withOpacity(0.2),
//                       width: 1,
//                     ),
//                   ),
//                   contentPadding: EdgeInsets.symmetric(
//                     horizontal: isMobile ? 14 : 16,
//                     vertical: isMobile ? 12 : 14,
//                   ),
//                 ),
//                 items: items.map((String item) {
//                   return DropdownMenuItem<String>(
//                     value: item,
//                     child: Text(
//                       item,
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: isMobile ? 14 : 15,
//                       ),
//                     ),
//                   );
//                 }).toList(),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildModernSwitchField({
//     required String label,
//     required String subtitle,
//     required bool value,
//     required Function(bool) onChanged,
//     required IconData icon,
//     required bool isMobile,
//   }) {
//     return Container(
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             const Color(0xFF2A2A2A),
//             const Color(0xFF1A1A1A),
//           ],
//         ),
//         borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
//         border: Border.all(
//           color: value 
//               ? AppColors.primaryOrange.withOpacity(0.5)
//               : AppColors.primaryOrange.withOpacity(0.2),
//           width: value ? 2 : 1.5,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: value 
//                 ? AppColors.primaryOrange.withOpacity(0.2)
//                 : AppColors.primaryOrange.withOpacity(0.1),
//             blurRadius: value ? 12 : 8,
//             offset: const Offset(0, 3),
//           ),
//         ],
//       ),
//       child: Material(
//         color: Colors.transparent,
//         child: InkWell(
//           borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
//           onTap: () => onChanged(!value),
//           child: Padding(
//             padding: EdgeInsets.all(isMobile ? 16 : 20),
//             child: Row(
//               children: [
//                 Container(
//                   padding: const EdgeInsets.all(8),
//                   decoration: BoxDecoration(
//                     color: value 
//                         ? AppColors.primaryOrange.withOpacity(0.2)
//                         : Colors.white.withOpacity(0.1),
//                     borderRadius: BorderRadius.circular(8),
//                   ),
//                   child: Icon(
//                     icon,
//                     color: value 
//                         ? AppColors.primaryOrange
//                         : Colors.white.withOpacity(0.6),
//                     size: isMobile ? 16 : 18,
//                   ),
//                 ),
//                 const SizedBox(width: 16),
//                 Expanded(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         label,
//                         style: TextStyle(
//                           color: Colors.white,
//                           fontSize: isMobile ? 15 : 16,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                       const SizedBox(height: 4),
//                       Text(
//                         subtitle,
//                         style: TextStyle(
//                           color: Colors.white.withOpacity(0.7),
//                           fontSize: isMobile ? 13 : 14,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 Transform.scale(
//                   scale: isMobile ? 0.9 : 1.0,
//                   child: Switch(
//                     value: value,
//                     onChanged: onChanged,
//                     activeColor: AppColors.primaryOrange,
//                     activeTrackColor: AppColors.primaryOrange.withOpacity(0.3),
//                     inactiveThumbColor: Colors.white.withOpacity(0.6),
//                     inactiveTrackColor: Colors.white.withOpacity(0.2),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
