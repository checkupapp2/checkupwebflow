// import 'package:flutter/material.dart';
// import 'package:check_up_app/core/theme/app_colors.dart';
// import 'package:intl/intl.dart';

// /// A modern, mobile-friendly date and time picker widget
// class ModernDateTimePicker extends StatefulWidget {
//   /// The currently selected date and time
//   final DateTime? selectedDateTime;
  
//   /// Callback when date and time are selected
//   final Function(DateTime) onDateTimeSelected;

//   /// Creates a [ModernDateTimePicker] widget
//   const ModernDateTimePicker({
//     Key? key,
//     this.selectedDateTime,
//     required this.onDateTimeSelected,
//   }) : super(key: key);

//   @override
//   State<ModernDateTimePicker> createState() => _ModernDateTimePickerState();
// }

// class _ModernDateTimePickerState extends State<ModernDateTimePicker> {
//   late DateTime _selectedDate;
//   late TimeOfDay _selectedTime;

//   @override
//   void initState() {
//     super.initState();
//     _selectedDate = widget.selectedDateTime ?? DateTime.now();
//     _selectedTime = widget.selectedDateTime != null 
//         ? TimeOfDay.fromDateTime(widget.selectedDateTime!) 
//         : TimeOfDay.now();
//   }

//   void _updateDateTime() {
//     final dateTime = DateTime(
//       _selectedDate.year,
//       _selectedDate.month,
//       _selectedDate.day,
//       _selectedTime.hour,
//       _selectedTime.minute,
//     );
//     widget.onDateTimeSelected(dateTime);
//   }

//   @override
//   Widget build(BuildContext context) {
//     final now = DateTime.now();
    
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),
          
//           // Compact Header
//           const Text(
//             'When is your event happening?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
          
//           const SizedBox(height: 32),
          
//           // Compact Date & Time Row
//           Row(
//             children: [
//               // Date Section
//               Expanded(
//                 child: GestureDetector(
//                   onTap: () async {
//                     final date = await showDatePicker(
//                       context: context,
//                       initialDate: widget.selectedDateTime ?? DateTime.now(),
//                       firstDate: DateTime.now(),
//                       lastDate: DateTime.now().add(const Duration(days: 365)),
//                       builder: (context, child) {
//                         return Theme(
//                           data: Theme.of(context).copyWith(
//                             colorScheme: ColorScheme.dark(
//                               primary: AppColors.primaryOrange,
//                               onPrimary: Colors.white,
//                               surface: AppColors.secondaryBlack,
//                               onSurface: Colors.white,
//                             ),
//                           ),
//                           child: child!,
//                         );
//                       },
//                     );
//                     if (date != null) {
//                       setState(() {
//                         _selectedDate = date;
//                       });
//                       _updateDateTime();
//                     }
//                   },
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.05),
//                       borderRadius: BorderRadius.circular(16),
//                       border: Border.all(
//                         color: widget.selectedDateTime != null 
//                           ? AppColors.primaryOrange.withOpacity(0.3)
//                           : Colors.white.withOpacity(0.1),
//                         width: 1,
//                       ),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           children: [
//                             Icon(
//                               Icons.calendar_today,
//                               color: AppColors.primaryOrange,
//                               size: 16,
//                             ),
//                             const SizedBox(width: 8),
//                             const Text(
//                               'Date',
//                               style: TextStyle(
//                                 color: Colors.white70,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 8),
//                         Text(
//                           widget.selectedDateTime != null 
//                             ? DateFormat('MMM d, yyyy').format(_selectedDate)
//                             : 'Select date',
//                           style: TextStyle(
//                             color: widget.selectedDateTime != null 
//                               ? Colors.white 
//                               : Colors.white54,
//                             fontSize: 16,
//                             fontWeight: FontWeight.w600,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
              
//               const SizedBox(width: 16),
              
//               // Time Section
//               Expanded(
//                 child: GestureDetector(
//                   onTap: () async {
//                     final time = await showTimePicker(
//                       context: context,
//                       initialTime: widget.selectedDateTime != null 
//                         ? TimeOfDay.fromDateTime(widget.selectedDateTime!) 
//                         : TimeOfDay.now(),
//                       builder: (context, child) {
//                         return Theme(
//                           data: Theme.of(context).copyWith(
//                             colorScheme: ColorScheme.dark(
//                               primary: AppColors.primaryOrange,
//                               onPrimary: Colors.white,
//                               surface: AppColors.secondaryBlack,
//                               onSurface: Colors.white,
//                             ),
//                           ),
//                           child: child!,
//                         );
//                       },
//                     );
//                     if (time != null) {
//                       setState(() {
//                         _selectedTime = time;
//                       });
//                       _updateDateTime();
//                     }
//                   },
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.05),
//                       borderRadius: BorderRadius.circular(16),
//                       border: Border.all(
//                         color: widget.selectedDateTime != null 
//                           ? AppColors.primaryOrange.withOpacity(0.3)
//                           : Colors.white.withOpacity(0.1),
//                         width: 1,
//                       ),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           children: [
//                             Icon(
//                               Icons.access_time,
//                               color: AppColors.primaryOrange,
//                               size: 16,
//                             ),
//                             const SizedBox(width: 8),
//                             const Text(
//                               'Time',
//                               style: TextStyle(
//                                 color: Colors.white70,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 8),
//                         Text(
//                           widget.selectedDateTime != null 
//                             ? _selectedTime.format(context)
//                             : 'Select time',
//                           style: TextStyle(
//                             color: widget.selectedDateTime != null 
//                               ? Colors.white 
//                               : Colors.white54,
//                             fontSize: 16,
//                             fontWeight: FontWeight.w600,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
          
//           const SizedBox(height: 24),
          
//           // Quick Date Options
//           const Text(
//             'Quick Date Selection',
//             style: TextStyle(
//               color: Colors.white70,
//               fontSize: 14,
//               fontWeight: FontWeight.w500,
//             ),
//           ),
//           const SizedBox(height: 12),
//           Row(
//             children: [
//               _buildQuickDateOption('Today', now),
//               const SizedBox(width: 12),
//               _buildQuickDateOption('Tomorrow', now.add(const Duration(days: 1))),
//               const SizedBox(width: 12),
//               _buildQuickDateOption('Weekend', _getNextWeekend()),
//             ],
//           ),
          
//           const SizedBox(height: 24),
          
//           // Quick Time Options
//           const Text(
//             'Quick Time Selection',
//             style: TextStyle(
//               color: Colors.white70,
//               fontSize: 14,
//               fontWeight: FontWeight.w500,
//             ),
//           ),
//           const SizedBox(height: 12),
//           Wrap(
//             spacing: 12,
//             runSpacing: 12,
//             children: [
//               _buildQuickTimeOption('9:00 AM'),
//               _buildQuickTimeOption('12:00 PM'),
//               _buildQuickTimeOption('3:00 PM'),
//               _buildQuickTimeOption('6:00 PM'),
//               _buildQuickTimeOption('8:00 PM'),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildQuickDateOption(String label, DateTime date) {
//     final isSelected = widget.selectedDateTime != null && 
//       widget.selectedDateTime!.year == date.year &&
//       widget.selectedDateTime!.month == date.month &&
//       widget.selectedDateTime!.day == date.day;
    
//     return GestureDetector(
//       onTap: () {
//         setState(() {
//           _selectedDate = date;
//         });
//         _updateDateTime();
//       },
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//         decoration: BoxDecoration(
//           color: isSelected 
//             ? AppColors.primaryOrange.withOpacity(0.2)
//             : Colors.white.withOpacity(0.05),
//           borderRadius: BorderRadius.circular(12),
//           border: Border.all(
//             color: isSelected 
//               ? AppColors.primaryOrange
//               : Colors.white.withOpacity(0.1),
//             width: 1,
//           ),
//         ),
//         child: Text(
//           label,
//           style: TextStyle(
//             color: isSelected ? AppColors.primaryOrange : Colors.white70,
//             fontSize: 14,
//             fontWeight: FontWeight.w500,
//           ),
//         ),
//       ),
//     );
//   }
  
//   Widget _buildQuickTimeOption(String time) {
//     final isSelected = widget.selectedDateTime != null && 
//       _formatTime(_selectedTime) == time;
    
//     return GestureDetector(
//       onTap: () {
//         final timeParts = time.split(' ');
//         final hourMinute = timeParts[0].split(':');
//         int hour = int.parse(hourMinute[0]);
//         final minute = int.parse(hourMinute[1]);
        
//         if (timeParts[1] == 'PM' && hour != 12) hour += 12;
//         if (timeParts[1] == 'AM' && hour == 12) hour = 0;
        
//         setState(() {
//           _selectedTime = TimeOfDay(hour: hour, minute: minute);
//         });
//         _updateDateTime();
//       },
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//         decoration: BoxDecoration(
//           color: isSelected 
//             ? AppColors.primaryOrange.withOpacity(0.2)
//             : Colors.white.withOpacity(0.05),
//           borderRadius: BorderRadius.circular(12),
//           border: Border.all(
//             color: isSelected 
//               ? AppColors.primaryOrange
//               : Colors.white.withOpacity(0.1),
//             width: 1,
//           ),
//         ),
//         child: Text(
//           time,
//           style: TextStyle(
//             color: isSelected ? AppColors.primaryOrange : Colors.white70,
//             fontSize: 14,
//             fontWeight: FontWeight.w500,
//           ),
//         ),
//       ),
//     );
//   }
  
//   DateTime _getNextWeekend() {
//     final now = DateTime.now();
//     int daysUntilSaturday = (6 - now.weekday) % 7;
//     if (daysUntilSaturday == 0 && now.weekday == 6) {
//       daysUntilSaturday = 7;
//     }
//     return now.add(Duration(days: daysUntilSaturday));
//   }
  
//   String _formatTime(TimeOfDay time) {
//     final hour = time.hourOfPeriod;
//     final minute = time.minute.toString().padLeft(2, '0');
//     final period = time.period == DayPeriod.am ? 'AM' : 'PM';
//     final displayHour = hour == 0 ? 12 : hour;
//     return '$displayHour:$minute $period';
//   }
// }

//   @override
//   Widget build(BuildContext context) {
//     final now = DateTime.now();
    
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),
          
//           // Compact Header
//           const Text(
//             'When is your event happening?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
          
//           const SizedBox(height: 32),
          
//           // Compact Date & Time Row
//           Row(
//             children: [
//               // Date Section
//               Expanded(
//                 child: GestureDetector(
//                   onTap: () async {
//                     final date = await showDatePicker(
//                       context: context,
//                       initialDate: widget.selectedDateTime ?? DateTime.now(),
//                       firstDate: DateTime.now(),
//                       lastDate: DateTime.now().add(const Duration(days: 365)),
//                       builder: (context, child) {
//                         return Theme(
//                           data: Theme.of(context).copyWith(
//                             colorScheme: ColorScheme.dark(
//                               primary: AppColors.primaryOrange,
//                               onPrimary: Colors.white,
//                               surface: AppColors.secondaryBlack,
//                               onSurface: Colors.white,
//                             ),
//                           ),
//                           child: child!,
//                         );
//                       },
//                     );
//                     if (date != null) {
//                       setState(() {
//                         _selectedDate = date;
//                       });
//                       _updateDateTime();
//                     }
//                   },
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.05),
//                       borderRadius: BorderRadius.circular(16),
//                       border: Border.all(
//                         color: widget.selectedDateTime != null 
//                           ? AppColors.primaryOrange.withOpacity(0.3)
//                           : Colors.white.withOpacity(0.1),
//                         width: 1,
//                       ),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           children: [
//                             Icon(
//                               Icons.calendar_today,
//                               color: AppColors.primaryOrange,
//                               size: 16,
//                             ),
//                             const SizedBox(width: 8),
//                             const Text(
//                               'Date',
//                               style: TextStyle(
//                                 color: Colors.white70,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 8),
//                         Text(
//                           widget.selectedDateTime != null 
//                             ? DateFormat('MMM d, yyyy').format(_selectedDate)
//                             : 'Select date',
//                           style: TextStyle(
//                             color: widget.selectedDateTime != null 
//                               ? Colors.white 
//                               : Colors.white54,
//                             fontSize: 16,
//                             fontWeight: FontWeight.w600,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
              
//               const SizedBox(width: 16),
              
//               // Time Section
//               Expanded(
//                 child: GestureDetector(
//                   onTap: () async {
//                     final time = await showTimePicker(
//                       context: context,
//                       initialTime: widget.selectedDateTime != null 
//                         ? TimeOfDay.fromDateTime(widget.selectedDateTime!) 
//                         : TimeOfDay.now(),
//                       builder: (context, child) {
//                         return Theme(
//                           data: Theme.of(context).copyWith(
//                             colorScheme: ColorScheme.dark(
//                               primary: AppColors.primaryOrange,
//                               onPrimary: Colors.white,
//                               surface: AppColors.secondaryBlack,
//                               onSurface: Colors.white,
//                             ),
//                           ),
//                           child: child!,
//                         );
//                       },
//                     );
//                     if (time != null) {
//                       setState(() {
//                         _selectedTime = time;
//                       });
//                       _updateDateTime();
//                     }
//                   },
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.05),
//                       borderRadius: BorderRadius.circular(16),
//                       border: Border.all(
//                         color: widget.selectedDateTime != null 
//                           ? AppColors.primaryOrange.withOpacity(0.3)
//                           : Colors.white.withOpacity(0.1),
//                         width: 1,
//                       ),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           children: [
//                             Icon(
//                               Icons.access_time,
//                               color: AppColors.primaryOrange,
//                               size: 16,
//                             ),
//                             const SizedBox(width: 8),
//                             const Text(
//                               'Time',
//                               style: TextStyle(
//                                 color: Colors.white70,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 8),
//                         Text(
//                           widget.selectedDateTime != null 
//                             ? _selectedTime.format(context)
//                             : 'Select time',
//                           style: TextStyle(
//                             color: widget.selectedDateTime != null 
//                               ? Colors.white 
//                               : Colors.white54,
//                             fontSize: 16,
//                             fontWeight: FontWeight.w600,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
          
//           const SizedBox(height: 24),
          
//           // Quick Date Options
//           const Text(
//             'Quick Date Selection',
//             style: TextStyle(
//               color: Colors.white70,
//               fontSize: 14,
//               fontWeight: FontWeight.w500,
//             ),
//           ),
//           const SizedBox(height: 12),
//           Row(
//             children: [
//               _buildQuickDateOption('Today', now),
//               const SizedBox(width: 12),
//               _buildQuickDateOption('Tomorrow', now.add(const Duration(days: 1))),
//               const SizedBox(width: 12),
//               _buildQuickDateOption('Weekend', _getNextWeekend()),
//             ],
//           ),
          
//           const SizedBox(height: 24),
          
//           // Quick Time Options
//           const Text(
//             'Quick Time Selection',
//             style: TextStyle(
//               color: Colors.white70,
//               fontSize: 14,
//               fontWeight: FontWeight.w500,
//             ),
//           ),
//           const SizedBox(height: 12),
//           Wrap(
//             spacing: 12,
//             runSpacing: 12,
//             children: [
//               _buildQuickTimeOption('9:00 AM'),
//               _buildQuickTimeOption('12:00 PM'),
//               _buildQuickTimeOption('3:00 PM'),
//               _buildQuickTimeOption('6:00 PM'),
//               _buildQuickTimeOption('8:00 PM'),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildQuickDateOption(String label, DateTime date) {
//     final isSelected = widget.selectedDateTime != null && 
//       widget.selectedDateTime!.year == date.year &&
//       widget.selectedDateTime!.month == date.month &&
//       widget.selectedDateTime!.day == date.day;
    
//     return GestureDetector(
//       onTap: () {
//         setState(() {
//           _selectedDate = date;
//         });
//         _updateDateTime();
//       },
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//         decoration: BoxDecoration(
//           color: isSelected 
//             ? AppColors.primaryOrange.withOpacity(0.2)
//             : Colors.white.withOpacity(0.05),
//           borderRadius: BorderRadius.circular(12),
//           border: Border.all(
//             color: isSelected 
//               ? AppColors.primaryOrange
//               : Colors.white.withOpacity(0.1),
//             width: 1,
//           ),
//         ),
//         child: Text(
//           label,
//           style: TextStyle(
//             color: isSelected ? AppColors.primaryOrange : Colors.white70,
//             fontSize: 14,
//             fontWeight: FontWeight.w500,
//           ),
//         ),
//       ),
//     );
//   }
  
//   Widget _buildQuickTimeOption(String time) {
//     final isSelected = widget.selectedDateTime != null && 
//       _formatTime(_selectedTime) == time;
    
//     return GestureDetector(
//       onTap: () {
//         final timeParts = time.split(' ');
//         final hourMinute = timeParts[0].split(':');
//         int hour = int.parse(hourMinute[0]);
//         final minute = int.parse(hourMinute[1]);
        
//         if (timeParts[1] == 'PM' && hour != 12) hour += 12;
//         if (timeParts[1] == 'AM' && hour == 12) hour = 0;
        
//         setState(() {
//           _selectedTime = TimeOfDay(hour: hour, minute: minute);
//         });
//         _updateDateTime();
//       },
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//         decoration: BoxDecoration(
//           color: isSelected 
//             ? AppColors.primaryOrange.withOpacity(0.2)
//             : Colors.white.withOpacity(0.05),
//           borderRadius: BorderRadius.circular(12),
//           border: Border.all(
//             color: isSelected 
//               ? AppColors.primaryOrange
//               : Colors.white.withOpacity(0.1),
//             width: 1,
//           ),
//         ),
//         child: Text(
//           time,
//           style: TextStyle(
//             color: isSelected ? AppColors.primaryOrange : Colors.white70,
//             fontSize: 14,
//             fontWeight: FontWeight.w500,
//           ),
//         ),
//       ),
//     );
//   }
  
//   DateTime _getNextWeekend() {
//     final now = DateTime.now();
//     int daysUntilSaturday = (6 - now.weekday) % 7;
//     if (daysUntilSaturday == 0 && now.weekday == 6) {
//       daysUntilSaturday = 7;
//     }
//     return now.add(Duration(days: daysUntilSaturday));
//   }
  
//   String _formatTime(TimeOfDay time) {
//     final hour = time.hourOfPeriod;
//     final minute = time.minute.toString().padLeft(2, '0');
//     final period = time.period == DayPeriod.am ? 'AM' : 'PM';
//     final displayHour = hour == 0 ? 12 : hour;
//     return '$displayHour:$minute $period';
//   }
// }

//   @override
//   Widget build(BuildContext context) {
//     final now = DateTime.now();
    
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),
          
//           // Compact Header
//           const Text(
//             'When is your event happening?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
          
//           const SizedBox(height: 32),
          
//           // Compact Date & Time Row
//           Row(
//             children: [
//               // Date Section
//               Expanded(
//                 child: GestureDetector(
//                   onTap: () async {
//                     final date = await showDatePicker(
//                       context: context,
//                       initialDate: widget.selectedDateTime ?? DateTime.now(),
//                       firstDate: DateTime.now(),
//                       lastDate: DateTime.now().add(const Duration(days: 365)),
//                       builder: (context, child) {
//                         return Theme(
//                           data: Theme.of(context).copyWith(
//                             colorScheme: ColorScheme.dark(
//                               primary: AppColors.primaryOrange,
//                               onPrimary: Colors.white,
//                               surface: AppColors.secondaryBlack,
//                               onSurface: Colors.white,
//                             ),
//                           ),
//                           child: child!,
//                         );
//                       },
//                     );
//                     if (date != null) {
//                       setState(() {
//                         _selectedDate = date;
//                       });
//                       _updateDateTime();
//                     }
//                   },
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.05),
//                       borderRadius: BorderRadius.circular(16),
//                       border: Border.all(
//                         color: widget.selectedDateTime != null 
//                           ? AppColors.primaryOrange.withOpacity(0.3)
//                           : Colors.white.withOpacity(0.1),
//                         width: 1,
//                       ),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           children: [
//                             Icon(
//                               Icons.calendar_today,
//                               color: AppColors.primaryOrange,
//                               size: 16,
//                             ),
//                             const SizedBox(width: 8),
//                             const Text(
//                               'Date',
//                               style: TextStyle(
//                                 color: Colors.white70,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 8),
//                         Text(
//                           widget.selectedDateTime != null 
//                             ? DateFormat('MMM d, yyyy').format(_selectedDate)
//                             : 'Select date',
//                           style: TextStyle(
//                             color: widget.selectedDateTime != null 
//                               ? Colors.white 
//                               : Colors.white54,
//                             fontSize: 16,
//                             fontWeight: FontWeight.w600,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
              
//               const SizedBox(width: 16),
              
//               // Time Section
//               Expanded(
//                 child: GestureDetector(
//                   onTap: () async {
//                     final time = await showTimePicker(
//                       context: context,
//                       initialTime: widget.selectedDateTime != null 
//                         ? TimeOfDay.fromDateTime(widget.selectedDateTime!) 
//                         : TimeOfDay.now(),
//                       builder: (context, child) {
//                         return Theme(
//                           data: Theme.of(context).copyWith(
//                             colorScheme: ColorScheme.dark(
//                               primary: AppColors.primaryOrange,
//                               onPrimary: Colors.white,
//                               surface: AppColors.secondaryBlack,
//                               onSurface: Colors.white,
//                             ),
//                           ),
//                           child: child!,
//                         );
//                       },
//                     );
//                     if (time != null) {
//                       setState(() {
//                         _selectedTime = time;
//                       });
//                       _updateDateTime();
//                     }
//                   },
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.05),
//                       borderRadius: BorderRadius.circular(16),
//                       border: Border.all(
//                         color: widget.selectedDateTime != null 
//                           ? AppColors.primaryOrange.withOpacity(0.3)
//                           : Colors.white.withOpacity(0.1),
//                         width: 1,
//                       ),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           children: [
//                             Icon(
//                               Icons.access_time,
//                               color: AppColors.primaryOrange,
//                               size: 16,
//                             ),
//                             const SizedBox(width: 8),
//                             const Text(
//                               'Time',
//                               style: TextStyle(
//                                 color: Colors.white70,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 8),
//                         Text(
//                           widget.selectedDateTime != null 
//                             ? _selectedTime.format(context)
//                             : 'Select time',
//                           style: TextStyle(
//                             color: widget.selectedDateTime != null 
//                               ? Colors.white 
//                               : Colors.white54,
//                             fontSize: 16,
//                             fontWeight: FontWeight.w600,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
          
//           const SizedBox(height: 24),
          
//           // Quick Date Options
//           const Text(
//             'Quick Date Selection',
//             style: TextStyle(
//               color: Colors.white70,
//               fontSize: 14,
//               fontWeight: FontWeight.w500,
//             ),
//           ),
//           const SizedBox(height: 12),
//           Row(
//             children: [
//               _buildQuickDateOption('Today', now),
//               const SizedBox(width: 12),
//               _buildQuickDateOption('Tomorrow', now.add(const Duration(days: 1))),
//               const SizedBox(width: 12),
//               _buildQuickDateOption('Weekend', _getNextWeekend()),
//             ],
//           ),
          
//           const SizedBox(height: 24),
          
//           // Quick Time Options
//           const Text(
//             'Quick Time Selection',
//             style: TextStyle(
//               color: Colors.white70,
//               fontSize: 14,
//               fontWeight: FontWeight.w500,
//             ),
//           ),
//           const SizedBox(height: 12),
//           Wrap(
//             spacing: 12,
//             runSpacing: 12,
//             children: [
//               _buildQuickTimeOption('9:00 AM'),
//               _buildQuickTimeOption('12:00 PM'),
//               _buildQuickTimeOption('3:00 PM'),
//               _buildQuickTimeOption('6:00 PM'),
//               _buildQuickTimeOption('8:00 PM'),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildQuickDateOption(String label, DateTime date) {
//     final isSelected = widget.selectedDateTime != null && 
//       widget.selectedDateTime!.year == date.year &&
//       widget.selectedDateTime!.month == date.month &&
//       widget.selectedDateTime!.day == date.day;
    
//     return GestureDetector(
//       onTap: () {
//         setState(() {
//           _selectedDate = date;
//         });
//         _updateDateTime();
//       },
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//         decoration: BoxDecoration(
//           color: isSelected 
//             ? AppColors.primaryOrange.withOpacity(0.2)
//             : Colors.white.withOpacity(0.05),
//           borderRadius: BorderRadius.circular(12),
//           border: Border.all(
//             color: isSelected 
//               ? AppColors.primaryOrange
//               : Colors.white.withOpacity(0.1),
//             width: 1,
//           ),
//         ),
//         child: Text(
//           label,
//           style: TextStyle(
//             color: isSelected ? AppColors.primaryOrange : Colors.white70,
//             fontSize: 14,
//             fontWeight: FontWeight.w500,
//           ),
//         ),
//       ),
//     );
//   }
  
//   Widget _buildQuickTimeOption(String time) {
//     final isSelected = widget.selectedDateTime != null && 
//       _formatTime(_selectedTime) == time;
    
//     return GestureDetector(
//       onTap: () {
//         final timeParts = time.split(' ');
//         final hourMinute = timeParts[0].split(':');
//         int hour = int.parse(hourMinute[0]);
//         final minute = int.parse(hourMinute[1]);
        
//         if (timeParts[1] == 'PM' && hour != 12) hour += 12;
//         if (timeParts[1] == 'AM' && hour == 12) hour = 0;
        
//         setState(() {
//           _selectedTime = TimeOfDay(hour: hour, minute: minute);
//         });
//         _updateDateTime();
//       },
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//         decoration: BoxDecoration(
//           color: isSelected 
//             ? AppColors.primaryOrange.withOpacity(0.2)
//             : Colors.white.withOpacity(0.05),
//           borderRadius: BorderRadius.circular(12),
//           border: Border.all(
//             color: isSelected 
//               ? AppColors.primaryOrange
//               : Colors.white.withOpacity(0.1),
//             width: 1,
//           ),
//         ),
//         child: Text(
//           time,
//           style: TextStyle(
//             color: isSelected ? AppColors.primaryOrange : Colors.white70,
//             fontSize: 14,
//             fontWeight: FontWeight.w500,
//           ),
//         ),
//       ),
//     );
//   }
  
//   DateTime _getNextWeekend() {
//     final now = DateTime.now();
//     int daysUntilSaturday = (6 - now.weekday) % 7;
//     if (daysUntilSaturday == 0 && now.weekday == 6) {
//       daysUntilSaturday = 7;
//     }
//     return now.add(Duration(days: daysUntilSaturday));
//   }
  
//   String _formatTime(TimeOfDay time) {
//     final hour = time.hourOfPeriod;
//     final minute = time.minute.toString().padLeft(2, '0');
//     final period = time.period == DayPeriod.am ? 'AM' : 'PM';
//     final displayHour = hour == 0 ? 12 : hour;
//     return '$displayHour:$minute $period';
//   }



//   Widget _buildCalendarGrid() {
//     // Get the first day of the month
//     final firstDayOfMonth = DateTime(_selectedDate.year, _selectedDate.month, 1);
    
// {{ ... }}
//               width: 30,
//               child: Text(
//                 day,
//                 textAlign: TextAlign.center,
//                 style: TextStyle(
//                   color: Colors.grey[400],
//                   fontSize: 12,
//                 ),
//               ),
//             )
//           ).toList(),
//         ),
//         const SizedBox(height: 8),
        
//         // Calendar days
//         GridView.builder(
//           shrinkWrap: true,
//           physics: const NeverScrollableScrollPhysics(),
//           gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//             crossAxisCount: 7,
//             childAspectRatio: 1,
//           ),
//           itemCount: adjustedFirstDay + daysInMonth,
//           itemBuilder: (context, index) {
//             if (index < adjustedFirstDay) {
//               return const SizedBox(); // Empty space for days before the month starts
//             }
            
//             final day = index - adjustedFirstDay + 1;
//             final date = DateTime(_selectedDate.year, _selectedDate.month, day);
//             final isSelected = day == _selectedDate.day;
//             final isToday = _isSameDay(date, DateTime.now());
            
//             return GestureDetector(
//               onTap: () {
//                 setState(() {
//                   _selectedDate = DateTime(
//                     _selectedDate.year,
//                     _selectedDate.month,
//                     day,
//                   );
//                 });
//               },
//               child: Container(
//                 margin: const EdgeInsets.all(2),
//                 decoration: BoxDecoration(
//                   gradient: isSelected ? AppColors.orangeGradient : null,
//                   color: isToday && !isSelected ? AppColors.darkGray : null,
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: Center(
//                   child: Text(
//                     day.toString(),
//                     style: TextStyle(
//                       color: isSelected ? Colors.white : (isToday ? Colors.white : Colors.grey[300]),
//                       fontWeight: isSelected || isToday ? FontWeight.bold : FontWeight.normal,
//                     ),
//                   ),
//                 ),
//               ),
//             );
//           },
//         ),
//       ],
//     );
//   }

//   bool _isSameDay(DateTime a, DateTime b) {
//     return a.year == b.year && a.month == b.month && a.day == b.day;
//   }

//   Widget _buildTimePicker() {
//     // Create time slots in 30-minute increments
//     final timeSlots = <TimeOfDay>[];
//     for (int hour = 0; hour < 24; hour++) {
//       timeSlots.add(TimeOfDay(hour: hour, minute: 0));
//       timeSlots.add(TimeOfDay(hour: hour, minute: 30));
//     }
    
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: AppColors.secondaryBlack,
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: AppColors.darkGray),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Text(
//             'Select Time',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 16,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 16),
          
//           // Time slots grid
//           SizedBox(
//             height: 200,
//             child: GridView.builder(
//               gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//                 crossAxisCount: 4,
//                 childAspectRatio: 2.5,
//                 crossAxisSpacing: 8,
//                 mainAxisSpacing: 8,
//               ),
//               itemCount: timeSlots.length,
//               itemBuilder: (context, index) {
//                 final time = timeSlots[index];
//                 final isSelected = time.hour == _selectedTime.hour && 
//                                   time.minute == _selectedTime.minute;
                
//                 return GestureDetector(
//                   onTap: () {
//                     setState(() {
//                       _selectedTime = time;
//                     });
//                   },
//                   child: Container(
//                     decoration: BoxDecoration(
//                       gradient: isSelected ? AppColors.orangeGradient : null,
//                       color: isSelected ? null : AppColors.darkGray,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: Center(
//                       child: Text(
//                         _formatTimeOfDay(time),
//                         style: TextStyle(
//                           color: isSelected ? Colors.white : Colors.grey[300],
//                           fontSize: 12,
//                           fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
//                         ),
//                       ),
//                     ),
//                   ),
//                 );
//               },
//             ),
//           ),
          
//           const SizedBox(height: 16),
          
//           // Done button
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               onPressed: () {
//                 setState(() {
//                   _isTimePickerVisible = false;
//                   _updateDateTime();
//                 });
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.orangeGradientEnd,
//                 foregroundColor: Colors.white,
//                 padding: const EdgeInsets.symmetric(vertical: 12),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//               ),
//               child: const Text('Done'),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   String _formatTimeOfDay(TimeOfDay time) {
//     final hour = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
//     final minute = time.minute.toString().padLeft(2, '0');
//     final period = time.period == DayPeriod.am ? 'AM' : 'PM';
//     return '$hour:$minute $period';
//   }

//   Widget _buildIconButton({required IconData icon, required VoidCallback onTap}) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         padding: const EdgeInsets.all(8),
//         decoration: BoxDecoration(
//           color: AppColors.darkGray,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: Icon(
//           icon,
//           color: Colors.white,
//           size: 16,
//         ),
//       ),
//     );
//   }
// }
