// lib/features/events/presentation/pages/host_event_detail_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:check_up_app/features/events/presentation/pages/manage_event_page.dart';
import '../widgets/host_detail/image_carousel_hero.dart';
import '../widgets/host_detail/event_info_card.dart';
import '../widgets/host_detail/host_info_card.dart';
import '../widgets/host_detail/location_card.dart';
import '../widgets/host_detail/collapsible_details_card.dart';
import '../widgets/host_detail/event_activity_section.dart';
import '../widgets/host_detail/feed_section.dart';
import '../widgets/host_detail/bottom_status_bar.dart';

import '../../data/events_repository.dart';
import '../../bloc/event_detail/event_detail_cubit.dart';
import '../../bloc/event_detail/event_detail_state.dart';
import '../../domain/models/event_model.dart';

class HostEventDetailPage extends StatefulWidget {
  final String? eventId;
  final String? title;

  const HostEventDetailPage({
    Key? key,
    this.eventId,
    this.title,
  }) : super(key: key);

  @override
  State<HostEventDetailPage> createState() => _HostEventDetailPageState();
}

class _HostEventDetailPageState extends State<HostEventDetailPage> {
  // You can flip this to true if you want it opened by default.
  bool _isDetailsExpanded = false;

  @override
  Widget build(BuildContext context) {
    final id = widget.eventId ?? '';

    return BlocProvider(
      create: (_) => EventDetailCubit(
        repo: EventsRepository(),
        auth: FirebaseAuth.instance,
      )..load(id),
      child: BlocBuilder<EventDetailCubit, EventDetailState>(
        builder: (context, state) {
          final ev = state.event;
          final loading = state.loading;

          final resolvedTitle =
              ev?.title ?? widget.title ?? '3v3 Summer Tournament';

          final String dateText =
              ev?.dateTime != null ? _longDate(ev!.dateTime) : 'June 15, 2025';
          final String timeText = ev?.dateTime != null
              ? _timeRange(ev!.dateTime)
              : '7:00 PM - 9:30 PM';

          final String placeName =
              (state.venueName != null && state.venueName!.trim().isNotEmpty)
                  ? state.venueName!
                  : 'Rucker Park';

          final String locationText = (state.venueAddress != null &&
                  state.venueAddress!.trim().isNotEmpty)
              ? state.venueAddress!
              : 'Harlem, New York';

          final String statusText = _isPublished(ev) ? 'Published' : 'Draft';

          final String detailsText = state.detailsText;
          final String previewText = detailsText
              .split('\n')
              .where((l) => l.trim().isNotEmpty)
              .take(2)
              .join('\n');

          // Prefer gallery first, then banner, else fallback happens inside the widget
          final List<String> images = () {
            final e = ev;
            if (e == null) return const <String>[];

            // Normalize to List<String>
            final List<String> gallery = (e.imageUrls is List<String>)
                ? (e.imageUrls as List<String>)
                : (e.imageUrls as List)
                    .map((x) => x?.toString() ?? '')
                    .where((s) => s.isNotEmpty)
                    .toList(growable: false);

            if (gallery.isNotEmpty) return gallery;

            final banner = e.bannerImageUrl;
            if (banner != null && banner.isNotEmpty) return <String>[banner];

            return const <String>[];
          }();

          final gameType = ev?.category?.trim().isNotEmpty == true
              ? ev!.category
              : '3v3 Tournament';

          return Scaffold(
            resizeToAvoidBottomInset: true,
            appBar: AppBar(
              title: Image.asset(
                'assets/images/checkup_main-1.png',
                height: 32,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => Text(resolvedTitle),
              ),
              backgroundColor: Colors.black,
              foregroundColor: Colors.white,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => Navigator.of(context).pop(),
              ),
              actions: const [_ShareButton()],
            ),
            body: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF0A0A0A), Color(0xFF1A1A1A)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: loading
                  ? const Center(
                      child: CircularProgressIndicator(color: Colors.orange),
                    )
                  : SingleChildScrollView(
                      padding: const EdgeInsets.only(bottom: 80),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Hero carousel (unchanged UI)
                          ImageCarouselHero(
                            images: images,
                            gameTypeText: gameType,
                          ),

                          // Details stack (unchanged UI; data-fed)
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  resolvedTitle,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Montserrat',
                                  ),
                                ),
                                const SizedBox(height: 16),

                                EventInfoCard(
                                  dateText: dateText,
                                  timeText: timeText,
                                ),
                                const SizedBox(height: 24),

                                const HostInfoCard(
                                  hostName: 'You (Host)',
                                  roleText: 'Event Organizer',
                                  actionText: 'Contact',
                                ),
                                const SizedBox(height: 16),

                                LocationCard(
                                  placeName: placeName,
                                  locationText: locationText,
                                  actionText: 'Directions',
                                ),

                                const SizedBox(height: 24),

                                // NEW API usage:
                                CollapsibleDetailsCard(
                                  previewText: previewText.isNotEmpty
                                      ? previewText
                                      : 'Tap to see more details...',
                                  detailsText: detailsText,
                                  initiallyExpanded: _isDetailsExpanded,
                                ),

                                const SizedBox(height: 24),
                                const EventActivitySection(),

                                const SizedBox(height: 24),
                                const FeedSection(),
                                const SizedBox(height: 32),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
            bottomNavigationBar: BottomStatusBar(
              statusText: statusText,
              onManageTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ManageEventPage(
                      eventId: id,
                      title: resolvedTitle,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  static bool _isPublished(EventModel? ev) {
    if (ev == null) return false;
    return ev.dateTime.isAfter(DateTime.now());
  }

  static String _longDate(DateTime dt) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    return '${months[dt.month - 1]} ${dt.day}, ${dt.year}';
  }

  static String _timeRange(DateTime start) {
    String _fmt(DateTime t) {
      final h = t.hour % 12 == 0 ? 12 : t.hour % 12;
      final m = t.minute.toString().padLeft(2, '0');
      final ampm = t.hour >= 12 ? 'PM' : 'AM';
      return '$h:$m $ampm';
    }

    return _fmt(start);
  }
}

class _ShareButton extends StatelessWidget {
  const _ShareButton();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF9800).withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            // Share handled elsewhere if needed
          },
          borderRadius: BorderRadius.circular(20),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.share, color: Colors.white, size: 16),
                SizedBox(width: 6),
                Text(
                  'Share',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
