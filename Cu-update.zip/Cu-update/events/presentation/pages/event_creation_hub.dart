import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../domain/models/event_type.dart';
import 'create_event_page.dart';

/// Unified Event Creation Hub
/// Provides three ways to create events: Advanced, Quick, and Voice-Guided
class EventCreationHub extends StatefulWidget {
  const EventCreationHub({super.key});

  @override
  State<EventCreationHub> createState() => _EventCreationHubState();
}

class _EventCreationHubState extends State<EventCreationHub>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  // Voice input state
  final TextEditingController _voiceInputController = TextEditingController();
  final FocusNode _textFieldFocusNode = FocusNode();
  bool _isProcessing = false;
  bool _hasProcessedInput = false;

  // Parsed event data
  String _eventTitle = '';
  String _eventDescription = '';
  DateTime? _eventDate;
  TimeOfDay? _eventTime;
  String _location = '';
  EventType _eventType = EventType.pickupRun;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    // Auto-start voice input when screen loads
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startVoiceInput();
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _voiceInputController.dispose();
    _textFieldFocusNode.dispose();
    super.dispose();
  }

  void _setupAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));

    _fadeController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            children: [
              // Header
              _buildHeader(),

              // Creation Options
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      const SizedBox(height: 20),

                      // ChatGPT-style Voice Widget
                      _buildVoiceWidget(),

                      const SizedBox(height: 32),

                      // Advanced Option
                      _buildCreationOption(
                        title: 'Advanced',
                        subtitle: 'Full customization',
                        description:
                            'Complete control over all event settings and options',
                        icon: Icons.tune,
                        gradient: const LinearGradient(
                          colors: [Color(0xFF4CAF50), Color(0xFF66BB6A)],
                        ),
                        onTap: () => _navigateToAdvanced(),
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 22,
                ),
              ),
              const Expanded(
                child: Text(
                  'Create Event',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(width: 48), // Balance the back button
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Choose how you\'d like to create your event',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreationOption({
    required String title,
    required String subtitle,
    required String description,
    required IconData icon,
    required Gradient gradient,
    required VoidCallback onTap,
    bool featured = false,
  }) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(bottom: featured ? 8 : 0),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF1A1A1A).withValues(alpha: 0.8),
            const Color(0xFF2A2A2A).withValues(alpha: 0.6),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: featured
              ? const Color(0xFF6C63FF).withValues(alpha: 0.3)
              : Colors.grey[700]!.withValues(alpha: 0.3),
          width: featured ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: featured ? 12 : 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            HapticFeedback.mediumImpact();
            onTap();
          },
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: EdgeInsets.all(featured ? 24 : 20),
            child: Row(
              children: [
                // Icon with gradient background
                Container(
                  width: featured ? 64 : 56,
                  height: featured ? 64 : 56,
                  decoration: BoxDecoration(
                    gradient: gradient,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: gradient.colors.first.withValues(alpha: 0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Icon(
                    icon,
                    color: Colors.white,
                    size: featured ? 32 : 28,
                  ),
                ),

                const SizedBox(width: 20),

                // Content
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            title,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: featured ? 20 : 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          if (featured) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                gradient: gradient,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Text(
                                'NEW',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: featured
                              ? const Color(0xFF6C63FF)
                              : const Color(0xFFFF6B35),
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        description,
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 13,
                          height: 1.3,
                        ),
                      ),
                    ],
                  ),
                ),

                // Arrow
                Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.grey[500],
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildVoiceWidget() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFFFF6B35).withValues(alpha: 0.15),
            Colors.black.withValues(alpha: 0.8),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFFF6B35).withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF6B35), Color(0xFFFF8A50)],
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.auto_awesome,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'AI Event Assistant',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      'Describe your event and I\'ll help create it',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Voice Input Area
          if (!_hasProcessedInput) ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[900]?.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Colors.grey[700]!,
                  width: 1,
                ),
              ),
              child: Column(
                children: [
                  TextField(
                    controller: _voiceInputController,
                    focusNode: _textFieldFocusNode,
                    style: const TextStyle(color: Colors.white),
                    maxLines: 3,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    decoration: InputDecoration(
                      hintText:
                          'Try: "Pickup basketball game tomorrow at 6 PM at the park"',
                      hintStyle: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 14,
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Process Button (full width without voice button)
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFF6B35), Color(0xFFFF8A50)],
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: _isProcessing ? null : _processVoiceInput,
                        borderRadius: BorderRadius.circular(16),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          child: _isProcessing
                              ? const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                Colors.white),
                                      ),
                                    ),
                                    SizedBox(width: 8),
                                    Text(
                                      'Processing...',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                )
                              : const Text(
                                  'Create Event',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ] else ...[
            // Processed Results
            _buildProcessedResults(),
          ],

          const SizedBox(height: 12),

          // Example suggestions
          if (!_hasProcessedInput)
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _getRandomSuggestionChips(),
            ),
        ],
      ),
    );
  }

  List<Widget> _getRandomSuggestionChips() {
    final allSuggestions = [
      // Pickup games
      'Pickup basketball game tomorrow at 6 PM',
      'Competitive pickup run Friday evening',
      'Casual pickup game Saturday morning at Riverside Park',
      'Pickup basketball at Lincoln Court tonight',

      // Training sessions
      'Basketball training session this Saturday',
      'Shooting practice Wednesday at 5 PM',
      'Skills training camp next week',
      'Basketball conditioning workout tomorrow',

      // Tournaments
      '3v3 tournament this weekend at Central Courts',
      'Basketball championship Friday night',
      '5v5 tournament at Memorial Gym',
      'Street ball competition Saturday',

      // Camps and clinics
      'Youth basketball camp next Monday',
      'Adult basketball clinic this Thursday',
      'Basketball fundamentals workshop',
      'Kids basketball camp at Community Center',

      // Open gym
      'Open gym Friday evening at the rec center',
      'Free play session Sunday afternoon',
      'Open court time at Westside Gym',
      'Basketball open gym tonight',

      // Fundraising events
      'Basketball fundraiser for charity Saturday',
      'Donation game to support local team',
      'Charity basketball event next week',
      'Fundraising tournament at Oak Park',

      // Special events
      '1v1 basketball challenge tomorrow',
      'Basketball skills showcase Friday',
      'Community basketball event Saturday',
      'Basketball social meetup tonight',
    ];

    // Shuffle and take 3 random suggestions
    final shuffled = List<String>.from(allSuggestions)..shuffle();
    final selected = shuffled.take(3).toList();

    return selected.map((text) => _buildSuggestionChip(text)).toList();
  }

  Widget _buildSuggestionChip(String text) {
    return GestureDetector(
      onTap: () {
        _voiceInputController.text = text;
        _processVoiceInput();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.grey[800]?.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.grey[600]!,
            width: 0.5,
          ),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: Colors.grey[300],
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  Widget _buildProcessedResults() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF4CAF50).withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFF4CAF50).withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.check_circle, color: Color(0xFF4CAF50), size: 20),
              SizedBox(width: 8),
              Text(
                'Event Details Parsed',
                style: TextStyle(
                  color: Color(0xFF4CAF50),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _buildResultItem('Title', _eventTitle),
          _buildResultItem('Type', _eventType.displayName),
          _buildResultItem('Date', _formatDate(_eventDate)),
          _buildResultItem('Time', _formatTime(_eventTime)),
          _buildResultItem('Location', _location),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _finishEventCreation,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4CAF50),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text(
                'Finish Event',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 60,
            child: Text(
              '$label:',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 12,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value.isNotEmpty ? value : 'Not specified',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _startVoiceInput() {
    HapticFeedback.lightImpact();
    // Don't auto-focus the text field - let user tap to focus when they want to type
    // This prevents the keyboard from opening automatically when the page loads
    // Users can still tap the text field or voice button to start input
  }

  void _processVoiceInput() {
    if (_voiceInputController.text.trim().isEmpty) return;

    setState(() => _isProcessing = true);

    // Simulate AI processing
    Future.delayed(const Duration(seconds: 2), () {
      final input = _voiceInputController.text.toLowerCase();
      final parsedData = _parseVoiceInput(input);

      setState(() {
        _eventTitle = parsedData['title'] ?? '';
        _eventDescription = parsedData['description'] ?? '';
        _eventDate = parsedData['date'];
        _eventTime = parsedData['time'];
        _location = parsedData['location'] ?? '';
        _eventType = parsedData['type'] ?? EventType.pickupRun;
        _isProcessing = false;
        _hasProcessedInput = true;
      });

      HapticFeedback.lightImpact();
    });
  }

  Map<String, dynamic> _parseVoiceInput(String input) {
    final lowerInput = input.toLowerCase();

    // Parse event type - basketball focused with more keywords
    EventType eventType = EventType.pickupRun;
    if (lowerInput.contains('fundraiser') ||
        lowerInput.contains('donation') ||
        lowerInput.contains('charity') ||
        lowerInput.contains('donate') ||
        lowerInput.contains('benefit')) {
      eventType = EventType.donationBased;
    } else if (lowerInput.contains('pickup') ||
        lowerInput.contains('game') ||
        lowerInput.contains('scrimmage') ||
        lowerInput.contains('run') ||
        lowerInput.contains('play basketball')) {
      eventType = EventType.pickupRun;
    } else if (lowerInput.contains('training') ||
        lowerInput.contains('practice') ||
        lowerInput.contains('drill') ||
        lowerInput.contains('skill') ||
        lowerInput.contains('workout')) {
      eventType = EventType.training;
    } else if (lowerInput.contains('tournament') ||
        lowerInput.contains('competition') ||
        lowerInput.contains('bracket') ||
        lowerInput.contains('championship') ||
        lowerInput.contains('contest')) {
      eventType = EventType.tournament;
    } else if (lowerInput.contains('camp') ||
        lowerInput.contains('clinic') ||
        lowerInput.contains('workshop') ||
        lowerInput.contains('lesson')) {
      eventType = EventType.camp;
    } else if (lowerInput.contains('open gym') ||
        lowerInput.contains('gym') ||
        lowerInput.contains('free play') ||
        lowerInput.contains('open court')) {
      eventType = EventType.openGym;
    } else if (lowerInput.contains('1v1') ||
        lowerInput.contains('one on one') ||
        lowerInput.contains('1 on 1') ||
        lowerInput.contains('one-on-one')) {
      eventType = EventType.oneVsOne;
    }

    // Enhanced date parsing with more options
    DateTime? date;
    if (lowerInput.contains('tomorrow')) {
      date = DateTime.now().add(const Duration(days: 1));
    } else if (lowerInput.contains('today')) {
      date = DateTime.now();
    } else if (lowerInput.contains('next week')) {
      date = DateTime.now().add(const Duration(days: 7));
    } else if (lowerInput.contains('saturday') || lowerInput.contains('sat')) {
      date = _getNextWeekday(DateTime.saturday);
    } else if (lowerInput.contains('sunday') || lowerInput.contains('sun')) {
      date = _getNextWeekday(DateTime.sunday);
    } else if (lowerInput.contains('friday') || lowerInput.contains('fri')) {
      date = _getNextWeekday(DateTime.friday);
    } else if (lowerInput.contains('monday') || lowerInput.contains('mon')) {
      date = _getNextWeekday(DateTime.monday);
    } else if (lowerInput.contains('tuesday') || lowerInput.contains('tue')) {
      date = _getNextWeekday(DateTime.tuesday);
    } else if (lowerInput.contains('wednesday') || lowerInput.contains('wed')) {
      date = _getNextWeekday(DateTime.wednesday);
    } else if (lowerInput.contains('thursday') || lowerInput.contains('thu')) {
      date = _getNextWeekday(DateTime.thursday);
    } else {
      date = DateTime.now().add(const Duration(days: 1)); // Default to tomorrow
    }

    // Enhanced time parsing with more specific times
    TimeOfDay? time;
    if (lowerInput.contains('6 pm') ||
        lowerInput.contains('6pm') ||
        lowerInput.contains('6:00 pm')) {
      time = const TimeOfDay(hour: 18, minute: 0);
    } else if (lowerInput.contains('7 pm') ||
        lowerInput.contains('7pm') ||
        lowerInput.contains('7:00 pm')) {
      time = const TimeOfDay(hour: 19, minute: 0);
    } else if (lowerInput.contains('8 pm') ||
        lowerInput.contains('8pm') ||
        lowerInput.contains('8:00 pm')) {
      time = const TimeOfDay(hour: 20, minute: 0);
    } else if (lowerInput.contains('5 pm') ||
        lowerInput.contains('5pm') ||
        lowerInput.contains('5:00 pm')) {
      time = const TimeOfDay(hour: 17, minute: 0);
    } else if (lowerInput.contains('4 pm') ||
        lowerInput.contains('4pm') ||
        lowerInput.contains('4:00 pm')) {
      time = const TimeOfDay(hour: 16, minute: 0);
    } else if (lowerInput.contains('3 pm') ||
        lowerInput.contains('3pm') ||
        lowerInput.contains('3:00 pm')) {
      time = const TimeOfDay(hour: 15, minute: 0);
    } else if (lowerInput.contains('2 pm') ||
        lowerInput.contains('2pm') ||
        lowerInput.contains('2:00 pm')) {
      time = const TimeOfDay(hour: 14, minute: 0);
    } else if (lowerInput.contains('1 pm') ||
        lowerInput.contains('1pm') ||
        lowerInput.contains('1:00 pm')) {
      time = const TimeOfDay(hour: 13, minute: 0);
    } else if (lowerInput.contains('12 pm') ||
        lowerInput.contains('12pm') ||
        lowerInput.contains('noon')) {
      time = const TimeOfDay(hour: 12, minute: 0);
    } else if (lowerInput.contains('11 am') ||
        lowerInput.contains('11am') ||
        lowerInput.contains('11:00 am')) {
      time = const TimeOfDay(hour: 11, minute: 0);
    } else if (lowerInput.contains('10 am') ||
        lowerInput.contains('10am') ||
        lowerInput.contains('10:00 am')) {
      time = const TimeOfDay(hour: 10, minute: 0);
    } else if (lowerInput.contains('9 am') ||
        lowerInput.contains('9am') ||
        lowerInput.contains('9:00 am')) {
      time = const TimeOfDay(hour: 9, minute: 0);
    } else if (lowerInput.contains('8 am') ||
        lowerInput.contains('8am') ||
        lowerInput.contains('8:00 am')) {
      time = const TimeOfDay(hour: 8, minute: 0);
    } else if (lowerInput.contains('morning')) {
      time = const TimeOfDay(hour: 9, minute: 0);
    } else if (lowerInput.contains('afternoon')) {
      time = const TimeOfDay(hour: 14, minute: 0);
    } else if (lowerInput.contains('evening')) {
      time = const TimeOfDay(hour: 18, minute: 0);
    } else if (lowerInput.contains('night')) {
      time = const TimeOfDay(hour: 19, minute: 0);
    } else {
      time = const TimeOfDay(hour: 18, minute: 0); // Default to 6 PM
    }

    // Enhanced location parsing with specific court names and venues
    String location = '';

    // Check for specific court/venue names first
    if (lowerInput.contains('riverside park') ||
        lowerInput.contains('riverside')) {
      location = 'Riverside Park Basketball Courts';
    } else if (lowerInput.contains('lincoln court') ||
        lowerInput.contains('lincoln')) {
      location = 'Lincoln Court';
    } else if (lowerInput.contains('central courts') ||
        lowerInput.contains('central court')) {
      location = 'Central Courts';
    } else if (lowerInput.contains('memorial gym') ||
        lowerInput.contains('memorial')) {
      location = 'Memorial Gym';
    } else if (lowerInput.contains('westside gym') ||
        lowerInput.contains('westside')) {
      location = 'Westside Gym';
    } else if (lowerInput.contains('oak park') || lowerInput.contains('oak')) {
      location = 'Oak Park Basketball Courts';
    } else if (lowerInput.contains('community center')) {
      location = 'Community Center';
    } else if (lowerInput.contains('downtown court') ||
        lowerInput.contains('downtown')) {
      location = 'Downtown Basketball Court';
    } else if (lowerInput.contains('northside park') ||
        lowerInput.contains('northside')) {
      location = 'Northside Park Courts';
    } else if (lowerInput.contains('eastside gym') ||
        lowerInput.contains('eastside')) {
      location = 'Eastside Gym';
    } else if (lowerInput.contains('southside court') ||
        lowerInput.contains('southside')) {
      location = 'Southside Basketball Court';
    } else if (lowerInput.contains('university gym') ||
        lowerInput.contains('university')) {
      location = 'University Gym';
    } else if (lowerInput.contains('high school') ||
        lowerInput.contains('hs ')) {
      location = 'High School Gym';
    } else if (lowerInput.contains('middle school') ||
        lowerInput.contains('ms ')) {
      location = 'Middle School Gym';
    } else if (lowerInput.contains('ymca') || lowerInput.contains('y.m.c.a')) {
      location = 'YMCA';
    } else if (lowerInput.contains('rec center') ||
        lowerInput.contains('recreation center')) {
      location = 'Recreation Center';
    }
    // Generic location types (only if no specific venue found)
    else if (lowerInput.contains('park') && lowerInput.contains('outdoor')) {
      location = ''; // Keep blank for generic references
    } else if (lowerInput.contains('gym') && lowerInput.contains('indoor')) {
      location = ''; // Keep blank for generic references
    } else if (lowerInput.contains('court') || lowerInput.contains('courts')) {
      location = ''; // Keep blank for generic references
    } else if (lowerInput.contains('school') || lowerInput.contains('campus')) {
      location = ''; // Keep blank for generic references
    } else {
      location = ''; // Keep blank if no specific location recognized
    }

    // Generate detailed title based on event type and context
    String title = '';
    if (eventType == EventType.donationBased) {
      if (lowerInput.contains('charity')) {
        title = 'Charity Basketball Game';
      } else if (lowerInput.contains('benefit')) {
        title = 'Benefit Basketball Event';
      } else if (lowerInput.contains('fundraiser')) {
        title = 'Basketball Fundraiser';
      } else {
        title = 'Basketball Donation Event';
      }
    } else if (eventType == EventType.pickupRun) {
      if (lowerInput.contains('competitive') ||
          lowerInput.contains('serious')) {
        title = 'Competitive Pickup Basketball';
      } else if (lowerInput.contains('casual') || lowerInput.contains('fun')) {
        title = 'Casual Pickup Basketball';
      } else {
        title = 'Pickup Basketball Game';
      }
    } else if (eventType == EventType.training) {
      if (lowerInput.contains('shooting')) {
        title = 'Basketball Shooting Practice';
      } else if (lowerInput.contains('conditioning') ||
          lowerInput.contains('fitness')) {
        title = 'Basketball Conditioning Training';
      } else if (lowerInput.contains('skill')) {
        title = 'Basketball Skills Training';
      } else {
        title = 'Basketball Training Session';
      }
    } else if (eventType == EventType.tournament) {
      if (lowerInput.contains('3v3') || lowerInput.contains('3 on 3')) {
        title = '3v3 Basketball Tournament';
      } else if (lowerInput.contains('5v5') || lowerInput.contains('5 on 5')) {
        title = '5v5 Basketball Tournament';
      } else {
        title = 'Basketball Tournament';
      }
    } else if (eventType == EventType.camp) {
      if (lowerInput.contains('youth') || lowerInput.contains('kids')) {
        title = 'Youth Basketball Camp';
      } else if (lowerInput.contains('adult')) {
        title = 'Adult Basketball Camp';
      } else {
        title = 'Basketball Camp';
      }
    } else if (eventType == EventType.openGym) {
      title = 'Open Gym Basketball';
    } else if (eventType == EventType.oneVsOne) {
      title = '1v1 Basketball Match';
    }

    // Generate detailed description based on parsed information
    String description = _generateDetailedDescription(
        eventType, lowerInput, location, date, time);

    return {
      'title': title,
      'description': description,
      'date': date,
      'time': time,
      'location': location,
      'type': eventType,
    };
  }

  String _generateDetailedDescription(EventType eventType, String input,
      String location, DateTime? date, TimeOfDay? time) {
    String baseDescription = '';

    // Generate type-specific description
    switch (eventType) {
      case EventType.donationBased:
        baseDescription = 'Basketball event supporting a great cause! ';
        if (input.contains('charity')) {
          baseDescription +=
              'Join us for this charity game where proceeds support local community programs.';
        } else if (input.contains('benefit')) {
          baseDescription +=
              'A benefit event to raise funds and awareness for important causes.';
        } else if (input.contains('fundraiser')) {
          baseDescription +=
              'Help us raise funds through basketball while having fun and supporting our community.';
        } else {
          baseDescription +=
              'Come play basketball while supporting a meaningful cause through donations.';
        }
        break;
      case EventType.pickupRun:
        baseDescription = 'Join us for a pickup basketball game! ';
        if (input.contains('competitive')) {
          baseDescription +=
              'This is a competitive game for serious players looking to test their skills.';
        } else if (input.contains('casual') || input.contains('fun')) {
          baseDescription +=
              'This is a casual, fun game open to all skill levels.';
        } else {
          baseDescription += 'Open to all skill levels - come ready to play!';
        }
        break;
      case EventType.training:
        baseDescription =
            'Basketball training session focused on skill development. ';
        if (input.contains('shooting')) {
          baseDescription +=
              'We\'ll be working on shooting techniques and accuracy.';
        } else if (input.contains('conditioning')) {
          baseDescription +=
              'High-intensity conditioning and fitness training.';
        } else {
          baseDescription +=
              'Improve your basketball skills with structured drills and practice.';
        }
        break;
      case EventType.tournament:
        baseDescription =
            'Basketball tournament - compete against other teams! ';
        if (input.contains('3v3')) {
          baseDescription += 'Fast-paced 3v3 format with multiple games.';
        } else {
          baseDescription += 'Organized tournament with brackets and prizes.';
        }
        break;
      case EventType.camp:
        baseDescription =
            'Basketball camp for skill development and learning. ';
        if (input.contains('youth') || input.contains('kids')) {
          baseDescription +=
              'Designed for young players to learn fundamentals.';
        } else {
          baseDescription +=
              'Comprehensive training for players of all levels.';
        }
        break;
      case EventType.openGym:
        baseDescription =
            'Open gym session - bring your own group or join others. ';
        baseDescription +=
            'Courts available for pickup games and individual practice.';
        break;
      case EventType.oneVsOne:
        baseDescription = '1v1 basketball competition. ';
        baseDescription += 'Test your skills in individual matchups.';
        break;
      default:
        baseDescription = 'Basketball event created via AI assistant.';
    }

    // Add location and time context if available
    if (location.isNotEmpty && location != 'TBD Location') {
      baseDescription += '\n\nLocation: $location';
    }

    if (date != null && time != null) {
      final dateStr = '${date.month}/${date.day}/${date.year}';
      final timeStr = _formatTime(time);
      baseDescription += '\nScheduled for $dateStr at $timeStr';
    }

    return baseDescription;
  }

  DateTime _getNextWeekday(int weekday) {
    final now = DateTime.now();
    int daysUntilWeekday = (weekday - now.weekday) % 7;
    if (daysUntilWeekday == 0) {
      daysUntilWeekday = 7; // Next week if today is the same weekday
    }
    return now.add(Duration(days: daysUntilWeekday));
  }

  String _formatDate(DateTime? date) {
    if (date == null) return '';
    final now = DateTime.now();
    final tomorrow = now.add(const Duration(days: 1));

    if (date.day == now.day && date.month == now.month) {
      return 'Today';
    } else if (date.day == tomorrow.day && date.month == tomorrow.month) {
      return 'Tomorrow';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }

  String _formatTime(TimeOfDay? time) {
    if (time == null) return '';
    final hour = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
    final minute = time.minute.toString().padLeft(2, '0');
    final period = time.period == DayPeriod.am ? 'AM' : 'PM';
    return '$hour:$minute $period';
  }

  void _finishEventCreation() {
    HapticFeedback.mediumImpact();

    // Navigate to create event page with parsed AI data
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => CreateEventPage(
          initialTitle: _eventTitle,
          initialDescription: _eventDescription,
          initialDate: _eventDate,
          initialTime: _eventTime,
          initialLocation: _location,
          initialEventType: _eventType,
        ),
      ),
    );
  }

  void _navigateToAdvanced() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const CreateEventPage(),
      ),
    );
  }
}
