// lib/features/events/presentation/pages/create_event/create_event_container.dart

import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../profile/bloc/profile_bloc.dart';
import '../../../bloc/events_bloc.dart';
import '../../../bloc/events_event.dart';
import '../../../bloc/events_state.dart';

import '../../../data/events_repository.dart';
import '../../../domain/models/event_model.dart';
import '../../../domain/models/event_type.dart';
import '../../../domain/models/location_model.dart';

import '../../../domain/models/simple_event.dart';
import '../../widgets/event_share_modal.dart';
import '../../pages/host_event_detail_page.dart';
import 'create_event_view.dart';

class CreateEventContainer extends StatefulWidget {
  final String? initialTitle;
  final String? initialDescription;
  final DateTime? initialDate;
  final TimeOfDay? initialTime;
  final String? initialLocation;
  final EventType? initialEventType;

  const CreateEventContainer({
    super.key,
    this.initialTitle,
    this.initialDescription,
    this.initialDate,
    this.initialTime,
    this.initialLocation,
    this.initialEventType,
  });

  @override
  State<CreateEventContainer> createState() => _CreateEventContainerState();
}

class _CreateEventContainerState extends State<CreateEventContainer>
    with TickerProviderStateMixin {
  int? expandedSection = 0;

  final Map<int, bool> sectionDone = {
    0: false,
    1: false,
    2: false,
    3: false,
    4: false,
    5: false,
    6: false,
  };

  EventType? selectedType;

  // Basic
  final titleCtrl = TextEditingController();
  final descCtrl = TextEditingController();
  DateTime? startDateTime;
  DateTime? endDateTime;

  // Location
  final locationCtrl = TextEditingController();
  LocationModel? selectedLocation;
  bool isLocationPrivate = false;

  // Visibility
  bool isEventPrivate = false;

  // Pricing
  bool isFree = true;
  final priceCtrl = TextEditingController();
  final capacityCtrl = TextEditingController();
  bool isRegistrationOpen = true;

  // Tickets
  List<Map<String, dynamic>> ticketTypes = [];
  final ticketNameCtrl = TextEditingController();
  final ticketPriceCtrl = TextEditingController();
  final ticketQtyCtrl = TextEditingController();

  // Q&A / Waiver
  bool hasCustomQuestions = false;
  List<Map<String, dynamic>> customQuestions = [];
  final questionTextCtrl = TextEditingController();
  final questionOptionsCtrl = TextEditingController();

  bool hasEarlyBirdPricing = false;
  final earlyBirdPriceCtrl = TextEditingController();
  DateTime? earlyBirdDeadline;

  bool requiresWaiver = false;
  final waiverTextCtrl = TextEditingController();
  String? selectedWaiverTemplate;

  Map<String, dynamic> typeSpecific = {};

  // Images
  List<String> previewImageUrls = [];

  DateTime? calendarViewingDate;

  @override
  void initState() {
    super.initState();
    _initializeWithAIData();
  }

  void _initializeWithAIData() {
    // Prefill form fields with AI-parsed data
    if (widget.initialTitle != null) {
      titleCtrl.text = widget.initialTitle!;
    }

    if (widget.initialDescription != null) {
      descCtrl.text = widget.initialDescription!;
    }

    if (widget.initialLocation != null) {
      locationCtrl.text = widget.initialLocation!;
    }

    if (widget.initialEventType != null) {
      selectedType = widget.initialEventType!;
    }

    if (widget.initialDate != null && widget.initialTime != null) {
      startDateTime = DateTime(
        widget.initialDate!.year,
        widget.initialDate!.month,
        widget.initialDate!.day,
        widget.initialTime!.hour,
        widget.initialTime!.minute,
      );
    } else if (widget.initialDate != null) {
      startDateTime = widget.initialDate!;
    }

    // Mark sections as done if they have data
    if (widget.initialTitle != null || widget.initialDescription != null) {
      sectionDone[0] = true; // Basic info section
    }

    if (widget.initialDate != null || widget.initialTime != null) {
      sectionDone[1] = true; // Date/time section
    }

    if (widget.initialLocation != null) {
      sectionDone[2] = true; // Location section
    }

    if (widget.initialEventType != null) {
      sectionDone[3] = true; // Event type section
    }
  }

  // Loader state
  bool _loaderVisible = false;
  void _showLoader() {
    if (_loaderVisible || !mounted) return;
    _loaderVisible = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(color: Color(0xFFFF9800)),
      ),
    );
  }

  void _hideLoader() {
    if (!_loaderVisible || !mounted) return;
    _loaderVisible = false;
    Navigator.of(context, rootNavigator: true).pop(); // dismiss dialog
  }

  @override
  void dispose() {
    titleCtrl.dispose();
    descCtrl.dispose();
    locationCtrl.dispose();
    priceCtrl.dispose();
    capacityCtrl.dispose();
    ticketNameCtrl.dispose();
    ticketPriceCtrl.dispose();
    ticketQtyCtrl.dispose();
    questionTextCtrl.dispose();
    questionOptionsCtrl.dispose();
    earlyBirdPriceCtrl.dispose();
    waiverTextCtrl.dispose();
    super.dispose();
  }

  Future<void> _uploadGalleryIfNeeded(String eventId) async {
    if (previewImageUrls.isEmpty) return;
    final localPaths =
        previewImageUrls.where((p) => !p.startsWith('http')).toList();
    if (localPaths.isEmpty) return;

    final repo = EventsRepository();
    final files = localPaths.map((p) => File(p)).toList();
    final urls = await repo.uploadGalleryFiles(eventId, files);
    await repo.setGallery(eventId, urls);

    if (!mounted) return;
    setState(() {
      final existingNet = previewImageUrls.where((p) => p.startsWith('http'));
      previewImageUrls = [...existingNet, ...urls];
    });
  }

  EventModel _buildEventModel() {
    final bannerUrl =
        previewImageUrls.isNotEmpty ? previewImageUrls.first : null;

    final bool effectiveIsFree = ticketTypes.isEmpty
        ? isFree
        : ticketTypes.every((t) => ((t['price'] as num?) ?? 0) == 0);

    final double? singlePrice =
        effectiveIsFree ? null : double.tryParse(priceCtrl.text);

    final locationLabel = (selectedLocation?.fullAddress?.isNotEmpty ?? false)
        ? selectedLocation!.fullAddress
        : (selectedLocation?.name?.isNotEmpty ?? false)
            ? selectedLocation!.name
            : locationCtrl.text;

    SimpleEvent buildSimple(EventType type, String category) => SimpleEvent(
          title: titleCtrl.text,
          description: descCtrl.text,
          dateTime: startDateTime ?? DateTime.now(),
          location: locationLabel,
          locationHidden: isLocationPrivate,
          bannerImageUrl: bannerUrl,
          category: category,
          type: type,
          isFree: effectiveIsFree,
          price: ticketTypes.isEmpty ? singlePrice : null,
        );

    switch (selectedType) {
      case EventType.tournament:
        return TournamentEvent(
          title: titleCtrl.text,
          description: descCtrl.text,
          dateTime: startDateTime ?? DateTime.now(),
          location: locationLabel,
          locationHidden: isLocationPrivate,
          bannerImageUrl: bannerUrl,
          category: 'Tournament',
          isFree: effectiveIsFree,
          price: singlePrice,
          numberOfTeams: (typeSpecific['numberOfTeams'] as num?)?.toInt() ?? 8,
          format: (typeSpecific['format'] as String?) ?? 'Single Elimination',
          prizePool: (typeSpecific['prizePool'] as num?)?.toDouble(),
          registrationDeadline:
              (typeSpecific['registrationDeadline'] as DateTime?) ??
                  (startDateTime ?? DateTime.now()),
        );

      case EventType.donationBased:
        return DonationEvent(
          title: titleCtrl.text,
          description: descCtrl.text,
          dateTime: startDateTime ?? DateTime.now(),
          location: locationLabel,
          locationHidden: isLocationPrivate,
          bannerImageUrl: bannerUrl,
          category: 'Charity',
          isFree: true,
          price: null,
          donationGoal:
              (typeSpecific['donationGoal'] as num?)?.toDouble() ?? 1000.0,
          currentAmount:
              (typeSpecific['currentAmount'] as num?)?.toDouble() ?? 0.0,
          beneficiary: (typeSpecific['beneficiary'] as String?) ?? '',
          hasTaxReceipts: (typeSpecific['hasTaxReceipts'] as bool?) ?? false,
        );

      case EventType.pickupRun:
        return PickupRunEvent(
          title: titleCtrl.text,
          description: descCtrl.text,
          dateTime: startDateTime ?? DateTime.now(),
          location: locationLabel,
          locationHidden: isLocationPrivate,
          bannerImageUrl: bannerUrl,
          category: 'Basketball',
          isFree: effectiveIsFree,
          price: ticketTypes.isEmpty ? singlePrice : null,
          maxPlayers: (typeSpecific['maxPlayers'] as num?)?.toInt() ?? 10,
          currentPlayers:
              (typeSpecific['currentPlayers'] as num?)?.toInt() ?? 0,
          skillLevel: (typeSpecific['skillLevel'] as String?) ?? 'Beginner',
        );

      case EventType.openGym:
        return buildSimple(EventType.openGym, 'Open Gym');
      case EventType.oneVsOne:
        return buildSimple(EventType.oneVsOne, '1v1');
      case EventType.camp:
        return buildSimple(EventType.camp, 'Camp');
      case EventType.training:
        return buildSimple(EventType.training, 'Training');
      case EventType.specialEvent:
        return buildSimple(EventType.specialEvent, 'Showcase');
      case EventType.oneOff:
        return buildSimple(EventType.oneOff, 'One-off');

      case null:
        return buildSimple(EventType.pickupRun, 'Basketball');
    }
  }

  bool _isFormComplete() {
    final hasLocation =
        (selectedLocation != null) || locationCtrl.text.isNotEmpty;
    final ok = titleCtrl.text.isNotEmpty &&
        selectedType != null &&
        startDateTime != null &&
        hasLocation;
    sectionDone[6] = ok;
    return ok;
  }

  Future<void> _onPublish() async {
    if (!_isFormComplete()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Fill the required fields first')),
      );
      return;
    }

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Please log in')));
      return;
    }

    final event = _buildEventModel();

    // Decide banner source from the first preview image (local → upload)
    File? bannerFile;
    if (previewImageUrls.isNotEmpty) {
      final first = previewImageUrls.first;
      if (!first.startsWith('http')) {
        bannerFile = File(first);
      }
    }

    _showLoader();

    final profile = context.read<ProfileBloc>().state.profile;
    final hostUsername = profile?.username ?? 'Hosted Event';
    final hostEmail = profile?.email ?? user.email ?? '';

    context.read<EventsBloc>().add(
          CreateEventRequested(
            event: event,
            hostId: user.uid,
            hostUsername: hostUsername, // 👈 add this
            hostEmail: hostEmail, // pass through
            bannerFile: bannerFile,
            tickets: ticketTypes, // persisted in BLoC
            extra: {
              ...typeSpecific,
              if (selectedLocation != null)
                'locationMeta': selectedLocation!.toMap(),
              'isLocationPrivate': isLocationPrivate,

              // Global registration meta (event-level)
              'registration': {
                'isOpen': isRegistrationOpen,
                'capacity': int.tryParse(capacityCtrl.text),
                'hasEarlyBirdPricing': hasEarlyBirdPricing,
                if (hasEarlyBirdPricing) ...{
                  'earlyBirdPrice': double.tryParse(earlyBirdPriceCtrl.text),
                  'earlyBirdDeadline': earlyBirdDeadline,
                },
                'requiresWaiver': requiresWaiver,
                if (requiresWaiver) ...{
                  'waiverTemplate': selectedWaiverTemplate,
                  'waiverText': waiverTextCtrl.text.trim(),
                },
                'hasCustomQuestions': hasCustomQuestions,
                if (hasCustomQuestions) 'customQuestions': customQuestions,
              },
            },
          ),
        );
  }

  void _onCreateSuccess(BuildContext context, String? eventId) {
    if (eventId == null) return;

    _uploadGalleryIfNeeded(eventId);

    final shareUrl = 'https://checkup.app/event/$eventId';
    final eventTitle = titleCtrl.text.isNotEmpty ? titleCtrl.text : 'New Event';
    final content = descCtrl.text.isNotEmpty
        ? descCtrl.text
        : 'Join us for this exciting event!';

    EventShareModal.show(
      context: context,
      eventId: eventId,
      eventContent: '$eventTitle - $content',
      shareUrl: shareUrl,
      onClose: () {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (_) => HostEventDetailPage(
              eventId: eventId,
              title: eventTitle,
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<EventsBloc, EventsState>(
      listener: (context, state) {
        if (state is EventsFailure) {
          _hideLoader();
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text(state.message)));
        } else if (state is EventsSuccess) {
          _hideLoader();
          _onCreateSuccess(context, state.createdId);
        }
      },
      child: CreateEventView(
        expandedSection: expandedSection,
        onToggleSection: (i) =>
            setState(() => expandedSection = (expandedSection == i ? null : i)),
        sectionDone: sectionDone,
        selectedType: selectedType,
        onTypeSelected: (t) {
          setState(() {
            selectedType = t;
            typeSpecific = {};
            sectionDone[0] = true;
            expandedSection = 1;
          });
        },
        titleCtrl: titleCtrl,
        descCtrl: descCtrl,
        onBasicChanged: (ok) => setState(() => sectionDone[1] = ok),
        startDateTime: startDateTime,
        endDateTime: endDateTime,
        onStartDateTimeChanged: (dt) => setState(() => startDateTime = dt),
        onEndDateTimeChanged: (dt) => setState(() => endDateTime = dt),
        calendarViewingDate: calendarViewingDate,
        onCalendarViewingDateChanged: (d) =>
            setState(() => calendarViewingDate = d),
        onDateTimeStepValid: (ok) => setState(() => sectionDone[2] = ok),
        locationCtrl: locationCtrl,
        selectedLocation: selectedLocation,
        selectedLocationPrivate: isLocationPrivate,
        onLocationSelected: (loc) {
          setState(() {
            selectedLocation = loc;
            if (loc != null && locationCtrl.text.isEmpty) {
              locationCtrl.text =
                  loc.fullAddress.isNotEmpty ? loc.fullAddress : loc.name;
            }
          });
        },
        onLocationChosen: (ok) => setState(() => sectionDone[3] = ok),
        onLocationPrivacyChanged: (v) => setState(() => isLocationPrivate = v),
        selectedEventType: selectedType,
        typeSpecific: typeSpecific,
        onTypeSpecificChanged: (data, valid) {
          setState(() {
            typeSpecific = data;
            sectionDone[4] = valid;
          });
        },
        capacityCtrl: capacityCtrl,
        isRegistrationOpen: isRegistrationOpen,
        onRegistrationOpenChanged: (v) =>
            setState(() => isRegistrationOpen = v),
        ticketTypes: ticketTypes,
        onTicketTypesUpdated: (tickets) {
          setState(() {
            ticketTypes = tickets;
            sectionDone[5] = tickets.isNotEmpty;
            isFree = tickets.isEmpty
                ? isFree
                : tickets.every((t) => ((t['price'] as num?) ?? 0) == 0);
          });
        },
        ticketNameCtrl: ticketNameCtrl,
        ticketPriceCtrl: ticketPriceCtrl,
        ticketQtyCtrl: ticketQtyCtrl,
        hasCustomQuestions: hasCustomQuestions,
        onHasCustomQuestionsChanged: (v) =>
            setState(() => hasCustomQuestions = v),
        customQuestions: customQuestions,
        onCustomQuestionsUpdated: (qs) => setState(() => customQuestions = qs),
        questionTextCtrl: questionTextCtrl,
        questionOptionsCtrl: questionOptionsCtrl,
        hasEarlyBirdPricing: hasEarlyBirdPricing,
        onHasEarlyBirdChanged: (v) => setState(() => hasEarlyBirdPricing = v),
        earlyBirdPriceCtrl: earlyBirdPriceCtrl,
        earlyBirdDeadline: earlyBirdDeadline,
        onEarlyBirdDeadlineChanged: (d) =>
            setState(() => earlyBirdDeadline = d),
        requiresWaiver: requiresWaiver,
        onRequiresWaiverChanged: (v) => setState(() => requiresWaiver = v),
        waiverTextCtrl: waiverTextCtrl,
        selectedWaiverTemplate: selectedWaiverTemplate,
        onWaiverTemplateSelected: (v) =>
            setState(() => selectedWaiverTemplate = v),
        isEventPrivate: isEventPrivate,
        onEventPrivacyChanged: (v) => setState(() => isEventPrivate = v),
        isFree: isFree,
        priceCtrl: priceCtrl,
        previewImageUrls: previewImageUrls,
        onPreviewImagesChanged: (imgs) =>
            setState(() => previewImageUrls = imgs),
        isFormComplete: _isFormComplete,
        onPublish: _onPublish,
      ),
    );
  }
}
