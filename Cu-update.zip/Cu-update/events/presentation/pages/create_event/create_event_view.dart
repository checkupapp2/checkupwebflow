import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import '../../../domain/models/event_type.dart';
import '../../../domain/models/location_model.dart';

import 'widgets/event_type_section.dart';
import 'widgets/basic_info_section.dart';
import 'widgets/date_time_section.dart';
import 'widgets/location_section.dart';
import 'widgets/details_section.dart';
import 'widgets/pricing_section.dart';
import 'widgets/preview_section.dart';

class CreateEventView extends StatelessWidget {
  const CreateEventView({
    super.key,
    // accordion
    required this.expandedSection,
    required this.onToggleSection,
    required this.sectionDone,
    // type
    required this.selectedType,
    required this.onTypeSelected,
    // basic
    required this.titleCtrl,
    required this.descCtrl,
    required this.onBasicChanged,
    // date time
    required this.startDateTime,
    required this.endDateTime,
    required this.onStartDateTimeChanged,
    required this.onEndDateTimeChanged,
    required this.calendarViewingDate,
    required this.onCalendarViewingDateChanged,
    required this.onDateTimeStepValid,
    // location (UPDATED)
    required this.locationCtrl,
    required this.selectedLocation,
    required this.selectedLocationPrivate,
    required this.onLocationSelected,
    required this.onLocationChosen,
    required this.onLocationPrivacyChanged,
    // details
    required this.selectedEventType,
    required this.typeSpecific,
    required this.onTypeSpecificChanged,
    // pricing
    required this.capacityCtrl,
    required this.isRegistrationOpen,
    required this.onRegistrationOpenChanged,
    required this.ticketTypes,
    required this.onTicketTypesUpdated,
    required this.ticketNameCtrl,
    required this.ticketPriceCtrl,
    required this.ticketQtyCtrl,
    required this.hasCustomQuestions,
    required this.onHasCustomQuestionsChanged,
    required this.customQuestions,
    required this.onCustomQuestionsUpdated,
    required this.questionTextCtrl,
    required this.questionOptionsCtrl,
    required this.hasEarlyBirdPricing,
    required this.onHasEarlyBirdChanged,
    required this.earlyBirdPriceCtrl,
    required this.earlyBirdDeadline,
    required this.onEarlyBirdDeadlineChanged,
    required this.requiresWaiver,
    required this.onRequiresWaiverChanged,
    required this.waiverTextCtrl,
    required this.selectedWaiverTemplate,
    required this.onWaiverTemplateSelected,
    // preview
    required this.isEventPrivate,
    required this.onEventPrivacyChanged,
    required this.isFree,
    required this.priceCtrl,
    required this.previewImageUrls,
    required this.onPreviewImagesChanged,
    required this.isFormComplete,
    required this.onPublish,
  });

  // accordion
  final int? expandedSection;
  final ValueChanged<int> onToggleSection;
  final Map<int, bool> sectionDone;

  // type
  final EventType? selectedType;
  final ValueChanged<EventType> onTypeSelected;

  // basic
  final TextEditingController titleCtrl;
  final TextEditingController descCtrl;
  final ValueChanged<bool> onBasicChanged;

  // date time
  final DateTime? startDateTime;
  final DateTime? endDateTime;
  final ValueChanged<DateTime?> onStartDateTimeChanged;
  final ValueChanged<DateTime?> onEndDateTimeChanged;
  final DateTime? calendarViewingDate;
  final ValueChanged<DateTime> onCalendarViewingDateChanged;
  final ValueChanged<bool> onDateTimeStepValid;

  // location (UPDATED)
  final TextEditingController locationCtrl;
  final LocationModel? selectedLocation;
  final bool selectedLocationPrivate;
  final ValueChanged<LocationModel?> onLocationSelected;
  final ValueChanged<bool> onLocationChosen;
  final ValueChanged<bool> onLocationPrivacyChanged;

  // details
  final EventType? selectedEventType;
  final Map<String, dynamic> typeSpecific;
  final void Function(Map<String, dynamic> data, bool valid)
      onTypeSpecificChanged;

  // pricing
  final TextEditingController capacityCtrl;
  final bool isRegistrationOpen;
  final ValueChanged<bool> onRegistrationOpenChanged;
  final List<Map<String, dynamic>> ticketTypes;
  final ValueChanged<List<Map<String, dynamic>>> onTicketTypesUpdated;
  final TextEditingController ticketNameCtrl;
  final TextEditingController ticketPriceCtrl;
  final TextEditingController ticketQtyCtrl;
  final bool hasCustomQuestions;
  final ValueChanged<bool> onHasCustomQuestionsChanged;
  final List<Map<String, dynamic>> customQuestions;
  final ValueChanged<List<Map<String, dynamic>>> onCustomQuestionsUpdated;
  final TextEditingController questionTextCtrl;
  final TextEditingController questionOptionsCtrl;
  final bool hasEarlyBirdPricing;
  final ValueChanged<bool> onHasEarlyBirdChanged;
  final TextEditingController earlyBirdPriceCtrl;
  final DateTime? earlyBirdDeadline;
  final ValueChanged<DateTime?> onEarlyBirdDeadlineChanged;
  final bool requiresWaiver;
  final ValueChanged<bool> onRequiresWaiverChanged;
  final TextEditingController waiverTextCtrl;
  final String? selectedWaiverTemplate;
  final ValueChanged<String?> onWaiverTemplateSelected;

  // preview
  final bool isEventPrivate;
  final ValueChanged<bool> onEventPrivacyChanged;
  final bool isFree;
  final TextEditingController priceCtrl;
  final List<String> previewImageUrls;
  final ValueChanged<List<String>> onPreviewImagesChanged;
  final bool Function() isFormComplete;
  final VoidCallback onPublish;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryBlack,
      appBar: AppBar(
        backgroundColor: AppColors.primaryBlack,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: Colors.white, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Create Event',
          style: TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          const SizedBox(height: 8),
          Text(
            'Set up your basketball event in just a few steps',
            style:
                TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 16),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          // 0. Type
          EventTypeSection(
            index: 0,
            isExpanded: expandedSection == 0,
            isCompleted: sectionDone[0] ?? false,
            onToggle: () => onToggleSection(0),
            selectedType: selectedType,
            onTypeSelected: onTypeSelected,
          ),
          const SizedBox(height: 12),
          // 1. Basic
          BasicInfoSection(
            index: 1,
            isExpanded: expandedSection == 1,
            isCompleted: sectionDone[1] ?? false,
            onToggle: () => onToggleSection(1),
            titleCtrl: titleCtrl,
            descCtrl: descCtrl,
            onValidChanged: onBasicChanged,
          ),
          const SizedBox(height: 12),
          // 2. Date & Time
          DateTimeSection(
            index: 2,
            isExpanded: expandedSection == 2,
            isCompleted: sectionDone[2] ?? false,
            onToggle: () => onToggleSection(2),
            startDateTime: startDateTime,
            endDateTime: endDateTime,
            onStartDateTimeChanged: onStartDateTimeChanged,
            onEndDateTimeChanged: onEndDateTimeChanged,
            calendarViewingDate: calendarViewingDate,
            onCalendarViewingDateChanged: onCalendarViewingDateChanged,
            onValidChanged: onDateTimeStepValid,
          ),
          const SizedBox(height: 12),
          // 3. Location
          LocationSection(
            index: 3,
            isExpanded: expandedSection == 3,
            isCompleted: sectionDone[3] ?? false,
            onToggle: () => onToggleSection(3),
            locationCtrl: locationCtrl,
            selectedLocation: selectedLocation,
            isLocationPrivate: selectedLocationPrivate,
            onLocationSelected: onLocationSelected,
            onLocationChosen: onLocationChosen,
            onPrivacyChanged: onLocationPrivacyChanged,
          ),
          const SizedBox(height: 12),
          // 4. Details (now receives start/end from step 2)
          DetailsSection(
            index: 4,
            isExpanded: expandedSection == 4,
            isCompleted: sectionDone[4] ?? false,
            onToggle: () => onToggleSection(4),
            eventType: selectedEventType,
            formData: typeSpecific,
            onFormDataChanged: (data, valid) =>
                onTypeSpecificChanged(data, valid),
            startDateTime: startDateTime, // <-- pass real values
            endDateTime: endDateTime, // <-- pass real values
          ),
          const SizedBox(height: 12),
          // 5. Pricing
          PricingSection(
            index: 5,
            isExpanded: expandedSection == 5,
            isCompleted: sectionDone[5] ?? false,
            onToggle: () => onToggleSection(5),
            capacityCtrl: capacityCtrl,
            isRegistrationOpen: isRegistrationOpen,
            onRegistrationOpenChanged: onRegistrationOpenChanged,
            ticketTypes: ticketTypes,
            onTicketTypesUpdated: onTicketTypesUpdated,
            ticketNameCtrl: ticketNameCtrl,
            ticketPriceCtrl: ticketPriceCtrl,
            ticketQtyCtrl: ticketQtyCtrl,
            hasCustomQuestions: hasCustomQuestions,
            onHasCustomQuestionsChanged: onHasCustomQuestionsChanged,
            customQuestions: customQuestions,
            onCustomQuestionsUpdated: onCustomQuestionsUpdated,
            questionTextCtrl: questionTextCtrl,
            questionOptionsCtrl: questionOptionsCtrl,
            hasEarlyBirdPricing: hasEarlyBirdPricing,
            onHasEarlyBirdChanged: onHasEarlyBirdChanged,
            earlyBirdPriceCtrl: earlyBirdPriceCtrl,
            earlyBirdDeadline: earlyBirdDeadline,
            onEarlyBirdDeadlineChanged: onEarlyBirdDeadlineChanged,
            requiresWaiver: requiresWaiver,
            onRequiresWaiverChanged: onRequiresWaiverChanged,
            waiverTextCtrl: waiverTextCtrl,
            selectedWaiverTemplate: selectedWaiverTemplate,
            onWaiverTemplateSelected: onWaiverTemplateSelected,
          ),
          const SizedBox(height: 12),
          // 6. Preview & Publish
          PreviewSection(
            index: 6,
            isExpanded: expandedSection == 6,
            isCompleted: sectionDone[6] ?? false,
            onToggle: () => onToggleSection(6),
            titleCtrl: titleCtrl,
            locationCtrl: locationCtrl,
            selectedType: selectedType,
            isEventPrivate: isEventPrivate,
            onEventPrivacyChanged: onEventPrivacyChanged,
            isFree: isFree,
            priceCtrl: priceCtrl,
            dateTime: startDateTime,
            previewImageUrls: previewImageUrls,
            ticketTypes: ticketTypes,
            onPreviewImagesChanged: onPreviewImagesChanged,
            isFormComplete: isFormComplete,
            onPublish: onPublish,
          ),
          const SizedBox(height: 100),
        ]),
      ),
      bottomNavigationBar: (expandedSection == 6 && isFormComplete())
          ? _BottomBar(onPublish: onPublish)
          : const SizedBox.shrink(),
    );
  }
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({required this.onPublish});
  final VoidCallback onPublish;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: AppColors.primaryBlack,
        border: Border(
          top: BorderSide(color: AppColors.darkGray, width: 1),
        ),
      ),
      child: SizedBox(
        width: double.infinity,
        child: Container(
          decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: onPublish,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              backgroundColor: Colors.transparent,
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: const Text(
              'Create Event',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
    );
  }
}
