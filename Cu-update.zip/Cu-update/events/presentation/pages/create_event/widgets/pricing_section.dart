// lib/features/events/presentation/pages/create_event/widgets/pricing_section.dart
import 'package:flutter/material.dart';
import '../../../widgets/registration_pricing_form.dart';
import 'event_type_section.dart';

class PricingSection extends StatelessWidget {
  const PricingSection({
    super.key,
    required this.index,
    required this.isExpanded,
    required this.isCompleted,
    required this.onToggle,
    required this.capacityCtrl,
    required this.isRegistrationOpen,
    required this.onRegistrationOpenChanged,
    required this.ticketTypes,
    required this.onTicketTypesUpdated,
    required this.ticketNameCtrl,
    required this.ticketPriceCtrl,
    required this.ticketQtyCtrl,
    required this.hasCustomQuestions,
    required this.onHasCustomQuestionsChanged,
    required this.customQuestions,
    required this.onCustomQuestionsUpdated,
    required this.questionTextCtrl,
    required this.questionOptionsCtrl,
    required this.hasEarlyBirdPricing,
    required this.onHasEarlyBirdChanged,
    required this.earlyBirdPriceCtrl,
    required this.earlyBirdDeadline,
    required this.onEarlyBirdDeadlineChanged,
    required this.requiresWaiver,
    required this.onRequiresWaiverChanged,
    required this.waiverTextCtrl,
    required this.selectedWaiverTemplate,
    required this.onWaiverTemplateSelected,
  });

  final int index;
  final bool isExpanded;
  final bool isCompleted;
  final VoidCallback onToggle;

  final TextEditingController capacityCtrl;
  final bool isRegistrationOpen;
  final ValueChanged<bool> onRegistrationOpenChanged;

  final List<Map<String, dynamic>> ticketTypes;
  final ValueChanged<List<Map<String, dynamic>>> onTicketTypesUpdated;
  final TextEditingController ticketNameCtrl;
  final TextEditingController ticketPriceCtrl;
  final TextEditingController ticketQtyCtrl;

  final bool hasCustomQuestions;
  final ValueChanged<bool> onHasCustomQuestionsChanged;
  final List<Map<String, dynamic>> customQuestions;
  final ValueChanged<List<Map<String, dynamic>>> onCustomQuestionsUpdated;
  final TextEditingController questionTextCtrl;
  final TextEditingController questionOptionsCtrl;

  final bool hasEarlyBirdPricing;
  final ValueChanged<bool> onHasEarlyBirdChanged;
  final TextEditingController earlyBirdPriceCtrl;
  final DateTime? earlyBirdDeadline;
  final ValueChanged<DateTime?> onEarlyBirdDeadlineChanged;

  final bool requiresWaiver;
  final ValueChanged<bool> onRequiresWaiverChanged;
  final TextEditingController waiverTextCtrl;
  final String? selectedWaiverTemplate;
  final ValueChanged<String?> onWaiverTemplateSelected;

  @override
  Widget build(BuildContext context) {
    return AccordionShell(
      title: 'Pricing & Tickets',
      subtitle: 'Set pricing and registration',
      icon: Icons.confirmation_number_rounded,
      index: index,
      isExpanded: isExpanded,
      isCompleted: isCompleted,
      onToggle: onToggle,
      child: RegistrationPricingForm(
        capacityController: capacityCtrl,
        isRegistrationOpen: isRegistrationOpen,
        onRegistrationStatusChanged: onRegistrationOpenChanged,
        ticketTypes: ticketTypes,
        onTicketTypesUpdated: onTicketTypesUpdated,
        ticketNameController: ticketNameCtrl,
        ticketPriceController: ticketPriceCtrl,
        ticketQuantityController: ticketQtyCtrl,
        hasCustomQuestions: hasCustomQuestions,
        onCustomQuestionsChanged: onHasCustomQuestionsChanged,
        customQuestions: customQuestions,
        onCustomQuestionsUpdated: onCustomQuestionsUpdated,
        questionTextController: questionTextCtrl,
        questionOptionsController: questionOptionsCtrl,
        hasEarlyBirdPricing: hasEarlyBirdPricing,
        onEarlyBirdPricingChanged: onHasEarlyBirdChanged,
        earlyBirdPriceController: earlyBirdPriceCtrl,
        earlyBirdDeadline: earlyBirdDeadline,
        onEarlyBirdDeadlineSelected: onEarlyBirdDeadlineChanged,
        requiresWaiver: requiresWaiver,
        onWaiverRequirementChanged: onRequiresWaiverChanged,
        waiverTextController: waiverTextCtrl,
        selectedWaiverTemplate: selectedWaiverTemplate,
        onWaiverTemplateSelected: onWaiverTemplateSelected,
      ),
    );
  }
}
