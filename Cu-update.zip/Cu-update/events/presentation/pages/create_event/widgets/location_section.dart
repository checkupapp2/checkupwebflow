// lib/features/events/presentation/pages/create_event/widgets/location_section.dart

import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import '../../../../domain/models/location_model.dart';
import '../../../widgets/enhanced_location_selector.dart';
import 'event_type_section.dart';

class LocationSection extends StatelessWidget {
  const LocationSection({
    super.key,
    required this.index,
    required this.isExpanded,
    required this.isCompleted,
    required this.onToggle,
    required this.locationCtrl,
    required this.selectedLocation,
    required this.isLocationPrivate,
    required this.onLocationSelected,
    required this.onLocationChosen,
    required this.onPrivacyChanged,
  });

  final int index;
  final bool isExpanded;
  final bool isCompleted;
  final VoidCallback onToggle;

  final TextEditingController locationCtrl;

  final LocationModel? selectedLocation;
  final bool isLocationPrivate;

  final ValueChanged<LocationModel?> onLocationSelected;
  final ValueChanged<bool> onLocationChosen;
  final ValueChanged<bool> onPrivacyChanged;

  @override
  Widget build(BuildContext context) {
    return AccordionShell(
      title: 'Location',
      subtitle: 'Where will it take place?',
      icon: Icons.location_on_rounded,
      index: index,
      isExpanded: isExpanded,
      isCompleted: isCompleted,
      onToggle: onToggle,
      child: EnhancedLocationSelector(
        selectedLocation: selectedLocation,
        isLocationPrivate: isLocationPrivate,
        locationController: locationCtrl,
        onPrivacyChanged: onPrivacyChanged,
        onLocationSelected: (loc) {
          // forward selected location model
          onLocationSelected(loc);

          // also tell the container whether the step is complete
          onLocationChosen(loc != null || locationCtrl.text.isNotEmpty);
        },
      ),
    );
  }
}
