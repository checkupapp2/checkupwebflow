// lib/features/events/presentation/pages/create_event/widgets/date_time_section.dart
import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'event_type_section.dart';
import 'package:check_up_app/features/events/presentation/widgets/date_time_pickers/modern_date_picker.dart';
import 'package:check_up_app/features/events/presentation/widgets/date_time_pickers/modern_time_picker.dart';

class DateTimeSection extends StatelessWidget {
  const DateTimeSection({
    super.key,
    required this.index,
    required this.isExpanded,
    required this.isCompleted,
    required this.onToggle,
    required this.startDateTime,
    required this.endDateTime,
    required this.onStartDateTimeChanged,
    required this.onEndDateTimeChanged,
    this.calendarViewingDate,
    this.onCalendarViewingDateChanged,
    required this.onValidChanged,
  });

  final int index;
  final bool isExpanded;
  final bool isCompleted;
  final VoidCallback onToggle;

  final DateTime? startDateTime;
  final DateTime? endDateTime;
  final ValueChanged<DateTime?> onStartDateTimeChanged;
  final ValueChanged<DateTime?> onEndDateTimeChanged;

  final DateTime? calendarViewingDate;
  final ValueChanged<DateTime>? onCalendarViewingDateChanged;

  final ValueChanged<bool> onValidChanged;

  @override
  Widget build(BuildContext context) {
    final _Validation v = _validate(startDateTime, endDateTime);
    // Report validity to parent
    WidgetsBinding.instance
        .addPostFrameCallback((_) => onValidChanged(v.isValid));

    return AccordionShell(
      title: 'Date & Time',
      subtitle: 'Set when your event happens',
      icon: Icons.schedule_rounded,
      index: index,
      isExpanded: isExpanded,
      isCompleted: isCompleted,
      onToggle: onToggle,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _combined(
            context: context,
            title: 'Event Date',
            icon: Icons.calendar_today,
            isDate: true,
            start: startDateTime,
            end: endDateTime,
            hasError: v.dateError != null,
            onPickStart: () async {
              final picked = await ModernDatePicker.show(
                context,
                current: startDateTime,
                initialViewingDate: calendarViewingDate,
              );
              if (picked != null) {
                final base = startDateTime ?? DateTime.now();
                onStartDateTimeChanged(
                  DateTime(picked.year, picked.month, picked.day, base.hour,
                      base.minute),
                );
                onCalendarViewingDateChanged
                    ?.call(DateTime(picked.year, picked.month, 1));
              }
            },
            onPickEnd: () async {
              final picked = await ModernDatePicker.show(
                context,
                current: endDateTime ?? startDateTime,
                initialViewingDate: calendarViewingDate,
              );
              if (picked != null) {
                final base = endDateTime ?? (startDateTime ?? DateTime.now());
                onEndDateTimeChanged(
                  DateTime(picked.year, picked.month, picked.day, base.hour,
                      base.minute),
                );
                onCalendarViewingDateChanged
                    ?.call(DateTime(picked.year, picked.month, 1));
              }
            },
          ),
          if (v.dateError != null) ...[
            const SizedBox(height: 8),
            _errorText(v.dateError!),
          ],
          const SizedBox(height: 16),
          _combined(
            context: context,
            title: 'Event Time',
            icon: Icons.access_time,
            isDate: false,
            start: startDateTime,
            end: endDateTime,
            hasError: v.timeError != null,
            onPickStart: () async {
              final base = startDateTime ?? DateTime.now();
              final picked = await ModernTimePicker.show(
                context,
                initial: TimeOfDay(hour: base.hour, minute: base.minute),
              );
              if (picked != null) {
                onStartDateTimeChanged(
                  DateTime(base.year, base.month, base.day, picked.hour,
                      picked.minute),
                );
              }
            },
            onPickEnd: () async {
              final base = endDateTime ?? (startDateTime ?? DateTime.now());
              final picked = await ModernTimePicker.show(
                context,
                initial: TimeOfDay(hour: base.hour, minute: base.minute),
              );
              if (picked != null) {
                onEndDateTimeChanged(
                  DateTime(base.year, base.month, base.day, picked.hour,
                      picked.minute),
                );
              }
            },
          ),
          if (v.timeError != null) ...[
            const SizedBox(height: 8),
            _errorText(v.timeError!),
          ],
          if (v.info != null) ...[
            const SizedBox(height: 8),
            _infoText(v.info!),
          ],
        ],
      ),
    );
  }

  _Validation _validate(DateTime? start, DateTime? end) {
    String? dateError;
    String? timeError;
    String? info;

    // Start must be selected
    if (start == null) {
      dateError = 'Please select a start date.';
      return _Validation(false, dateError: dateError);
    }

    // Start should not be in the past (date-only check already enforced by picker; time might still be past)
    final now = DateTime.now();
    if (start.isBefore(now)) {
      timeError = 'Start time appears to be in the past.';
    }

    // If end selected, it must be strictly after start
    if (end != null) {
      if (!end.isAfter(start)) {
        timeError = 'End must be after start.';
      }
    } else {
      // End is optional; provide a gentle hint
      info = 'Tip: set an end time so attendees know the full duration.';
    }

    final isValid = timeError == null && dateError == null;
    return _Validation(isValid,
        dateError: dateError, timeError: timeError, info: info);
  }

  Widget _combined({
    required BuildContext context,
    required String title,
    required IconData icon,
    required bool isDate,
    required DateTime? start,
    required DateTime? end,
    required VoidCallback onPickStart,
    required VoidCallback onPickEnd,
    bool hasError = false,
  }) {
    final hasStart = start != null;
    final hasEnd = end != null;
    final hasAny = hasStart || hasEnd;

    String fmtDate(DateTime d) => '${_month(d.month)} ${d.day}';
    String fmtTime(DateTime d) {
      final hour = d.hour % 12 == 0 ? 12 : d.hour % 12;
      final m = d.minute.toString().padLeft(2, '0');
      final p = d.hour >= 12 ? 'PM' : 'AM';
      return '$hour:$m $p';
    }

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: hasAny
            ? LinearGradient(colors: [
                Colors.orange.shade400.withValues(alpha: 0.2),
                Colors.deepOrange.shade600.withValues(alpha: 0.2),
                const Color(0xFF2A2A2A),
                const Color(0xFF1A1A1A),
              ])
            : const LinearGradient(colors: [
                Color(0xFF3A3A3A),
                Color(0xFF2A2A2A),
                Color(0xFF1A1A1A),
                Color(0xFF0A0A0A)
              ]),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: hasError
              ? Colors.red.withValues(alpha: 0.55)
              : (hasAny
                  ? Colors.orange.withValues(alpha: 0.3)
                  : Colors.white.withValues(alpha: 0.08)),
          width: hasError ? 1.5 : (hasAny ? 1.5 : 0.5),
        ),
        boxShadow: [
          if (hasError)
            BoxShadow(
              color: Colors.red.withValues(alpha: 0.2),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: hasAny
                    ? LinearGradient(colors: [
                        Colors.orange.shade400,
                        Colors.deepOrange.shade600
                      ])
                    : LinearGradient(
                        colors: [Colors.grey.shade600, Colors.grey.shade700]),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: Colors.white, size: 16),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: TextStyle(
                color: hasAny ? Colors.white : Colors.white.withValues(alpha: 0.9),
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(
              child: _slot(
                label: 'Start',
                value: hasStart
                    ? (isDate ? fmtDate(start!) : fmtTime(start!))
                    : (isDate ? 'Select date' : 'Select time'),
                onTap: onPickStart,
                active: hasStart,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _slot(
                label: 'End',
                value: hasEnd
                    ? (isDate ? fmtDate(end!) : fmtTime(end!))
                    : (isDate ? 'Select date' : 'Select time'),
                onTap: onPickEnd,
                active: hasEnd,
              ),
            ),
          ]),
        ]),
      ),
    );
  }

  Widget _slot({
    required String label,
    required String value,
    required VoidCallback onTap,
    required bool active,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: active
              ? Colors.orange.withValues(alpha: 0.1)
              : Colors.white.withValues(alpha: 0.05),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: active
                ? Colors.orange.withValues(alpha: 0.3)
                : Colors.white.withValues(alpha: 0.1),
            width: 1,
          ),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.7),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: active ? Colors.white : Colors.white.withValues(alpha: 0.6),
              fontSize: active ? 16 : 14,
              fontWeight: active ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ]),
      ),
    );
  }

  Widget _errorText(String text) {
    return Row(
      children: [
        const Icon(Icons.error_outline_rounded,
            size: 16, color: Colors.redAccent),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(
                color: Colors.redAccent,
                fontSize: 12,
                fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }

  Widget _infoText(String text) {
    return Row(
      children: [
        Icon(Icons.info_outline_rounded,
            size: 16, color: AppColors.primaryOrange),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
                color: AppColors.primaryOrange,
                fontSize: 12,
                fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }

  String _month(int m) => const [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
      ][m - 1];
}

class _Validation {
  final bool isValid;
  final String? dateError;
  final String? timeError;
  final String? info;
  const _Validation(this.isValid, {this.dateError, this.timeError, this.info});
}
