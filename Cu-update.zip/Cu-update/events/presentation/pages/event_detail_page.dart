// lib/features/events/presentation/pages/event_detail_page.dart

import 'dart:async';
import 'package:check_up_app/features/tickets/presentation/pages/ticket_payment/ticket_payment_page.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Domain / data
import '../../domain/models/event_model.dart';
import '../../domain/models/event_type.dart';
import '../../domain/models/event_model_firestore.dart';
import '../../data/events_repository.dart';

// Cubit
import '../../bloc/event_detail/event_detail_cubit.dart';
import '../../bloc/event_detail/event_detail_state.dart';

// Sections / UI
import 'package:check_up_app/features/players/presentation/pages/player_profile_page.dart';
import 'package:check_up_app/features/feed/presentation/widgets/create_post_widget.dart';
import 'package:check_up_app/features/feed/presentation/widgets/feed_post.dart';
import 'package:check_up_app/features/feed/domain/models/feed_post_model.dart';
import 'package:check_up_app/features/feed/data/feed_data_provider.dart';
import 'package:check_up_app/features/feed/presentation/widgets/share_modal.dart';
import 'package:check_up_app/features/brackets/presentation/pages/bracket_detail_page.dart';
import 'package:check_up_app/features/brackets/domain/models/bracket_model.dart';

import '../widgets/event_detail/banner_carousel.dart';
import '../widgets/event_detail/event_info_card.dart';
import '../widgets/event_detail/host_card.dart';
import '../widgets/event_detail/court_location_card.dart';
import '../widgets/event_detail/collapsible_details_card.dart';
import '../widgets/event_detail/specialized_sections.dart';
import '../widgets/event_detail/players_strip.dart';
import '../widgets/event_detail/feed_slice.dart';
import '../widgets/event_detail/bottom_ticket_bar.dart';

class EventDetailPage extends StatefulWidget {
  final String? eventId;
  final String? title;
  final String? eventType;

  const EventDetailPage({
    Key? key,
    this.eventId,
    this.title,
    this.eventType,
  }) : super(key: key);

  @override
  State<EventDetailPage> createState() => _EventDetailPageState();
}

class _EventDetailPageState extends State<EventDetailPage>
    with TickerProviderStateMixin {
  late PageController _pageController;
  int _currentPage = 0;
  Timer? _timer;

  bool _isDetailsExpanded = false;
  late List<FeedPostModel> _feedPosts;

  final List<String> _fallbackImages = const [
    'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=1000',
    'https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=1000',
  ];

  String _longDate(DateTime dt) => DateFormat('MMMM d, y').format(dt);
  String _timeRange(DateTime start, {DateTime? end}) {
    final startStr = DateFormat('h:mm a').format(start);
    if (end == null) return startStr;
    final endStr = DateFormat('h:mm a').format(end);
    return '$startStr - $endStr';
  }

  void _addToCalendar(EventModel event, String title) {
    // Show dialog with calendar options
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          title: const Text(
            'Add to Calendar',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: const Text(
            'This will open your calendar app to add this event.',
            style: TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Calendar functionality would open here'),
                    backgroundColor: Color(0xFF22C55E),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF22C55E),
                foregroundColor: Colors.white,
              ),
              child: const Text('Add Event'),
            ),
          ],
        );
      },
    );
  }

  void _navigateToCourtDetail(String courtName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Court details for $courtName coming soon!'),
        backgroundColor: const Color(0xFFFF6B35),
      ),
    );
  }

  void _navigateToHostProfile(String hostName) {
    Navigator.pushNamed(context, '/profile');
  }

  /// Build event type specific widgets based on the event model
  List<Widget> _buildEventTypeSpecificWidgets(
      EventModel event, String eventId, String title, BuildContext context) {
    final widgets = <Widget>[];

    switch (event.eventType) {
      case EventType.tournament:
        widgets.add(
          TournamentBracketPreview(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BracketDetailPage(
                    bracket: BracketModel(
                      id: 'tournament_$eventId',
                      name: title,
                      description: title,
                      startDate: DateTime.now(),
                      createdAt: DateTime.now(),
                      createdBy: 'System',
                      rounds: [],
                      participantCount: 8,
                      status: BracketStatus.inProgress,
                      sport: 'Basketball',
                    ),
                  ),
                ),
              );
            },
          ),
        );
        break;

      case EventType.oneOff:
      case EventType.specialEvent:
        widgets.add(const LeagueStrip());
        break;

      default:
        // For other event types, show a generic widget
        break;
    }

    return widgets;
  }

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: 0);
    _loadFeedData();
    _startAutoScroll();
  }

  void _loadFeedData() {
    final provider = FeedDataProvider();
    _feedPosts = provider.getFeedPosts().take(3).toList();
  }

  void _startAutoScroll() {
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted) return;

      final len = context.read<EventDetailCubit?>() == null
          ? _fallbackImages.length
          : _resolvedImagesLength(context.read<EventDetailCubit>().state);

      _currentPage = (_currentPage + 1) % len;

      if (_pageController.hasClients) {
        _pageController.animateToPage(
          _currentPage,
          duration: const Duration(milliseconds: 700),
          curve: Curves.easeInOut,
        );
      }

      setState(() {});
    });
  }

  int _resolvedImagesLength(EventDetailState state) {
    final ev = state.event;
    if (ev == null) return _fallbackImages.length;
    if (ev.imageUrls.isNotEmpty) return ev.imageUrls.length;
    if ((ev.bannerImageUrl ?? '').isNotEmpty) return 1;
    return _fallbackImages.length;
  }

  List<String> _resolveImages(EventModel? ev) {
    if (ev != null) {
      if (ev.imageUrls.isNotEmpty) return ev.imageUrls;
      if (ev.bannerImageUrl?.isNotEmpty == true) return [ev.bannerImageUrl!];
    }
    return _fallbackImages;
  }

  @override
  void dispose() {
    _pageController.dispose();
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final eventId = widget.eventId ?? '';

    return BlocProvider(
      create: (_) => EventDetailCubit(
        repo: EventsRepository(),
        auth: FirebaseAuth.instance,
      )..load(eventId),
      child: BlocBuilder<EventDetailCubit, EventDetailState>(
        builder: (context, state) {
          final ev = state.event;
          final loading = state.loading;

          final images = _resolveImages(ev);

          final title = ev?.title ?? widget.title ?? 'Event Details';

          final priceText = state.priceLabel ??
              (ev == null
                  ? ''
                  : ev.isFree
                      ? 'Free'
                      : (ev.price != null
                          ? '\$${ev.price!.toStringAsFixed(2)}'
                          : 'From tickets'));

          return Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              backgroundColor: Colors.black,
              foregroundColor: Colors.white,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => Navigator.pop(context),
              ),
              title: Image.asset(
                'assets/images/checkup_main-1.png',
                height: 30,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => Text(title),
              ),
              actions: [
                Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: _SharePill(
                    onTap: () {
                      ShareModal.show(
                        context: context,
                        postId: eventId,
                        postContent: title,
                        shareUrl: 'https://checkup.app/events/$eventId',
                      );
                    },
                  ),
                ),
              ],
            ),
            body: loading
                ? const Center(
                    child: CircularProgressIndicator(color: Colors.orange),
                  )
                : SingleChildScrollView(
                    padding: const EdgeInsets.only(bottom: 80),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        BannerCarousel(
                          pageController: _pageController,
                          currentPage: _currentPage,
                          images: images,
                          priceText: priceText,
                          gameTypeText: ev?.eventType.displayName ?? '',
                        ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Title
                              Text(
                                title,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              const SizedBox(height: 16),

                              // Date/time
                              if (ev?.dateTime != null)
                                EventInfoCard(
                                  dateText: _longDate(ev!.dateTime),
                                  timeText: _timeRange(ev.dateTime),
                                ),

                              const SizedBox(height: 24),

                              // HOST INFO (fetched from Firestore)
                              HostCard(
                                hostName: state.hostName ?? 'Event Host',
                                roleText: 'Organizer',
                                contactText: "Contact",
                              ),

                              const SizedBox(height: 16),

                              // LOCATION — now using meta
                              CourtLocationCard(
                                courtName: state.venueName ?? 'Court',
                                courtLocation:
                                    state.venueAddress ?? ev?.location ?? '',
                                directionsText: 'Directions',
                              ),

                              const SizedBox(height: 24),

                              CollapsibleDetailsCard(
                                expanded: _isDetailsExpanded,
                                previewText: state.detailsText
                                    .split('\n')
                                    .take(2)
                                    .join('\n'),
                                detailsText: state.detailsText,
                                onToggle: () {
                                  setState(() =>
                                      _isDetailsExpanded = !_isDetailsExpanded);
                                },
                              ),

                              const SizedBox(height: 24),

                              // Event type specific widgets
                              if (ev != null) ...[
                                ..._buildEventTypeSpecificWidgets(
                                    ev, eventId, title, context),
                                const SizedBox(height: 16),
                              ],

                              PlayersStrip(
                                registeredCount: state.registeredCount,
                                players: state.activityUsers
                                    .map((u) =>
                                        (u.name, u.distanceLabel, u.isOnline))
                                    .toList(),
                                onPlayerTap: (name) {},
                              ),

                              const SizedBox(height: 24),

                              FeedSlice(
                                createPost: CreatePostWidget(
                                  placeholder: "What's happening?",
                                  profileImagePath:
                                      'assets/images/main_btn.png',
                                  isAssetImage: true,
                                  onTap: () {},
                                  onCameraTap: () {},
                                ),
                                posts: _feedPosts
                                    .map(
                                      (post) => FeedPost(
                                        post: post,
                                        onLikeTap: () {},
                                        onCommentTap: () {},
                                        onRepostTap: () {},
                                        onShareTap: () {},
                                      ),
                                    )
                                    .toList(),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
            bottomNavigationBar: ev == null
                ? null
                : BottomTicketBar(
                    ticketLabel:
                        state.isTicketed ? 'View Tickets' : 'Standard Ticket',
                    priceText: priceText,
                    spotsText: 'Limited Spots',
                    onViewTickets: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => TicketPaymentPage(
                            eventId: eventId,
                            eventName: title,
                            ticketPrice: 0,
                            eventLocation: state.venueAddress ?? ev.location,
                            eventDateTime: ev.dateTime,
                          ),
                        ),
                      );
                    },
                  ),
          );
        },
      ),
    );
  }
}

class _SharePill extends StatelessWidget {
  final VoidCallback onTap;
  const _SharePill({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: InkWell(
        onTap: onTap,
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.share, color: Colors.white, size: 16),
              SizedBox(width: 6),
              Text(
                'Share',
                style: TextStyle(color: Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
