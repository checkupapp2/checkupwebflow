import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';

class TeamRegistrationDetailsPage extends StatefulWidget {
  final Map<String, dynamic> team;
  final String eventTitle;

  const TeamRegistrationDetailsPage({
    Key? key,
    required this.team,
    required this.eventTitle,
  }) : super(key: key);

  @override
  State<TeamRegistrationDetailsPage> createState() => _TeamRegistrationDetailsPageState();
}

class _TeamRegistrationDetailsPageState extends State<TeamRegistrationDetailsPage> {
  @override
  Widget build(BuildContext context) {
    final team = widget.team;
    final teamStatus = team['status'] ?? 'unknown';
    
    return Scaffold(
      backgroundColor: AppColors.primaryBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          team['name'] ?? 'Team Details',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.grey[900]!,
                AppColors.primaryBlack,
              ],
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Team Header Card
            _buildTeamHeaderCard(team),
            
            const SizedBox(height: 20),
            
            // Team Information Card
            _buildTeamInfoCard(team),
            
            const SizedBox(height: 20),
            
            // Captain Information Card
            _buildCaptainInfoCard(team),
            
            const SizedBox(height: 20),
            
            // Status and Actions Card
            _buildStatusActionsCard(team, teamStatus),
            
            const SizedBox(height: 20),
            
            // Event Information Card
            _buildEventInfoCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildTeamHeaderCard(Map<String, dynamic> team) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.black,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              gradient: AppColors.orangeGradient,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.groups, color: Colors.white, size: 30),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  team['name'] ?? 'Team Name',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${team['teamSize'] ?? 0} Players',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.primaryOrange.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.primaryOrange.withOpacity(0.5)),
                  ),
                  child: const Text(
                    'TEAM',
                    style: TextStyle(
                      color: AppColors.primaryOrange,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamInfoCard(Map<String, dynamic> team) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.black,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline, color: AppColors.primaryOrange, size: 20),
              const SizedBox(width: 8),
              const Text(
                'Team Information',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildInfoRow('Team Size', '${team['teamSize'] ?? 0} players'),
          _buildInfoRow('Ticket Type', team['ticketType'] ?? 'Team'),
          _buildInfoRow('Registration Date', team['requestedDate'] ?? team['joinedDate'] ?? 'Unknown'),
          if (team['checkedIn'] == true)
            _buildInfoRow('Check-in Status', 'Checked In', isHighlight: true),
        ],
      ),
    );
  }

  Widget _buildCaptainInfoCard(Map<String, dynamic> team) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.black,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.person_outline, color: AppColors.primaryOrange, size: 20),
              const SizedBox(width: 8),
              const Text(
                'Team Captain',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildInfoRow('Captain Name', team['captain'] ?? 'Unknown'),
          _buildInfoRow('Phone Number', team['captainPhone'] ?? 'No phone'),
          _buildInfoRow('Email Address', team['email'] ?? 'No email'),
        ],
      ),
    );
  }

  Widget _buildStatusActionsCard(Map<String, dynamic> team, String teamStatus) {
    Color statusColor = AppColors.primaryOrange;
    String statusText = teamStatus.toUpperCase();
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.black,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.flag_outlined, color: AppColors.primaryOrange, size: 20),
              const SizedBox(width: 8),
              const Text(
                'Status & Actions',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Status Display
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: statusColor.withOpacity(0.5)),
            ),
            child: Row(
              children: [
                Icon(Icons.circle, color: statusColor, size: 12),
                const SizedBox(width: 8),
                Text(
                  'Status: $statusText',
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Action Buttons
          if (teamStatus == 'requested') ...[
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      // Handle accept team action
                      _handleAcceptTeam();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryOrange,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: const Icon(Icons.check_circle),
                    label: const Text('Accept Team'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      // Handle decline team action
                      _handleDeclineTeam();
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primaryOrange.withOpacity(0.7),
                      side: BorderSide(color: AppColors.primaryOrange.withOpacity(0.7)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: const Icon(Icons.cancel),
                    label: const Text('Decline'),
                  ),
                ),
              ],
            ),
          ] else if (teamStatus == 'joined' && team['checkedIn'] != true) ...[
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  // Handle check-in team action
                  _handleCheckInTeam();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryOrange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                icon: const Icon(Icons.login),
                label: const Text('Check In Team'),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildEventInfoCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.black,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.event, color: AppColors.primaryOrange, size: 20),
              const SizedBox(width: 8),
              const Text(
                'Event Information',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildInfoRow('Event Name', widget.eventTitle),
          _buildInfoRow('Event Type', 'Tournament'),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, {bool isHighlight = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: isHighlight ? AppColors.primaryOrange : Colors.white,
                fontSize: 14,
                fontWeight: isHighlight ? FontWeight.bold : FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleAcceptTeam() {
    // Handle accept team logic
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Team "${widget.team['name']}" accepted!'),
        backgroundColor: AppColors.primaryOrange,
      ),
    );
  }

  void _handleDeclineTeam() {
    // Handle decline team logic
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Team "${widget.team['name']}" declined.'),
        backgroundColor: AppColors.primaryOrange.withOpacity(0.7),
      ),
    );
  }

  void _handleCheckInTeam() {
    // Handle check-in team logic
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Team "${widget.team['name']}" checked in!'),
        backgroundColor: AppColors.primaryOrange,
      ),
    );
  }
}
