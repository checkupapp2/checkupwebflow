// lib/features/events/presentation/pages/create_event/create_event_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';

import '../../../profile/bloc/profile_bloc.dart';
import '../../../profile/bloc/profile_event.dart';
import '../../../profile/data/firebase_profile_repository.dart';

import '../../bloc/events_bloc.dart';
import '../../data/events_repository.dart';
import '../../domain/models/event_type.dart';
import 'create_event/create_event_container.dart';

class CreateEventPage extends StatelessWidget {
  final String? initialTitle;
  final String? initialDescription;
  final DateTime? initialDate;
  final TimeOfDay? initialTime;
  final String? initialLocation;
  final EventType? initialEventType;

  const CreateEventPage({
    super.key,
    this.initialTitle,
    this.initialDescription,
    this.initialDate,
    this.initialTime,
    this.initialLocation,
    this.initialEventType,
  });

  @override
  Widget build(BuildContext context) {
    final sl = GetIt.I;

    return MultiBlocProvider(
      providers: [
        // ProfileBloc is required by the Create form (for username, etc.)
        BlocProvider<ProfileBloc>(
          create: (_) => ProfileBloc(sl<FirebaseProfileRepository>())
            ..add(const ProfileLoadRequested()),
        ),
        // EventsBloc handles create/update/delete
        BlocProvider<EventsBloc>(
          create: (_) => EventsBloc(repo: sl<EventsRepository>()),
        ),
      ],
      child: CreateEventContainer(
        initialTitle: initialTitle,
        initialDescription: initialDescription,
        initialDate: initialDate,
        initialTime: initialTime,
        initialLocation: initialLocation,
        initialEventType: initialEventType,
      ),
    );
  }
}
