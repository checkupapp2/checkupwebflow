import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// A modern, mobile-friendly page for viewing attendee registration details and managing approval/rejection
class AttendeeRegistrationDetailsPage extends StatefulWidget {
  /// The attendee data
  final Map<String, dynamic> attendee;
  
  /// The event title
  final String? eventTitle;

  /// Creates an [AttendeeRegistrationDetailsPage] instance.
  const AttendeeRegistrationDetailsPage({
    Key? key,
    required this.attendee,
    this.eventTitle,
  }) : super(key: key);

  @override
  State<AttendeeRegistrationDetailsPage> createState() => _AttendeeRegistrationDetailsPageState();
}

class _AttendeeRegistrationDetailsPageState extends State<AttendeeRegistrationDetailsPage> 
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  
  // Sample registration questions and answers
  final List<Map<String, String>> _registrationQA = [
    {
      'question': 'What is your basketball experience level?',
      'answer': 'Intermediate - played in college for 2 years',
    },
    {
      'question': 'Do you have any injuries or medical conditions?',
      'answer': 'Minor knee injury from last season, but cleared to play',
    },
    {
      'question': 'What position do you prefer to play?',
      'answer': 'Point Guard / Shooting Guard',
    },
    {
      'question': 'Why do you want to join this event?',
      'answer': 'Looking to get back into competitive basketball and meet new players in the area.',
    },
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));
    
    // Start animations
    _fadeController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  // Helper method to get contextual page title
  String _getPageTitle() {
    switch (widget.attendee['status']) {
      case 'requested':
        return 'Registration Review';
      case 'joined':
        return 'Attendee Details';
      case 'invited':
        return 'Invitation Details';
      default:
        return 'Attendee Details';
    }
  }

  // Helper method to get contextual header text
  String _getHeaderText() {
    switch (widget.attendee['status']) {
      case 'requested':
        return 'Registration Request';
      case 'joined':
        return 'Confirmed Attendee';
      case 'invited':
        return 'Invited Attendee';
      default:
        return 'Attendee Information';
    }
  }

  // Helper method to determine if registration Q&A should be shown
  bool _shouldShowRegistrationQA() {
    return widget.attendee['status'] == 'requested';
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;
    
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: FadeTransition(
          opacity: _fadeAnimation,
          child: Text(
            _getPageTitle(),
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: isTablet ? 22 : 20,
              letterSpacing: 0.8,
            ),
          ),
        ),
        backgroundColor: Colors.black.withOpacity(0.9),
        foregroundColor: Colors.white,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        leading: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.grey[800]!, Colors.grey[900]!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () {
                HapticFeedback.lightImpact();
                Navigator.of(context).pop();
              },
              child: const Icon(Icons.arrow_back_ios_new, size: 18),
            ),
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.9),
                Colors.black.withOpacity(0.7),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black,
              Colors.grey[900]!,
              Colors.black,
            ],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: SlideTransition(
              position: _slideAnimation,
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverPadding(
                    padding: EdgeInsets.symmetric(
                      horizontal: isTablet ? 32 : 20,
                      vertical: 16,
                    ),
                    sliver: SliverList(
                      delegate: SliverChildListDelegate([
                        // Hero section with attendee info
                        _buildModernAttendeeHero(),
                        
                        SizedBox(height: isTablet ? 32 : 24),
                        
                        // Event context card
                        _buildModernEventCard(),
                        
                        SizedBox(height: isTablet ? 32 : 24),
                        
                        // Registration details (only for requested attendees)
                        if (_shouldShowRegistrationQA()) ...[
                          _buildModernRegistrationCard(),
                          SizedBox(height: isTablet ? 32 : 24),
                        ],
                        
                        // Additional info for joined/invited attendees
                        if (!_shouldShowRegistrationQA()) ...[
                          _buildAttendeeStatusCard(),
                          SizedBox(height: isTablet ? 32 : 24),
                        ],
                        
                        SizedBox(height: isTablet ? 40 : 32),
                        
                        // Action buttons (contextual based on status)
                        _buildModernActionButtons(),
                        
                        SizedBox(height: isTablet ? 32 : 24),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildModernAttendeeHero() {
    // Define colors based on status
    Color statusColor;
    IconData statusIcon;
    
    switch (widget.attendee['status']) {
      case 'joined':
        statusColor = Colors.green;
        statusIcon = Icons.check_circle;
        break;
      case 'invited':
        statusColor = Colors.orange;
        statusIcon = Icons.mail;
        break;
      case 'requested':
        statusColor = Colors.purple;
        statusIcon = Icons.person_add;
        break;
      default:
        statusColor = Colors.blue;
        statusIcon = Icons.info;
    }
    
    Color ticketColor = widget.attendee['ticketType'] == 'VIP' 
        ? Colors.amber 
        : Colors.blue;

    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;
    
    return Container(
      padding: EdgeInsets.all(isTablet ? 28 : 24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            statusColor.withOpacity(0.1),
            Colors.grey[850]!,
            Colors.black,
          ],
          stops: const [0.0, 0.3, 1.0],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: statusColor.withOpacity(0.2),
            blurRadius: 20,
            spreadRadius: 0,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 12,
            spreadRadius: 0,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: statusColor.withOpacity(0.4),
          width: 2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Modern header with animated icon
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.orange[400]!, Colors.orange[600]!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.orange.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.person_pin,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  _getHeaderText(),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isTablet ? 22 : 20,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
          
          SizedBox(height: isTablet ? 24 : 20),
          
          // Modern profile section with hero layout
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Enhanced profile image with status ring
              Stack(
                children: [
                  Container(
                    width: isTablet ? 80 : 70,
                    height: isTablet ? 80 : 70,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [statusColor.withOpacity(0.3), statusColor.withOpacity(0.1)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      border: Border.all(
                        color: statusColor,
                        width: 3,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: statusColor.withOpacity(0.4),
                          blurRadius: 12,
                          spreadRadius: 2,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: widget.attendee['isRegistered'] == true
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(50),
                            child: Image.network(
                              widget.attendee['profileImage'],
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) => 
                                  Icon(Icons.person, color: statusColor, size: isTablet ? 40 : 35),
                            ),
                          )
                        : Icon(
                            Icons.person_outline,
                            color: Colors.amber,
                            size: isTablet ? 40 : 35,
                          ),
                  ),
                  // Animated status indicator
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: isTablet ? 24 : 20,
                      height: isTablet ? 24 : 20,
                      decoration: BoxDecoration(
                        color: statusColor,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.black, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: statusColor.withOpacity(0.6),
                            blurRadius: 6,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: Icon(
                        statusIcon,
                        color: Colors.white,
                        size: isTablet ? 12 : 10,
                      ),
                    ),
                  ),
                ],
              ),
              
              SizedBox(width: isTablet ? 20 : 16),
              
              // Name and details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            widget.attendee['name'],
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),
                          ),
                        ),
                        // Status badge
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: statusColor.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: statusColor.withOpacity(0.5),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                statusIcon,
                                color: statusColor,
                                size: 12,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                widget.attendee['status'].toString().toUpperCase(),
                                style: TextStyle(
                                  color: statusColor,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 8),
                    
                    Text(
                      widget.attendee['email'],
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 14,
                      ),
                    ),
                    
                    const SizedBox(height: 8),
                    
                    // User type and ticket type
                    Row(
                      children: [
                        if (widget.attendee['isRegistered'] != true) ...[
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.amber.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Colors.amber.withOpacity(0.5),
                                width: 1,
                              ),
                            ),
                            child: const Text(
                              'GUEST',
                              style: TextStyle(
                                color: Colors.amber,
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                        ],
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: ticketColor.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: ticketColor.withOpacity(0.5),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            widget.attendee['ticketType'],
                            style: TextStyle(
                              color: ticketColor,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildModernEventCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.black,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 8,
            spreadRadius: 0,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: Colors.orange.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              const Icon(
                Icons.event,
                color: Colors.orange,
                size: 24,
              ),
              const SizedBox(width: 8),
              const Text(
                'Event Information',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Event details
          _buildInfoRow('Event', widget.eventTitle ?? 'Evening Shootaround'),
          const SizedBox(height: 8),
          _buildInfoRow('Date', 'March 15, 2024'),
          const SizedBox(height: 8),
          _buildInfoRow('Time', '7:00 PM - 9:00 PM'),
          const SizedBox(height: 8),
          _buildInfoRow('Location', 'Downtown Basketball Court'),
        ],
      ),
    );
  }

  Widget _buildModernRegistrationCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.black,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 8,
            spreadRadius: 0,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: Colors.purple.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              const Icon(
                Icons.quiz,
                color: Colors.orange,
                size: 24,
              ),
              const SizedBox(width: 8),
              const Text(
                'Registration Questions',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Questions and answers
          ..._registrationQA.map((qa) => _buildQuestionAnswerItem(qa)).toList(),
        ],
      ),
    );
  }

  Widget _buildQuestionAnswerItem(Map<String, String> qa) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.grey[700]!,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            qa['question']!,
            style: const TextStyle(
              color: Colors.orange,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            qa['answer']!,
            style: TextStyle(
              color: Colors.grey[300],
              fontSize: 14,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 80,
          child: Text(
            label,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAttendeeStatusCard() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;
    
    return Container(
      padding: EdgeInsets.all(isTablet ? 28 : 24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.black,
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 12,
            spreadRadius: 0,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: Colors.blue.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.blue[400]!, Colors.blue[600]!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blue.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Icon(
                  widget.attendee['status'] == 'joined' ? Icons.check_circle : Icons.mail_outline,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  widget.attendee['status'] == 'joined' 
                      ? 'Attendance Status' 
                      : 'Invitation Status',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isTablet ? 22 : 20,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
          
          SizedBox(height: isTablet ? 24 : 20),
          
          // Status information
          _buildStatusInfoRow('Status', widget.attendee['status'].toString().toUpperCase()),
          const SizedBox(height: 12),
          
          if (widget.attendee['status'] == 'joined') ...[
            _buildStatusInfoRow('Check-in Status', widget.attendee['checkedIn'] ? 'Checked In' : 'Not Checked In'),
            const SizedBox(height: 12),
            _buildStatusInfoRow('Registration Date', 'March 10, 2024'),
          ] else if (widget.attendee['status'] == 'invited') ...[
            _buildStatusInfoRow('Invitation Sent', 'March 8, 2024'),
            const SizedBox(height: 12),
            _buildStatusInfoRow('Response Status', 'Pending Response'),
          ],
        ],
      ),
    );
  }

  Widget _buildStatusInfoRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 120,
          child: Text(
            label,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildModernActionButtons() {
    if (widget.attendee['status'] != 'requested') {
      return const SizedBox.shrink();
    }

    return Row(
      children: [
        // Approve button
        Expanded(
          child: Container(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: () => _approveRequest(),
              icon: const Icon(Icons.check, size: 20),
              label: const Text(
                'Approve',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                  letterSpacing: 0.5,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[600],
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 4,
                shadowColor: Colors.green.withOpacity(0.4),
              ),
            ),
          ),
        ),
        
        const SizedBox(width: 16),
        
        // Reject button
        Expanded(
          child: Container(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: () => _rejectRequest(),
              icon: const Icon(Icons.close, size: 20),
              label: const Text(
                'Reject',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                  letterSpacing: 0.5,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[600],
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 4,
                shadowColor: Colors.red.withOpacity(0.4),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _approveRequest() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text(
            'Approve Request',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: Text(
            'Are you sure you want to approve ${widget.attendee['name']}\'s registration request?',
            style: TextStyle(color: Colors.grey[300]),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'Cancel',
                style: TextStyle(color: Colors.grey[400]),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop(); // Go back to manage event page
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('${widget.attendee['name']} has been approved!'),
                    backgroundColor: Colors.green[600],
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green[600],
                foregroundColor: Colors.white,
              ),
              child: const Text('Approve'),
            ),
          ],
        );
      },
    );
  }

  void _rejectRequest() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Text(
            'Reject Request',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: Text(
            'Are you sure you want to reject ${widget.attendee['name']}\'s registration request?',
            style: TextStyle(color: Colors.grey[300]),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'Cancel',
                style: TextStyle(color: Colors.grey[400]),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop(); // Go back to manage event page
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('${widget.attendee['name']} has been rejected.'),
                    backgroundColor: Colors.red[600],
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[600],
                foregroundColor: Colors.white,
              ),
              child: const Text('Reject'),
            ),
          ],
        );
      },
    );
  }
}
