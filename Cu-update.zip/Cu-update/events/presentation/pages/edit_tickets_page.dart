import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// A modern page for editing event ticket details and pricing
class EditTicketsPage extends StatefulWidget {
  /// The event title
  final String? eventTitle;

  /// Creates an [EditTicketsPage] instance.
  const EditTicketsPage({
    Key? key,
    this.eventTitle,
  }) : super(key: key);

  @override
  State<EditTicketsPage> createState() => _EditTicketsPageState();
}

class _EditTicketsPageState extends State<EditTicketsPage> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  
  // Form controllers for ticket editing
  final _regularPriceController = TextEditingController(text: '15.00');
  final _regularDescriptionController = TextEditingController(text: 'Standard entry to the event');
  final _regularQuantityController = TextEditingController(text: '24');
  
  final _vipPriceController = TextEditingController(text: '30.00');
  final _vipDescriptionController = TextEditingController(text: 'Premium access with reserved seating');
  final _vipQuantityController = TextEditingController(text: '10');
  
  // State variables
  bool _regularEnabled = true;
  bool _vipEnabled = true;
  bool _hasUnsavedChanges = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));
    
    _fadeController.forward();
    
    // Add listeners to detect changes
    _addChangeListeners();
  }

  void _addChangeListeners() {
    _regularPriceController.addListener(() => _markAsChanged());
    _regularDescriptionController.addListener(() => _markAsChanged());
    _regularQuantityController.addListener(() => _markAsChanged());
    _vipPriceController.addListener(() => _markAsChanged());
    _vipDescriptionController.addListener(() => _markAsChanged());
    _vipQuantityController.addListener(() => _markAsChanged());
  }

  void _markAsChanged() {
    if (!_hasUnsavedChanges) {
      setState(() {
        _hasUnsavedChanges = true;
      });
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _regularPriceController.dispose();
    _regularDescriptionController.dispose();
    _regularQuantityController.dispose();
    _vipPriceController.dispose();
    _vipDescriptionController.dispose();
    _vipQuantityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;
    
    return Scaffold(
      appBar: AppBar(
        title: FadeTransition(
          opacity: _fadeAnimation,
          child: Text(
            'Edit Tickets',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: isTablet ? 22 : 20,
              letterSpacing: 0.8,
            ),
          ),
        ),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        leading: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.grey[800]!, Colors.grey[900]!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () {
                HapticFeedback.lightImpact();
                _handleBackPress();
              },
              child: const Icon(Icons.arrow_back_ios_new, size: 18),
            ),
          ),
        ),
        actions: [
          if (_hasUnsavedChanges)
            Container(
              margin: const EdgeInsets.only(right: 16, top: 8, bottom: 8),
              child: ElevatedButton(
                onPressed: _saveChanges,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange[600],
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 4,
                ),
                child: const Text(
                  'Save',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black,
              Colors.grey[900]!,
              Colors.black,
            ],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverPadding(
                  padding: EdgeInsets.symmetric(
                    horizontal: isTablet ? 32 : 20,
                    vertical: 16,
                  ),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      // Event info header
                      _buildEventInfoHeader(),
                      
                      SizedBox(height: isTablet ? 32 : 24),
                      
                      // Regular ticket editing
                      _buildTicketEditCard(
                        'Regular Entry',
                        Icons.confirmation_number,
                        Colors.blue,
                        _regularPriceController,
                        _regularDescriptionController,
                        _regularQuantityController,
                        _regularEnabled,
                        (value) => setState(() => _regularEnabled = value),
                      ),
                      
                      SizedBox(height: isTablet ? 24 : 20),
                      
                      // VIP ticket editing
                      _buildTicketEditCard(
                        'VIP Access',
                        Icons.star,
                        Colors.amber,
                        _vipPriceController,
                        _vipDescriptionController,
                        _vipQuantityController,
                        _vipEnabled,
                        (value) => setState(() => _vipEnabled = value),
                      ),
                      
                      SizedBox(height: isTablet ? 40 : 32),
                      
                      // Action buttons
                      _buildActionButtons(),
                      
                      SizedBox(height: isTablet ? 32 : 24),
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEventInfoHeader() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;
    
    return Container(
      padding: EdgeInsets.all(isTablet ? 24 : 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.orange.withOpacity(0.1),
            Colors.grey[850]!,
            Colors.black,
          ],
          stops: const [0.0, 0.3, 1.0],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.orange.withOpacity(0.2),
            blurRadius: 16,
            spreadRadius: 0,
            offset: const Offset(0, 6),
          ),
        ],
        border: Border.all(
          color: Colors.orange.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.orange[400]!, Colors.orange[600]!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.edit_note,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Editing Tickets',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isTablet ? 20 : 18,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.eventTitle ?? 'Evening Shootaround',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: isTablet ? 16 : 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTicketEditCard(
    String title,
    IconData icon,
    Color accentColor,
    TextEditingController priceController,
    TextEditingController descriptionController,
    TextEditingController quantityController,
    bool isEnabled,
    Function(bool) onToggle,
  ) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;
    final isMobile = screenWidth < 600;
    
    return Container(
      padding: EdgeInsets.all(isMobile ? 16 : (isTablet ? 24 : 20)),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[850]!,
            Colors.grey[900]!,
            Colors.black,
          ],
          stops: const [0.0, 0.5, 1.0],
        ),
        borderRadius: BorderRadius.circular(isMobile ? 16 : 20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: isMobile ? 8 : 12,
            spreadRadius: 0,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: Colors.orange.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with toggle
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(isMobile ? 8 : 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.orange[400]!, Colors.orange[600]!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(isMobile ? 12 : 14),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.orange.withOpacity(0.4),
                      blurRadius: isMobile ? 6 : 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Icon(
                  icon,
                  color: Colors.white,
                  size: isMobile ? 18 : 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isTablet ? 18 : 16,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              Switch(
                value: isEnabled,
                onChanged: onToggle,
                activeColor: Colors.orange,
                activeTrackColor: Colors.orange.withOpacity(0.3),
                inactiveThumbColor: Colors.grey[600],
                inactiveTrackColor: Colors.grey[800],
                materialTapTargetSize: MaterialTapTargetSize.padded,
              ),
            ],
          ),
          
          if (isEnabled) ...[
            SizedBox(height: isTablet ? 20 : 16),
            
            // Price field
            _buildInputField(
              'Price',
              priceController,
              Icons.attach_money,
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              prefix: '\$',
            ),
            
            SizedBox(height: isMobile ? 12 : 16),
            
            // Description field
            _buildInputField(
              'Description',
              descriptionController,
              Icons.description,
              maxLines: 2,
            ),
            
            SizedBox(height: isMobile ? 12 : 16),
            
            // Quantity field
            _buildInputField(
              'Available Quantity',
              quantityController,
              Icons.inventory,
              keyboardType: TextInputType.number,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInputField(
    String label,
    TextEditingController controller,
    IconData icon, {
    TextInputType? keyboardType,
    String? prefix,
    int maxLines = 1,
  }) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 600;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: isMobile ? 6 : 8),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          maxLines: maxLines,
          style: TextStyle(
            color: Colors.white,
            fontSize: isMobile ? 15 : 16,
            fontWeight: FontWeight.w500,
          ),
          decoration: InputDecoration(
            prefixText: prefix,
            prefixStyle: TextStyle(
              color: Colors.orange,
              fontSize: isMobile ? 15 : 16,
              fontWeight: FontWeight.w600,
            ),
            prefixIcon: Icon(
              icon,
              color: Colors.orange,
              size: isMobile ? 18 : 20,
            ),
            filled: true,
            fillColor: Colors.black.withOpacity(0.6),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
              borderSide: BorderSide(color: Colors.grey[700]!),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
              borderSide: BorderSide(color: Colors.grey[600]!),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(isMobile ? 10 : 12),
              borderSide: BorderSide(color: Colors.orange, width: 2),
            ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: isMobile ? 12 : 16, 
              vertical: isMobile ? 10 : 12,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth > 600;
    final isMobile = screenWidth < 600;
    
    return Row(
      children: [
        // Cancel button
        Expanded(
          child: Container(
            height: isMobile ? 48 : (isTablet ? 56 : 50),
            child: ElevatedButton(
              onPressed: _handleBackPress,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey[800],
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
                ),
                elevation: 4,
                shadowColor: Colors.black.withOpacity(0.4),
              ),
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: isMobile ? 14 : (isTablet ? 16 : 15),
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
        ),
        
        SizedBox(width: isMobile ? 12 : 16),
        
        // Save button with orange gradient
        Expanded(
          child: Container(
            height: isMobile ? 48 : (isTablet ? 56 : 50),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.orange[400]!, Colors.orange[600]!],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.4),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _saveChanges,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: Colors.white,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
                ),
                elevation: 0,
              ),
              child: Text(
                'Save Changes',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: isMobile ? 14 : (isTablet ? 16 : 15),
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _handleBackPress() {
    if (_hasUnsavedChanges) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: Colors.grey[900],
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: const Text(
              'Unsaved Changes',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
            content: Text(
              'You have unsaved changes. Are you sure you want to leave without saving?',
              style: TextStyle(color: Colors.grey[300]),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: Colors.grey[400]),
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[600],
                  foregroundColor: Colors.white,
                ),
                child: const Text('Leave'),
              ),
            ],
          );
        },
      );
    } else {
      Navigator.of(context).pop();
    }
  }

  void _saveChanges() {
    // Here you would typically save to a backend or state management
    setState(() {
      _hasUnsavedChanges = false;
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Ticket changes saved successfully!'),
        backgroundColor: Colors.green[600],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
    
    // Navigate back after a short delay
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) {
        Navigator.of(context).pop();
      }
    });
  }
}
