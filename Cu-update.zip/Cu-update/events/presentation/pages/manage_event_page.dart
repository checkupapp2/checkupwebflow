import 'package:flutter/material.dart';
import 'package:check_up_app/features/events/domain/models/location_model.dart';
import '../../../courts/presentation/widgets/court_image_picker.dart';
import '../widgets/enhanced_location_selector.dart';
import '../widgets/registration_pricing_form.dart';
import '../../../../core/theme/app_colors.dart';

// sections
import '../widgets/manage_events/attendance_section.dart';
import '../widgets/manage_events/basic_info_section.dart';
import '../widgets/manage_events/date_time_section.dart';
import '../widgets/manage_events/location_section.dart';
import '../widgets/manage_events/tickets_section.dart';
import '../widgets/manage_events/settings_section.dart';

class ManageEventPage extends StatefulWidget {
  final String? eventId;
  final String? title;

  const ManageEventPage({Key? key, this.eventId, this.title}) : super(key: key);

  @override
  State<ManageEventPage> createState() => _ManageEventPageState();
}

class _ManageEventPageState extends State<ManageEventPage>
    with TickerProviderStateMixin {
  int? _expandedSection = 0;
  late AnimationController _animationController;

  final Map<int, bool> _sectionCompletion = {
    0: true, // Attendance
    1: true, // Basic Information
    2: true, // Date & Time
    3: true, // Location
    4: true, // Pricing & Tickets
    5: true, // Event Settings
  };

  // ----- Shared state originally in the monolith -----

  // Location
  LocationModel? _selectedLocation = const LocationModel(
    id: 'west4th',
    name: 'West 4th Street Courts',
    address: '6th Avenue & West 4th Street',
    city: 'New York',
    state: 'NY',
    zipCode: '10014',
    venueType: 'court',
    isPopular: true,
    description: 'Iconic outdoor streetball courts in the West Village.',
  );
  bool _isLocationPrivate = false;
  final TextEditingController _locationController = TextEditingController();

  // Date & time (demo)
  DateTime? _selectedStartDateTime =
      DateTime.now().add(const Duration(days: 5, hours: 18));
  DateTime? _selectedEndDateTime =
      DateTime.now().add(const Duration(days: 5, hours: 21));

  // Tickets
  final TextEditingController _capacityController = TextEditingController();
  bool _isRegistrationOpen = true;

  List<Map<String, dynamic>> _ticketTypes = [];
  final TextEditingController _ticketNameController = TextEditingController();
  final TextEditingController _ticketPriceController = TextEditingController();
  final TextEditingController _ticketQuantityController =
      TextEditingController();

  bool _hasCustomQuestions = false;
  List<Map<String, dynamic>> _customQuestions = [];
  final TextEditingController _questionTextController = TextEditingController();
  final TextEditingController _questionOptionsController =
      TextEditingController();

  bool _hasEarlyBirdPricing = false;
  final TextEditingController _earlyBirdPriceController =
      TextEditingController();
  DateTime? _earlyBirdDeadline;

  bool _requiresWaiver = false;
  final TextEditingController _waiverTextController = TextEditingController();
  String? _selectedWaiverTemplate;

  // Event images
  List<String> _eventImageUrls = [];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 300));

    _expandedSection = 0;

    // prefill to match your original demo
    _locationController.text = _selectedLocation!.name;
    _capacityController.text = '120';
    _ticketTypes = [
      {
        'name': 'General Admission',
        'description': 'Standard entry with access to all tournament games.',
        'price': 25.0,
        'quantity': 80,
        'isExpanded': false,
      },
      {
        'name': 'VIP Courtside',
        'description':
            'Courtside seating, player tunnel access, and VIP lounge.',
        'price': 60.0,
        'quantity': 20,
        'isExpanded': false,
      },
      {
        'name': 'Student Ticket',
        'description': 'Discounted entry for students with valid ID.',
        'price': 15.0,
        'quantity': 20,
        'isExpanded': false,
      },
    ];

    _waiverTextController.text =
        'By registering for this event, you acknowledge the risks of participating in basketball activities and agree to the event waiver terms.';
  }

  @override
  void dispose() {
    _animationController.dispose();
    _locationController.dispose();
    _capacityController.dispose();
    _ticketNameController.dispose();
    _ticketPriceController.dispose();
    _ticketQuantityController.dispose();
    _questionTextController.dispose();
    _questionOptionsController.dispose();
    _earlyBirdPriceController.dispose();
    _waiverTextController.dispose();
    super.dispose();
  }

  void _handleManageEventImageTap() {
    showDialog(
      context: context,
      builder: (context) => CourtImagePicker(
        initialImages: _eventImageUrls,
        maxImages: 4,
        onImagesSelected: (images) {
          setState(() => _eventImageUrls = List<String>.from(images));
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryBlack,
      appBar: AppBar(
        backgroundColor: AppColors.primaryBlack,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: Colors.white, size: 20),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          'Manage ${widget.title ?? 'Event'}',
          style: const TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const SizedBox(height: 8),
            Text(
              'Manage attendance, tickets, and event settings',
              style:
                  TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),

            // 0 — Attendance
            _accordion(
              index: 0,
              title: 'Attendance Management',
              subtitle: 'View and manage event attendees',
              icon: Icons.people_rounded,
              child: AttendanceSection(
                eventTitle: widget.title ?? 'Event',
              ),
            ),
            const SizedBox(height: 12),

            // 1 — Basic Info
            _accordion(
              index: 1,
              title: 'Basic Information',
              subtitle: 'Manage ticket types and pricing',
              icon: Icons.info_rounded,
              child: BasicInfoSection(
                titleText: widget.title ?? 'West 4th Street Tournament',
                eventImageUrls: _eventImageUrls,
                onTapManageImages: _handleManageEventImageTap,
                onTitleChanged: (_) {},
              ),
            ),
            const SizedBox(height: 12),

            // 2 — Date & Time
            _accordion(
              index: 2,
              title: 'Date & Time',
              subtitle: 'Configure event settings',
              icon: Icons.schedule_rounded,
              child: DateTimeSection(
                startDateTime: _selectedStartDateTime,
                endDateTime: _selectedEndDateTime,
                onChanged: (start, end) {
                  setState(() {
                    _selectedStartDateTime = start;
                    _selectedEndDateTime = end;
                  });
                },
              ),
            ),
            const SizedBox(height: 12),

            // 3 — Location
            _accordion(
              index: 3,
              title: 'Location',
              subtitle: 'Manage event location',
              icon: Icons.location_on_rounded,
              child: LocationSection(
                selectedLocation: _selectedLocation,
                isLocationPrivate: _isLocationPrivate,
                locationController: _locationController,
                onLocationSelected: (loc) =>
                    setState(() => _selectedLocation = loc),
                onPrivacyChanged: (val) =>
                    setState(() => _isLocationPrivate = val),
              ),
            ),
            const SizedBox(height: 12),

            // 4 — Pricing & Tickets
            _accordion(
              index: 4,
              title: 'Pricing & Tickets',
              subtitle: 'Manage tickets and pricing',
              icon: Icons.confirmation_number_rounded,
              child: TicketsSection(
                capacityController: _capacityController,
                isRegistrationOpen: _isRegistrationOpen,
                onRegistrationStatusChanged: (v) =>
                    setState(() => _isRegistrationOpen = v),
                ticketTypes: _ticketTypes,
                onTicketTypesUpdated: (t) => setState(() => _ticketTypes = t),
                ticketNameController: _ticketNameController,
                ticketPriceController: _ticketPriceController,
                ticketQuantityController: _ticketQuantityController,
                hasCustomQuestions: _hasCustomQuestions,
                onCustomQuestionsChanged: (v) =>
                    setState(() => _hasCustomQuestions = v),
                customQuestions: _customQuestions,
                onCustomQuestionsUpdated: (q) =>
                    setState(() => _customQuestions = q),
                questionTextController: _questionTextController,
                questionOptionsController: _questionOptionsController,
                hasEarlyBirdPricing: _hasEarlyBirdPricing,
                onEarlyBirdPricingChanged: (v) =>
                    setState(() => _hasEarlyBirdPricing = v),
                earlyBirdPriceController: _earlyBirdPriceController,
                earlyBirdDeadline: _earlyBirdDeadline,
                onEarlyBirdDeadlineSelected: (d) =>
                    setState(() => _earlyBirdDeadline = d),
                requiresWaiver: _requiresWaiver,
                onWaiverRequirementChanged: (v) =>
                    setState(() => _requiresWaiver = v),
                waiverTextController: _waiverTextController,
                selectedWaiverTemplate: _selectedWaiverTemplate,
                onWaiverTemplateSelected: (t) =>
                    setState(() => _selectedWaiverTemplate = t),
              ),
            ),
            const SizedBox(height: 12),

            // 5 — Settings
            _accordion(
              index: 5,
              title: 'Event Settings',
              subtitle: 'Configure event preferences',
              icon: Icons.settings_rounded,
              child: const SettingsSection(),
            ),

            const SizedBox(height: 100),
          ],
        ),
      ),
    );
  }

  Widget _accordion({
    required int index,
    required String title,
    required String subtitle,
    required IconData icon,
    required Widget child,
  }) {
    final isExpanded = _expandedSection == index;
    final isCompleted = _sectionCompletion[index] ?? false;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isExpanded
              ? [
                  const Color(0xFF3A3A3A),
                  const Color(0xFF2A2A2A),
                  const Color(0xFF1A1A1A)
                ]
              : [
                  const Color(0xFF2A2A2A),
                  const Color(0xFF1A1A1A),
                  const Color(0xFF0A0A0A)
                ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isExpanded
              ? AppColors.primaryOrange.withOpacity(0.3)
              : Colors.white.withOpacity(0.08),
          width: isExpanded ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: isExpanded
                ? AppColors.primaryOrange.withOpacity(0.2)
                : Colors.black.withOpacity(0.3),
            blurRadius: isExpanded ? 12 : 6,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () =>
                  setState(() => _expandedSection = isExpanded ? null : index),
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        gradient: isCompleted
                            ? AppColors.orangeGradient
                            : LinearGradient(colors: [
                                Colors.grey.shade600,
                                Colors.grey.shade700
                              ]),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: isCompleted
                                ? AppColors.primaryOrange.withOpacity(0.3)
                                : Colors.black.withOpacity(0.2),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Icon(isCompleted ? Icons.check_rounded : icon,
                          color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(title,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600)),
                            const SizedBox(height: 4),
                            Text(
                              isCompleted ? 'Completed ✓' : subtitle,
                              style: TextStyle(
                                color: isCompleted
                                    ? AppColors.primaryOrange
                                    : Colors.white.withOpacity(0.7),
                                fontSize: 14,
                                fontWeight: isCompleted
                                    ? FontWeight.w500
                                    : FontWeight.normal,
                              ),
                            ),
                          ]),
                    ),
                    AnimatedRotation(
                      turns: isExpanded ? 0.5 : 0,
                      duration: const Duration(milliseconds: 300),
                      child: Icon(Icons.keyboard_arrow_down_rounded,
                          color: isExpanded
                              ? AppColors.primaryOrange
                              : Colors.white.withOpacity(0.6),
                          size: 28),
                    ),
                  ],
                ),
              ),
            ),
          ),
          AnimatedSize(
            duration: const Duration(milliseconds: 300),
            child: isExpanded
                ? Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                    child: child)
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}
