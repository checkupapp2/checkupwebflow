import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import '../../../../domain/models/event_type.dart';
import '../../../widgets/event_type_specific_forms.dart';
import 'event_type_section.dart';

class DetailsSection extends StatelessWidget {
  const DetailsSection({
    super.key,
    required this.index,
    required this.isExpanded,
    required this.isCompleted,
    required this.onToggle,
    required this.eventType,
    required this.formData,
    required this.onFormDataChanged,
    required this.startDateTime, // <-- added
    required this.endDateTime, // <-- added
  });

  final int index;
  final bool isExpanded;
  final bool isCompleted;
  final VoidCallback onToggle;

  final EventType? eventType;
  final Map<String, dynamic> formData;
  final void Function(Map<String, dynamic> data, bool valid) onFormDataChanged;

  /// From the Date & Time step (used by some type forms e.g. Tournament reg deadline)
  final DateTime? startDateTime; // <-- added
  final DateTime? endDateTime; // <-- added

  String _title(EventType t) {
    switch (t) {
      case EventType.pickupRun:
      case EventType.openGym:
        return 'Pickup Run Configuration';
      case EventType.tournament:
        return 'Tournament Configuration';
      case EventType.donationBased:
        return 'Fundraiser Configuration';
      case EventType.camp:
        return 'Camp Configuration';
      case EventType.training:
        return 'Training Configuration';
      case EventType.specialEvent:
      case EventType.oneOff:
        return 'Special Event Configuration';
      case EventType.oneVsOne:
        return '1v1 Configuration';
    }
  }

  String _subtitle(EventType t) {
    switch (t) {
      case EventType.pickupRun:
      case EventType.openGym:
        return 'Set up your casual basketball game';
      case EventType.tournament:
        return 'Design your tournament structure';
      case EventType.donationBased:
        return 'Set up your charity fundraiser';
      case EventType.camp:
        return 'Set up your multi-day basketball camp';
      case EventType.training:
        return 'Configure your training session';
      case EventType.specialEvent:
      case EventType.oneOff:
        return 'Make your special event memorable';
      case EventType.oneVsOne:
        return 'Configure your 1v1 matchup';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (eventType == null) {
      return AccordionShell(
        title: 'Event Details',
        subtitle: 'Configure event-specific details',
        icon: Icons.settings_rounded,
        index: index,
        isExpanded: isExpanded,
        isCompleted: isCompleted,
        onToggle: onToggle,
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Icon(Icons.arrow_upward_rounded,
                color: AppColors.primaryOrange, size: 32),
            const SizedBox(height: 16),
            Text('Please select an event type first',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.7), fontSize: 16),
                textAlign: TextAlign.center),
          ]),
        ),
      );
    }

    final t = eventType!;
    return AccordionShell(
      title: _title(t),
      subtitle: _subtitle(t),
      icon: _iconFor(t),
      index: index,
      isExpanded: isExpanded,
      isCompleted: isCompleted,
      onToggle: onToggle,
      child: EventTypeSpecificForms(
        eventType: t,
        formData: formData,
        startDateTime: startDateTime, // <-- now passed through
        endDateTime: endDateTime, // <-- now passed through
        onFormDataChanged: (data) => onFormDataChanged(data, data.isNotEmpty),
        onNextStep: () {},
        onPreviousStep: () {},
      ),
    );
  }

  IconData _iconFor(EventType t) {
    switch (t) {
      case EventType.pickupRun:
      case EventType.openGym:
        return Icons.sports_basketball_rounded;
      case EventType.tournament:
        return Icons.emoji_events_rounded;
      case EventType.donationBased:
        return Icons.favorite_rounded;
      case EventType.camp:
        return Icons.school_rounded;
      case EventType.training:
        return Icons.fitness_center_rounded;
      case EventType.specialEvent:
      case EventType.oneOff:
        return Icons.star_rounded;
      case EventType.oneVsOne:
        return Icons.person_rounded;
    }
  }
}
