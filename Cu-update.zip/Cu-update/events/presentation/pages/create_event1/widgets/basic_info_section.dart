// TODO Implement this library.
// lib/features/events/presentation/pages/create_event/widgets/basic_info_section.dart
import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import 'event_type_section.dart';

class BasicInfoSection extends StatelessWidget {
  const BasicInfoSection({
    super.key,
    required this.index,
    required this.isExpanded,
    required this.isCompleted,
    required this.onToggle,
    required this.titleCtrl,
    required this.descCtrl,
    required this.onValidChanged,
  });

  final int index;
  final bool isExpanded;
  final bool isCompleted;
  final VoidCallback onToggle;

  final TextEditingController titleCtrl;
  final TextEditingController descCtrl;
  final ValueChanged<bool> onValidChanged;

  @override
  Widget build(BuildContext context) {
    return AccordionShell(
      title: 'Basic Information',
      subtitle: 'Add title and description',
      icon: Icons.info_rounded,
      index: index,
      isExpanded: isExpanded,
      isCompleted: isCompleted,
      onToggle: onToggle,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: _box(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _head(icon: Icons.title_rounded, label: 'Event Title'),
                const SizedBox(height: 12),
                TextField(
                  controller: titleCtrl,
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                  decoration: _input('Give your event an exciting name...'),
                  onChanged: (v) => onValidChanged(v.isNotEmpty),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Visibility card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: _box(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _head(
                    icon: Icons.description_rounded,
                    label: 'Event Description'),
                const SizedBox(height: 12),
                TextField(
                  controller: descCtrl,
                  maxLines: 3,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 14, height: 1.4),
                  decoration: _input(
                    'Share what makes your event special...\n\n• What should attendees expect?\n• Any special requirements?',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  BoxDecoration _box() => BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF3A3A3A), Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.08), width: 0.5),
      );

  InputDecoration _input(String hint) => InputDecoration(
        hintText: hint,
        hintStyle:
            TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 14),
        filled: true,
        fillColor: Colors.white.withOpacity(0.08),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.primaryOrange, width: 2),
        ),
        contentPadding: const EdgeInsets.all(12),
      );

  Widget _head({required IconData icon, required String label}) {
    return Row(children: [
      Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
            gradient: AppColors.orangeGradient,
            borderRadius: BorderRadius.circular(8)),
        child: Icon(icon, color: Colors.white, size: 16),
      ),
      const SizedBox(width: 12),
      Text(label,
          style: const TextStyle(
              color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
    ]);
  }
}
