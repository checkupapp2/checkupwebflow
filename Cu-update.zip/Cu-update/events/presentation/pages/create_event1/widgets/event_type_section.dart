// lib/features/events/presentation/pages/create_event/widgets/event_type_section.dart
import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import '../../../../domain/models/event_type.dart';
import '../../../widgets/event_type_selector.dart';

class EventTypeSection extends StatelessWidget {
  const EventTypeSection({
    super.key,
    required this.index,
    required this.isExpanded,
    required this.isCompleted,
    required this.onToggle,
    required this.selectedType,
    required this.onTypeSelected,
  });

  final int index;
  final bool isExpanded;
  final bool isCompleted;
  final VoidCallback onToggle;
  final EventType? selectedType;
  final ValueChanged<EventType> onTypeSelected;

  @override
  Widget build(BuildContext context) {
    return AccordionShell(
      title: 'Event Type',
      subtitle: 'Choose your event category',
      icon: Icons.category_rounded,
      index: index,
      isExpanded: isExpanded,
      isCompleted: isCompleted,
      onToggle: onToggle,
      child: EventTypeSelector(
        selectedType: selectedType,
        onTypeSelected: (t) {
          onTypeSelected(t);
        },
      ),
    );
  }
}

class AccordionShell extends StatelessWidget {
  const AccordionShell({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.index,
    required this.isExpanded,
    required this.isCompleted,
    required this.onToggle,
    required this.child,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final int index;
  final bool isExpanded;
  final bool isCompleted;
  final VoidCallback onToggle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: isExpanded
              ? [
                  const Color(0xFF3A3A3A),
                  const Color(0xFF2A2A2A),
                  const Color(0xFF1A1A1A)
                ]
              : [
                  const Color(0xFF2A2A2A),
                  const Color(0xFF1A1A1A),
                  const Color(0xFF0A0A0A)
                ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isExpanded
              ? AppColors.primaryOrange.withOpacity(0.3)
              : Colors.white.withOpacity(0.08),
          width: isExpanded ? 2 : 1,
        ),
      ),
      child: Column(children: [
        InkWell(
          onTap: onToggle,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: isCompleted
                      ? AppColors.orangeGradient
                      : LinearGradient(
                          colors: [Colors.grey.shade600, Colors.grey.shade700]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(isCompleted ? Icons.check_rounded : icon,
                    color: Colors.white, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Text(
                        isCompleted ? 'Completed ✓' : subtitle,
                        style: TextStyle(
                          color: isCompleted
                              ? AppColors.primaryOrange
                              : Colors.white.withOpacity(0.7),
                          fontSize: 14,
                          fontWeight:
                              isCompleted ? FontWeight.w500 : FontWeight.normal,
                        ),
                      ),
                    ]),
              ),
              AnimatedRotation(
                turns: isExpanded ? 0.5 : 0,
                duration: const Duration(milliseconds: 250),
                child: Icon(Icons.keyboard_arrow_down_rounded,
                    color: isExpanded
                        ? AppColors.primaryOrange
                        : Colors.white.withOpacity(0.6),
                    size: 28),
              ),
            ]),
          ),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 250),
          child: isExpanded
              ? Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  child: child)
              : const SizedBox.shrink(),
        ),
      ]),
    );
  }
}
