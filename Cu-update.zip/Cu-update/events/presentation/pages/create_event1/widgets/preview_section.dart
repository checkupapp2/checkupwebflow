// lib/features/events/presentation/pages/create_event/widgets/preview_section.dart
import 'package:flutter/material.dart';
import 'package:check_up_app/core/theme/app_colors.dart';
import '../../../../../courts/presentation/widgets/court_image_picker.dart';
import '../../../../domain/models/event_type.dart';
import '../../../widgets/event_preview.dart';
import 'event_type_section.dart';

class PreviewSection extends StatelessWidget {
  const PreviewSection({
    super.key,
    required this.index,
    required this.isExpanded,
    required this.isCompleted,
    required this.onToggle,
    required this.titleCtrl,
    required this.locationCtrl,
    required this.selectedType,
    required this.isEventPrivate,
    required this.onEventPrivacyChanged,
    required this.isFree,
    required this.priceCtrl,
    required this.dateTime,
    required this.previewImageUrls,
    required this.onPreviewImagesChanged,
    required this.ticketTypes,
    required this.isFormComplete,
    required this.onPublish,
  });

  final int index;
  final bool isExpanded;
  final bool isCompleted;
  final VoidCallback onToggle;

  final TextEditingController titleCtrl;
  final TextEditingController locationCtrl;
  final EventType? selectedType;
  final bool isEventPrivate;
  final ValueChanged<bool> onEventPrivacyChanged;

  final bool isFree;
  final TextEditingController priceCtrl;
  final DateTime? dateTime;

  final List<String> previewImageUrls;
  final ValueChanged<List<String>> onPreviewImagesChanged;
  final List<Map<String, dynamic>> ticketTypes;

  final bool Function() isFormComplete;
  final VoidCallback onPublish;

  void _pickImages(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => CourtImagePicker(
        initialImages: previewImageUrls,
        maxImages: 4,
        onImagesSelected: (images) =>
            onPreviewImagesChanged(List<String>.from(images)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AccordionShell(
      title: 'Preview & Publish',
      subtitle: 'Review and publish',
      icon: Icons.preview_rounded,
      index: index,
      isExpanded: isExpanded,
      isCompleted: isCompleted,
      onToggle: onToggle,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // info bar
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.primaryOrange.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border:
                  Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded,
                    color: AppColors.primaryOrange, size: 18),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                      'Review your event details and publish when ready',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w500)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // preview
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4)),
              ],
            ),
            child: EventPreview(
              title: titleCtrl.text.isNotEmpty
                  ? titleCtrl.text
                  : 'Your Event Title',
              dateTime: dateTime,
              location: locationCtrl.text.isNotEmpty
                  ? locationCtrl.text
                  : 'Event Location',
              eventType: selectedType,
              isFree: isFree,
              price: isFree ? null : double.tryParse(priceCtrl.text),
              isPrivate: isEventPrivate,
              ticketTypes: ticketTypes, // ← use real tickets here
              imageUrls: previewImageUrls.isNotEmpty ? previewImageUrls : null,
              onImageTap: () => _pickImages(context),
              imageCount: previewImageUrls.length,
              maxImages: 4,
            ),
          ),
          const SizedBox(height: 24),
          // visibility quick toggle
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            title: Text(isEventPrivate ? 'Private Event' : 'Public Event',
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 14)),
            subtitle: Text(
              isEventPrivate
                  ? 'Only invited people can see and join'
                  : 'Anyone can discover and join this event',
              style:
                  TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12),
            ),
            value: !isEventPrivate,
            onChanged: (v) => onEventPrivacyChanged(!v),
            activeColor: Colors.green,
            inactiveThumbColor: AppColors.primaryOrange,
            inactiveTrackColor: AppColors.primaryOrange.withOpacity(0.3),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
