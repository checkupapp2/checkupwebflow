// lib/features/events/presentation/pages/my_events_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:check_up_app/features/events/domain/models/event_model.dart';
import 'package:check_up_app/features/search/presentation/widgets/common_filter_row.dart';
import 'package:check_up_app/features/events/presentation/pages/host_event_detail_page.dart';
import 'package:check_up_app/features/events/presentation/pages/event_detail_page.dart';
import 'package:check_up_app/features/events/presentation/pages/manage_event_page.dart';
import 'package:check_up_app/features/events/presentation/pages/edit_event_page.dart';

import '../../../../core/widgets/unified_tab_bar.dart';
import '../../../../core/routes/app_router.dart';
import '../../bloc/my_events/my_events_cubit.dart';
import '../../bloc/my_events/my_events_state.dart';
import '../widgets/my_events/calendar_header.dart';
import '../widgets/my_events/events_calendar.dart';
import '../widgets/my_events/event_list.dart';

// Bloc
import '../../data/events_repository.dart';

class MyEventsPage extends StatelessWidget {
  const MyEventsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider<MyEventsCubit>(
      create: (_) => MyEventsCubit(
        repo: EventsRepository(),
        auth: FirebaseAuth.instance,
      )..init(),
      child: const _MyEventsView(),
    );
  }
}

class _MyEventsView extends StatefulWidget {
  const _MyEventsView({Key? key}) : super(key: key);

  @override
  State<_MyEventsView> createState() => _MyEventsViewState();
}

class _MyEventsViewState extends State<_MyEventsView>
    with TickerProviderStateMixin {
  late TabController _tabController; // 0: Attending, 1: Hosting

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ---- Filtering helpers (pure) ----
  List<EventModel> _applyDateAndTimeFilters({
    required List<EventModel> base,
    required DateTime? selectedDate,
    required String
        timeFilter, // Popular, Nearby, Friends, Today, This Week, Future, Past
  }) {
    var list = base;

    if (selectedDate != null) {
      list = list
          .where((e) =>
              e.dateTime.year == selectedDate.year &&
              e.dateTime.month == selectedDate.month &&
              e.dateTime.day == selectedDate.day)
          .toList();
    }

    if (timeFilter != 'Popular' &&
        timeFilter != 'Nearby' &&
        timeFilter != 'Friends') {
      final now = DateTime.now();
      list = list.where((e) {
        switch (timeFilter) {
          case 'Today':
            return e.dateTime.year == now.year &&
                e.dateTime.month == now.month &&
                e.dateTime.day == now.day;
          case 'This Week':
            final weekTo = now.add(const Duration(days: 7));
            return e.dateTime.isAfter(now) && e.dateTime.isBefore(weekTo);
          case 'Future':
            return e.dateTime.isAfter(now);
          case 'Past':
            return e.dateTime.isBefore(now);
          default:
            return true;
        }
      }).toList();
    }

    return list;
  }

  bool _hasEventsOnDate(
    DateTime date, {
    required List<EventModel> attendingToday,
    required List<EventModel> attendingUpcoming,
    required List<EventModel> hostingToday,
    required List<EventModel> hostingUpcoming,
    required List<EventModel> past,
  }) {
    final all = [
      ...attendingToday,
      ...attendingUpcoming,
      ...hostingToday,
      ...hostingUpcoming,
      ...past,
    ];
    return all.any((e) =>
        e.dateTime.year == date.year &&
        e.dateTime.month == date.month &&
        e.dateTime.day == date.day);
  }

  String _fmtDate(DateTime d) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    return '${months[d.month - 1]} ${d.day}, ${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MyEventsCubit, MyEventsState>(
      builder: (context, state) {
        final loading = state.loading;

        // Compose base lists from state
        final attendingAll = [
          ...state.attendingToday,
          ...state.attendingUpcoming,
          if (state.selectedFilter == 'Past') ...state.past,
        ];
        final hostingAll = [
          ...state.hostingToday,
          ...state.hostingUpcoming,
          if (state.selectedFilter == 'Past') ...state.past,
        ];

        // Apply the current filters for counts and display
        final attendingFiltered = _applyDateAndTimeFilters(
          base: attendingAll,
          selectedDate: state.selectedDate,
          timeFilter: state.selectedFilter,
        );
        final hostingFiltered = _applyDateAndTimeFilters(
          base: hostingAll,
          selectedDate: state.selectedDate,
          timeFilter: state.selectedFilter,
        );

        return Scaffold(
          backgroundColor: const Color(0xFF121212),
          appBar: AppBar(
            title: const Text(
              'My Events',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
                fontSize: 20,
                letterSpacing: 0.3,
              ),
            ),
            backgroundColor: const Color(0xFF1E1E1E),
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.notifications_none, color: Colors.white),
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Notifications')),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.settings_outlined, color: Colors.white),
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Settings')),
                ),
              ),
            ],
            bottom: UnifiedTabBar(
              controller: _tabController,
              tabs: [
                UnifiedTab(
                  text: 'ATTENDING',
                  icon: Icons.event,
                  count: attendingFiltered.length,
                ),
                UnifiedTab(
                  text: 'HOSTING',
                  icon: Icons.event_note,
                  count: hostingFiltered.length,
                ),
              ],
            ),
          ),
          body: loading
              ? const Center(
                  child: CircularProgressIndicator(color: Colors.orange),
                )
              : RefreshIndicator(
                  onRefresh: () async {
                    context.read<MyEventsCubit>().refresh();
                  },
                  color: Colors.orange,
                  backgroundColor: Colors.grey[900],
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    child: Column(
                      children: [
                        // Calendar header + grid
                        CalendarHeader(
                          currentMonth: state.currentMonth,
                          expanded: state.calendarExpanded,
                          onToggle: () => context
                              .read<MyEventsCubit>()
                              .toggleCalendarExpanded(),
                          onPrev: () {
                            if (state.calendarExpanded) {
                              context.read<MyEventsCubit>().prevMonth();
                            }
                          },
                          onNext: () {
                            if (state.calendarExpanded) {
                              context.read<MyEventsCubit>().nextMonth();
                            }
                          },
                        ),

                        EventsCalendar(
                          month: state.currentMonth,
                          expanded: state.calendarExpanded,
                          selectedDate: state.selectedDate,
                          hasEventsOn: (d) => _hasEventsOnDate(
                            d,
                            attendingToday: state.attendingToday,
                            attendingUpcoming: state.attendingUpcoming,
                            hostingToday: state.hostingToday,
                            hostingUpcoming: state.hostingUpcoming,
                            past: state.past,
                          ),
                          onSelect: (d) =>
                              context.read<MyEventsCubit>().setSelectedDate(d),
                        ),

                        // Create button
                        Container(
                          margin: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.pushNamed(
                                context,
                                AppRouter.createEventRoute,
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.orange,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(28),
                              ),
                            ),
                            child: const Text(
                              'Create New Event',
                              style: TextStyle(fontWeight: FontWeight.w700),
                            ),
                          ),
                        ),

                        // Filters
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                          child: CommonFilterRow(
                            selectedFilter: state.selectedFilter,
                            onFilterSelected: (f) => context
                                .read<MyEventsCubit>()
                                .setSelectedFilter(f),
                            dropdownOptions: const [
                              'Popular',
                              'Nearby',
                              'Friends'
                            ],
                            regularFilters: const [
                              'Today',
                              'This Week',
                              'Future',
                              'Past'
                            ],
                          ),
                        ),

                        // Tabs content
                        SizedBox(
                          height: 620,
                          child: TabBarView(
                            controller: _tabController,
                            children: [
                              // ATTENDING (you can ignore for now if you want)
                              _EventsSection(
                                title: state.selectedDate == null
                                    ? 'All Events'
                                    : 'Events for ${_fmtDate(state.selectedDate!)}',
                                events: attendingFiltered,
                                isHosting: false,
                                onOpen: (ev) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => EventDetailPage(
                                        eventId: ev.id!,
                                        title: ev.title,
                                        eventType: ev.category,
                                      ),
                                    ),
                                  );
                                },
                                onViewTickets: (ev) {
                                  // wire later if needed
                                },
                              ),
                              // HOSTING (dynamic from Firestore)
                              _EventsSection(
                                title: state.selectedDate == null
                                    ? 'All Hosted Events'
                                    : 'Hosted on ${_fmtDate(state.selectedDate!)}',
                                events: hostingFiltered,
                                isHosting: true,
                                onOpen: (ev) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => HostEventDetailPage(
                                        eventId: ev.id!,
                                        title: ev.title,
                                      ),
                                    ),
                                  );
                                },
                                onEdit: (ev) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => EditEventPage(event: ev),
                                    ),
                                  );
                                },
                                onManage: (ev) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => ManageEventPage(
                                        eventId: ev.id!,
                                        title: ev.title,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
        );
      },
    );
  }
}

/// Thin section wrapper so titles/clear chips match earlier layout.
class _EventsSection extends StatelessWidget {
  final String title;
  final List<EventModel> events;
  final bool isHosting;

  final void Function(EventModel ev)? onOpen; // Card tap
  final void Function(EventModel ev)? onEdit; // Host edit
  final void Function(EventModel ev)? onManage; // Host manage
  final void Function(EventModel ev)? onViewTickets; // Attendee ticket

  const _EventsSection({
    required this.title,
    required this.events,
    required this.isHosting,
    this.onOpen,
    this.onEdit,
    this.onManage,
    this.onViewTickets,
  });

  @override
  Widget build(BuildContext context) {
    if (events.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Text(
            'No $title',
            style: const TextStyle(color: Colors.white70, fontSize: 16),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // Delegates UI and buttons to EventList (existing UI)
          EventList(
            events: events,
            isHosting: isHosting,
            onOpen: onOpen,
            onEdit: onEdit,
            onManage: onManage,
            onViewTickets: onViewTickets,
          ),
        ],
      ),
    );
  }
}
