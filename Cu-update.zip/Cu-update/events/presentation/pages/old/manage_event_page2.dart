// import 'package:flutter/material.dart';
// import 'package:check_up_app/features/events/domain/models/location_model.dart';
// import 'package:check_up_app/features/events/presentation/widgets/enhanced_location_selector.dart';
// import 'package:check_up_app/features/events/presentation/widgets/registration_pricing_form.dart';
// import 'package:check_up_app/features/courts/presentation/widgets/court_image_picker.dart';
// import '../../../../core/theme/app_colors.dart';
// import 'attendee_registration_details_page.dart';
// import 'team_registration_details_page.dart';

// /// A page for managing event details including attendance, tickets, and settings.
// class ManageEventPage extends StatefulWidget {
//   /// The unique identifier for the event.
//   final String? eventId;

//   /// The title of the event.
//   final String? title;

//   /// Creates a [ManageEventPage] instance.
//   const ManageEventPage({
//     Key? key,
//     this.eventId,
//     this.title,
//   }) : super(key: key);

//   @override
//   State<ManageEventPage> createState() => _ManageEventPageState();
// }

// class _ManageEventPageState extends State<ManageEventPage>
//     with TickerProviderStateMixin {
//   // Accordion section tracking
//   int? _expandedSection;
//   late AnimationController _animationController;

//   // Section completion tracking
//   Map<int, bool> _sectionCompletion = {
//     0: true, // Attendance Management
//     1: true, // Basic Information
//     2: true, // Date & Time
//     3: true, // Location
//     4: true, // Pricing & Tickets
//     5: true, // Event Settings
//   };

//   // State variables for filters
//   String _attendanceFilter = 'all';

//   // State variable for expanding requested section
//   bool _isRequestedExpanded = false;

//   // Location state for EnhancedLocationSelector
//   LocationModel? _selectedLocation;
//   bool _isLocationPrivate = false;
//   final TextEditingController _locationController = TextEditingController();

//   // Date & time demo state for manage view (static sample values)
//   DateTime? _selectedStartDateTime =
//       DateTime.now().add(const Duration(days: 5, hours: 18));
//   DateTime? _selectedEndDateTime =
//       DateTime.now().add(const Duration(days: 5, hours: 21));

//   // Pricing & tickets state (mirroring create event page structure)
//   final TextEditingController _capacityController = TextEditingController();
//   bool _isRegistrationOpen = true;

//   List<Map<String, dynamic>> _ticketTypes = [];
//   final TextEditingController _ticketNameController = TextEditingController();
//   final TextEditingController _ticketPriceController = TextEditingController();
//   final TextEditingController _ticketQuantityController =
//       TextEditingController();

//   bool _hasCustomQuestions = false;
//   List<Map<String, dynamic>> _customQuestions = [];
//   final TextEditingController _questionTextController = TextEditingController();
//   final TextEditingController _questionOptionsController =
//       TextEditingController();

//   bool _hasEarlyBirdPricing = false;
//   final TextEditingController _earlyBirdPriceController =
//       TextEditingController();
//   DateTime? _earlyBirdDeadline;

//   bool _requiresWaiver = false;
//   final TextEditingController _waiverTextController = TextEditingController();
//   String? _selectedWaiverTemplate;

//   // Event images for manage preview (up to 4)
//   List<String> _eventImageUrls = [];

//   @override
//   void initState() {
//     super.initState();
//     _animationController = AnimationController(
//       duration: const Duration(milliseconds: 300),
//       vsync: this,
//     );
//     // Start with Attendance Management section expanded
//     _expandedSection = 0;

//     // Pre-fill demo data so manage view looks fully configured

//     // Sample location matching West 4th Street Tournament
//     _selectedLocation = const LocationModel(
//       id: 'west4th',
//       name: 'West 4th Street Courts',
//       address: '6th Avenue & West 4th Street',
//       city: 'New York',
//       state: 'NY',
//       zipCode: '10014',
//       venueType: 'court',
//       isPopular: true,
//       description: 'Iconic outdoor streetball courts in the West Village.',
//     );
//     _locationController.text = _selectedLocation!.name;

//     // Sample capacity and tickets
//     _capacityController.text = '120';
//     _ticketTypes = [
//       {
//         'name': 'General Admission',
//         'description': 'Standard entry with access to all tournament games.',
//         'price': 25.0,
//         'quantity': 80,
//         'isExpanded': false,
//       },
//       {
//         'name': 'VIP Courtside',
//         'description':
//             'Courtside seating, player tunnel access, and VIP lounge.',
//         'price': 60.0,
//         'quantity': 20,
//         'isExpanded': false,
//       },
//       {
//         'name': 'Student Ticket',
//         'description': 'Discounted entry for students with valid ID.',
//         'price': 15.0,
//         'quantity': 20,
//         'isExpanded': false,
//       },
//     ];

//     // Example waiver text placeholder
//     _waiverTextController.text =
//         'By registering for this event, you acknowledge the risks of participating in basketball activities and agree to the event waiver terms.';
//   }

//   @override
//   void dispose() {
//     _animationController.dispose();
//     _locationController.dispose();
//     _capacityController.dispose();
//     _ticketNameController.dispose();
//     _ticketPriceController.dispose();
//     _ticketQuantityController.dispose();
//     _questionTextController.dispose();
//     _questionOptionsController.dispose();
//     _earlyBirdPriceController.dispose();
//     _waiverTextController.dispose();
//     super.dispose();
//   }

//   void _handleManageEventImageTap() {
//     showDialog(
//       context: context,
//       builder: (context) => CourtImagePicker(
//         initialImages: _eventImageUrls,
//         maxImages: 4,
//         onImagesSelected: (images) {
//           setState(() {
//             _eventImageUrls = List<String>.from(images);
//           });
//         },
//       ),
//     );
//   }

//   Widget _buildBody() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(16),
//       child: Column(
//         children: [
//           const SizedBox(height: 8),
//           Text(
//             'Manage attendance, tickets, and event settings',
//             style: TextStyle(
//               color: Colors.white.withOpacity(0.7),
//               fontSize: 16,
//             ),
//             textAlign: TextAlign.center,
//           ),
//           const SizedBox(height: 24),
//           // Accordion sections
//           _buildAccordionSection(
//             index: 0,
//             title: 'Attendance Management',
//             subtitle: 'View and manage event attendees',
//             icon: Icons.people_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 1,
//             title: 'Basic Information',
//             subtitle: 'Manage ticket types and pricing',
//             icon: Icons.info_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 2,
//             title: 'Date & Time',
//             subtitle: 'Configure event settings',
//             icon: Icons.schedule_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 3,
//             title: 'Location',
//             subtitle: 'Manage event location',
//             icon: Icons.location_on_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 4,
//             title: 'Pricing & Tickets',
//             subtitle: 'Manage tickets and pricing',
//             icon: Icons.confirmation_number_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 5,
//             title: 'Event Settings',
//             subtitle: 'Configure event preferences',
//             icon: Icons.settings_rounded,
//           ),
//           const SizedBox(height: 100), // Extra space for scrolling
//         ],
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.primaryBlack,
//       appBar: AppBar(
//         backgroundColor: AppColors.primaryBlack,
//         elevation: 0,
//         leading: IconButton(
//           icon: const Icon(
//             Icons.arrow_back_ios_new_rounded,
//             color: Colors.white,
//             size: 20,
//           ),
//           onPressed: () => Navigator.of(context).pop(),
//         ),
//         title: Text(
//           'Manage ${widget.title ?? 'Event'}',
//           style: const TextStyle(
//             color: Colors.white,
//             fontSize: 18,
//             fontWeight: FontWeight.w600,
//           ),
//         ),
//         centerTitle: true,
//       ),
//       body: _buildBody(),
//     );
//   }

//   // Build accordion section
//   Widget _buildAccordionSection({
//     required int index,
//     required String title,
//     required String subtitle,
//     required IconData icon,
//   }) {
//     final bool isExpanded = _expandedSection == index;
//     final bool isCompleted = _sectionCompletion[index] ?? false;

//     return AnimatedContainer(
//       duration: const Duration(milliseconds: 300),
//       margin: const EdgeInsets.symmetric(vertical: 4),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: isExpanded
//               ? [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                 ]
//               : [
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//         ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(
//           color: isExpanded
//               ? AppColors.primaryOrange.withOpacity(0.3)
//               : Colors.white.withOpacity(0.08),
//           width: isExpanded ? 2 : 1,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: isExpanded
//                 ? AppColors.primaryOrange.withOpacity(0.2)
//                 : Colors.black.withOpacity(0.3),
//             blurRadius: isExpanded ? 12 : 6,
//             offset: const Offset(0, 4),
//           ),
//         ],
//       ),
//       child: Column(
//         children: [
//           // Header
//           Material(
//             color: Colors.transparent,
//             child: InkWell(
//               onTap: () {
//                 setState(() {
//                   _expandedSection = isExpanded ? null : index;
//                 });
//               },
//               borderRadius: BorderRadius.circular(16),
//               child: Padding(
//                 padding: const EdgeInsets.all(20),
//                 child: Row(
//                   children: [
//                     // Icon
//                     Container(
//                       width: 48,
//                       height: 48,
//                       decoration: BoxDecoration(
//                         gradient: isCompleted
//                             ? AppColors.orangeGradient
//                             : LinearGradient(
//                                 colors: [
//                                   Colors.grey.shade600,
//                                   Colors.grey.shade700,
//                                 ],
//                               ),
//                         borderRadius: BorderRadius.circular(12),
//                         boxShadow: [
//                           BoxShadow(
//                             color: isCompleted
//                                 ? AppColors.primaryOrange.withOpacity(0.3)
//                                 : Colors.black.withOpacity(0.2),
//                             blurRadius: 8,
//                             offset: const Offset(0, 2),
//                           ),
//                         ],
//                       ),
//                       child: Icon(
//                         isCompleted ? Icons.check_rounded : icon,
//                         color: Colors.white,
//                         size: 24,
//                       ),
//                     ),
//                     const SizedBox(width: 16),
//                     // Title and subtitle
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             title,
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 18,
//                               fontWeight: FontWeight.w600,
//                             ),
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             isCompleted ? 'Completed ✓' : subtitle,
//                             style: TextStyle(
//                               color: isCompleted
//                                   ? AppColors.primaryOrange
//                                   : Colors.white.withOpacity(0.7),
//                               fontSize: 14,
//                               fontWeight: isCompleted
//                                   ? FontWeight.w500
//                                   : FontWeight.normal,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     // Expand/collapse arrow
//                     AnimatedRotation(
//                       turns: isExpanded ? 0.5 : 0,
//                       duration: const Duration(milliseconds: 300),
//                       child: Icon(
//                         Icons.keyboard_arrow_down_rounded,
//                         color: isExpanded
//                             ? AppColors.primaryOrange
//                             : Colors.white.withOpacity(0.6),
//                         size: 28,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//           // Content
//           AnimatedSize(
//             duration: const Duration(milliseconds: 300),
//             child: isExpanded
//                 ? Container(
//                     width: double.infinity,
//                     padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
//                     child: _buildSectionContent(index),
//                   )
//                 : const SizedBox.shrink(),
//           ),
//         ],
//       ),
//     );
//   }

//   // Build content for each section
//   Widget _buildSectionContent(int index) {
//     switch (index) {
//       case 0:
//         return _buildAttendanceContent();
//       case 1:
//         return _buildBasicInfoContent();
//       case 2:
//         return _buildDateTimeContent();
//       case 3:
//         return _buildLocationContent();
//       case 4:
//         return _buildTicketsContent();
//       case 5:
//         return _buildSettingsContent();
//       default:
//         return const SizedBox.shrink();
//     }
//   }

//   // Modern Attendance content with cleaner design
//   Widget _buildAttendanceContent() {
//     // Sample attendee data (mix of individuals and teams)
//     final List<Map<String, dynamic>> attendees = [
//       // Individual attendees
//       {
//         'name': 'Michael Jordan',
//         'email': 'mjordan@example.com',
//         'status': 'joined',
//         'ticketType': 'VIP',
//         'profileImage': 'https://randomuser.me/api/portraits/men/32.jpg',
//         'checkedIn': true,
//         'isRegistered': true,
//         'joinedDate': 'Nov 10, 2024',
//         'type': 'individual',
//       },
//       {
//         'name': 'LeBron James',
//         'email': 'ljames@example.com',
//         'status': 'joined',
//         'ticketType': 'Regular',
//         'profileImage': 'https://randomuser.me/api/portraits/men/42.jpg',
//         'checkedIn': false,
//         'isRegistered': true,
//         'joinedDate': 'Nov 12, 2024',
//         'type': 'individual',
//       },
//       // Team entries
//       {
//         'name': 'Lakers Elite',
//         'email': 'contact@lakerselite.com',
//         'status': 'requested',
//         'ticketType': 'Team',
//         'profileImage': null,
//         'checkedIn': false,
//         'isRegistered': true,
//         'requestedDate': 'Nov 15, 2024',
//         'type': 'team',
//         'teamSize': 8,
//         'captain': 'John Smith',
//         'captainPhone': '+1 (555) 123-4567',
//       },
//       {
//         'name': 'Warriors Squad',
//         'email': 'info@warriorssquad.com',
//         'status': 'requested',
//         'ticketType': 'Team',
//         'profileImage': null,
//         'checkedIn': false,
//         'isRegistered': true,
//         'requestedDate': 'Nov 16, 2024',
//         'type': 'team',
//         'teamSize': 10,
//         'captain': 'Mike Johnson',
//         'captainPhone': '+1 (555) 987-6543',
//       },
//       {
//         'name': 'Bulls United',
//         'email': 'team@bullsunited.org',
//         'status': 'joined',
//         'ticketType': 'Team',
//         'profileImage': null,
//         'checkedIn': true,
//         'isRegistered': true,
//         'joinedDate': 'Nov 12, 2024',
//         'type': 'team',
//         'teamSize': 12,
//         'captain': 'Sarah Wilson',
//         'captainPhone': '+1 (555) 456-7890',
//       },
//       // More individual attendees
//       {
//         'name': 'Stephen Curry',
//         'email': 'scurry@example.com',
//         'status': 'joined',
//         'ticketType': 'VIP',
//         'profileImage': 'https://randomuser.me/api/portraits/men/45.jpg',
//         'checkedIn': true,
//         'isRegistered': false,
//         'joinedDate': 'Nov 14, 2024',
//         'type': 'individual',
//       },
//       {
//         'name': 'Kevin Durant',
//         'email': 'kdurant@example.com',
//         'status': 'invited',
//         'ticketType': 'VIP',
//         'profileImage': 'https://randomuser.me/api/portraits/men/50.jpg',
//         'checkedIn': false,
//         'isRegistered': true,
//         'invitedDate': 'Nov 8, 2024',
//         'type': 'individual',
//       },
//     ];

//     // Counts for stats
//     int joinedCount = attendees.where((a) => a['status'] == 'joined').length;
//     int invitedCount = attendees.where((a) => a['status'] == 'invited').length;
//     int requestedCount =
//         attendees.where((a) => a['status'] == 'requested').length;
//     int checkedInCount = attendees.where((a) => a['checkedIn'] == true).length;
//     int totalCount = attendees.length;

//     return StatefulBuilder(
//       builder: (BuildContext context, StateSetter setFilterState) {
//         // Filter the attendees based on current filter
//         List<Map<String, dynamic>> filteredAttendees =
//             attendees.where((attendee) {
//           return _attendanceFilter == 'all' ||
//               attendee['status'] == _attendanceFilter;
//         }).toList();

//         void updateFilter(String filter) {
//           setFilterState(() {
//             _attendanceFilter = filter;
//           });
//         }

//         return Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // Compact Stats Overview
//             _buildModernStatsOverview(totalCount, joinedCount, invitedCount,
//                 requestedCount, checkedInCount),

//             const SizedBox(height: 12),

//             // Compact Search Bar
//             _buildModernSearchBar(),

//             const SizedBox(height: 12),

//             // Compact Filter Tabs
//             _buildModernFilterTabs(totalCount, joinedCount, invitedCount,
//                 requestedCount, updateFilter),

//             const SizedBox(height: 12),

//             // Compact Attendee List
//             _buildModernAttendeeList(
//                 filteredAttendees, joinedCount, invitedCount, requestedCount),
//           ],
//         );
//       },
//     );
//   }

//   // Compact Stats Overview with black/orange theme
//   Widget _buildModernStatsOverview(
//       int total, int joined, int invited, int requested, int checkedIn) {
//     return Container(
//       padding: const EdgeInsets.all(12),
//       margin: const EdgeInsets.symmetric(horizontal: 16),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             Colors.grey[900]!,
//             Colors.black,
//           ],
//         ),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
//       ),
//       child: Row(
//         children: [
//           Expanded(child: _buildCompactStatItem('Total', total, Icons.people)),
//           Container(width: 1, height: 30, color: Colors.grey[700]),
//           Expanded(
//               child:
//                   _buildCompactStatItem('Joined', joined, Icons.check_circle)),
//           Container(width: 1, height: 30, color: Colors.grey[700]),
//           Expanded(
//               child: _buildCompactStatItem('Invited', invited, Icons.mail)),
//           Container(width: 1, height: 30, color: Colors.grey[700]),
//           Expanded(
//               child: _buildCompactStatItem(
//                   'Requests', requested, Icons.person_add)),
//         ],
//       ),
//     );
//   }

//   Widget _buildCompactStatItem(String label, int count, IconData icon) {
//     return Column(
//       children: [
//         Icon(icon, color: AppColors.primaryOrange, size: 18),
//         const SizedBox(height: 4),
//         Text(
//           count.toString(),
//           style: const TextStyle(
//             color: Colors.white,
//             fontSize: 16,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//         Text(
//           label,
//           style: TextStyle(
//             color: Colors.grey[400],
//             fontSize: 11,
//             fontWeight: FontWeight.w500,
//           ),
//         ),
//       ],
//     );
//   }

//   // Compact Search Bar
//   Widget _buildModernSearchBar() {
//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 16),
//       padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//       decoration: BoxDecoration(
//         color: Colors.grey[850],
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: Colors.grey[700]!),
//       ),
//       child: Row(
//         children: [
//           Icon(Icons.search, color: Colors.grey[400], size: 20),
//           const SizedBox(width: 12),
//           Expanded(
//             child: TextField(
//               style: const TextStyle(color: Colors.white, fontSize: 14),
//               decoration: InputDecoration(
//                 hintText: 'Search attendees...',
//                 hintStyle: TextStyle(color: Colors.grey[500], fontSize: 14),
//                 border: InputBorder.none,
//                 contentPadding: EdgeInsets.zero,
//                 isDense: true,
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   // Modern Filter Tabs
//   Widget _buildModernFilterTabs(int total, int joined, int invited,
//       int requested, Function(String) updateFilter) {
//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 16),
//       padding: const EdgeInsets.all(4),
//       decoration: BoxDecoration(
//         color: Colors.grey[900],
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: Colors.grey[700]!),
//       ),
//       child: Row(
//         children: [
//           Expanded(
//               child: _buildModernFilterTab('All', 'all', total, updateFilter)),
//           Expanded(
//               child: _buildModernFilterTab(
//                   'Joined', 'joined', joined, updateFilter)),
//           Expanded(
//               child: _buildModernFilterTab(
//                   'Invited', 'invited', invited, updateFilter)),
//           Expanded(
//               child: _buildModernFilterTab(
//                   'Requests', 'requested', requested, updateFilter)),
//         ],
//       ),
//     );
//   }

//   Widget _buildModernFilterTab(
//       String label, String value, int count, Function(String) updateFilter) {
//     final isSelected = _attendanceFilter == value;
//     return GestureDetector(
//       onTap: () => updateFilter(value),
//       child: AnimatedContainer(
//         duration: const Duration(milliseconds: 200),
//         padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
//         decoration: BoxDecoration(
//           gradient: isSelected ? AppColors.orangeGradient : null,
//           color: isSelected ? null : Colors.transparent,
//           borderRadius: BorderRadius.circular(12),
//           boxShadow: isSelected
//               ? [
//                   BoxShadow(
//                     color: AppColors.primaryOrange.withOpacity(0.3),
//                     blurRadius: 8,
//                     offset: const Offset(0, 2),
//                   ),
//                 ]
//               : null,
//         ),
//         child: Column(
//           children: [
//             Text(
//               count.toString(),
//               style: TextStyle(
//                 color: isSelected ? Colors.white : Colors.grey[400],
//                 fontSize: 18,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             const SizedBox(height: 2),
//             Text(
//               label,
//               style: TextStyle(
//                 color: isSelected ? Colors.white : Colors.grey[500],
//                 fontSize: 12,
//                 fontWeight: FontWeight.w500,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   // Modern Attendee List
//   Widget _buildModernAttendeeList(List<Map<String, dynamic>> filteredAttendees,
//       int joined, int invited, int requested) {
//     if (filteredAttendees.isEmpty) {
//       return _buildEmptyState();
//     }

//     // Group attendees by status for better organization
//     final groupedAttendees = <String, List<Map<String, dynamic>>>{};
//     for (final attendee in filteredAttendees) {
//       final status = attendee['status'] as String;
//       groupedAttendees.putIfAbsent(status, () => []).add(attendee);
//     }

//     return Column(
//       children: [
//         // Show requested attendees first (if any)
//         if (groupedAttendees.containsKey('requested') &&
//             groupedAttendees['requested']!.isNotEmpty) ...[
//           _buildModernSectionHeader(
//               'Pending Requests',
//               groupedAttendees['requested']!.length,
//               Icons.person_add,
//               AppColors.primaryOrange),
//           ...groupedAttendees['requested']!
//               .map((attendee) => _buildModernAttendeeCard(attendee))
//               .toList(),
//           const SizedBox(height: 16),
//         ],

//         // Show joined attendees
//         if (groupedAttendees.containsKey('joined') &&
//             groupedAttendees['joined']!.isNotEmpty) ...[
//           _buildModernSectionHeader(
//               'Confirmed Attendees',
//               groupedAttendees['joined']!.length,
//               Icons.check_circle,
//               AppColors.primaryOrange),
//           ...groupedAttendees['joined']!
//               .map((attendee) => _buildModernAttendeeCard(attendee))
//               .toList(),
//           const SizedBox(height: 16),
//         ],

//         // Show invited attendees
//         if (groupedAttendees.containsKey('invited') &&
//             groupedAttendees['invited']!.isNotEmpty) ...[
//           _buildModernSectionHeader(
//               'Invited',
//               groupedAttendees['invited']!.length,
//               Icons.mail,
//               AppColors.primaryOrange),
//           ...groupedAttendees['invited']!
//               .map((attendee) => _buildModernAttendeeCard(attendee))
//               .toList(),
//         ],
//       ],
//     );
//   }

//   Widget _buildModernSectionHeader(
//       String title, int count, IconData icon, Color color) {
//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             Colors.grey[800]!,
//             Colors.black,
//           ],
//         ),
//         borderRadius: BorderRadius.circular(8),
//         border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
//       ),
//       child: Row(
//         children: [
//           Icon(icon, color: AppColors.primaryOrange, size: 16),
//           const SizedBox(width: 8),
//           Text(
//             title,
//             style: const TextStyle(
//               color: Colors.white,
//               fontSize: 14,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const Spacer(),
//           Container(
//             padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
//             decoration: BoxDecoration(
//               gradient: AppColors.orangeGradient,
//               borderRadius: BorderRadius.circular(8),
//             ),
//             child: Text(
//               count.toString(),
//               style: const TextStyle(
//                 color: Colors.white,
//                 fontSize: 11,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildModernAttendeeCard(Map<String, dynamic> attendee) {
//     Color statusColor = AppColors.primaryOrange; // All statuses use orange
//     IconData statusIcon;
//     bool isTeam = attendee['type'] == 'team';

//     switch (attendee['status']) {
//       case 'joined':
//         statusIcon = Icons.check_circle;
//         break;
//       case 'invited':
//         statusIcon = Icons.mail;
//         break;
//       case 'requested':
//         statusIcon = Icons.person_add;
//         break;
//       default:
//         statusIcon = Icons.info;
//     }

//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [Colors.grey[850]!, Colors.black],
//         ),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: AppColors.primaryOrange.withOpacity(0.2)),
//       ),
//       child: Material(
//         color: Colors.transparent,
//         child: InkWell(
//           borderRadius: BorderRadius.circular(12),
//           onTap: () {
//             // Handle team vs individual attendee navigation
//             if (isTeam) {
//               // For teams, navigate to the team details page
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => TeamRegistrationDetailsPage(
//                     team: attendee,
//                     eventTitle: widget.title ?? 'Event',
//                   ),
//                 ),
//               );
//             } else {
//               // For individuals, navigate to the detailed attendee page
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => AttendeeRegistrationDetailsPage(
//                     attendee: attendee,
//                     eventTitle: widget.title ?? 'Event',
//                   ),
//                 ),
//               );
//             }
//           },
//           child: Padding(
//             padding: const EdgeInsets.all(16),
//             child: Row(
//               children: [
//                 // Compact profile section (individual or team)
//                 Stack(
//                   children: [
//                     Container(
//                       width: 40,
//                       height: 40,
//                       decoration: BoxDecoration(
//                         shape: BoxShape.circle,
//                         border: Border.all(color: statusColor, width: 2),
//                         image: !isTeam &&
//                                 attendee['isRegistered'] &&
//                                 attendee['profileImage'] != null
//                             ? DecorationImage(
//                                 image: NetworkImage(attendee['profileImage']),
//                                 fit: BoxFit.cover,
//                               )
//                             : null,
//                         color: isTeam
//                             ? AppColors.primaryOrange.withOpacity(0.2)
//                             : (attendee['isRegistered']
//                                 ? null
//                                 : Colors.amber.withOpacity(0.2)),
//                       ),
//                       child: isTeam
//                           ? Icon(Icons.groups,
//                               color: AppColors.primaryOrange, size: 20)
//                           : (attendee['isRegistered'] &&
//                                   attendee['profileImage'] != null
//                               ? null
//                               : const Icon(Icons.person_outline,
//                                   color: Colors.amber, size: 20)),
//                     ),
//                     Positioned(
//                       bottom: 0,
//                       right: 0,
//                       child: Container(
//                         width: 12,
//                         height: 12,
//                         decoration: BoxDecoration(
//                           color: statusColor,
//                           shape: BoxShape.circle,
//                           border: Border.all(color: Colors.black, width: 1),
//                         ),
//                         child: Icon(statusIcon, color: Colors.white, size: 6),
//                       ),
//                     ),
//                   ],
//                 ),

//                 const SizedBox(width: 12),

//                 // Compact info section (individual or team)
//                 Expanded(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Row(
//                         children: [
//                           Expanded(
//                             child: Text(
//                               attendee['name'] ?? 'Unknown User',
//                               style: const TextStyle(
//                                 color: Colors.white,
//                                 fontSize: 14,
//                                 fontWeight: FontWeight.w600,
//                               ),
//                               overflow: TextOverflow.ellipsis,
//                             ),
//                           ),
//                           if (isTeam) ...[
//                             Container(
//                               padding: const EdgeInsets.symmetric(
//                                   horizontal: 4, vertical: 1),
//                               decoration: BoxDecoration(
//                                 color: AppColors.primaryOrange.withOpacity(0.2),
//                                 borderRadius: BorderRadius.circular(6),
//                                 border: Border.all(
//                                     color: AppColors.primaryOrange
//                                         .withOpacity(0.5)),
//                               ),
//                               child: const Text(
//                                 'TEAM',
//                                 style: TextStyle(
//                                   color: AppColors.primaryOrange,
//                                   fontSize: 8,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ),
//                           ] else if (!attendee['isRegistered']) ...[
//                             Container(
//                               padding: const EdgeInsets.symmetric(
//                                   horizontal: 4, vertical: 1),
//                               decoration: BoxDecoration(
//                                 color: Colors.amber.withOpacity(0.2),
//                                 borderRadius: BorderRadius.circular(6),
//                                 border: Border.all(
//                                     color: Colors.amber.withOpacity(0.5)),
//                               ),
//                               child: const Text(
//                                 'GUEST',
//                                 style: TextStyle(
//                                   color: Colors.amber,
//                                   fontSize: 8,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ],
//                       ),
//                       const SizedBox(height: 4),
//                       Text(
//                         isTeam
//                             ? 'Captain: ${attendee['captain'] ?? 'Unknown'} • ${attendee['teamSize'] ?? 0} players'
//                             : attendee['email'] ?? 'No email',
//                         style: TextStyle(
//                           color: Colors.grey[400],
//                           fontSize: 12,
//                         ),
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                       const SizedBox(height: 8),
//                       Row(
//                         children: [
//                           Container(
//                             padding: const EdgeInsets.symmetric(
//                                 horizontal: 6, vertical: 2),
//                             decoration: BoxDecoration(
//                               color: statusColor.withOpacity(0.2),
//                               borderRadius: BorderRadius.circular(8),
//                               border: Border.all(
//                                   color: statusColor.withOpacity(0.5)),
//                             ),
//                             child: Text(
//                               (attendee['status'] ?? 'unknown')
//                                   .toString()
//                                   .toUpperCase(),
//                               style: TextStyle(
//                                 color: statusColor,
//                                 fontSize: 9,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                           ),
//                           const SizedBox(width: 8),
//                           Container(
//                             padding: const EdgeInsets.symmetric(
//                                 horizontal: 6, vertical: 2),
//                             decoration: BoxDecoration(
//                               color: isTeam
//                                   ? AppColors.primaryOrange.withOpacity(0.2)
//                                   : ((attendee['ticketType'] ?? 'Regular') ==
//                                           'VIP'
//                                       ? Colors.amber.withOpacity(0.2)
//                                       : Colors.blue.withOpacity(0.2)),
//                               borderRadius: BorderRadius.circular(8),
//                               border: Border.all(
//                                 color: isTeam
//                                     ? AppColors.primaryOrange.withOpacity(0.5)
//                                     : ((attendee['ticketType'] ?? 'Regular') ==
//                                             'VIP'
//                                         ? Colors.amber.withOpacity(0.5)
//                                         : Colors.blue.withOpacity(0.5)),
//                               ),
//                             ),
//                             child: Text(
//                               attendee['ticketType'] ?? 'Regular',
//                               style: TextStyle(
//                                 color: isTeam
//                                     ? AppColors.primaryOrange
//                                     : ((attendee['ticketType'] ?? 'Regular') ==
//                                             'VIP'
//                                         ? Colors.amber
//                                         : Colors.blue),
//                                 fontSize: 9,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                           ),
//                           if (attendee['checkedIn'] == true) ...[
//                             const SizedBox(width: 8),
//                             Container(
//                               padding: const EdgeInsets.symmetric(
//                                   horizontal: 6, vertical: 2),
//                               decoration: BoxDecoration(
//                                 color: AppColors.primaryOrange.withOpacity(0.2),
//                                 borderRadius: BorderRadius.circular(8),
//                                 border: Border.all(
//                                     color: AppColors.primaryOrange
//                                         .withOpacity(0.5)),
//                               ),
//                               child: Text(
//                                 'IN',
//                                 style: TextStyle(
//                                   color: AppColors.primaryOrange,
//                                   fontSize: 9,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),

//                 // Compact action button
//                 if (attendee['status'] == 'requested') ...[
//                   Row(
//                     children: [
//                       _buildQuickActionButton(
//                           Icons.check, AppColors.primaryOrange, () {}),
//                       const SizedBox(width: 6),
//                       _buildQuickActionButton(Icons.close,
//                           AppColors.primaryOrange.withOpacity(0.7), () {}),
//                     ],
//                   ),
//                 ] else if (attendee['status'] == 'joined' &&
//                     !attendee['checkedIn']) ...[
//                   _buildQuickActionButton(
//                       Icons.login, AppColors.primaryOrange, () {}),
//                 ] else ...[
//                   Icon(Icons.chevron_right,
//                       color: AppColors.primaryOrange.withOpacity(0.6),
//                       size: 20),
//                 ],
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildQuickActionButton(
//       IconData icon, Color color, VoidCallback onTap) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         width: 36,
//         height: 36,
//         decoration: BoxDecoration(
//           color: color.withOpacity(0.2),
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: color.withOpacity(0.5)),
//         ),
//         child: Icon(icon, color: color, size: 20),
//       ),
//     );
//   }

//   Widget _buildEmptyState() {
//     return Container(
//       margin: const EdgeInsets.all(32),
//       padding: const EdgeInsets.all(32),
//       decoration: BoxDecoration(
//         color: Colors.grey[850],
//         borderRadius: BorderRadius.circular(20),
//         border: Border.all(color: Colors.grey[700]!),
//       ),
//       child: Column(
//         children: [
//           Icon(Icons.people_outline, color: Colors.grey[500], size: 64),
//           const SizedBox(height: 16),
//           Text(
//             'No attendees found',
//             style: TextStyle(
//               color: Colors.grey[400],
//               fontSize: 18,
//               fontWeight: FontWeight.w600,
//             ),
//           ),
//           const SizedBox(height: 8),
//           Text(
//             'Try adjusting your filters or search terms',
//             style: TextStyle(
//               color: Colors.grey[500],
//               fontSize: 14,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   // Basic Information content
//   Widget _buildBasicInfoContent() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         // Event Images Card
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: const LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 Color(0xFF3A3A3A),
//                 Color(0xFF2A2A2A),
//                 Color(0xFF1A1A1A),
//               ],
//             ),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.white.withOpacity(0.08),
//               width: 0.5,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 32,
//                     height: 32,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: const Icon(
//                       Icons.image_rounded,
//                       color: Colors.white,
//                       size: 16,
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   const Text(
//                     'Event Images',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                   const Spacer(),
//                   Text(
//                     '${_eventImageUrls.length}/4',
//                     style: TextStyle(
//                       color: Colors.white.withOpacity(0.6),
//                       fontSize: 12,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               AspectRatio(
//                 aspectRatio: 1.0,
//                 child: GestureDetector(
//                   onTap: _handleManageEventImageTap,
//                   child: ClipRRect(
//                     borderRadius: BorderRadius.circular(12),
//                     child: _eventImageUrls.isNotEmpty
//                         ? PageView.builder(
//                             itemCount: _eventImageUrls.length,
//                             itemBuilder: (context, index) {
//                               final url = _eventImageUrls[index];
//                               return Image.network(
//                                 url,
//                                 fit: BoxFit.cover,
//                               );
//                             },
//                           )
//                         : Container(
//                             decoration: BoxDecoration(
//                               color: AppColors.darkGray,
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                             child: Column(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               children: [
//                                 Icon(
//                                   Icons.image_outlined,
//                                   color: Colors.white.withOpacity(0.5),
//                                   size: 40,
//                                 ),
//                                 const SizedBox(height: 8),
//                                 const Text(
//                                   'Tap to add event images',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 13,
//                                     fontWeight: FontWeight.w500,
//                                   ),
//                                 ),
//                                 const SizedBox(height: 4),
//                                 Text(
//                                   '${_eventImageUrls.length}/4 selected',
//                                   style: TextStyle(
//                                     color: Colors.white.withOpacity(0.6),
//                                     fontSize: 11,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),
//         // Event Title Card
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: const LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 Color(0xFF3A3A3A),
//                 Color(0xFF2A2A2A),
//                 Color(0xFF1A1A1A),
//               ],
//             ),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.white.withOpacity(0.08),
//               width: 0.5,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 32,
//                     height: 32,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: const Icon(
//                       Icons.edit_rounded,
//                       color: Colors.white,
//                       size: 16,
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   const Text(
//                     'Event Title',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               TextField(
//                 controller: TextEditingController(
//                     text: widget.title ?? 'West 4th Street Tournament'),
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 16,
//                 ),
//                 decoration: InputDecoration(
//                   hintText: 'Enter event title...',
//                   hintStyle: TextStyle(
//                     color: Colors.white.withOpacity(0.5),
//                     fontSize: 14,
//                   ),
//                   filled: true,
//                   fillColor: Colors.white.withOpacity(0.08),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12),
//                     borderSide: BorderSide.none,
//                   ),
//                   focusedBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12),
//                     borderSide: BorderSide(
//                       color: AppColors.primaryOrange,
//                       width: 2,
//                     ),
//                   ),
//                   contentPadding: const EdgeInsets.all(12),
//                 ),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),
//         // Description Card
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: const LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 Color(0xFF3A3A3A),
//                 Color(0xFF2A2A2A),
//                 Color(0xFF1A1A1A),
//               ],
//             ),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.white.withOpacity(0.08),
//               width: 0.5,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 32,
//                     height: 32,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: const Icon(
//                       Icons.description_rounded,
//                       color: Colors.white,
//                       size: 16,
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   const Text(
//                     'Event Description',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               TextField(
//                 controller: TextEditingController(
//                   text:
//                       'Streetball-style tournament under the lights at West 4th Street. High energy games, live DJ, and prizes for the champions.',
//                 ),
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 14,
//                   height: 1.4,
//                 ),
//                 maxLines: 4,
//                 decoration: InputDecoration(
//                   hintText: 'Add a short description...',
//                   hintStyle: TextStyle(
//                     color: Colors.white.withOpacity(0.5),
//                     fontSize: 13,
//                   ),
//                   filled: true,
//                   fillColor: Colors.white.withOpacity(0.08),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12),
//                     borderSide: BorderSide.none,
//                   ),
//                   focusedBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12),
//                     borderSide: BorderSide(
//                       color: AppColors.primaryOrange,
//                       width: 2,
//                     ),
//                   ),
//                   contentPadding: const EdgeInsets.all(12),
//                 ),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),
//         // Skill level and visibility card
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: const LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 Color(0xFF3A3A3A),
//                 Color(0xFF2A2A2A),
//                 Color(0xFF1A1A1A),
//               ],
//             ),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.white.withOpacity(0.08),
//               width: 0.5,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 32,
//                     height: 32,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: const Icon(
//                       Icons.sports_basketball_rounded,
//                       color: Colors.white,
//                       size: 16,
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   const Text(
//                     'Skill level & visibility',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               Row(
//                 children: [
//                   Container(
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(20),
//                     ),
//                     child: const Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(
//                           Icons.bolt_rounded,
//                           color: Colors.white,
//                           size: 14,
//                         ),
//                         SizedBox(width: 6),
//                         Text(
//                           'Advanced / Pro',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 12,
//                             fontWeight: FontWeight.w600,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   const SizedBox(width: 8),
//                   Container(
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.06),
//                       borderRadius: BorderRadius.circular(20),
//                       border: Border.all(
//                         color: Colors.white.withOpacity(0.1),
//                       ),
//                     ),
//                     child: Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(
//                           Icons.lock_open_rounded,
//                           color: Colors.white.withOpacity(0.8),
//                           size: 14,
//                         ),
//                         const SizedBox(width: 6),
//                         Text(
//                           'Public event',
//                           style: TextStyle(
//                             color: Colors.white.withOpacity(0.9),
//                             fontSize: 12,
//                             fontWeight: FontWeight.w500,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               Text(
//                 'Players of all positions welcome. Competitive run aimed at experienced hoopers.',
//                 style: TextStyle(
//                   color: Colors.white.withOpacity(0.7),
//                   fontSize: 13,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }

//   // Helper method to build section headers - mobile optimized
//   Widget _buildSectionHeader(String title, int count) {
//     return Padding(
//       padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Row(
//             children: [
//               Container(
//                 width: 4,
//                 height: 20,
//                 decoration: BoxDecoration(
//                   gradient: const LinearGradient(
//                     begin: Alignment.topCenter,
//                     end: Alignment.bottomCenter,
//                     colors: [
//                       Colors.orange,
//                       Colors.deepOrange,
//                     ],
//                   ),
//                   borderRadius: BorderRadius.circular(4),
//                 ),
//               ),
//               const SizedBox(width: 8),
//               Text(
//                 title,
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 16,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ],
//           ),
//           Container(
//             padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   Colors.orange.withOpacity(0.7),
//                   Colors.deepOrange.withOpacity(0.7),
//                 ],
//               ),
//               borderRadius: BorderRadius.circular(12),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.orange.withOpacity(0.3),
//                   blurRadius: 4,
//                   offset: const Offset(0, 2),
//                 ),
//               ],
//             ),
//             child: Text(
//               count.toString(),
//               style: const TextStyle(
//                 color: Colors.white,
//                 fontWeight: FontWeight.bold,
//                 fontSize: 12,
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   // Helper method to build requested attendee cards with expand/collapse functionality
//   List<Widget> _buildRequestedAttendeeCards(
//       List<Map<String, dynamic>> requestedAttendees) {
//     List<Widget> cards = [];

//     // Show first 2 cards always
//     int cardsToShow = _isRequestedExpanded ? requestedAttendees.length : 2;
//     cardsToShow = cardsToShow > requestedAttendees.length
//         ? requestedAttendees.length
//         : cardsToShow;

//     // Add the visible cards
//     for (int i = 0; i < cardsToShow; i++) {
//       cards.add(_buildAttendeeCard(requestedAttendees[i]));
//     }

//     // Add expand/collapse button if there are more than 2 cards
//     if (requestedAttendees.length > 2) {
//       cards.add(_buildExpandCollapseButton(requestedAttendees.length));
//     }

//     return cards;
//   }

//   // Helper method to build expand/collapse button
//   Widget _buildExpandCollapseButton(int totalCount) {
//     final remainingCount = totalCount - 2;

//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//       child: Material(
//         color: Colors.transparent,
//         child: InkWell(
//           borderRadius: BorderRadius.circular(16),
//           onTap: () {
//             setState(() {
//               _isRequestedExpanded = !_isRequestedExpanded;
//             });
//           },
//           child: Container(
//             padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   Colors.grey[800]!,
//                   Colors.grey[900]!,
//                 ],
//               ),
//               borderRadius: BorderRadius.circular(16),
//               border: Border.all(
//                 color: Colors.orange.withOpacity(0.3),
//                 width: 1,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.3),
//                   blurRadius: 8,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Icon(
//                   _isRequestedExpanded ? Icons.expand_less : Icons.expand_more,
//                   color: Colors.orange,
//                   size: 24,
//                 ),
//                 const SizedBox(width: 8),
//                 Text(
//                   _isRequestedExpanded
//                       ? 'Show Less'
//                       : 'Show $remainingCount More Request${remainingCount > 1 ? 's' : ''}',
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                     fontWeight: FontWeight.w600,
//                     letterSpacing: 0.5,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   // Helper method to build attendee cards with different designs for registered users vs guests
//   Widget _buildAttendeeCard(Map<String, dynamic> attendee) {
//     // Define colors based on status
//     Color statusColor;
//     IconData statusIcon;

//     switch (attendee['status']) {
//       case 'joined':
//         statusColor = Colors.green;
//         statusIcon = Icons.check_circle;
//         break;
//       case 'invited':
//         statusColor = Colors.orange;
//         statusIcon = Icons.mail;
//         break;
//       case 'requested':
//         statusColor = Colors.purple;
//         statusIcon = Icons.person_add;
//         break;
//       default:
//         statusColor = Colors.blue;
//         statusIcon = Icons.info;
//     }

//     // Define ticket type colors
//     Color ticketColor =
//         attendee['ticketType'] == 'VIP' ? Colors.amber : Colors.blue;

//     // Use different card designs based on user type
//     if (attendee['isRegistered'] == true) {
//       // REGISTERED USER CARD - with profile image and username
//       return _buildRegisteredUserCard(
//           attendee, statusColor, statusIcon, ticketColor);
//     } else {
//       // GUEST CARD - simpler design
//       return _buildGuestCard(attendee, statusColor, statusIcon, ticketColor);
//     }
//   }

//   // Simplified card design for registered app users
//   Widget _buildRegisteredUserCard(Map<String, dynamic> attendee,
//       Color statusColor, IconData statusIcon, Color ticketColor) {
//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             Colors.grey[850]!,
//             Colors.black,
//           ],
//         ),
//         borderRadius: BorderRadius.circular(16),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.4),
//             blurRadius: 8,
//             spreadRadius: 0,
//             offset: const Offset(0, 4),
//           ),
//         ],
//         border: Border.all(
//           color: statusColor.withOpacity(0.3),
//           width: 1,
//         ),
//       ),
//       child: Material(
//         color: Colors.transparent,
//         child: InkWell(
//           borderRadius: BorderRadius.circular(16),
//           onTap: () {
//             // Navigate to attendee registration details page
//             Navigator.push(
//               context,
//               MaterialPageRoute(
//                 builder: (context) => AttendeeRegistrationDetailsPage(
//                   attendee: attendee,
//                   eventTitle: widget.title,
//                 ),
//               ),
//             );
//           },
//           child: Padding(
//             padding: const EdgeInsets.all(16),
//             child: Column(
//               children: [
//                 // Main info row
//                 Row(
//                   children: [
//                     // Profile image with status indicator
//                     Stack(
//                       children: [
//                         Container(
//                           width: 48,
//                           height: 48,
//                           decoration: BoxDecoration(
//                             shape: BoxShape.circle,
//                             border: Border.all(
//                               color: statusColor.withOpacity(0.6),
//                               width: 2,
//                             ),
//                             image: DecorationImage(
//                               image: NetworkImage(attendee['profileImage']),
//                               fit: BoxFit.cover,
//                             ),
//                           ),
//                         ),
//                         // Status indicator dot
//                         Positioned(
//                           bottom: 0,
//                           right: 0,
//                           child: Container(
//                             width: 14,
//                             height: 14,
//                             decoration: BoxDecoration(
//                               color: statusColor,
//                               shape: BoxShape.circle,
//                               border: Border.all(color: Colors.black, width: 2),
//                             ),
//                             child: Icon(
//                               statusIcon,
//                               color: Colors.white,
//                               size: 8,
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(width: 12),

//                     // Name and email
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             attendee['name'],
//                             style: const TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.w600,
//                               fontSize: 16,
//                             ),
//                             maxLines: 1,
//                             overflow: TextOverflow.ellipsis,
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             attendee['email'],
//                             style: TextStyle(
//                               color: Colors.grey[400],
//                               fontSize: 13,
//                             ),
//                             maxLines: 1,
//                             overflow: TextOverflow.ellipsis,
//                           ),
//                         ],
//                       ),
//                     ),

//                     // Ticket type badge
//                     Container(
//                       padding: const EdgeInsets.symmetric(
//                           horizontal: 8, vertical: 4),
//                       decoration: BoxDecoration(
//                         color: ticketColor.withOpacity(0.2),
//                         borderRadius: BorderRadius.circular(12),
//                         border: Border.all(
//                           color: ticketColor.withOpacity(0.5),
//                           width: 1,
//                         ),
//                       ),
//                       child: Text(
//                         attendee['ticketType'],
//                         style: TextStyle(
//                           color: ticketColor,
//                           fontSize: 11,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),

//                 // Action buttons (if needed)
//                 if (attendee['status'] == 'requested') ...[
//                   const SizedBox(height: 12),
//                   _buildActionButton(attendee),
//                 ] else if (attendee['status'] == 'joined' &&
//                     !attendee['checkedIn']) ...[
//                   const SizedBox(height: 12),
//                   Container(
//                     width: double.infinity,
//                     child: ElevatedButton.icon(
//                       onPressed: () {
//                         // Check in user
//                       },
//                       icon: const Icon(Icons.login, size: 16),
//                       label: const Text('Check In'),
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.green[600],
//                         foregroundColor: Colors.white,
//                         padding: const EdgeInsets.symmetric(vertical: 8),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(12),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   // Simplified card design for guest users (non-app users)
//   Widget _buildGuestCard(Map<String, dynamic> attendee, Color statusColor,
//       IconData statusIcon, Color ticketColor) {
//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             Colors.grey[850]!,
//             Colors.black,
//           ],
//         ),
//         borderRadius: BorderRadius.circular(16),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.4),
//             blurRadius: 8,
//             spreadRadius: 0,
//             offset: const Offset(0, 4),
//           ),
//         ],
//         border: Border.all(
//           color: statusColor.withOpacity(0.3),
//           width: 1,
//         ),
//       ),
//       child: Material(
//         color: Colors.transparent,
//         child: InkWell(
//           borderRadius: BorderRadius.circular(16),
//           onTap: () {
//             // Navigate to attendee registration details page
//             Navigator.push(
//               context,
//               MaterialPageRoute(
//                 builder: (context) => AttendeeRegistrationDetailsPage(
//                   attendee: attendee,
//                   eventTitle: widget.title,
//                 ),
//               ),
//             );
//           },
//           child: Padding(
//             padding: const EdgeInsets.all(16),
//             child: Column(
//               children: [
//                 // Main info row
//                 Row(
//                   children: [
//                     // Guest icon with status indicator
//                     Stack(
//                       children: [
//                         Container(
//                           width: 48,
//                           height: 48,
//                           decoration: BoxDecoration(
//                             color: Colors.amber.withOpacity(0.2),
//                             shape: BoxShape.circle,
//                             border: Border.all(
//                               color: statusColor.withOpacity(0.6),
//                               width: 2,
//                             ),
//                           ),
//                           child: const Icon(
//                             Icons.person_outline,
//                             color: Colors.amber,
//                             size: 24,
//                           ),
//                         ),
//                         // Status indicator dot
//                         Positioned(
//                           bottom: 0,
//                           right: 0,
//                           child: Container(
//                             width: 14,
//                             height: 14,
//                             decoration: BoxDecoration(
//                               color: statusColor,
//                               shape: BoxShape.circle,
//                               border: Border.all(color: Colors.black, width: 2),
//                             ),
//                             child: Icon(
//                               statusIcon,
//                               color: Colors.white,
//                               size: 8,
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(width: 12),

//                     // Name and email
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: Text(
//                                   attendee['name'],
//                                   style: const TextStyle(
//                                     color: Colors.white,
//                                     fontWeight: FontWeight.w600,
//                                     fontSize: 16,
//                                   ),
//                                   maxLines: 1,
//                                   overflow: TextOverflow.ellipsis,
//                                 ),
//                               ),
//                               // Guest badge
//                               Container(
//                                 padding: const EdgeInsets.symmetric(
//                                     horizontal: 6, vertical: 2),
//                                 decoration: BoxDecoration(
//                                   color: Colors.amber.withOpacity(0.2),
//                                   borderRadius: BorderRadius.circular(8),
//                                   border: Border.all(
//                                     color: Colors.amber.withOpacity(0.5),
//                                     width: 1,
//                                   ),
//                                 ),
//                                 child: const Text(
//                                   'GUEST',
//                                   style: TextStyle(
//                                     color: Colors.amber,
//                                     fontSize: 10,
//                                     fontWeight: FontWeight.w700,
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             attendee['email'],
//                             style: TextStyle(
//                               color: Colors.grey[400],
//                               fontSize: 13,
//                             ),
//                             maxLines: 1,
//                             overflow: TextOverflow.ellipsis,
//                           ),
//                         ],
//                       ),
//                     ),

//                     // Ticket type badge
//                     Container(
//                       padding: const EdgeInsets.symmetric(
//                           horizontal: 8, vertical: 4),
//                       decoration: BoxDecoration(
//                         color: ticketColor.withOpacity(0.2),
//                         borderRadius: BorderRadius.circular(12),
//                         border: Border.all(
//                           color: ticketColor.withOpacity(0.5),
//                           width: 1,
//                         ),
//                       ),
//                       child: Text(
//                         attendee['ticketType'],
//                         style: TextStyle(
//                           color: ticketColor,
//                           fontSize: 11,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),

//                 // Action buttons (if needed)
//                 if (attendee['status'] == 'requested') ...[
//                   const SizedBox(height: 12),
//                   _buildActionButton(attendee),
//                 ] else if (attendee['status'] == 'joined' &&
//                     !attendee['checkedIn']) ...[
//                   const SizedBox(height: 12),
//                   Container(
//                     width: double.infinity,
//                     child: ElevatedButton.icon(
//                       onPressed: () {
//                         // Check in user
//                       },
//                       icon: const Icon(Icons.login, size: 16),
//                       label: const Text('Check In'),
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.green[600],
//                         foregroundColor: Colors.white,
//                         padding: const EdgeInsets.symmetric(vertical: 8),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(12),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   // Helper method to build badges
//   Widget _buildBadge(
//       {required IconData icon, required String label, required Color color}) {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             color.withOpacity(0.7),
//             color.withOpacity(0.4),
//           ],
//         ),
//         borderRadius: BorderRadius.circular(12),
//         boxShadow: [
//           BoxShadow(
//             color: color.withOpacity(0.2),
//             blurRadius: 4,
//             offset: const Offset(0, 2),
//           ),
//         ],
//       ),
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           Icon(
//             icon,
//             color: Colors.white,
//             size: 12,
//           ),
//           const SizedBox(width: 4),
//           Text(
//             label,
//             style: const TextStyle(
//               color: Colors.white,
//               fontSize: 12,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   // Helper method to build action buttons based on attendee status - mobile optimized
//   Widget _buildActionButton(Map<String, dynamic> attendee) {
//     switch (attendee['status']) {
//       case 'joined':
//         return Material(
//           color: Colors.transparent,
//           borderRadius: BorderRadius.circular(20),
//           child: InkWell(
//             borderRadius: BorderRadius.circular(20),
//             onTap: () {
//               // Show options for joined users
//             },
//             child: Padding(
//               padding: const EdgeInsets.all(8),
//               child: const Icon(Icons.more_vert, color: Colors.white, size: 20),
//             ),
//           ),
//         );
//       case 'invited':
//         return Material(
//           color: Colors.transparent,
//           borderRadius: BorderRadius.circular(20),
//           child: Ink(
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   Colors.orange,
//                   Colors.deepOrange,
//                 ],
//               ),
//               borderRadius: BorderRadius.circular(20),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.orange.withOpacity(0.3),
//                   blurRadius: 4,
//                   offset: const Offset(0, 2),
//                 ),
//               ],
//             ),
//             child: InkWell(
//               borderRadius: BorderRadius.circular(20),
//               onTap: () {
//                 // Resend invitation
//               },
//               splashColor: Colors.white.withOpacity(0.2),
//               child: Padding(
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                 child: Row(
//                   mainAxisSize: MainAxisSize.min,
//                   children: const [
//                     Icon(Icons.send, color: Colors.white, size: 16),
//                     SizedBox(width: 4),
//                     Text(
//                       'Resend',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 12,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         );
//       case 'requested':
//         return Row(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Material(
//               color: Colors.transparent,
//               borderRadius: BorderRadius.circular(16),
//               child: Ink(
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     begin: Alignment.topLeft,
//                     end: Alignment.bottomRight,
//                     colors: [
//                       Colors.green[400]!,
//                       Colors.green[600]!,
//                     ],
//                   ),
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.green.withOpacity(0.4),
//                       blurRadius: 8,
//                       spreadRadius: 0,
//                       offset: const Offset(0, 3),
//                     ),
//                   ],
//                   border: Border.all(
//                     color: Colors.green.withOpacity(0.3),
//                     width: 1,
//                   ),
//                 ),
//                 child: InkWell(
//                   borderRadius: BorderRadius.circular(16),
//                   onTap: () {
//                     // Accept request
//                   },
//                   splashColor: Colors.white.withOpacity(0.2),
//                   child: const Padding(
//                     padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//                     child: Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(Icons.check, color: Colors.white, size: 20),
//                         SizedBox(width: 8),
//                         Text(
//                           'Accept',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontWeight: FontWeight.w700,
//                             fontSize: 14,
//                             letterSpacing: 0.5,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             const SizedBox(width: 12),
//             Material(
//               color: Colors.transparent,
//               borderRadius: BorderRadius.circular(16),
//               child: Ink(
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     begin: Alignment.topLeft,
//                     end: Alignment.bottomRight,
//                     colors: [
//                       Colors.red[400]!,
//                       Colors.red[600]!,
//                     ],
//                   ),
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.red.withOpacity(0.4),
//                       blurRadius: 8,
//                       spreadRadius: 0,
//                       offset: const Offset(0, 3),
//                     ),
//                   ],
//                   border: Border.all(
//                     color: Colors.red.withOpacity(0.3),
//                     width: 1,
//                   ),
//                 ),
//                 child: InkWell(
//                   borderRadius: BorderRadius.circular(16),
//                   onTap: () {
//                     // Decline request
//                   },
//                   splashColor: Colors.white.withOpacity(0.2),
//                   child: const Padding(
//                     padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//                     child: Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(Icons.close, color: Colors.white, size: 20),
//                         SizedBox(width: 8),
//                         Icon(Icons.close, color: Colors.white, size: 18),
//                         SizedBox(width: 6),
//                         Text(
//                           'Decline',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontWeight: FontWeight.bold,
//                             fontSize: 14,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         );
//       default:
//         return const SizedBox.shrink();
//     }
//   }

//   // Date time content
//   Widget _buildDateTimeContent() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         // Combined Date section (mirrors create event page style)
//         _buildCombinedDateTimeSection(
//           title: 'Event Date',
//           icon: Icons.calendar_today,
//           startDateTime: _selectedStartDateTime,
//           endDateTime: _selectedEndDateTime,
//           isDateSection: true,
//         ),
//         const SizedBox(height: 16),
//         // Combined Time section
//         _buildCombinedDateTimeSection(
//           title: 'Event Time',
//           icon: Icons.access_time,
//           startDateTime: _selectedStartDateTime,
//           endDateTime: _selectedEndDateTime,
//           isDateSection: false,
//         ),
//       ],
//     );
//   }

//   Widget _buildCombinedDateTimeSection({
//     required String title,
//     required IconData icon,
//     required DateTime? startDateTime,
//     required DateTime? endDateTime,
//     required bool isDateSection,
//   }) {
//     final bool hasStartSelection = startDateTime != null;
//     final bool hasEndSelection = endDateTime != null;
//     final bool hasAnySelection = hasStartSelection || hasEndSelection;

//     return Container(
//       width: double.infinity,
//       decoration: BoxDecoration(
//         gradient: hasAnySelection
//             ? LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   Colors.orange.shade400.withOpacity(0.2),
//                   Colors.deepOrange.shade600.withOpacity(0.2),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                 ],
//                 stops: const [0.0, 0.15, 0.5, 1.0],
//               )
//             : const LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   Color(0xFF3A3A3A),
//                   Color(0xFF2A2A2A),
//                   Color(0xFF1A1A1A),
//                   Color(0xFF0A0A0A),
//                 ],
//                 stops: [0.0, 0.3, 0.7, 1.0],
//               ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(
//           color: hasAnySelection
//               ? Colors.orange.withOpacity(0.3)
//               : Colors.white.withOpacity(0.08),
//           width: hasAnySelection ? 1.5 : 0.5,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: hasAnySelection
//                 ? Colors.orange.withOpacity(0.15)
//                 : Colors.white.withOpacity(0.03),
//             blurRadius: hasAnySelection ? 8 : 1,
//             offset: Offset(0, hasAnySelection ? 3 : 1),
//           ),
//           BoxShadow(
//             color: Colors.black.withOpacity(0.4),
//             blurRadius: 12,
//             offset: const Offset(0, 4),
//           ),
//         ],
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(20),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(
//               children: [
//                 Container(
//                   width: 32,
//                   height: 32,
//                   decoration: BoxDecoration(
//                     gradient: hasAnySelection
//                         ? LinearGradient(
//                             colors: [
//                               Colors.orange.shade400,
//                               Colors.deepOrange.shade600,
//                             ],
//                           )
//                         : LinearGradient(
//                             colors: [
//                               Colors.grey.shade600,
//                               Colors.grey.shade700,
//                             ],
//                           ),
//                     borderRadius: BorderRadius.circular(8),
//                     boxShadow: [
//                       BoxShadow(
//                         color: hasAnySelection
//                             ? Colors.orange.withOpacity(0.3)
//                             : Colors.black.withOpacity(0.2),
//                         blurRadius: 4,
//                         offset: const Offset(0, 2),
//                       ),
//                     ],
//                   ),
//                   child: Icon(
//                     icon,
//                     color: Colors.white,
//                     size: 16,
//                   ),
//                 ),
//                 const SizedBox(width: 12),
//                 Text(
//                   title,
//                   style: TextStyle(
//                     color: hasAnySelection
//                         ? Colors.white
//                         : Colors.white.withOpacity(0.9),
//                     fontSize: 18,
//                     fontWeight: FontWeight.w700,
//                     letterSpacing: 0.3,
//                   ),
//                 ),
//               ],
//             ),
//             const SizedBox(height: 16),
//             Row(
//               children: [
//                 // Start
//                 Expanded(
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: hasStartSelection
//                           ? Colors.orange.withOpacity(0.1)
//                           : Colors.white.withOpacity(0.05),
//                       borderRadius: BorderRadius.circular(12),
//                       border: Border.all(
//                         color: hasStartSelection
//                             ? Colors.orange.withOpacity(0.3)
//                             : Colors.white.withOpacity(0.1),
//                         width: 1,
//                       ),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(
//                           'Start',
//                           style: TextStyle(
//                             color: Colors.white.withOpacity(0.7),
//                             fontSize: 12,
//                             fontWeight: FontWeight.w500,
//                           ),
//                         ),
//                         const SizedBox(height: 4),
//                         Text(
//                           hasStartSelection
//                               ? (isDateSection
//                                   ? '${_getMonthName(startDateTime!.month)} ${startDateTime!.day}'
//                                   : _formatTime12Hour(startDateTime!))
//                               : (isDateSection ? 'Select date' : 'Select time'),
//                           style: TextStyle(
//                             color: hasStartSelection
//                                 ? Colors.white
//                                 : Colors.white.withOpacity(0.6),
//                             fontSize: hasStartSelection ? 16 : 14,
//                             fontWeight: hasStartSelection
//                                 ? FontWeight.w600
//                                 : FontWeight.normal,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//                 const SizedBox(width: 12),
//                 // End
//                 Expanded(
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: hasEndSelection
//                           ? Colors.orange.withOpacity(0.1)
//                           : Colors.white.withOpacity(0.05),
//                       borderRadius: BorderRadius.circular(12),
//                       border: Border.all(
//                         color: hasEndSelection
//                             ? Colors.orange.withOpacity(0.3)
//                             : Colors.white.withOpacity(0.1),
//                         width: 1,
//                       ),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(
//                           'End',
//                           style: TextStyle(
//                             color: Colors.white.withOpacity(0.7),
//                             fontSize: 12,
//                             fontWeight: FontWeight.w500,
//                           ),
//                         ),
//                         const SizedBox(height: 4),
//                         Text(
//                           hasEndSelection
//                               ? (isDateSection
//                                   ? '${_getMonthName(endDateTime!.month)} ${endDateTime!.day}'
//                                   : _formatTime12Hour(endDateTime!))
//                               : (isDateSection ? 'Select date' : 'Select time'),
//                           style: TextStyle(
//                             color: hasEndSelection
//                                 ? Colors.white
//                                 : Colors.white.withOpacity(0.6),
//                             fontSize: hasEndSelection ? 16 : 14,
//                             fontWeight: hasEndSelection
//                                 ? FontWeight.w600
//                                 : FontWeight.normal,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   String _getMonthName(int month) {
//     const months = [
//       'Jan',
//       'Feb',
//       'Mar',
//       'Apr',
//       'May',
//       'Jun',
//       'Jul',
//       'Aug',
//       'Sep',
//       'Oct',
//       'Nov',
//       'Dec',
//     ];
//     return months[(month - 1).clamp(0, months.length - 1)];
//   }

//   String _formatTime12Hour(DateTime dateTime) {
//     int hour = dateTime.hour;
//     final minutes = dateTime.minute.toString().padLeft(2, '0');
//     final period = hour >= 12 ? 'PM' : 'AM';
//     hour = hour % 12;
//     if (hour == 0) hour = 12;
//     return '$hour:$minutes $period';
//   }

//   // Location content
//   Widget _buildLocationContent() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         EnhancedLocationSelector(
//           selectedLocation: _selectedLocation,
//           isLocationPrivate: _isLocationPrivate,
//           onLocationSelected: (location) {
//             setState(() {
//               _selectedLocation = location;
//             });
//           },
//           onPrivacyChanged: (value) {
//             setState(() {
//               _isLocationPrivate = value;
//             });
//           },
//           locationController: _locationController,
//         ),
//       ],
//     );
//   }

//   // Tickets content
//   Widget _buildTicketsContent() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         RegistrationPricingForm(
//           capacityController: _capacityController,
//           isRegistrationOpen: _isRegistrationOpen,
//           onRegistrationStatusChanged: (value) {
//             setState(() {
//               _isRegistrationOpen = value;
//             });
//           },
//           ticketTypes: _ticketTypes,
//           onTicketTypesUpdated: (tickets) {
//             setState(() {
//               _ticketTypes = tickets;
//             });
//           },
//           ticketNameController: _ticketNameController,
//           ticketPriceController: _ticketPriceController,
//           ticketQuantityController: _ticketQuantityController,
//           hasCustomQuestions: _hasCustomQuestions,
//           onCustomQuestionsChanged: (value) {
//             setState(() {
//               _hasCustomQuestions = value;
//             });
//           },
//           customQuestions: _customQuestions,
//           onCustomQuestionsUpdated: (questions) {
//             setState(() {
//               _customQuestions = questions;
//             });
//           },
//           questionTextController: _questionTextController,
//           questionOptionsController: _questionOptionsController,
//           hasEarlyBirdPricing: _hasEarlyBirdPricing,
//           onEarlyBirdPricingChanged: (value) {
//             setState(() {
//               _hasEarlyBirdPricing = value;
//             });
//           },
//           earlyBirdPriceController: _earlyBirdPriceController,
//           earlyBirdDeadline: _earlyBirdDeadline,
//           onEarlyBirdDeadlineSelected: (date) {
//             setState(() {
//               _earlyBirdDeadline = date;
//             });
//           },
//           requiresWaiver: _requiresWaiver,
//           onWaiverRequirementChanged: (value) {
//             setState(() {
//               _requiresWaiver = value;
//             });
//           },
//           waiverTextController: _waiverTextController,
//           selectedWaiverTemplate: _selectedWaiverTemplate,
//           onWaiverTemplateSelected: (template) {
//             setState(() {
//               _selectedWaiverTemplate = template;
//             });
//           },
//         ),
//       ],
//     );
//   }

//   // Settings content
//   Widget _buildSettingsContent() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         // Registration & check-in settings
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: const LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 Color(0xFF3A3A3A),
//                 Color(0xFF2A2A2A),
//                 Color(0xFF1A1A1A),
//               ],
//             ),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.white.withOpacity(0.08),
//               width: 0.5,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 32,
//                     height: 32,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: const Icon(
//                       Icons.event_available_rounded,
//                       color: Colors.white,
//                       size: 16,
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   const Text(
//                     'Registration & check-in',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               SwitchListTile(
//                 contentPadding: EdgeInsets.zero,
//                 title: const Text(
//                   'Allow new registrations',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 14,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//                 subtitle: Text(
//                   'Players can still join this event from the app.',
//                   style: TextStyle(
//                     color: Colors.white.withOpacity(0.7),
//                     fontSize: 12,
//                   ),
//                 ),
//                 value: true,
//                 onChanged: (value) {
//                   // Toggle registrations
//                 },
//                 activeColor: AppColors.primaryOrange,
//                 inactiveThumbColor: Colors.white,
//                 inactiveTrackColor: Colors.white.withOpacity(0.3),
//               ),
//               const Divider(color: Colors.white24, height: 24),
//               SwitchListTile(
//                 contentPadding: EdgeInsets.zero,
//                 title: const Text(
//                   'Enable QR code check-in',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 14,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//                 subtitle: Text(
//                   'Scan tickets at the gate to mark attendees as checked in.',
//                   style: TextStyle(
//                     color: Colors.white.withOpacity(0.7),
//                     fontSize: 12,
//                   ),
//                 ),
//                 value: true,
//                 onChanged: (value) {
//                   // Toggle QR check-in
//                 },
//                 activeColor: AppColors.primaryOrange,
//                 inactiveThumbColor: Colors.white,
//                 inactiveTrackColor: Colors.white.withOpacity(0.3),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),
//         // Visibility & privacy settings
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: const LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 Color(0xFF3A3A3A),
//                 Color(0xFF2A2A2A),
//                 Color(0xFF1A1A1A),
//               ],
//             ),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.white.withOpacity(0.08),
//               width: 0.5,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 32,
//                     height: 32,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: const Icon(
//                       Icons.visibility_rounded,
//                       color: Colors.white,
//                       size: 16,
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   const Text(
//                     'Visibility & privacy',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               SwitchListTile(
//                 contentPadding: EdgeInsets.zero,
//                 title: const Text(
//                   'Show event in Discover',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 14,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//                 subtitle: Text(
//                   'Event will appear in local Discover and search results.',
//                   style: TextStyle(
//                     color: Colors.white.withOpacity(0.7),
//                     fontSize: 12,
//                   ),
//                 ),
//                 value: true,
//                 onChanged: (value) {
//                   // Toggle discover visibility
//                 },
//                 activeColor: AppColors.primaryOrange,
//                 inactiveThumbColor: Colors.white,
//                 inactiveTrackColor: Colors.white.withOpacity(0.3),
//               ),
//               SwitchListTile(
//                 contentPadding: EdgeInsets.zero,
//                 title: const Text(
//                   'Hide exact location until approved',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 14,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//                 subtitle: Text(
//                   'Only approved players see the full address.',
//                   style: TextStyle(
//                     color: Colors.white.withOpacity(0.7),
//                     fontSize: 12,
//                   ),
//                 ),
//                 value: false,
//                 onChanged: (value) {
//                   // Toggle location visibility
//                 },
//                 activeColor: AppColors.primaryOrange,
//                 inactiveThumbColor: Colors.white,
//                 inactiveTrackColor: Colors.white.withOpacity(0.3),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),
//         // Danger zone / event status
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             color: const Color(0xFF2A1515),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.red.withOpacity(0.5),
//               width: 0.8,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 28,
//                     height: 28,
//                     decoration: BoxDecoration(
//                       color: Colors.red.withOpacity(0.2),
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: const Icon(
//                       Icons.warning_rounded,
//                       color: Colors.redAccent,
//                       size: 18,
//                     ),
//                   ),
//                   const SizedBox(width: 10),
//                   const Text(
//                     'Danger zone',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 15,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               Text(
//                 'Close registrations, pause the event, or cancel it entirely.',
//                 style: TextStyle(
//                   color: Colors.white.withOpacity(0.75),
//                   fontSize: 13,
//                 ),
//               ),
//               const SizedBox(height: 12),
//               Row(
//                 children: [
//                   Expanded(
//                     child: OutlinedButton(
//                       onPressed: () {
//                         // Close registrations
//                       },
//                       style: OutlinedButton.styleFrom(
//                         side: BorderSide(
//                           color: Colors.orangeAccent.withOpacity(0.8),
//                         ),
//                         foregroundColor: Colors.orangeAccent,
//                         padding: const EdgeInsets.symmetric(vertical: 10),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(10),
//                         ),
//                       ),
//                       child: const Text(
//                         'Close registrations',
//                         style: TextStyle(
//                           fontSize: 13,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   Expanded(
//                     child: ElevatedButton(
//                       onPressed: () {
//                         // Cancel event
//                       },
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.redAccent,
//                         foregroundColor: Colors.white,
//                         padding: const EdgeInsets.symmetric(vertical: 10),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(10),
//                         ),
//                       ),
//                       child: const Text(
//                         'Cancel event',
//                         style: TextStyle(
//                           fontSize: 13,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }
// }
