// import 'package:flutter/material.dart';
// import 'package:check_up_app/core/theme/app_colors.dart';
// import 'package:check_up_app/features/events/domain/models/event_type.dart';
// import 'package:check_up_app/features/events/domain/models/location_model.dart';
// import 'package:check_up_app/features/events/domain/models/event_model.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_type_selector.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_preview.dart';
// import 'package:check_up_app/features/events/presentation/widgets/enhanced_location_selector.dart';
// import 'package:check_up_app/features/events/presentation/widgets/registration_pricing_form.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_type_specific_forms.dart';
// import 'package:check_up_app/features/search/domain/models/team_model.dart';

// /// A page for editing events with the same flow as create event
// class EditEventPage extends StatefulWidget {
//   final EventModel event;
  
//   /// Creates an [EditEventPage] instance
//   const EditEventPage({Key? key, required this.event}) : super(key: key);

//   @override
//   State<EditEventPage> createState() => _EditEventPageState();
// }

// class _EditEventPageState extends State<EditEventPage> {
//   // Step tracking
//   int _currentStep = 0;

//   // Event type selection
//   EventType? _selectedEventType;

//   // Common form controllers
//   final TextEditingController _titleController = TextEditingController();
//   final TextEditingController _descriptionController = TextEditingController();
//   DateTime? _selectedDateTime;
//   final TextEditingController _locationController = TextEditingController();
//   LocationModel? _selectedLocation;
//   bool _isLocationPrivate = false;
//   bool _isEventPrivate = false;
//   bool _isFree = true;
//   final TextEditingController _priceController = TextEditingController();
//   String? _selectedSkillLevel;

//   // Pickup Run fields
//   final _maxPlayersController = TextEditingController();

//   // Tournament fields
//   final _numberOfTeamsController = TextEditingController();
//   String? _selectedFormat;
//   final _prizePoolController = TextEditingController();
//   DateTime? _registrationDeadline;
//   bool _wantToAddTeams = false;
//   List<TeamModel> _selectedTeams = [];
//   bool _useManualTeamInput = false;

//   // League Games fields
//   String? _selectedSeason;
//   String? _selectedGameType;

//   // One-on-One fields
//   final _player1Controller = TextEditingController();
//   final _player2Controller = TextEditingController();
//   String? _selectedGameFormat;

//   // Donation fields
//   final _donationGoalController = TextEditingController();
//   final _beneficiaryController = TextEditingController();
//   bool _hasTaxReceipts = false;

//   // Registration & Pricing fields
//   final _capacityController = TextEditingController();
//   bool _isRegistrationOpen = true;

//   // Ticket types
//   List<Map<String, dynamic>> _ticketTypes = [];
//   final _ticketNameController = TextEditingController();
//   final _ticketPriceController = TextEditingController();
//   final _ticketQuantityController = TextEditingController();

//   // Legacy pricing fields
//   bool _hasEarlyBirdPricing = false;
//   final _earlyBirdPriceController = TextEditingController();
//   DateTime? _earlyBirdDeadline;

//   // Waiver fields
//   bool _requiresWaiver = false;
//   final _waiverTextController = TextEditingController();
//   String? _selectedWaiverTemplate;

//   // Custom registration questions
//   bool _hasCustomQuestions = false;
//   List<Map<String, dynamic>> _customQuestions = [];
//   final _questionTextController = TextEditingController();
//   final _questionOptionsController = TextEditingController();

//   // Event type-specific form data
//   Map<String, dynamic> _eventTypeSpecificData = {};

//   @override
//   void initState() {
//     super.initState();
//     _populateFieldsFromEvent();
//   }

//   void _populateFieldsFromEvent() {
//     final event = widget.event;
    
//     // Populate basic fields
//     _titleController.text = event.title;
//     _descriptionController.text = event.description;
//     _selectedDateTime = event.dateTime;
//     _locationController.text = event.location;
//     _isEventPrivate = false; // Default, could be extended
//     _isFree = event.isFree;
    
//     if (!event.isFree && event.price != null) {
//       _priceController.text = event.price.toString();
//     }

//     // Set event type based on the event model type
//     if (event is PickupRunEvent) {
//       _selectedEventType = EventType.pickupRun;
//       _maxPlayersController.text = event.maxPlayers.toString();
//       _selectedSkillLevel = event.skillLevel;
//     } else if (event is TournamentEvent) {
//       _selectedEventType = EventType.tournament;
//       _numberOfTeamsController.text = event.numberOfTeams.toString();
//       _selectedFormat = event.format;
//       _prizePoolController.text = event.prizePool.toString();
//       _registrationDeadline = event.registrationDeadline;
//     } else if (event is DonationEvent) {
//       _selectedEventType = EventType.donationBased;
//       _donationGoalController.text = event.donationGoal.toString();
//       _beneficiaryController.text = event.beneficiary;
//       _hasTaxReceipts = event.hasTaxReceipts;
//     }
//   }

//   @override
//   void dispose() {
//     _titleController.dispose();
//     _descriptionController.dispose();
//     _locationController.dispose();
//     _priceController.dispose();
//     _maxPlayersController.dispose();
//     _numberOfTeamsController.dispose();
//     _prizePoolController.dispose();
//     _player1Controller.dispose();
//     _player2Controller.dispose();
//     _donationGoalController.dispose();
//     _beneficiaryController.dispose();
//     _capacityController.dispose();
//     _ticketNameController.dispose();
//     _ticketPriceController.dispose();
//     _ticketQuantityController.dispose();
//     _earlyBirdPriceController.dispose();
//     _waiverTextController.dispose();
//     _questionTextController.dispose();
//     _questionOptionsController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.primaryBlack,
//       appBar: PreferredSize(
//         preferredSize: const Size.fromHeight(80),
//         child: Container(
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topCenter,
//               end: Alignment.bottomCenter,
//               colors: [
//                 AppColors.primaryBlack,
//                 AppColors.primaryBlack.withOpacity(0.95),
//                 AppColors.primaryBlack.withOpacity(0.9),
//               ],
//             ),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black.withOpacity(0.3),
//                 blurRadius: 8,
//                 offset: const Offset(0, 2),
//               ),
//             ],
//           ),
//           child: SafeArea(
//             child: Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//               child: Row(
//                 children: [
//                   // Back Button
//                   Container(
//                     width: 56,
//                     height: 56,
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.08),
//                       borderRadius: BorderRadius.circular(20),
//                       border: Border.all(
//                         color: Colors.white.withOpacity(0.12),
//                         width: 0.5,
//                       ),
//                       boxShadow: [
//                         BoxShadow(
//                           color: Colors.black.withOpacity(0.2),
//                           blurRadius: 8,
//                           offset: const Offset(0, 2),
//                         ),
//                       ],
//                     ),
//                     child: Material(
//                       color: Colors.transparent,
//                       child: InkWell(
//                         borderRadius: BorderRadius.circular(20),
//                         onTap: () => Navigator.of(context).pop(),
//                         child: const Icon(
//                           Icons.arrow_back_ios_new_rounded,
//                           color: Colors.white,
//                           size: 20,
//                         ),
//                       ),
//                     ),
//                   ),
//                   const SizedBox(width: 16),
//                   // Title
//                   Expanded(
//                     child: Container(
//                       height: 56,
//                       padding: const EdgeInsets.symmetric(horizontal: 20),
//                       decoration: BoxDecoration(
//                         color: Colors.white.withOpacity(0.05),
//                         borderRadius: BorderRadius.circular(20),
//                         border: Border.all(
//                           color: Colors.white.withOpacity(0.08),
//                           width: 0.5,
//                         ),
//                       ),
//                       child: const Center(
//                         child: Text(
//                           'Edit Event',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 18,
//                             fontWeight: FontWeight.w600,
//                             letterSpacing: 0.3,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   const SizedBox(width: 16),
//                   // Save Draft Button
//                   Container(
//                     height: 56,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(20),
//                       boxShadow: [
//                         BoxShadow(
//                           color: const Color(0xFFFF9800).withOpacity(0.3),
//                           blurRadius: 12,
//                           offset: const Offset(0, 4),
//                         ),
//                       ],
//                     ),
//                     child: Material(
//                       color: Colors.transparent,
//                       child: InkWell(
//                         borderRadius: BorderRadius.circular(20),
//                         onTap: _saveDraft,
//                         child: const Padding(
//                           padding: EdgeInsets.symmetric(horizontal: 20),
//                           child: Center(
//                             child: Text(
//                               'Save Draft',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontSize: 14,
//                                 fontWeight: FontWeight.w600,
//                                 letterSpacing: 0.2,
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//       body: _buildBody(),
//       bottomNavigationBar: _buildBottomBar(),
//     );
//   }

//   Widget _buildBody() {
//     return LayoutBuilder(
//       builder: (context, constraints) {
//         final minHeight = constraints.maxHeight > 0
//             ? constraints.maxHeight - 100
//             : MediaQuery.of(context).size.height - 200;

//         return SingleChildScrollView(
//           child: ConstrainedBox(
//             constraints: BoxConstraints(minHeight: minHeight),
//             child: IntrinsicHeight(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   const SizedBox(height: 16),
//                   Flexible(child: _buildCurrentStep()),
//                   const SizedBox(height: 100),
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   Widget _buildCurrentStep() {
//     switch (_currentStep) {
//       case 0:
//         return Container(
//           width: double.infinity,
//           constraints: const BoxConstraints(minHeight: 400),
//           child: Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 16.0),
//             child: EventTypeSelector(
//               selectedType: _selectedEventType,
//               onTypeSelected: (type) {
//                 setState(() {
//                   _selectedEventType = type;
//                   _eventTypeSpecificData = {};
//                   _currentStep = 1;
//                 });
//               },
//             ),
//           ),
//         );
//       case 1:
//         return Container(
//           width: double.infinity,
//           constraints: const BoxConstraints(minHeight: 400),
//           child: _buildEventInfoStep(),
//         );
//       case 2:
//         return Container(
//           width: double.infinity,
//           constraints: const BoxConstraints(minHeight: 400),
//           child: _buildDateTimeStep(),
//         );
//       case 3:
//         return Container(
//           width: double.infinity,
//           constraints: const BoxConstraints(minHeight: 400),
//           child: _buildLocationStep(),
//         );
//       case 4:
//         return Container(
//           width: double.infinity,
//           constraints: const BoxConstraints(minHeight: 400),
//           child: _selectedEventType != null
//               ? EventTypeSpecificForms(
//                   eventType: _selectedEventType!,
//                   formData: _eventTypeSpecificData,
//                   onFormDataChanged: (data) {
//                     setState(() {
//                       _eventTypeSpecificData = data;
//                     });
//                   },
//                   onNextStep: () {
//                     setState(() {
//                       _currentStep = 5;
//                     });
//                   },
//                   onPreviousStep: () {
//                     setState(() {
//                       _currentStep = 3;
//                     });
//                   },
//                 )
//               : const Center(
//                   child: Text(
//                     'Please select an event type first',
//                     style: TextStyle(color: Colors.white),
//                   ),
//                 ),
//         );
//       case 5:
//         return Container(
//           width: double.infinity,
//           constraints: const BoxConstraints(minHeight: 400),
//           child: _buildTicketTypesStep(),
//         );
//       case 6:
//         return Container(
//           width: double.infinity,
//           constraints: const BoxConstraints(minHeight: 400),
//           child: _buildPreviewStep(),
//         );
//       default:
//         return Container(
//           width: double.infinity,
//           height: 400,
//           child: const Center(
//             child: Text(
//               'Loading...',
//               style: TextStyle(color: Colors.white),
//             ),
//           ),
//         );
//     }
//   }

//   Widget _buildBottomBar() {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: AppColors.primaryBlack,
//         border: Border(
//           top: BorderSide(color: AppColors.darkGray, width: 1),
//         ),
//       ),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           if (_currentStep > 0)
//             TextButton(
//               onPressed: _previousStep,
//               child: const Text(
//                 'Back',
//                 style: TextStyle(color: Colors.white, fontSize: 16),
//               ),
//             )
//           else
//             const SizedBox.shrink(),
//           Container(
//             decoration: BoxDecoration(
//               gradient: AppColors.orangeGradient,
//               borderRadius: BorderRadius.circular(24),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.orange.withOpacity(0.3),
//                   blurRadius: 8,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: ElevatedButton(
//               onPressed: _nextStep,
//               style: ElevatedButton.styleFrom(
//                 padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(24),
//                 ),
//                 backgroundColor: Colors.transparent,
//                 elevation: 0,
//                 shadowColor: Colors.transparent,
//               ),
//               child: Text(
//                 _currentStep == 6 ? 'Update Event' : 'Continue',
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 16,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   void _nextStep() {
//     if (_currentStep < 6) {
//       if (_currentStep == 0 && _selectedEventType == null) {
//         setState(() {
//           _selectedEventType = EventType.pickupRun;
//           _currentStep++;
//         });
//       } else {
//         setState(() {
//           _currentStep++;
//         });
//       }
//     } else {
//       _updateEvent();
//     }
//   }

//   void _previousStep() {
//     if (_currentStep > 0) {
//       setState(() {
//         _currentStep--;
//       });
//     }
//   }

//   void _saveDraft() {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         content: Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//             ),
//             borderRadius: BorderRadius.circular(8),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.orange.withOpacity(0.3),
//                 blurRadius: 8,
//                 offset: const Offset(0, 4),
//               ),
//             ],
//           ),
//           child: const Text('Draft saved successfully'),
//         ),
//       ),
//     );
//   }

//   void _updateEvent() {
//     Map<String, dynamic> eventData = {
//       'id': widget.event.id,
//       'title': _titleController.text,
//       'description': _descriptionController.text,
//       'location': _locationController.text,
//       'dateTime': _selectedDateTime,
//       'eventType': _selectedEventType,
//       'isPrivate': _isEventPrivate,
//       'isLocationPrivate': _isLocationPrivate,
//       'isFree': _isFree && _ticketTypes.isEmpty,
//       'price': _isFree ? null : double.tryParse(_priceController.text),
//       'eventTypeSpecificData': _eventTypeSpecificData,
//     };

//     print('Event updated with data: $eventData');

//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         content: Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//             ),
//             borderRadius: BorderRadius.circular(8),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.orange.withOpacity(0.3),
//                 blurRadius: 8,
//                 offset: const Offset(0, 4),
//               ),
//             ],
//           ),
//           child: const Text('Event updated successfully'),
//         ),
//       ),
//     );

//     Navigator.of(context).pop();
//   }

//   // Placeholder methods for missing steps - these would be copied from create_event_page.dart
//   Widget _buildEventInfoStep() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),

//           // Modern Header with Icon
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.edit_note_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'Tell us about your event',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),

//           const SizedBox(height: 40),

//           // Event Title Card
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//               borderRadius: BorderRadius.circular(20),
//               border: Border.all(
//                 color: Colors.white.withOpacity(0.08),
//                 width: 0.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.white.withOpacity(0.03),
//                   blurRadius: 1,
//                   offset: const Offset(0, 1),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.4),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     Container(
//                       width: 36,
//                       height: 36,
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [
//                             Colors.orange.shade400,
//                             Colors.deepOrange.shade600,
//                           ],
//                         ),
//                         borderRadius: BorderRadius.circular(10),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.orange.withOpacity(0.3),
//                             blurRadius: 6,
//                             offset: const Offset(0, 2),
//                           ),
//                         ],
//                       ),
//                       child: const Icon(
//                         Icons.title_rounded,
//                         color: Colors.white,
//                         size: 18,
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     const Text(
//                       'Event Title',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 18,
//                         fontWeight: FontWeight.w700,
//                         letterSpacing: 0.3,
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
//                 TextField(
//                   controller: _titleController,
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                     fontWeight: FontWeight.w500,
//                   ),
//                   decoration: InputDecoration(
//                     hintText: 'Give your event an exciting name...',
//                     hintStyle: TextStyle(
//                       color: Colors.white.withOpacity(0.5),
//                       fontSize: 16,
//                     ),
//                     filled: true,
//                     fillColor: Colors.white.withOpacity(0.08),
//                     border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(16),
//                       borderSide: BorderSide.none,
//                     ),
//                     focusedBorder: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(16),
//                       borderSide: BorderSide(
//                         color: AppColors.primaryOrange,
//                         width: 2,
//                       ),
//                     ),
//                     contentPadding: const EdgeInsets.all(16),
//                   ),
//                 ),
//               ],
//             ),
//           ),

//           const SizedBox(height: 24),

//           // Privacy Settings Card
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//               borderRadius: BorderRadius.circular(20),
//               border: Border.all(
//                 color: Colors.white.withOpacity(0.08),
//                 width: 0.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.white.withOpacity(0.03),
//                   blurRadius: 1,
//                   offset: const Offset(0, 1),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.4),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     Container(
//                       width: 36,
//                       height: 36,
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [
//                             Colors.orange.shade400,
//                             Colors.deepOrange.shade600,
//                           ],
//                         ),
//                         borderRadius: BorderRadius.circular(10),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.orange.withOpacity(0.3),
//                             blurRadius: 6,
//                             offset: const Offset(0, 2),
//                           ),
//                         ],
//                       ),
//                       child: Icon(
//                         _isEventPrivate
//                             ? Icons.lock_rounded
//                             : Icons.public_rounded,
//                         color: Colors.white,
//                         size: 18,
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     const Text(
//                       'Event Visibility',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 18,
//                         fontWeight: FontWeight.w700,
//                         letterSpacing: 0.3,
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
//                 Container(
//                   decoration: BoxDecoration(
//                     color: Colors.white.withOpacity(0.05),
//                     borderRadius: BorderRadius.circular(16),
//                     border: Border.all(
//                       color: _isEventPrivate
//                           ? AppColors.primaryOrange.withOpacity(0.3)
//                           : Colors.green.withOpacity(0.3),
//                     ),
//                   ),
//                   child: SwitchListTile(
//                     contentPadding:
//                         const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
//                     title: Text(
//                       _isEventPrivate ? 'Private Event' : 'Public Event',
//                       style: const TextStyle(
//                         color: Colors.white,
//                         fontWeight: FontWeight.w600,
//                         fontSize: 16,
//                       ),
//                     ),
//                     subtitle: Text(
//                       _isEventPrivate
//                           ? 'Only invited people can see and join'
//                           : 'Anyone can discover and join this event',
//                       style: TextStyle(
//                         color: Colors.white.withOpacity(0.7),
//                         fontSize: 14,
//                       ),
//                     ),
//                     value: !_isEventPrivate,
//                     onChanged: (value) {
//                       setState(() {
//                         _isEventPrivate = !value;
//                       });
//                     },
//                     activeColor: Colors.green,
//                     inactiveThumbColor: AppColors.primaryOrange,
//                     inactiveTrackColor:
//                         AppColors.primaryOrange.withOpacity(0.3),
//                   ),
//                 ),
//               ],
//             ),
//           ),

//           const SizedBox(height: 24),

//           // Description Card
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//               borderRadius: BorderRadius.circular(20),
//               border: Border.all(
//                 color: Colors.white.withOpacity(0.08),
//                 width: 0.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.white.withOpacity(0.03),
//                   blurRadius: 1,
//                   offset: const Offset(0, 1),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.4),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     Container(
//                       width: 36,
//                       height: 36,
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [
//                             Colors.orange.shade400,
//                             Colors.deepOrange.shade600,
//                           ],
//                         ),
//                         borderRadius: BorderRadius.circular(10),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.orange.withOpacity(0.3),
//                             blurRadius: 6,
//                             offset: const Offset(0, 2),
//                           ),
//                         ],
//                       ),
//                       child: const Icon(
//                         Icons.description_rounded,
//                         color: Colors.white,
//                         size: 18,
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     const Text(
//                       'Event Description',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 18,
//                         fontWeight: FontWeight.w700,
//                         letterSpacing: 0.3,
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
//                 TextField(
//                   controller: _descriptionController,
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                     height: 1.5,
//                   ),
//                   maxLines: 4,
//                   decoration: InputDecoration(
//                     hintText:
//                         'Share what makes your event special...\n\n• What should attendees expect?\n• Any special requirements?',
//                     hintStyle: TextStyle(
//                       color: Colors.white.withOpacity(0.5),
//                       fontSize: 15,
//                       height: 1.4,
//                     ),
//                     filled: true,
//                     fillColor: Colors.white.withOpacity(0.08),
//                     border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(16),
//                       borderSide: BorderSide.none,
//                     ),
//                     focusedBorder: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(16),
//                       borderSide: BorderSide(
//                         color: AppColors.primaryOrange,
//                         width: 2,
//                       ),
//                     ),
//                     contentPadding: const EdgeInsets.all(16),
//                   ),
//                 ),
//               ],
//             ),
//           ),

//           const SizedBox(height: 40),
//         ],
//       ),
//     );
//   }

//   Widget _buildDateTimeStep() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),

//           // Modern Header with Icon
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.schedule_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'When is your event?',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),

//           const SizedBox(height: 40),

//           // Date picker card
//           Container(
//             width: double.infinity,
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//               borderRadius: BorderRadius.circular(16),
//               border: Border.all(
//                 color: Colors.white.withOpacity(0.08),
//                 width: 0.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.white.withOpacity(0.03),
//                   blurRadius: 1,
//                   offset: const Offset(0, 1),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.4),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Material(
//               color: Colors.transparent,
//               child: InkWell(
//                 onTap: () => _showModernDatePicker(),
//                 borderRadius: BorderRadius.circular(16),
//                 child: Padding(
//                   padding: const EdgeInsets.all(24),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Row(
//                         children: [
//                           Container(
//                             width: 36,
//                             height: 36,
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [
//                                   Colors.orange.shade400,
//                                   Colors.deepOrange.shade600,
//                                 ],
//                               ),
//                               borderRadius: BorderRadius.circular(10),
//                               boxShadow: [
//                                 BoxShadow(
//                                   color: Colors.orange.withOpacity(0.3),
//                                   blurRadius: 6,
//                                   offset: const Offset(0, 2),
//                                 ),
//                               ],
//                             ),
//                             child: const Icon(
//                               Icons.calendar_today,
//                               color: Colors.white,
//                               size: 18,
//                             ),
//                           ),
//                           const SizedBox(width: 12),
//                           const Text(
//                             'Event Date',
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 18,
//                               fontWeight: FontWeight.w700,
//                               letterSpacing: 0.3,
//                             ),
//                           ),
//                           const Spacer(),
//                           Icon(
//                             Icons.arrow_forward_ios,
//                             color: Colors.white.withOpacity(0.6),
//                             size: 16,
//                           ),
//                         ],
//                       ),
//                       const SizedBox(height: 16),
//                       Text(
//                         _selectedDateTime != null
//                             ? '${_getMonthName(_selectedDateTime!.month)} ${_selectedDateTime!.day}, ${_selectedDateTime!.year}'
//                             : 'Tap to select date',
//                         style: TextStyle(
//                           color: _selectedDateTime != null
//                               ? Colors.white
//                               : Colors.white.withOpacity(0.7),
//                           fontSize: _selectedDateTime != null ? 20 : 16,
//                           fontWeight: _selectedDateTime != null
//                               ? FontWeight.w600
//                               : FontWeight.normal,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),

//           const SizedBox(height: 20),

//           // Time picker card
//           Container(
//             width: double.infinity,
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//               borderRadius: BorderRadius.circular(16),
//               border: Border.all(
//                 color: Colors.white.withOpacity(0.08),
//                 width: 0.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.white.withOpacity(0.03),
//                   blurRadius: 1,
//                   offset: const Offset(0, 1),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.4),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Material(
//               color: Colors.transparent,
//               child: InkWell(
//                 onTap: () => _showModernTimePicker(),
//                 borderRadius: BorderRadius.circular(16),
//                 child: Padding(
//                   padding: const EdgeInsets.all(24),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Row(
//                         children: [
//                           Container(
//                             width: 36,
//                             height: 36,
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [
//                                   Colors.orange.shade400,
//                                   Colors.deepOrange.shade600,
//                                 ],
//                               ),
//                               borderRadius: BorderRadius.circular(10),
//                               boxShadow: [
//                                 BoxShadow(
//                                   color: Colors.orange.withOpacity(0.3),
//                                   blurRadius: 6,
//                                   offset: const Offset(0, 2),
//                                 ),
//                               ],
//                             ),
//                             child: const Icon(
//                               Icons.access_time,
//                               color: Colors.white,
//                               size: 18,
//                             ),
//                           ),
//                           const SizedBox(width: 12),
//                           const Text(
//                             'Event Time',
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 18,
//                               fontWeight: FontWeight.w700,
//                               letterSpacing: 0.3,
//                             ),
//                           ),
//                           const Spacer(),
//                           Icon(
//                             Icons.arrow_forward_ios,
//                             color: Colors.white.withOpacity(0.6),
//                             size: 16,
//                           ),
//                         ],
//                       ),
//                       const SizedBox(height: 16),
//                       Text(
//                         _selectedDateTime != null
//                             ? _formatTime12Hour(_selectedDateTime!)
//                             : 'Tap to select time',
//                         style: TextStyle(
//                           color: _selectedDateTime != null
//                               ? Colors.white
//                               : Colors.white.withOpacity(0.7),
//                           fontSize: _selectedDateTime != null ? 20 : 16,
//                           fontWeight: _selectedDateTime != null
//                               ? FontWeight.w600
//                               : FontWeight.normal,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),

//           const SizedBox(height: 40),
//         ],
//       ),
//     );
//   }

//   Widget _buildLocationStep() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),

//           // Modern Header with Icon
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.location_on_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'Where is your event taking place?',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),

//           const SizedBox(height: 40),

//           EnhancedLocationSelector(
//             selectedLocation: _selectedLocation,
//             isLocationPrivate: _isLocationPrivate,
//             onLocationSelected: (location) {
//               setState(() {
//                 _selectedLocation = location;
//               });
//             },
//             onPrivacyChanged: (value) {
//               setState(() {
//                 _isLocationPrivate = value;
//               });
//             },
//             locationController: _locationController,
//           ),

//           const SizedBox(height: 40),
//         ],
//       ),
//     );
//   }

//   Widget _buildTicketTypesStep() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),

//           // Modern Header with Icon
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.confirmation_number_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'Event Pricing',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),

//           const SizedBox(height: 8),

//           // Pricing Form Container
//           Container(
//             constraints: const BoxConstraints(minHeight: 400),
//             child: RegistrationPricingForm(
//               // Registration settings
//               capacityController: _capacityController,
//               isRegistrationOpen: _isRegistrationOpen,
//               onRegistrationStatusChanged: (value) {
//                 setState(() {
//                   _isRegistrationOpen = value;
//                 });
//               },

//               // Ticket types settings
//               ticketTypes: _ticketTypes,
//               onTicketTypesUpdated: (tickets) {
//                 setState(() {
//                   _ticketTypes = tickets;
//                 });
//               },
//               ticketNameController: _ticketNameController,
//               ticketPriceController: _ticketPriceController,
//               ticketQuantityController: _ticketQuantityController,

//               // Custom questions settings
//               hasCustomQuestions: _hasCustomQuestions,
//               onCustomQuestionsChanged: (value) {
//                 setState(() {
//                   _hasCustomQuestions = value;
//                 });
//               },
//               customQuestions: _customQuestions,
//               onCustomQuestionsUpdated: (questions) {
//                 setState(() {
//                   _customQuestions = questions;
//                 });
//               },
//               questionTextController: _questionTextController,
//               questionOptionsController: _questionOptionsController,

//               // Early bird pricing settings
//               hasEarlyBirdPricing: _hasEarlyBirdPricing,
//               onEarlyBirdPricingChanged: (value) {
//                 setState(() {
//                   _hasEarlyBirdPricing = value;
//                 });
//               },
//               earlyBirdPriceController: _earlyBirdPriceController,
//               earlyBirdDeadline: _earlyBirdDeadline,
//               onEarlyBirdDeadlineSelected: (date) {
//                 setState(() {
//                   _earlyBirdDeadline = date;
//                 });
//               },

//               // Waiver settings
//               requiresWaiver: _requiresWaiver,
//               onWaiverRequirementChanged: (value) {
//                 setState(() {
//                   _requiresWaiver = value;
//                 });
//               },
//               waiverTextController: _waiverTextController,
//               selectedWaiverTemplate: _selectedWaiverTemplate,
//               onWaiverTemplateSelected: (template) {
//                 setState(() {
//                   _selectedWaiverTemplate = template;
//                 });
//               },
//             ),
//           ),
//           const SizedBox(height: 20),
//         ],
//       ),
//     );
//   }

//   Widget _buildPreviewStep() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.preview_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'Review your changes',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 32),
//           Container(
//             padding: const EdgeInsets.all(16),
//             decoration: BoxDecoration(
//               color: AppColors.primaryOrange.withOpacity(0.1),
//               borderRadius: BorderRadius.circular(16),
//               border: Border.all(
//                 color: AppColors.primaryOrange.withOpacity(0.3),
//               ),
//             ),
//             child: Row(
//               children: [
//                 Icon(
//                   Icons.info_outline_rounded,
//                   color: AppColors.primaryOrange,
//                   size: 20,
//                 ),
//                 const SizedBox(width: 12),
//                 const Expanded(
//                   child: Text(
//                     'This is how your updated event will appear to others',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 14,
//                       fontWeight: FontWeight.w500,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           const SizedBox(height: 24),
//           Container(
//             decoration: BoxDecoration(
//               borderRadius: BorderRadius.circular(24),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.3),
//                   blurRadius: 20,
//                   offset: const Offset(0, 8),
//                 ),
//               ],
//             ),
//             child: EventPreview(
//               title: _titleController.text,
//               dateTime: _selectedDateTime,
//               location: _locationController.text,
//               eventType: _selectedEventType,
//               isFree: _isFree,
//               price: _isFree ? null : double.tryParse(_priceController.text),
//               isPrivate: _isEventPrivate,
//             ),
//           ),
//           const SizedBox(height: 40),
//         ],
//       ),
//     );
//   }

//   // Modern, mobile-friendly date picker
//   void _showModernDatePicker() {
//     showModalBottomSheet(
//       context: context,
//       isScrollControlled: true,
//       backgroundColor: Colors.transparent,
//       builder: (context) => Container(
//         height: MediaQuery.of(context).size.height * 0.6,
//         decoration: const BoxDecoration(
//           color: AppColors.primaryBlack,
//           borderRadius: BorderRadius.only(
//             topLeft: Radius.circular(24),
//             topRight: Radius.circular(24),
//           ),
//         ),
//         child: Column(
//           children: [
//             // Handle bar
//             Container(
//               margin: const EdgeInsets.only(top: 12),
//               width: 40,
//               height: 4,
//               decoration: BoxDecoration(
//                 color: Colors.white.withOpacity(0.3),
//                 borderRadius: BorderRadius.circular(2),
//               ),
//             ),

//             // Header
//             Padding(
//               padding: const EdgeInsets.all(24),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   const Text(
//                     'Select Date',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 20,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   GestureDetector(
//                     onTap: () => Navigator.pop(context),
//                     child: Container(
//                       padding: const EdgeInsets.all(8),
//                       decoration: BoxDecoration(
//                         color: Colors.white.withOpacity(0.1),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       child: const Icon(
//                         Icons.close,
//                         color: Colors.white,
//                         size: 20,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),

//             // Calendar
//             Expanded(
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 24),
//                 child: _buildModernCalendar(),
//               ),
//             ),

//             // Done button
//             Padding(
//               padding: const EdgeInsets.all(24),
//               child: SizedBox(
//                 width: double.infinity,
//                 child: Container(
//                   decoration: BoxDecoration(
//                     gradient: AppColors.orangeGradient,
//                     borderRadius: BorderRadius.circular(16),
//                     boxShadow: [
//                       BoxShadow(
//                         color: const Color(0xFFFF9800).withOpacity(0.4),
//                         blurRadius: 12,
//                         offset: const Offset(0, 4),
//                       ),
//                     ],
//                   ),
//                   child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.pop(context);
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: Colors.transparent,
//                       padding: const EdgeInsets.symmetric(vertical: 16),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(16),
//                       ),
//                       shadowColor: Colors.transparent,
//                     ),
//                     child: const Text(
//                       'Done',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 16,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   // Modern, mobile-friendly time picker
//   void _showModernTimePicker() {
//     showModalBottomSheet(
//       context: context,
//       isScrollControlled: true,
//       backgroundColor: Colors.transparent,
//       builder: (context) => Container(
//         height: MediaQuery.of(context).size.height * 0.7,
//         decoration: const BoxDecoration(
//           color: AppColors.primaryBlack,
//           borderRadius: BorderRadius.only(
//             topLeft: Radius.circular(24),
//             topRight: Radius.circular(24),
//           ),
//         ),
//         child: Column(
//           children: [
//             // Handle bar
//             Container(
//               margin: const EdgeInsets.only(top: 12),
//               width: 40,
//               height: 4,
//               decoration: BoxDecoration(
//                 color: Colors.white.withOpacity(0.3),
//                 borderRadius: BorderRadius.circular(2),
//               ),
//             ),

//             // Header
//             Padding(
//               padding: const EdgeInsets.all(24),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   const Text(
//                     'Select Time',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 20,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   GestureDetector(
//                     onTap: () => Navigator.pop(context),
//                     child: Container(
//                       padding: const EdgeInsets.all(8),
//                       decoration: BoxDecoration(
//                         color: Colors.white.withOpacity(0.1),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       child: const Icon(
//                         Icons.close,
//                         color: Colors.white,
//                         size: 20,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),

//             // Time slots
//             Expanded(
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 24),
//                 child: _buildModernTimeSlots(),
//               ),
//             ),

//             // Done button
//             Padding(
//               padding: const EdgeInsets.all(24),
//               child: SizedBox(
//                 width: double.infinity,
//                 child: Container(
//                   decoration: BoxDecoration(
//                     gradient: AppColors.orangeGradient,
//                     borderRadius: BorderRadius.circular(16),
//                     boxShadow: [
//                       BoxShadow(
//                         color: const Color(0xFFFF9800).withOpacity(0.4),
//                         blurRadius: 12,
//                         offset: const Offset(0, 4),
//                       ),
//                     ],
//                   ),
//                   child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.pop(context);
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: Colors.transparent,
//                       padding: const EdgeInsets.symmetric(vertical: 16),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(16),
//                       ),
//                       shadowColor: Colors.transparent,
//                     ),
//                     child: const Text(
//                       'Done',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 16,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   // Build modern calendar widget
//   Widget _buildModernCalendar() {
//     final now = DateTime.now();
//     final selectedDate = _selectedDateTime ?? now;
//     final firstDayOfMonth = DateTime(selectedDate.year, selectedDate.month, 1);
//     final lastDayOfMonth =
//         DateTime(selectedDate.year, selectedDate.month + 1, 0);
//     final firstDayWeekday = (firstDayOfMonth.weekday - 1) % 7;
//     final daysInMonth = lastDayOfMonth.day;

//     return Column(
//       children: [
//         // Month/Year header with navigation
//         Container(
//           padding: const EdgeInsets.symmetric(vertical: 16),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               GestureDetector(
//                 onTap: () {
//                   setState(() {
//                     final newDate =
//                         DateTime(selectedDate.year, selectedDate.month - 1, 1);
//                     _selectedDateTime = _selectedDateTime != null
//                         ? DateTime(
//                             newDate.year,
//                             newDate.month,
//                             _selectedDateTime!.day,
//                             _selectedDateTime!.hour,
//                             _selectedDateTime!.minute)
//                         : newDate;
//                   });
//                 },
//                 child: Container(
//                   padding: const EdgeInsets.all(12),
//                   decoration: BoxDecoration(
//                     color: Colors.white.withOpacity(0.1),
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: const Icon(Icons.chevron_left, color: Colors.white),
//                 ),
//               ),
//               Text(
//                 '${_getMonthName(selectedDate.month)} ${selectedDate.year}',
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//               GestureDetector(
//                 onTap: () {
//                   setState(() {
//                     final newDate =
//                         DateTime(selectedDate.year, selectedDate.month + 1, 1);
//                     _selectedDateTime = _selectedDateTime != null
//                         ? DateTime(
//                             newDate.year,
//                             newDate.month,
//                             _selectedDateTime!.day,
//                             _selectedDateTime!.hour,
//                             _selectedDateTime!.minute)
//                         : newDate;
//                   });
//                 },
//                 child: Container(
//                   padding: const EdgeInsets.all(12),
//                   decoration: BoxDecoration(
//                     color: Colors.white.withOpacity(0.1),
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: const Icon(Icons.chevron_right, color: Colors.white),
//                 ),
//               ),
//             ],
//           ),
//         ),

//         // Day labels
//         Container(
//           padding: const EdgeInsets.symmetric(vertical: 12),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceAround,
//             children: ['S', 'M', 'T', 'W', 'T', 'F', 'S']
//                 .map((day) => Text(
//                       day,
//                       style: TextStyle(
//                         color: Colors.white.withOpacity(0.6),
//                         fontSize: 14,
//                         fontWeight: FontWeight.w600,
//                       ),
//                     ))
//                 .toList(),
//           ),
//         ),

//         // Calendar grid
//         Expanded(
//           child: GridView.builder(
//             gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//               crossAxisCount: 7,
//               childAspectRatio: 1,
//               mainAxisSpacing: 8,
//               crossAxisSpacing: 8,
//             ),
//             itemCount: firstDayWeekday + daysInMonth,
//             itemBuilder: (context, index) {
//               if (index < firstDayWeekday) {
//                 return const SizedBox();
//               }

//               final day = index - firstDayWeekday + 1;
//               final date = DateTime(selectedDate.year, selectedDate.month, day);
//               final isSelected = _selectedDateTime != null &&
//                   _selectedDateTime!.year == date.year &&
//                   _selectedDateTime!.month == date.month &&
//                   _selectedDateTime!.day == date.day;
//               final isToday = date.year == now.year &&
//                   date.month == now.month &&
//                   date.day == now.day;
//               final isPast =
//                   date.isBefore(DateTime(now.year, now.month, now.day));

//               return GestureDetector(
//                 onTap: isPast
//                     ? null
//                     : () {
//                         setState(() {
//                           if (_selectedDateTime != null) {
//                             _selectedDateTime = DateTime(
//                               date.year,
//                               date.month,
//                               date.day,
//                               _selectedDateTime!.hour,
//                               _selectedDateTime!.minute,
//                             );
//                           } else {
//                             _selectedDateTime = DateTime(
//                                 date.year, date.month, date.day, 12, 0);
//                           }
//                         });
//                       },
//                 child: Container(
//                   decoration: BoxDecoration(
//                     gradient: isSelected ? AppColors.orangeGradient : null,
//                     color: isToday && !isSelected
//                         ? Colors.white.withOpacity(0.15)
//                         : isPast
//                             ? null
//                             : Colors.white.withOpacity(0.05),
//                     borderRadius: BorderRadius.circular(12),
//                     border: isSelected
//                         ? Border.all(color: Colors.white, width: 2)
//                         : isToday && !isSelected
//                             ? Border.all(
//                                 color: const Color(0xFFFF9800), width: 2)
//                             : Border.all(
//                                 color: Colors.white.withOpacity(0.1), width: 1),
//                     boxShadow: isSelected
//                         ? [
//                             BoxShadow(
//                               color: const Color(0xFFFF9800).withOpacity(0.5),
//                               blurRadius: 8,
//                               offset: const Offset(0, 2),
//                             ),
//                           ]
//                         : null,
//                   ),
//                   child: Center(
//                     child: Text(
//                       day.toString(),
//                       style: TextStyle(
//                         color: isPast
//                             ? Colors.white.withOpacity(0.3)
//                             : isSelected
//                                 ? Colors.white
//                                 : isToday
//                                     ? const Color(0xFFFF9800)
//                                     : Colors.white.withOpacity(0.9),
//                         fontSize: isSelected ? 18 : 16,
//                         fontWeight: isSelected
//                             ? FontWeight.w900
//                             : isToday
//                                 ? FontWeight.bold
//                                 : FontWeight.w500,
//                       ),
//                     ),
//                   ),
//                 ),
//               );
//             },
//           ),
//         ),
//       ],
//     );
//   }

//   // Build modern time slots with 12-hour format and 15-minute intervals
//   Widget _buildModernTimeSlots() {
//     final timeSlots = <Map<String, dynamic>>[];

//     // Generate time slots from 6 AM to 11:45 PM with 15-minute intervals
//     for (int hour = 6; hour < 24; hour++) {
//       for (int minute = 0; minute < 60; minute += 15) {
//         final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
//         final period = hour >= 12 ? 'PM' : 'AM';
//         final timeString =
//             '${displayHour}:${minute.toString().padLeft(2, '0')} $period';

//         timeSlots.add({
//           'display': timeString,
//           'hour': hour,
//           'minute': minute,
//         });
//       }
//     }

//     return GridView.builder(
//       gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//         crossAxisCount: 3,
//         childAspectRatio: 2.2,
//         mainAxisSpacing: 12,
//         crossAxisSpacing: 12,
//       ),
//       itemCount: timeSlots.length,
//       itemBuilder: (context, index) {
//         final timeSlot = timeSlots[index];
//         final displayTime = timeSlot['display'] as String;
//         final hour = timeSlot['hour'] as int;
//         final minute = timeSlot['minute'] as int;

//         final isSelected = _selectedDateTime != null &&
//             _selectedDateTime!.hour == hour &&
//             _selectedDateTime!.minute == minute;

//         return GestureDetector(
//           onTap: () {
//             setState(() {
//               if (_selectedDateTime != null) {
//                 _selectedDateTime = DateTime(
//                   _selectedDateTime!.year,
//                   _selectedDateTime!.month,
//                   _selectedDateTime!.day,
//                   hour,
//                   minute,
//                 );
//               } else {
//                 final now = DateTime.now();
//                 _selectedDateTime =
//                     DateTime(now.year, now.month, now.day, hour, minute);
//               }
//             });
//           },
//           child: Container(
//             decoration: BoxDecoration(
//               gradient: isSelected ? AppColors.orangeGradient : null,
//               color: isSelected ? null : Colors.white.withOpacity(0.1),
//               borderRadius: BorderRadius.circular(12),
//               border: Border.all(
//                 color: isSelected
//                     ? Colors.transparent
//                     : Colors.white.withOpacity(0.2),
//                 width: 1,
//               ),
//             ),
//             child: Center(
//               child: Text(
//                 displayTime,
//                 style: TextStyle(
//                   color:
//                       isSelected ? Colors.white : Colors.white.withOpacity(0.8),
//                   fontSize: 14,
//                   fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
//                 ),
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   // Helper method to get month name
//   String _getMonthName(int month) {
//     const months = [
//       'January',
//       'February',
//       'March',
//       'April',
//       'May',
//       'June',
//       'July',
//       'August',
//       'September',
//       'October',
//       'November',
//       'December'
//     ];
//     return months[month - 1];
//   }

//   // Helper method to format time in 12-hour format
//   String _formatTime12Hour(DateTime dateTime) {
//     final hour = dateTime.hour;
//     final minute = dateTime.minute;
//     final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
//     final period = hour >= 12 ? 'PM' : 'AM';
//     return '${displayHour}:${minute.toString().padLeft(2, '0')} $period';
//   }
// }
