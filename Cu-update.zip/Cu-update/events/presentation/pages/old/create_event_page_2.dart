// import 'package:flutter/material.dart';
// import 'package:check_up_app/core/theme/app_colors.dart';
// import 'package:check_up_app/features/events/domain/models/event_type.dart';
// import 'package:check_up_app/features/events/domain/models/location_model.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_type_selector.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_preview.dart';

// import 'package:check_up_app/features/events/presentation/widgets/enhanced_location_selector.dart';
// import 'package:check_up_app/features/events/presentation/widgets/registration_pricing_form.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_type_specific_forms.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_share_modal.dart';
// import 'package:check_up_app/features/events/presentation/pages/host_event_detail_page.dart';
// import 'package:check_up_app/features/courts/presentation/widgets/court_image_picker.dart';

// import 'package:check_up_app/features/search/domain/models/team_model.dart';

// /// A page for creating events with dynamic form fields based on event type
// class CreateEventPage extends StatefulWidget {
//   /// Creates a [CreateEventPage] instance
//   const CreateEventPage({Key? key}) : super(key: key);

//   @override
//   State<CreateEventPage> createState() => _CreateEventPageState();
// }

// class _CreateEventPageState extends State<CreateEventPage>
//     with TickerProviderStateMixin {
//   // Accordion section tracking
//   int? _expandedSection;
//   late AnimationController _animationController;

//   // Section completion tracking
//   Map<int, bool> _sectionCompletion = {
//     0: false, // Event Type
//     1: false, // Basic Information
//     2: false, // Date & Time
//     3: false, // Location
//     4: false, // Event Details
//     5: false, // Pricing & Tickets
//     6: false, // Preview & Publish
//   };

//   // Event type selection
//   EventType? _selectedEventType;

//   // Common form controllers
//   final TextEditingController _titleController = TextEditingController();
//   final TextEditingController _descriptionController = TextEditingController();
//   DateTime? _selectedStartDateTime;
//   DateTime? _selectedEndDateTime;
//   final TextEditingController _locationController = TextEditingController();
//   LocationModel? _selectedLocation;
//   bool _isLocationPrivate = false;
//   bool _isEventPrivate = false;
//   bool _isFree = true;
//   final TextEditingController _priceController = TextEditingController();
//   String? _selectedSkillLevel;

//   // Pickup Run fields
//   final _maxPlayersController = TextEditingController();

//   // Tournament fields
//   final _numberOfTeamsController = TextEditingController();
//   String? _selectedFormat;
//   final _prizePoolController = TextEditingController();
//   DateTime? _registrationDeadline;
//   bool _wantToAddTeams = false; // Toggle for adding teams now
//   List<TeamModel> _selectedTeams = []; // List of selected teams
//   bool _useManualTeamInput = false; // Toggle between search and manual input

//   // League Games fields
//   String? _selectedSeason;
//   String? _selectedGameType;

//   // One-on-One fields
//   final _player1Controller = TextEditingController();
//   final _player2Controller = TextEditingController();
//   String? _selectedGameFormat;

//   // Donation fields
//   final _donationGoalController = TextEditingController();
//   final _beneficiaryController = TextEditingController();
//   bool _hasTaxReceipts = false; // Used for charity events

//   // Registration & Pricing fields
//   final _capacityController = TextEditingController();
//   bool _isRegistrationOpen =
//       true; // Always open by default since we removed the toggle

//   // Ticket types
//   List<Map<String, dynamic>> _ticketTypes = [];
//   final _ticketNameController = TextEditingController();
//   final _ticketPriceController = TextEditingController();
//   final _ticketQuantityController = TextEditingController();

//   // Legacy pricing fields (will be replaced by ticket types)
//   bool _hasEarlyBirdPricing = false;
//   final _earlyBirdPriceController = TextEditingController();
//   DateTime? _earlyBirdDeadline;

//   // Waiver fields
//   bool _requiresWaiver = false;
//   final _waiverTextController = TextEditingController();
//   String? _selectedWaiverTemplate;

//   // Custom registration questions
//   bool _hasCustomQuestions = false;
//   List<Map<String, dynamic>> _customQuestions = [];
//   final _questionTextController = TextEditingController();
//   final _questionOptionsController = TextEditingController();

//   // Event type-specific form data
//   Map<String, dynamic> _eventTypeSpecificData = {};

//   // Recurring events fields
//   bool _isRecurringEvent = false;
//   List<int> _selectedRecurringDays = []; // 0=Sunday, 1=Monday, etc.

//   // Calendar viewing state
//   DateTime? _calendarViewingDate;

//   // Event images for preview (up to 4)
//   List<String> _eventImageUrls = [];

//   @override
//   void initState() {
//     super.initState();
//     _animationController = AnimationController(
//       duration: const Duration(milliseconds: 300),
//       vsync: this,
//     );
//     // Start with Event Type section expanded
//     _expandedSection = 0;
//   }

//   @override
//   void dispose() {
//     _animationController.dispose();
//     _titleController.dispose();
//     _descriptionController.dispose();
//     _locationController.dispose();
//     _priceController.dispose();
//     _maxPlayersController.dispose();
//     _numberOfTeamsController.dispose();
//     _prizePoolController.dispose();
//     _player1Controller.dispose();
//     _player2Controller.dispose();
//     _donationGoalController.dispose();
//     _beneficiaryController.dispose();
//     _capacityController.dispose();

//     // Ticket type controllers
//     _ticketNameController.dispose();
//     _ticketPriceController.dispose();
//     _ticketQuantityController.dispose();

//     // Legacy pricing controllers
//     _earlyBirdPriceController.dispose();
//     _waiverTextController.dispose();

//     // Custom questions controllers
//     _questionTextController.dispose();
//     _questionOptionsController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.primaryBlack,
//       appBar: AppBar(
//         backgroundColor: AppColors.primaryBlack,
//         elevation: 0,
//         leading: IconButton(
//           icon: const Icon(
//             Icons.arrow_back_ios_new_rounded,
//             color: Colors.white,
//             size: 20,
//           ),
//           onPressed: () => Navigator.of(context).pop(),
//         ),
//         title: const Text(
//           'Create Event',
//           style: TextStyle(
//             color: Colors.white,
//             fontSize: 18,
//             fontWeight: FontWeight.w600,
//           ),
//         ),
//         centerTitle: true,
//       ),
//       body: _buildBody(),
//       bottomNavigationBar: _buildBottomBar(),
//     );
//   }

//   Widget _buildBody() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(16),
//       child: Column(
//         children: [
//           const SizedBox(height: 8),
//           Text(
//             'Set up your basketball event in just a few steps',
//             style: TextStyle(
//               color: Colors.white.withOpacity(0.7),
//               fontSize: 16,
//             ),
//             textAlign: TextAlign.center,
//           ),
//           const SizedBox(height: 24),
//           // Accordion sections
//           _buildAccordionSection(
//             index: 0,
//             title: 'Event Type',
//             subtitle: 'Choose your event category',
//             icon: Icons.category_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 1,
//             title: 'Basic Information',
//             subtitle: 'Add title and description',
//             icon: Icons.info_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 2,
//             title: 'Date & Time',
//             subtitle: 'Set when your event happens',
//             icon: Icons.schedule_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 3,
//             title: 'Location',
//             subtitle: 'Where will it take place?',
//             icon: Icons.location_on_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 4,
//             title: _getEventDetailsTitle(),
//             subtitle: _getEventDetailsSubtitle(),
//             icon: _getEventDetailsIcon(),
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 5,
//             title: 'Pricing & Tickets',
//             subtitle: 'Set pricing and registration',
//             icon: Icons.confirmation_number_rounded,
//           ),
//           const SizedBox(height: 12),
//           _buildAccordionSection(
//             index: 6,
//             title: 'Preview & Publish',
//             subtitle: 'Review and publish',
//             icon: Icons.preview_rounded,
//           ),
//           const SizedBox(height: 100), // Extra space for scrolling
//         ],
//       ),
//     );
//   }

//   // Build accordion section
//   Widget _buildAccordionSection({
//     required int index,
//     required String title,
//     required String subtitle,
//     required IconData icon,
//   }) {
//     final bool isExpanded = _expandedSection == index;
//     final bool isCompleted = _sectionCompletion[index] ?? false;

//     return AnimatedContainer(
//       duration: const Duration(milliseconds: 300),
//       margin: const EdgeInsets.symmetric(vertical: 4),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: isExpanded
//               ? [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                 ]
//               : [
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//         ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(
//           color: isExpanded
//               ? AppColors.primaryOrange.withOpacity(0.3)
//               : Colors.white.withOpacity(0.08),
//           width: isExpanded ? 2 : 1,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: isExpanded
//                 ? AppColors.primaryOrange.withOpacity(0.2)
//                 : Colors.black.withOpacity(0.3),
//             blurRadius: isExpanded ? 12 : 6,
//             offset: const Offset(0, 4),
//           ),
//         ],
//       ),
//       child: Column(
//         children: [
//           // Header
//           Material(
//             color: Colors.transparent,
//             child: InkWell(
//               onTap: () {
//                 setState(() {
//                   _expandedSection = isExpanded ? null : index;
//                 });
//               },
//               borderRadius: BorderRadius.circular(16),
//               child: Padding(
//                 padding: const EdgeInsets.all(20),
//                 child: Row(
//                   children: [
//                     // Icon
//                     Container(
//                       width: 48,
//                       height: 48,
//                       decoration: BoxDecoration(
//                         gradient: isCompleted
//                             ? AppColors.orangeGradient
//                             : LinearGradient(
//                                 colors: [
//                                   Colors.grey.shade600,
//                                   Colors.grey.shade700,
//                                 ],
//                               ),
//                         borderRadius: BorderRadius.circular(12),
//                         boxShadow: [
//                           BoxShadow(
//                             color: isCompleted
//                                 ? AppColors.primaryOrange.withOpacity(0.3)
//                                 : Colors.black.withOpacity(0.2),
//                             blurRadius: 8,
//                             offset: const Offset(0, 2),
//                           ),
//                         ],
//                       ),
//                       child: Icon(
//                         isCompleted ? Icons.check_rounded : icon,
//                         color: Colors.white,
//                         size: 24,
//                       ),
//                     ),
//                     const SizedBox(width: 16),
//                     // Title and subtitle
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             title,
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 18,
//                               fontWeight: FontWeight.w600,
//                             ),
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             isCompleted ? 'Completed ✓' : subtitle,
//                             style: TextStyle(
//                               color: isCompleted
//                                   ? AppColors.primaryOrange
//                                   : Colors.white.withOpacity(0.7),
//                               fontSize: 14,
//                               fontWeight: isCompleted
//                                   ? FontWeight.w500
//                                   : FontWeight.normal,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     // Expand/collapse arrow
//                     AnimatedRotation(
//                       turns: isExpanded ? 0.5 : 0,
//                       duration: const Duration(milliseconds: 300),
//                       child: Icon(
//                         Icons.keyboard_arrow_down_rounded,
//                         color: isExpanded
//                             ? AppColors.primaryOrange
//                             : Colors.white.withOpacity(0.6),
//                         size: 28,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//           // Content
//           AnimatedSize(
//             duration: const Duration(milliseconds: 300),
//             child: isExpanded
//                 ? Container(
//                     width: double.infinity,
//                     padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
//                     child: _buildSectionContent(index),
//                   )
//                 : const SizedBox.shrink(),
//           ),
//         ],
//       ),
//     );
//   }

//   // Build content for each section
//   Widget _buildSectionContent(int index) {
//     switch (index) {
//       case 0:
//         return _buildEventTypeContent();
//       case 1:
//         return _buildBasicInfoContent();
//       case 2:
//         return _buildDateTimeContent();
//       case 3:
//         return _buildLocationContent();
//       case 4:
//         return _buildEventDetailsContent();
//       case 5:
//         return _buildPricingContent();
//       case 6:
//         return _buildPreviewContent();
//       default:
//         return const SizedBox.shrink();
//     }
//   }

//   // Event type content
//   Widget _buildEventTypeContent() {
//     return EventTypeSelector(
//       selectedType: _selectedEventType,
//       onTypeSelected: (type) {
//         setState(() {
//           _selectedEventType = type;
//           _eventTypeSpecificData = {};
//           _sectionCompletion[0] = true;
//           // Auto-expand next section
//           Future.delayed(const Duration(milliseconds: 400), () {
//             if (mounted) {
//               setState(() {
//                 _expandedSection = 1;
//               });
//             }
//           });
//         });
//       },
//     );
//   }

//   // Basic info content
//   Widget _buildBasicInfoContent() {
//     return _buildEventInfoStepCompact();
//   }

//   // Date time content
//   Widget _buildDateTimeContent() {
//     return _buildDateTimeStepCompact();
//   }

//   // Location content
//   Widget _buildLocationContent() {
//     return _buildLocationStepCompact();
//   }

//   // Event details content
//   Widget _buildEventDetailsContent() {
//     if (_selectedEventType == null) {
//       return Container(
//         padding: const EdgeInsets.all(16),
//         child: Column(
//           children: [
//             Icon(
//               Icons.arrow_upward_rounded,
//               color: AppColors.primaryOrange,
//               size: 32,
//             ),
//             const SizedBox(height: 16),
//             Text(
//               'Please select an event type first',
//               style: TextStyle(
//                 color: Colors.white.withOpacity(0.7),
//                 fontSize: 16,
//               ),
//               textAlign: TextAlign.center,
//             ),
//           ],
//         ),
//       );
//     }

//     return EventTypeSpecificForms(
//       eventType: _selectedEventType!,
//       formData: _eventTypeSpecificData,
//       startDateTime: _selectedStartDateTime,
//       endDateTime: _selectedEndDateTime,
//       onFormDataChanged: (data) {
//         setState(() {
//           _eventTypeSpecificData = data;
//           _sectionCompletion[4] = data.isNotEmpty;
//         });
//       },
//       onNextStep: () {
//         setState(() {
//           _expandedSection = 5;
//         });
//       },
//       onPreviousStep: () {
//         setState(() {
//           _expandedSection = 3;
//         });
//       },
//     );
//   }

//   // Pricing content
//   Widget _buildPricingContent() {
//     return _buildTicketTypesStepCompact();
//   }

//   // Preview content
//   Widget _buildPreviewContent() {
//     return _buildPreviewStepCompact();
//   }

//   // Helper methods for event details section
//   String _getEventDetailsTitle() {
//     if (_selectedEventType == null) return 'Event Details';

//     switch (_selectedEventType!) {
//       case EventType.pickupRun:
//       case EventType.openGym:
//         return 'Pickup Run Configuration';
//       case EventType.tournament:
//         return 'Tournament Configuration';
//       case EventType.donationBased:
//         return 'Fundraiser Configuration';
//       case EventType.camp:
//         return 'Camp Configuration';
//       case EventType.training:
//         return 'Training Configuration';
//       case EventType.specialEvent:
//       case EventType.oneOff:
//         return 'Special Event Configuration';
//       case EventType.oneVsOne:
//         return '1v1 Configuration';
//     }
//   }

//   String _getEventDetailsSubtitle() {
//     if (_selectedEventType == null) return 'Configure event-specific details';

//     switch (_selectedEventType!) {
//       case EventType.pickupRun:
//       case EventType.openGym:
//         return 'Set up your casual basketball game';
//       case EventType.tournament:
//         return 'Design your tournament structure';
//       case EventType.donationBased:
//         return 'Set up your charity fundraiser';
//       case EventType.camp:
//         return 'Set up your multi-day basketball camp';
//       case EventType.training:
//         return 'Configure your training session';
//       case EventType.specialEvent:
//       case EventType.oneOff:
//         return 'Make your special event memorable';
//       case EventType.oneVsOne:
//         return 'Configure your 1v1 matchup';
//     }
//   }

//   IconData _getEventDetailsIcon() {
//     if (_selectedEventType == null) return Icons.settings_rounded;

//     switch (_selectedEventType!) {
//       case EventType.pickupRun:
//       case EventType.openGym:
//         return Icons.sports_basketball_rounded;
//       case EventType.tournament:
//         return Icons.emoji_events_rounded;
//       case EventType.donationBased:
//         return Icons.favorite_rounded;
//       case EventType.camp:
//         return Icons.school_rounded;
//       case EventType.training:
//         return Icons.fitness_center_rounded;
//       case EventType.specialEvent:
//       case EventType.oneOff:
//         return Icons.star_rounded;
//       case EventType.oneVsOne:
//         return Icons.person_rounded;
//     }
//   }

//   // Check if form is complete
//   bool _isFormComplete() {
//     final isComplete = _titleController.text.isNotEmpty &&
//         _selectedStartDateTime != null &&
//         _locationController.text.isNotEmpty &&
//         _selectedEventType != null;

//     // Update preview section completion status
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (mounted) {
//         setState(() {
//           _sectionCompletion[6] = isComplete;
//         });
//       }
//     });

//     return isComplete;
//   }

//   // Compact versions of step methods for accordion sections
//   Widget _buildEventInfoStepCompact() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         // Event Title Card
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 const Color(0xFF3A3A3A),
//                 const Color(0xFF2A2A2A),
//                 const Color(0xFF1A1A1A),
//               ],
//             ),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.white.withOpacity(0.08),
//               width: 0.5,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 32,
//                     height: 32,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: const Icon(
//                       Icons.title_rounded,
//                       color: Colors.white,
//                       size: 16,
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   const Text(
//                     'Event Title',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               TextField(
//                 controller: _titleController,
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 16,
//                 ),
//                 decoration: InputDecoration(
//                   hintText: 'Give your event an exciting name...',
//                   hintStyle: TextStyle(
//                     color: Colors.white.withOpacity(0.5),
//                     fontSize: 14,
//                   ),
//                   filled: true,
//                   fillColor: Colors.white.withOpacity(0.08),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12),
//                     borderSide: BorderSide.none,
//                   ),
//                   focusedBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12),
//                     borderSide: BorderSide(
//                       color: AppColors.primaryOrange,
//                       width: 2,
//                     ),
//                   ),
//                   contentPadding: const EdgeInsets.all(12),
//                 ),
//                 onChanged: (value) {
//                   setState(() {
//                     _sectionCompletion[1] = value.isNotEmpty;
//                   });
//                 },
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),
//         // Privacy Settings Card
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 const Color(0xFF3A3A3A),
//                 const Color(0xFF2A2A2A),
//                 const Color(0xFF1A1A1A),
//               ],
//             ),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.white.withOpacity(0.08),
//               width: 0.5,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 32,
//                     height: 32,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: Icon(
//                       _isEventPrivate
//                           ? Icons.lock_rounded
//                           : Icons.public_rounded,
//                       color: Colors.white,
//                       size: 16,
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   const Text(
//                     'Event Visibility',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               Container(
//                 decoration: BoxDecoration(
//                   color: Colors.white.withOpacity(0.05),
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//                 child: SwitchListTile(
//                   contentPadding:
//                       const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
//                   title: Text(
//                     _isEventPrivate ? 'Private Event' : 'Public Event',
//                     style: const TextStyle(
//                       color: Colors.white,
//                       fontWeight: FontWeight.w500,
//                       fontSize: 14,
//                     ),
//                   ),
//                   subtitle: Text(
//                     _isEventPrivate
//                         ? 'Only invited people can see and join'
//                         : 'Anyone can discover and join this event',
//                     style: TextStyle(
//                       color: Colors.white.withOpacity(0.7),
//                       fontSize: 12,
//                     ),
//                   ),
//                   value: !_isEventPrivate,
//                   onChanged: (value) {
//                     setState(() {
//                       _isEventPrivate = !value;
//                     });
//                   },
//                   activeColor: Colors.green,
//                   inactiveThumbColor: AppColors.primaryOrange,
//                   inactiveTrackColor: AppColors.primaryOrange.withOpacity(0.3),
//                 ),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),
//         // Description Card
//         Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//               colors: [
//                 const Color(0xFF3A3A3A),
//                 const Color(0xFF2A2A2A),
//                 const Color(0xFF1A1A1A),
//               ],
//             ),
//             borderRadius: BorderRadius.circular(16),
//             border: Border.all(
//               color: Colors.white.withOpacity(0.08),
//               width: 0.5,
//             ),
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Container(
//                     width: 32,
//                     height: 32,
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: const Icon(
//                       Icons.description_rounded,
//                       color: Colors.white,
//                       size: 16,
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   const Text(
//                     'Event Description',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w600,
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 12),
//               TextField(
//                 controller: _descriptionController,
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 14,
//                   height: 1.4,
//                 ),
//                 maxLines: 3,
//                 decoration: InputDecoration(
//                   hintText:
//                       'Share what makes your event special...\n\n• What should attendees expect?\n• Any special requirements?',
//                   hintStyle: TextStyle(
//                     color: Colors.white.withOpacity(0.5),
//                     fontSize: 13,
//                     height: 1.3,
//                   ),
//                   filled: true,
//                   fillColor: Colors.white.withOpacity(0.08),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12),
//                     borderSide: BorderSide.none,
//                   ),
//                   focusedBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12),
//                     borderSide: BorderSide(
//                       color: AppColors.primaryOrange,
//                       width: 2,
//                     ),
//                   ),
//                   contentPadding: const EdgeInsets.all(12),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }

//   void _handlePreviewImageTap() {
//     showDialog(
//       context: context,
//       builder: (context) => CourtImagePicker(
//         initialImages: _eventImageUrls,
//         maxImages: 4,
//         onImagesSelected: (images) {
//           setState(() {
//             _eventImageUrls = List<String>.from(images);
//           });
//         },
//       ),
//     );
//   }

//   void _showAddImageDialog() {
//     final controller = TextEditingController();
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           backgroundColor: AppColors.secondaryBlack,
//           title: const Text(
//             'Add Image URL',
//             style: TextStyle(color: Colors.white),
//           ),
//           content: TextField(
//             controller: controller,
//             style: const TextStyle(color: Colors.white),
//             decoration: const InputDecoration(
//               hintText: 'https://...',
//               hintStyle: TextStyle(color: Colors.grey),
//             ),
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: const Text('Cancel'),
//             ),
//             TextButton(
//               onPressed: () {
//                 final url = controller.text.trim();
//                 if (url.isNotEmpty && _eventImageUrls.length < 4) {
//                   setState(() {
//                     _eventImageUrls.add(url);
//                   });
//                 }
//                 Navigator.of(context).pop();
//               },
//               child: const Text('Add'),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   Widget _buildDateTimeStepCompact() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         // Combined Date Section
//         _buildCombinedDateTimeSection(
//           title: 'Event Date',
//           icon: Icons.calendar_today,
//           startDateTime: _selectedStartDateTime,
//           endDateTime: _selectedEndDateTime,
//           isDateSection: true,
//         ),
//         const SizedBox(height: 16),
//         // Combined Time Section
//         _buildCombinedDateTimeSection(
//           title: 'Event Time',
//           icon: Icons.access_time,
//           startDateTime: _selectedStartDateTime,
//           endDateTime: _selectedEndDateTime,
//           isDateSection: false,
//         ),
//       ],
//     );
//   }

//   Widget _buildLocationStepCompact() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         EnhancedLocationSelector(
//           selectedLocation: _selectedLocation,
//           isLocationPrivate: _isLocationPrivate,
//           onLocationSelected: (location) {
//             setState(() {
//               _selectedLocation = location;
//               _sectionCompletion[3] = location != null;
//             });
//           },
//           onPrivacyChanged: (value) {
//             setState(() {
//               _isLocationPrivate = value;
//             });
//           },
//           locationController: _locationController,
//         ),
//       ],
//     );
//   }

//   Widget _buildTicketTypesStepCompact() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         RegistrationPricingForm(
//           capacityController: _capacityController,
//           isRegistrationOpen: _isRegistrationOpen,
//           onRegistrationStatusChanged: (value) {
//             setState(() {
//               _isRegistrationOpen = value;
//             });
//           },
//           ticketTypes: _ticketTypes,
//           onTicketTypesUpdated: (tickets) {
//             setState(() {
//               _ticketTypes = tickets;
//               _sectionCompletion[5] = tickets.isNotEmpty;
//             });
//           },
//           ticketNameController: _ticketNameController,
//           ticketPriceController: _ticketPriceController,
//           ticketQuantityController: _ticketQuantityController,
//           hasCustomQuestions: _hasCustomQuestions,
//           onCustomQuestionsChanged: (value) {
//             setState(() {
//               _hasCustomQuestions = value;
//             });
//           },
//           customQuestions: _customQuestions,
//           onCustomQuestionsUpdated: (questions) {
//             setState(() {
//               _customQuestions = questions;
//             });
//           },
//           questionTextController: _questionTextController,
//           questionOptionsController: _questionOptionsController,
//           hasEarlyBirdPricing: _hasEarlyBirdPricing,
//           onEarlyBirdPricingChanged: (value) {
//             setState(() {
//               _hasEarlyBirdPricing = value;
//             });
//           },
//           earlyBirdPriceController: _earlyBirdPriceController,
//           earlyBirdDeadline: _earlyBirdDeadline,
//           onEarlyBirdDeadlineSelected: (date) {
//             setState(() {
//               _earlyBirdDeadline = date;
//             });
//           },
//           requiresWaiver: _requiresWaiver,
//           onWaiverRequirementChanged: (value) {
//             setState(() {
//               _requiresWaiver = value;
//             });
//           },
//           waiverTextController: _waiverTextController,
//           selectedWaiverTemplate: _selectedWaiverTemplate,
//           onWaiverTemplateSelected: (template) {
//             setState(() {
//               _selectedWaiverTemplate = template;
//             });
//           },
//         ),
//       ],
//     );
//   }

//   Widget _buildPreviewStepCompact() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const SizedBox(height: 8),
//         // Preview Description
//         Container(
//           padding: const EdgeInsets.all(12),
//           decoration: BoxDecoration(
//             color: AppColors.primaryOrange.withOpacity(0.1),
//             borderRadius: BorderRadius.circular(12),
//             border: Border.all(
//               color: AppColors.primaryOrange.withOpacity(0.3),
//             ),
//           ),
//           child: Row(
//             children: [
//               Icon(
//                 Icons.info_outline_rounded,
//                 color: AppColors.primaryOrange,
//                 size: 18,
//               ),
//               const SizedBox(width: 8),
//               const Expanded(
//                 child: Text(
//                   'Review your event details and publish when ready',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 13,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),
//         // Enhanced Event Preview
//         Container(
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(16),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.black.withOpacity(0.3),
//                 blurRadius: 12,
//                 offset: const Offset(0, 4),
//               ),
//             ],
//           ),
//           child: EventPreview(
//             title: _titleController.text.isNotEmpty
//                 ? _titleController.text
//                 : 'Your Event Title',
//             dateTime: _selectedStartDateTime,
//             location: _locationController.text.isNotEmpty
//                 ? _locationController.text
//                 : 'Event Location',
//             eventType: _selectedEventType,
//             isFree: _ticketTypes.isEmpty
//                 ? _isFree
//                 : _ticketTypes.every((ticket) => ticket['price'] == 0),
//             price: _ticketTypes.isEmpty
//                 ? (_isFree ? null : double.tryParse(_priceController.text))
//                 : null,
//             isPrivate: _isEventPrivate,
//             ticketTypes: _ticketTypes.isNotEmpty ? _ticketTypes : null,
//             imageUrls: _eventImageUrls.isNotEmpty ? _eventImageUrls : null,
//             onImageTap: _handlePreviewImageTap,
//             imageCount: _eventImageUrls.length,
//             maxImages: 4,
//           ),
//         ),

//         const SizedBox(height: 24),

//         // Publish Button
//         _buildPublishButton(),
//       ],
//     );
//   }

//   // Old progress indicator removed - using accordion sections now

//   Widget _buildPreviewStep() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),

//           // Modern Header with Icon
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.preview_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'Review your event',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),

//           const SizedBox(height: 32),

//           // Preview Description
//           Container(
//             padding: const EdgeInsets.all(16),
//             decoration: BoxDecoration(
//               color: AppColors.primaryOrange.withOpacity(0.1),
//               borderRadius: BorderRadius.circular(16),
//               border: Border.all(
//                 color: AppColors.primaryOrange.withOpacity(0.3),
//               ),
//             ),
//             child: Row(
//               children: [
//                 Icon(
//                   Icons.info_outline_rounded,
//                   color: AppColors.primaryOrange,
//                   size: 20,
//                 ),
//                 const SizedBox(width: 12),
//                 const Expanded(
//                   child: Text(
//                     'This is how your event will appear to others',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 14,
//                       fontWeight: FontWeight.w500,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),

//           const SizedBox(height: 24),

//           // Enhanced Event Preview
//           Container(
//             decoration: BoxDecoration(
//               borderRadius: BorderRadius.circular(24),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.3),
//                   blurRadius: 20,
//                   offset: const Offset(0, 8),
//                 ),
//               ],
//             ),
//             child: EventPreview(
//               title: _titleController.text,
//               dateTime: _selectedStartDateTime,
//               location: _locationController.text,
//               eventType: _selectedEventType,
//               isFree: _isFree,
//               price: _isFree ? null : double.tryParse(_priceController.text),
//               isPrivate: _isEventPrivate,
//             ),
//           ),

//           const SizedBox(height: 32),

//           // Event Summary Cards
//           if (_titleController.text.isNotEmpty ||
//               _descriptionController.text.isNotEmpty ||
//               _selectedStartDateTime != null ||
//               _locationController.text.isNotEmpty) ...[
//             const Text(
//               'Event Summary',
//               style: TextStyle(
//                 color: Colors.white,
//                 fontSize: 20,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             const SizedBox(height: 16),

//             // Summary Grid
//             Column(
//               children: [
//                 if (_titleController.text.isNotEmpty)
//                   _buildSummaryItem(
//                     Icons.title_rounded,
//                     'Title',
//                     _titleController.text,
//                   ),
//                 if (_selectedEventType != null)
//                   _buildSummaryItem(
//                     Icons.category_rounded,
//                     'Event Type',
//                     _selectedEventType!.displayName,
//                   ),
//                 if (_selectedStartDateTime != null)
//                   _buildSummaryItem(
//                     Icons.schedule_rounded,
//                     'Date & Time',
//                     '${_selectedStartDateTime!.day}/${_selectedStartDateTime!.month}/${_selectedStartDateTime!.year} at ${_selectedStartDateTime!.hour.toString().padLeft(2, '0')}:${_selectedStartDateTime!.minute.toString().padLeft(2, '0')}',
//                   ),
//                 if (_locationController.text.isNotEmpty)
//                   _buildSummaryItem(
//                     Icons.location_on_rounded,
//                     'Location',
//                     _locationController.text,
//                   ),
//                 _buildSummaryItem(
//                   _isEventPrivate ? Icons.lock_rounded : Icons.public_rounded,
//                   'Visibility',
//                   _isEventPrivate ? 'Private Event' : 'Public Event',
//                 ),
//                 if (_isRecurringEvent && _selectedRecurringDays.isNotEmpty)
//                   _buildSummaryItem(
//                     Icons.repeat_rounded,
//                     'Recurring Event',
//                     _getRecurringDaysText(),
//                   ),
//                 if (_descriptionController.text.isNotEmpty)
//                   _buildSummaryItem(
//                     Icons.description_rounded,
//                     'Description',
//                     _descriptionController.text.length > 100
//                         ? '${_descriptionController.text.substring(0, 100)}...'
//                         : _descriptionController.text,
//                   ),
//               ],
//             ),
//           ],

//           const SizedBox(height: 40),
//         ],
//       ),
//     );
//   }

//   Widget _buildSummaryItem(IconData icon, String label, String value) {
//     return Container(
//       margin: const EdgeInsets.only(bottom: 12),
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: AppColors.secondaryBlack,
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: AppColors.darkGray.withOpacity(0.3)),
//       ),
//       child: Row(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Container(
//             padding: const EdgeInsets.all(8),
//             decoration: BoxDecoration(
//               color: AppColors.primaryOrange.withOpacity(0.2),
//               borderRadius: BorderRadius.circular(8),
//             ),
//             child: Icon(
//               icon,
//               color: AppColors.primaryOrange,
//               size: 16,
//             ),
//           ),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   label,
//                   style: TextStyle(
//                     color: Colors.white.withOpacity(0.7),
//                     fontSize: 12,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//                 const SizedBox(height: 4),
//                 Text(
//                   value,
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 14,
//                     fontWeight: FontWeight.w600,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildPublishButton() {
//     return Container(
//       width: double.infinity,
//       decoration: BoxDecoration(
//         gradient: AppColors.orangeGradient,
//         borderRadius: BorderRadius.circular(16),
//         boxShadow: [
//           BoxShadow(
//             color: AppColors.primaryOrange.withOpacity(0.3),
//             blurRadius: 12,
//             offset: const Offset(0, 4),
//           ),
//         ],
//       ),
//       child: ElevatedButton.icon(
//         onPressed: _createEvent,
//         style: ElevatedButton.styleFrom(
//           padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(16),
//           ),
//           backgroundColor: Colors.transparent,
//           elevation: 0,
//           shadowColor: Colors.transparent,
//         ),
//         icon: const Icon(
//           Icons.publish_rounded,
//           color: Colors.white,
//           size: 20,
//         ),
//         label: const Text(
//           'Publish Event',
//           style: TextStyle(
//             color: Colors.white,
//             fontSize: 16,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildBottomBar() {
//     // Only show publish button when preview section is expanded and form is complete
//     if (_expandedSection == 6 && _isFormComplete()) {
//       return Container(
//         padding: const EdgeInsets.all(16),
//         decoration: BoxDecoration(
//           color: AppColors.primaryBlack,
//           border: Border(
//             top: BorderSide(color: AppColors.darkGray, width: 1),
//           ),
//         ),
//         child: SizedBox(
//           width: double.infinity,
//           child: Container(
//             decoration: BoxDecoration(
//               gradient: AppColors.orangeGradient,
//               borderRadius: BorderRadius.circular(24),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.orange.withOpacity(0.3),
//                   blurRadius: 8,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: ElevatedButton(
//               onPressed: _createEvent,
//               style: ElevatedButton.styleFrom(
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(24),
//                 ),
//                 backgroundColor: Colors.transparent,
//                 elevation: 0,
//                 shadowColor: Colors.transparent,
//               ),
//               child: const Text(
//                 'Create Event',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ),
//       );
//     }
//     return const SizedBox.shrink();
//   }

//   // Old step navigation methods removed - using accordion sections now

//   // _saveDraft method removed - no longer needed

//   void _createEvent() {
//     // Collect all the event data
//     Map<String, dynamic> eventData = {
//       'title': _titleController.text,
//       'description': _descriptionController.text,
//       'location': _locationController.text,
//       'startDateTime': _selectedStartDateTime,
//       'endDateTime': _selectedEndDateTime,
//       'eventType': _selectedEventType,
//       'isPrivate': _isEventPrivate,
//       'isLocationPrivate': _isLocationPrivate,
//       'isFree': _isFree && _ticketTypes.isEmpty,
//       'price': _isFree ? null : double.tryParse(_priceController.text),
//       'eventTypeSpecificData': _eventTypeSpecificData,
//       // Recurring event data
//       'isRecurringEvent': _isRecurringEvent,
//       'recurringDays': _selectedRecurringDays,
//       'registrationData': {
//         'isRegistrationOpen': _isRegistrationOpen,
//         'capacityLimit': _capacityController.text,
//         'ticketTypes': _ticketTypes,
//         // Legacy pricing fields (kept for backward compatibility)
//         'hasEarlyBirdPricing': _hasEarlyBirdPricing,
//         'earlyBirdPrice': _earlyBirdPriceController.text,
//         'earlyBirdDeadline': _earlyBirdDeadline,
//         'requiresWaiver': _requiresWaiver,
//         'selectedWaiverTemplate': _selectedWaiverTemplate,
//         'hasCustomQuestions': _hasCustomQuestions,
//         'customQuestions': _customQuestions,
//       }
//     };

//     // Use eventData for API calls or database operations
//     print('Event created with data: $eventData');

//     // Generate event ID and share URL
//     final eventId = 'event-${DateTime.now().millisecondsSinceEpoch}';
//     final shareUrl = 'https://checkup.app/event/$eventId';

//     // Create event content for sharing
//     final eventTitle = _titleController.text.isNotEmpty
//         ? _titleController.text
//         : 'New ${_selectedEventType?.displayName ?? 'Event'}';

//     final eventContent = _descriptionController.text.isNotEmpty
//         ? _descriptionController.text
//         : 'Join us for this exciting ${_selectedEventType?.displayName.toLowerCase() ?? 'event'}!';

//     // Show share modal instead of just a success message
//     _showEventShareModal(eventId, eventTitle, eventContent, shareUrl);
//   }

//   void _showEventShareModal(
//       String eventId, String eventTitle, String eventContent, String shareUrl) {
//     EventShareModal.show(
//       context: context,
//       eventId: eventId,
//       eventContent: '$eventTitle - $eventContent',
//       shareUrl: shareUrl,
//       onClose: () {
//         // After sharing, take host directly to the event detail page
//         Navigator.of(context).pushReplacement(
//           MaterialPageRoute(
//             builder: (context) => HostEventDetailPage(
//               eventId: eventId,
//               title: eventTitle,
//             ),
//           ),
//         );
//       },
//     );
//   }

//   Widget _buildEventInfoStep() {
//     return SingleChildScrollView(
//       physics: const AlwaysScrollableScrollPhysics(),
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),

//           // Modern Header with Icon
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.edit_note_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'Tell us about your event',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),

//           const SizedBox(height: 40),

//           // Event Title Card
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//               borderRadius: BorderRadius.circular(20),
//               border: Border.all(
//                 color: Colors.white.withOpacity(0.08),
//                 width: 0.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.white.withOpacity(0.03),
//                   blurRadius: 1,
//                   offset: const Offset(0, 1),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.4),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     Container(
//                       width: 36,
//                       height: 36,
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [
//                             Colors.orange.shade400,
//                             Colors.deepOrange.shade600,
//                           ],
//                         ),
//                         borderRadius: BorderRadius.circular(10),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.orange.withOpacity(0.3),
//                             blurRadius: 6,
//                             offset: const Offset(0, 2),
//                           ),
//                         ],
//                       ),
//                       child: const Icon(
//                         Icons.title_rounded,
//                         color: Colors.white,
//                         size: 18,
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     const Text(
//                       'Event Title',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 18,
//                         fontWeight: FontWeight.w700,
//                         letterSpacing: 0.3,
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
//                 TextField(
//                   controller: _titleController,
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                     fontWeight: FontWeight.w500,
//                   ),
//                   decoration: InputDecoration(
//                     hintText: 'Give your event an exciting name...',
//                     hintStyle: TextStyle(
//                       color: Colors.white.withOpacity(0.5),
//                       fontSize: 16,
//                     ),
//                     filled: true,
//                     fillColor: Colors.white.withOpacity(0.08),
//                     border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(16),
//                       borderSide: BorderSide.none,
//                     ),
//                     focusedBorder: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(16),
//                       borderSide: BorderSide(
//                         color: AppColors.primaryOrange,
//                         width: 2,
//                       ),
//                     ),
//                     contentPadding: const EdgeInsets.all(16),
//                   ),
//                 ),
//               ],
//             ),
//           ),

//           const SizedBox(height: 24),

//           // Privacy Settings Card
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//               borderRadius: BorderRadius.circular(20),
//               border: Border.all(
//                 color: Colors.white.withOpacity(0.08),
//                 width: 0.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.white.withOpacity(0.03),
//                   blurRadius: 1,
//                   offset: const Offset(0, 1),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.4),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     Container(
//                       width: 36,
//                       height: 36,
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [
//                             Colors.orange.shade400,
//                             Colors.deepOrange.shade600,
//                           ],
//                         ),
//                         borderRadius: BorderRadius.circular(10),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.orange.withOpacity(0.3),
//                             blurRadius: 6,
//                             offset: const Offset(0, 2),
//                           ),
//                         ],
//                       ),
//                       child: Icon(
//                         _isEventPrivate
//                             ? Icons.lock_rounded
//                             : Icons.public_rounded,
//                         color: Colors.white,
//                         size: 18,
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     const Text(
//                       'Event Visibility',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 18,
//                         fontWeight: FontWeight.w700,
//                         letterSpacing: 0.3,
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
//                 Container(
//                   decoration: BoxDecoration(
//                     color: Colors.white.withOpacity(0.05),
//                     borderRadius: BorderRadius.circular(16),
//                     border: Border.all(
//                       color: _isEventPrivate
//                           ? AppColors.primaryOrange.withOpacity(0.3)
//                           : Colors.green.withOpacity(0.3),
//                     ),
//                   ),
//                   child: SwitchListTile(
//                     contentPadding:
//                         const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
//                     title: Text(
//                       _isEventPrivate ? 'Private Event' : 'Public Event',
//                       style: const TextStyle(
//                         color: Colors.white,
//                         fontWeight: FontWeight.w600,
//                         fontSize: 16,
//                       ),
//                     ),
//                     subtitle: Text(
//                       _isEventPrivate
//                           ? 'Only invited people can see and join'
//                           : 'Anyone can discover and join this event',
//                       style: TextStyle(
//                         color: Colors.white.withOpacity(0.7),
//                         fontSize: 14,
//                       ),
//                     ),
//                     value: !_isEventPrivate,
//                     onChanged: (value) {
//                       setState(() {
//                         _isEventPrivate = !value;
//                       });
//                     },
//                     activeColor: Colors.green,
//                     inactiveThumbColor: AppColors.primaryOrange,
//                     inactiveTrackColor:
//                         AppColors.primaryOrange.withOpacity(0.3),
//                   ),
//                 ),
//               ],
//             ),
//           ),

//           const SizedBox(height: 24),

//           // Description Card
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//               borderRadius: BorderRadius.circular(20),
//               border: Border.all(
//                 color: Colors.white.withOpacity(0.08),
//                 width: 0.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.white.withOpacity(0.03),
//                   blurRadius: 1,
//                   offset: const Offset(0, 1),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.4),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     Container(
//                       width: 36,
//                       height: 36,
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [
//                             Colors.orange.shade400,
//                             Colors.deepOrange.shade600,
//                           ],
//                         ),
//                         borderRadius: BorderRadius.circular(10),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.orange.withOpacity(0.3),
//                             blurRadius: 6,
//                             offset: const Offset(0, 2),
//                           ),
//                         ],
//                       ),
//                       child: const Icon(
//                         Icons.description_rounded,
//                         color: Colors.white,
//                         size: 18,
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     const Text(
//                       'Event Description',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 18,
//                         fontWeight: FontWeight.w700,
//                         letterSpacing: 0.3,
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
//                 TextField(
//                   controller: _descriptionController,
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                     height: 1.5,
//                   ),
//                   maxLines: 4,
//                   decoration: InputDecoration(
//                     hintText:
//                         'Share what makes your event special...\n\n• What should attendees expect?\n• Any special requirements?',
//                     hintStyle: TextStyle(
//                       color: Colors.white.withOpacity(0.5),
//                       fontSize: 15,
//                       height: 1.4,
//                     ),
//                     filled: true,
//                     fillColor: Colors.white.withOpacity(0.08),
//                     border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(16),
//                       borderSide: BorderSide.none,
//                     ),
//                     focusedBorder: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(16),
//                       borderSide: BorderSide(
//                         color: AppColors.primaryOrange,
//                         width: 2,
//                       ),
//                     ),
//                     contentPadding: const EdgeInsets.all(16),
//                   ),
//                 ),
//               ],
//             ),
//           ),

//           const SizedBox(height: 40),

//           // Extra bottom padding for mobile scrolling
//           SizedBox(height: MediaQuery.of(context).viewInsets.bottom + 100),
//         ],
//       ),
//     );
//   }

//   // _buildTitleStep removed - using accordion sections now

//   // _buildDescriptionStep removed - using accordion sections now

//   Widget _buildDateTimeStep() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),

//           // Modern Header with Icon
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.schedule_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'When is your event?',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),

//           const SizedBox(height: 30),

//           // Combined Date Section
//           _buildCombinedDateTimeSection(
//             title: 'Event Date',
//             icon: Icons.calendar_today,
//             startDateTime: _selectedStartDateTime,
//             endDateTime: _selectedEndDateTime,
//             isDateSection: true,
//           ),

//           const SizedBox(height: 20),

//           // Combined Time Section
//           _buildCombinedDateTimeSection(
//             title: 'Event Time',
//             icon: Icons.access_time,
//             startDateTime: _selectedStartDateTime,
//             endDateTime: _selectedEndDateTime,
//             isDateSection: false,
//           ),

//           const SizedBox(height: 20),

//           // Recurring Events Toggle
//           Container(
//             width: double.infinity,
//             decoration: BoxDecoration(
//               gradient: LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//               borderRadius: BorderRadius.circular(16),
//               border: Border.all(
//                 color: Colors.white.withOpacity(0.08),
//                 width: 0.5,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.white.withOpacity(0.03),
//                   blurRadius: 1,
//                   offset: const Offset(0, 1),
//                 ),
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.4),
//                   blurRadius: 12,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Padding(
//               padding: const EdgeInsets.all(24),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Row(
//                     children: [
//                       Container(
//                         width: 36,
//                         height: 36,
//                         decoration: BoxDecoration(
//                           gradient: LinearGradient(
//                             colors: [
//                               Colors.orange.shade400,
//                               Colors.deepOrange.shade600,
//                             ],
//                           ),
//                           borderRadius: BorderRadius.circular(10),
//                           boxShadow: [
//                             BoxShadow(
//                               color: Colors.orange.withOpacity(0.3),
//                               blurRadius: 6,
//                               offset: const Offset(0, 2),
//                             ),
//                           ],
//                         ),
//                         child: const Icon(
//                           Icons.repeat_rounded,
//                           color: Colors.white,
//                           size: 18,
//                         ),
//                       ),
//                       const SizedBox(width: 12),
//                       const Expanded(
//                         child: Text(
//                           'Recurring Event',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 18,
//                             fontWeight: FontWeight.w700,
//                             letterSpacing: 0.3,
//                           ),
//                         ),
//                       ),
//                       // Modern Toggle Switch
//                       GestureDetector(
//                         onTap: () {
//                           setState(() {
//                             _isRecurringEvent = !_isRecurringEvent;
//                             if (!_isRecurringEvent) {
//                               _selectedRecurringDays.clear();
//                             }
//                           });
//                         },
//                         child: AnimatedContainer(
//                           duration: const Duration(milliseconds: 200),
//                           width: 56,
//                           height: 32,
//                           decoration: BoxDecoration(
//                             gradient: _isRecurringEvent
//                                 ? LinearGradient(
//                                     colors: [
//                                       Colors.orange.shade400,
//                                       Colors.deepOrange.shade600,
//                                     ],
//                                   )
//                                 : null,
//                             color:
//                                 _isRecurringEvent ? null : Colors.grey.shade700,
//                             borderRadius: BorderRadius.circular(16),
//                             boxShadow: [
//                               BoxShadow(
//                                 color: _isRecurringEvent
//                                     ? Colors.orange.withOpacity(0.3)
//                                     : Colors.black.withOpacity(0.2),
//                                 blurRadius: 4,
//                                 offset: const Offset(0, 2),
//                               ),
//                             ],
//                           ),
//                           child: AnimatedAlign(
//                             duration: const Duration(milliseconds: 200),
//                             alignment: _isRecurringEvent
//                                 ? Alignment.centerRight
//                                 : Alignment.centerLeft,
//                             child: Container(
//                               width: 28,
//                               height: 28,
//                               margin: const EdgeInsets.all(2),
//                               decoration: BoxDecoration(
//                                 color: Colors.white,
//                                 borderRadius: BorderRadius.circular(14),
//                                 boxShadow: [
//                                   BoxShadow(
//                                     color: Colors.black.withOpacity(0.2),
//                                     blurRadius: 3,
//                                     offset: const Offset(0, 1),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   const SizedBox(height: 16),
//                   Text(
//                     _isRecurringEvent
//                         ? 'This event will repeat on selected days'
//                         : 'Enable to make this a recurring event',
//                     style: TextStyle(
//                       color: Colors.white.withOpacity(0.7),
//                       fontSize: 14,
//                       fontWeight: FontWeight.normal,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),

//           // Days of Week Selection (only show when recurring is enabled)
//           if (_isRecurringEvent) ...[
//             const SizedBox(height: 20),
//             Container(
//               width: double.infinity,
//               decoration: BoxDecoration(
//                 gradient: LinearGradient(
//                   begin: Alignment.topLeft,
//                   end: Alignment.bottomRight,
//                   colors: [
//                     const Color(0xFF3A3A3A),
//                     const Color(0xFF2A2A2A),
//                     const Color(0xFF1A1A1A),
//                     const Color(0xFF0A0A0A),
//                   ],
//                   stops: const [0.0, 0.3, 0.7, 1.0],
//                 ),
//                 borderRadius: BorderRadius.circular(16),
//                 border: Border.all(
//                   color: Colors.white.withOpacity(0.08),
//                   width: 0.5,
//                 ),
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.white.withOpacity(0.03),
//                     blurRadius: 1,
//                     offset: const Offset(0, 1),
//                   ),
//                   BoxShadow(
//                     color: Colors.black.withOpacity(0.4),
//                     blurRadius: 12,
//                     offset: const Offset(0, 4),
//                   ),
//                 ],
//               ),
//               child: Padding(
//                 padding: const EdgeInsets.all(24),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Row(
//                       children: [
//                         Container(
//                           width: 36,
//                           height: 36,
//                           decoration: BoxDecoration(
//                             gradient: LinearGradient(
//                               colors: [
//                                 Colors.orange.shade400,
//                                 Colors.deepOrange.shade600,
//                               ],
//                             ),
//                             borderRadius: BorderRadius.circular(10),
//                             boxShadow: [
//                               BoxShadow(
//                                 color: Colors.orange.withOpacity(0.3),
//                                 blurRadius: 6,
//                                 offset: const Offset(0, 2),
//                               ),
//                             ],
//                           ),
//                           child: const Icon(
//                             Icons.date_range_rounded,
//                             color: Colors.white,
//                             size: 18,
//                           ),
//                         ),
//                         const SizedBox(width: 12),
//                         const Text(
//                           'Select Days',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 18,
//                             fontWeight: FontWeight.w700,
//                             letterSpacing: 0.3,
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(height: 20),
//                     // Days of the week grid
//                     _buildDaysOfWeekSelector(),
//                   ],
//                 ),
//               ),
//             ),
//           ],

//           const SizedBox(height: 40),
//         ],
//       ),
//     );
//   }

//   Widget _buildCombinedDateTimeSection({
//     required String title,
//     required IconData icon,
//     required DateTime? startDateTime,
//     required DateTime? endDateTime,
//     required bool isDateSection,
//   }) {
//     final bool hasStartSelection = startDateTime != null;
//     final bool hasEndSelection = endDateTime != null;
//     final bool hasAnySelection = hasStartSelection || hasEndSelection;

//     return Container(
//       width: double.infinity,
//       decoration: BoxDecoration(
//         gradient: hasAnySelection
//             ? LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   Colors.orange.shade400.withOpacity(0.2),
//                   Colors.deepOrange.shade600.withOpacity(0.2),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                 ],
//                 stops: const [0.0, 0.15, 0.5, 1.0],
//               )
//             : LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(
//           color: hasAnySelection
//               ? Colors.orange.withOpacity(0.3)
//               : Colors.white.withOpacity(0.08),
//           width: hasAnySelection ? 1.5 : 0.5,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: hasAnySelection
//                 ? Colors.orange.withOpacity(0.15)
//                 : Colors.white.withOpacity(0.03),
//             blurRadius: hasAnySelection ? 8 : 1,
//             offset: Offset(0, hasAnySelection ? 3 : 1),
//           ),
//           BoxShadow(
//             color: Colors.black.withOpacity(0.4),
//             blurRadius: 12,
//             offset: const Offset(0, 4),
//           ),
//         ],
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(20),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // Header
//             Row(
//               children: [
//                 Container(
//                   width: 32,
//                   height: 32,
//                   decoration: BoxDecoration(
//                     gradient: hasAnySelection
//                         ? LinearGradient(
//                             colors: [
//                               Colors.orange.shade400,
//                               Colors.deepOrange.shade600,
//                             ],
//                           )
//                         : LinearGradient(
//                             colors: [
//                               Colors.grey.shade600,
//                               Colors.grey.shade700,
//                             ],
//                           ),
//                     borderRadius: BorderRadius.circular(8),
//                     boxShadow: [
//                       BoxShadow(
//                         color: hasAnySelection
//                             ? Colors.orange.withOpacity(0.3)
//                             : Colors.black.withOpacity(0.2),
//                         blurRadius: 4,
//                         offset: const Offset(0, 2),
//                       ),
//                     ],
//                   ),
//                   child: Icon(
//                     icon,
//                     color: Colors.white,
//                     size: 16,
//                   ),
//                 ),
//                 const SizedBox(width: 12),
//                 Text(
//                   title,
//                   style: TextStyle(
//                     color: hasAnySelection
//                         ? Colors.white
//                         : Colors.white.withOpacity(0.9),
//                     fontSize: 18,
//                     fontWeight: FontWeight.w700,
//                     letterSpacing: 0.3,
//                   ),
//                 ),
//               ],
//             ),
//             const SizedBox(height: 16),

//             // Start and End sections in a row
//             Row(
//               children: [
//                 // Start section
//                 Expanded(
//                   child: GestureDetector(
//                     onTap: () {
//                       if (isDateSection) {
//                         _showModernDatePicker(isStartDate: true);
//                       } else {
//                         _showModernTimePicker(isStartTime: true);
//                       }
//                     },
//                     child: Container(
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         color: hasStartSelection
//                             ? Colors.orange.withOpacity(0.1)
//                             : Colors.white.withOpacity(0.05),
//                         borderRadius: BorderRadius.circular(12),
//                         border: Border.all(
//                           color: hasStartSelection
//                               ? Colors.orange.withOpacity(0.3)
//                               : Colors.white.withOpacity(0.1),
//                           width: 1,
//                         ),
//                       ),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             'Start',
//                             style: TextStyle(
//                               color: Colors.white.withOpacity(0.7),
//                               fontSize: 12,
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             hasStartSelection
//                                 ? (isDateSection
//                                     ? '${_getMonthName(startDateTime!.month)} ${startDateTime!.day}'
//                                     : _formatTime12Hour(startDateTime!))
//                                 : (isDateSection
//                                     ? 'Select date'
//                                     : 'Select time'),
//                             style: TextStyle(
//                               color: hasStartSelection
//                                   ? Colors.white
//                                   : Colors.white.withOpacity(0.6),
//                               fontSize: hasStartSelection ? 16 : 14,
//                               fontWeight: hasStartSelection
//                                   ? FontWeight.w600
//                                   : FontWeight.normal,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),

//                 const SizedBox(width: 12),

//                 // End section
//                 Expanded(
//                   child: GestureDetector(
//                     onTap: () {
//                       if (isDateSection) {
//                         _showModernDatePicker(isStartDate: false);
//                       } else {
//                         _showModernTimePicker(isStartTime: false);
//                       }
//                     },
//                     child: Container(
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         color: hasEndSelection
//                             ? Colors.orange.withOpacity(0.1)
//                             : Colors.white.withOpacity(0.05),
//                         borderRadius: BorderRadius.circular(12),
//                         border: Border.all(
//                           color: hasEndSelection
//                               ? Colors.orange.withOpacity(0.3)
//                               : Colors.white.withOpacity(0.1),
//                           width: 1,
//                         ),
//                       ),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             'End',
//                             style: TextStyle(
//                               color: Colors.white.withOpacity(0.7),
//                               fontSize: 12,
//                               fontWeight: FontWeight.w500,
//                             ),
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             hasEndSelection
//                                 ? (isDateSection
//                                     ? '${_getMonthName(endDateTime!.month)} ${endDateTime!.day}'
//                                     : _formatTime12Hour(endDateTime!))
//                                 : (isDateSection
//                                     ? 'Select date'
//                                     : 'Select time'),
//                             style: TextStyle(
//                               color: hasEndSelection
//                                   ? Colors.white
//                                   : Colors.white.withOpacity(0.6),
//                               fontSize: hasEndSelection ? 16 : 14,
//                               fontWeight: hasEndSelection
//                                   ? FontWeight.w600
//                                   : FontWeight.normal,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildDateTimeCard({
//     required String title,
//     required IconData icon,
//     required DateTime? selectedDateTime,
//     required VoidCallback onTap,
//     required bool isDateCard,
//   }) {
//     final bool hasSelection = selectedDateTime != null;

//     return Container(
//       width: double.infinity,
//       decoration: BoxDecoration(
//         gradient: hasSelection
//             ? LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   Colors.orange.shade400.withOpacity(0.3),
//                   Colors.deepOrange.shade600.withOpacity(0.3),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                 ],
//                 stops: const [0.0, 0.2, 0.6, 1.0],
//               )
//             : LinearGradient(
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//                 colors: [
//                   const Color(0xFF3A3A3A),
//                   const Color(0xFF2A2A2A),
//                   const Color(0xFF1A1A1A),
//                   const Color(0xFF0A0A0A),
//                 ],
//                 stops: const [0.0, 0.3, 0.7, 1.0],
//               ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(
//           color: hasSelection
//               ? Colors.orange.withOpacity(0.3)
//               : Colors.white.withOpacity(0.08),
//           width: hasSelection ? 1.5 : 0.5,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: hasSelection
//                 ? Colors.orange.withOpacity(0.2)
//                 : Colors.white.withOpacity(0.03),
//             blurRadius: hasSelection ? 8 : 1,
//             offset: Offset(0, hasSelection ? 3 : 1),
//           ),
//           BoxShadow(
//             color: Colors.black.withOpacity(0.4),
//             blurRadius: 12,
//             offset: const Offset(0, 4),
//           ),
//         ],
//       ),
//       child: Material(
//         color: Colors.transparent,
//         child: InkWell(
//           onTap: onTap,
//           borderRadius: BorderRadius.circular(16),
//           child: Padding(
//             padding: const EdgeInsets.all(24),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     Container(
//                       width: 36,
//                       height: 36,
//                       decoration: BoxDecoration(
//                         gradient: hasSelection
//                             ? LinearGradient(
//                                 colors: [
//                                   Colors.orange.shade400,
//                                   Colors.deepOrange.shade600,
//                                 ],
//                               )
//                             : LinearGradient(
//                                 colors: [
//                                   Colors.grey.shade600,
//                                   Colors.grey.shade700,
//                                 ],
//                               ),
//                         borderRadius: BorderRadius.circular(10),
//                         boxShadow: [
//                           BoxShadow(
//                             color: hasSelection
//                                 ? Colors.orange.withOpacity(0.3)
//                                 : Colors.black.withOpacity(0.2),
//                             blurRadius: 6,
//                             offset: const Offset(0, 2),
//                           ),
//                         ],
//                       ),
//                       child: Icon(
//                         icon,
//                         color: Colors.white,
//                         size: 18,
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     Text(
//                       title,
//                       style: TextStyle(
//                         color: hasSelection
//                             ? Colors.white
//                             : Colors.white.withOpacity(0.9),
//                         fontSize: 18,
//                         fontWeight: FontWeight.w700,
//                         letterSpacing: 0.3,
//                       ),
//                     ),
//                     const Spacer(),
//                     Icon(
//                       Icons.arrow_forward_ios,
//                       color: hasSelection
//                           ? Colors.orange.withOpacity(0.8)
//                           : Colors.white.withOpacity(0.6),
//                       size: 16,
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 16),
//                 Text(
//                   hasSelection
//                       ? (isDateCard
//                           ? '${_getMonthName(selectedDateTime!.month)} ${selectedDateTime!.day}, ${selectedDateTime!.year}'
//                           : _formatTime12Hour(selectedDateTime!))
//                       : (isDateCard
//                           ? 'Tap to select date'
//                           : 'Tap to select time'),
//                   style: TextStyle(
//                     color: hasSelection
//                         ? Colors.white
//                         : Colors.white.withOpacity(0.7),
//                     fontSize: hasSelection ? 20 : 16,
//                     fontWeight:
//                         hasSelection ? FontWeight.w600 : FontWeight.normal,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildDaysOfWeekSelector() {
//     final days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

//     return Wrap(
//       spacing: 12,
//       runSpacing: 12,
//       children: List.generate(7, (index) {
//         final isSelected = _selectedRecurringDays.contains(index);

//         return GestureDetector(
//           onTap: () {
//             setState(() {
//               if (isSelected) {
//                 _selectedRecurringDays.remove(index);
//               } else {
//                 _selectedRecurringDays.add(index);
//               }
//             });
//           },
//           child: AnimatedContainer(
//             duration: const Duration(milliseconds: 200),
//             width: 48,
//             height: 48,
//             decoration: BoxDecoration(
//               gradient: isSelected
//                   ? LinearGradient(
//                       colors: [
//                         Colors.orange.shade400,
//                         Colors.deepOrange.shade600,
//                       ],
//                     )
//                   : null,
//               color: isSelected ? null : Colors.grey.shade800,
//               borderRadius: BorderRadius.circular(12),
//               border: Border.all(
//                 color: isSelected
//                     ? Colors.orange.withOpacity(0.5)
//                     : Colors.white.withOpacity(0.1),
//                 width: 1,
//               ),
//               boxShadow: [
//                 BoxShadow(
//                   color: isSelected
//                       ? Colors.orange.withOpacity(0.3)
//                       : Colors.black.withOpacity(0.2),
//                   blurRadius: isSelected ? 6 : 3,
//                   offset: const Offset(0, 2),
//                 ),
//               ],
//             ),
//             child: Center(
//               child: Text(
//                 days[index],
//                 style: TextStyle(
//                   color:
//                       isSelected ? Colors.white : Colors.white.withOpacity(0.7),
//                   fontSize: 14,
//                   fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
//                 ),
//               ),
//             ),
//           ),
//         );
//       }),
//     );
//   }

//   Widget _buildLocationStep() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),

//           // Modern Header with Icon
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.location_on_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'Where is your event taking place?',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),

//           const SizedBox(height: 40),

//           EnhancedLocationSelector(
//             selectedLocation: _selectedLocation,
//             isLocationPrivate: _isLocationPrivate,
//             onLocationSelected: (location) {
//               setState(() {
//                 _selectedLocation = location;
//               });
//             },
//             onPrivacyChanged: (value) {
//               setState(() {
//                 _isLocationPrivate = value;
//               });
//             },
//             locationController: _locationController,
//           ),

//           const SizedBox(height: 40),
//         ],
//       ),
//     );
//   }

//   // _buildPrivacyStep removed - using accordion sections now

//   // _buildRegistrationStep removed - using accordion sections now

//   Widget _buildTicketTypesStep() {
//     return SingleChildScrollView(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 20),

//           // Modern Header with Icon
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   gradient: AppColors.orangeGradient,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.orange.withOpacity(0.3),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: const Icon(
//                   Icons.confirmation_number_rounded,
//                   color: Colors.white,
//                   size: 28,
//                 ),
//               ),
//               const SizedBox(width: 16),
//               const Expanded(
//                 child: Text(
//                   'Event Pricing',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     height: 1.2,
//                   ),
//                 ),
//               ),
//             ],
//           ),

//           const SizedBox(height: 8),

//           // Pricing Form Container
//           Container(
//             constraints: const BoxConstraints(minHeight: 400),
//             child: RegistrationPricingForm(
//               // Registration settings
//               capacityController: _capacityController,
//               isRegistrationOpen: _isRegistrationOpen,
//               onRegistrationStatusChanged: (value) {
//                 setState(() {
//                   _isRegistrationOpen = value;
//                 });
//               },

//               // Ticket types settings
//               ticketTypes: _ticketTypes,
//               onTicketTypesUpdated: (tickets) {
//                 setState(() {
//                   _ticketTypes = tickets;
//                 });
//               },
//               ticketNameController: _ticketNameController,
//               ticketPriceController: _ticketPriceController,
//               ticketQuantityController: _ticketQuantityController,

//               // Custom questions settings
//               hasCustomQuestions: _hasCustomQuestions,
//               onCustomQuestionsChanged: (value) {
//                 setState(() {
//                   _hasCustomQuestions = value;
//                 });
//               },
//               customQuestions: _customQuestions,
//               onCustomQuestionsUpdated: (questions) {
//                 setState(() {
//                   _customQuestions = questions;
//                 });
//               },
//               questionTextController: _questionTextController,
//               questionOptionsController: _questionOptionsController,

//               // Early bird pricing settings
//               hasEarlyBirdPricing: _hasEarlyBirdPricing,
//               onEarlyBirdPricingChanged: (value) {
//                 setState(() {
//                   _hasEarlyBirdPricing = value;
//                 });
//               },
//               earlyBirdPriceController: _earlyBirdPriceController,
//               earlyBirdDeadline: _earlyBirdDeadline,
//               onEarlyBirdDeadlineSelected: (date) {
//                 setState(() {
//                   _earlyBirdDeadline = date;
//                 });
//               },

//               // Waiver settings
//               requiresWaiver: _requiresWaiver,
//               onWaiverRequirementChanged: (value) {
//                 setState(() {
//                   _requiresWaiver = value;
//                 });
//               },
//               waiverTextController: _waiverTextController,
//               selectedWaiverTemplate: _selectedWaiverTemplate,
//               onWaiverTemplateSelected: (template) {
//                 setState(() {
//                   _selectedWaiverTemplate = template;
//                 });
//               },
//             ),
//           ),
//           const SizedBox(height: 20),
//         ],
//       ),
//     );
//   }

//   // Modern, mobile-friendly date picker
//   void _showModernDatePicker({required bool isStartDate}) {
//     // Reset calendar viewing date to today when opening picker
//     _calendarViewingDate = DateTime.now();

//     showModalBottomSheet(
//       context: context,
//       isScrollControlled: true,
//       backgroundColor: Colors.transparent,
//       builder: (context) => StatefulBuilder(
//         builder: (context, setModalState) => Container(
//           height: MediaQuery.of(context).size.height * 0.6,
//           decoration: const BoxDecoration(
//             color: AppColors.primaryBlack,
//             borderRadius: BorderRadius.only(
//               topLeft: Radius.circular(24),
//               topRight: Radius.circular(24),
//             ),
//           ),
//           child: Column(
//             children: [
//               // Handle bar
//               Container(
//                 margin: const EdgeInsets.only(top: 12),
//                 width: 40,
//                 height: 4,
//                 decoration: BoxDecoration(
//                   color: Colors.white.withOpacity(0.3),
//                   borderRadius: BorderRadius.circular(2),
//                 ),
//               ),

//               // Header
//               Padding(
//                 padding: const EdgeInsets.all(24),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     const Text(
//                       'Select Date',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 20,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                     GestureDetector(
//                       onTap: () => Navigator.pop(context),
//                       child: Container(
//                         padding: const EdgeInsets.all(8),
//                         decoration: BoxDecoration(
//                           color: Colors.white.withOpacity(0.1),
//                           borderRadius: BorderRadius.circular(20),
//                         ),
//                         child: const Icon(
//                           Icons.close,
//                           color: Colors.white,
//                           size: 20,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),

//               // Calendar
//               Expanded(
//                 child: Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 24),
//                   child: _buildModernCalendar(
//                       isStartDate: isStartDate, setModalState: setModalState),
//                 ),
//               ),

//               // Done button
//               Padding(
//                 padding: const EdgeInsets.all(24),
//                 child: SizedBox(
//                   width: double.infinity,
//                   child: Container(
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(16),
//                       boxShadow: [
//                         BoxShadow(
//                           color: const Color(0xFFFF9800).withOpacity(0.4),
//                           blurRadius: 12,
//                           offset: const Offset(0, 4),
//                         ),
//                       ],
//                     ),
//                     child: ElevatedButton(
//                       onPressed: () {
//                         Navigator.pop(context);
//                       },
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.transparent,
//                         padding: const EdgeInsets.symmetric(vertical: 16),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(16),
//                         ),
//                         shadowColor: Colors.transparent,
//                       ),
//                       child: const Text(
//                         'Done',
//                         style: TextStyle(
//                           color: Colors.white,
//                           fontSize: 16,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   // Modern, mobile-friendly time picker
//   void _showModernTimePicker({required bool isStartTime}) {
//     showModalBottomSheet(
//       context: context,
//       isScrollControlled: true,
//       backgroundColor: Colors.transparent,
//       builder: (context) => StatefulBuilder(
//         builder: (context, setModalState) => Container(
//           height: MediaQuery.of(context).size.height * 0.7,
//           decoration: const BoxDecoration(
//             color: AppColors.primaryBlack,
//             borderRadius: BorderRadius.only(
//               topLeft: Radius.circular(24),
//               topRight: Radius.circular(24),
//             ),
//           ),
//           child: Column(
//             children: [
//               // Handle bar
//               Container(
//                 margin: const EdgeInsets.only(top: 12),
//                 width: 40,
//                 height: 4,
//                 decoration: BoxDecoration(
//                   color: Colors.white.withOpacity(0.3),
//                   borderRadius: BorderRadius.circular(2),
//                 ),
//               ),

//               // Header
//               Padding(
//                 padding: const EdgeInsets.all(24),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     const Text(
//                       'Select Time',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 20,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                     GestureDetector(
//                       onTap: () => Navigator.pop(context),
//                       child: Container(
//                         padding: const EdgeInsets.all(8),
//                         decoration: BoxDecoration(
//                           color: Colors.white.withOpacity(0.1),
//                           borderRadius: BorderRadius.circular(20),
//                         ),
//                         child: const Icon(
//                           Icons.close,
//                           color: Colors.white,
//                           size: 20,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),

//               // Time slots
//               Expanded(
//                 child: Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 24),
//                   child: _buildModernTimeSlots(
//                       isStartTime: isStartTime, setModalState: setModalState),
//                 ),
//               ),

//               // Done button
//               Padding(
//                 padding: const EdgeInsets.all(24),
//                 child: SizedBox(
//                   width: double.infinity,
//                   child: Container(
//                     decoration: BoxDecoration(
//                       gradient: AppColors.orangeGradient,
//                       borderRadius: BorderRadius.circular(16),
//                       boxShadow: [
//                         BoxShadow(
//                           color: const Color(0xFFFF9800).withOpacity(0.4),
//                           blurRadius: 12,
//                           offset: const Offset(0, 4),
//                         ),
//                       ],
//                     ),
//                     child: ElevatedButton(
//                       onPressed: () {
//                         Navigator.pop(context);
//                       },
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.transparent,
//                         padding: const EdgeInsets.symmetric(vertical: 16),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(16),
//                         ),
//                         shadowColor: Colors.transparent,
//                       ),
//                       child: const Text(
//                         'Done',
//                         style: TextStyle(
//                           color: Colors.white,
//                           fontSize: 16,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   // Build modern calendar widget
//   Widget _buildModernCalendar(
//       {required bool isStartDate, required StateSetter setModalState}) {
//     final now = DateTime.now();

//     // Initialize calendar viewing date to today if not set
//     if (_calendarViewingDate == null) {
//       _calendarViewingDate = now;
//     }

//     // Use calendar viewing date for display
//     final viewingDate = _calendarViewingDate!;

//     final firstDayOfMonth = DateTime(viewingDate.year, viewingDate.month, 1);
//     final lastDayOfMonth = DateTime(viewingDate.year, viewingDate.month + 1, 0);
//     final firstDayWeekday = (firstDayOfMonth.weekday - 1) % 7;
//     final daysInMonth = lastDayOfMonth.day;

//     return Column(
//       children: [
//         // Month/Year header with navigation
//         Container(
//           padding: const EdgeInsets.symmetric(vertical: 16),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               GestureDetector(
//                 onTap: () {
//                   setState(() {
//                     _calendarViewingDate =
//                         DateTime(viewingDate.year, viewingDate.month - 1, 1);
//                   });
//                   // Also update the modal state for real-time visual feedback
//                   setModalState(() {});
//                 },
//                 child: Container(
//                   padding: const EdgeInsets.all(12),
//                   decoration: BoxDecoration(
//                     color: Colors.white.withOpacity(0.1),
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: const Icon(Icons.chevron_left, color: Colors.white),
//                 ),
//               ),
//               Text(
//                 '${_getMonthName(viewingDate.month)} ${viewingDate.year}',
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//               GestureDetector(
//                 onTap: () {
//                   setState(() {
//                     _calendarViewingDate =
//                         DateTime(viewingDate.year, viewingDate.month + 1, 1);
//                   });
//                   // Also update the modal state for real-time visual feedback
//                   setModalState(() {});
//                 },
//                 child: Container(
//                   padding: const EdgeInsets.all(12),
//                   decoration: BoxDecoration(
//                     color: Colors.white.withOpacity(0.1),
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: const Icon(Icons.chevron_right, color: Colors.white),
//                 ),
//               ),
//             ],
//           ),
//         ),

//         // Day labels
//         Container(
//           padding: const EdgeInsets.symmetric(vertical: 12),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceAround,
//             children: ['S', 'M', 'T', 'W', 'T', 'F', 'S']
//                 .map((day) => Text(
//                       day,
//                       style: TextStyle(
//                         color: Colors.white.withOpacity(0.6),
//                         fontSize: 14,
//                         fontWeight: FontWeight.w600,
//                       ),
//                     ))
//                 .toList(),
//           ),
//         ),

//         // Calendar grid
//         Expanded(
//           child: GridView.builder(
//             gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//               crossAxisCount: 7,
//               childAspectRatio: 1,
//               mainAxisSpacing: 8,
//               crossAxisSpacing: 8,
//             ),
//             itemCount: firstDayWeekday + daysInMonth,
//             itemBuilder: (context, index) {
//               if (index < firstDayWeekday) {
//                 return const SizedBox();
//               }

//               final day = index - firstDayWeekday + 1;
//               final date = DateTime(viewingDate.year, viewingDate.month, day);
//               final currentDateTime =
//                   isStartDate ? _selectedStartDateTime : _selectedEndDateTime;
//               final isSelected = currentDateTime != null &&
//                   currentDateTime.year == date.year &&
//                   currentDateTime.month == date.month &&
//                   currentDateTime.day == date.day;
//               final isToday = date.year == now.year &&
//                   date.month == now.month &&
//                   date.day == now.day;
//               final isPast =
//                   date.isBefore(DateTime(now.year, now.month, now.day));

//               return GestureDetector(
//                 onTap: isPast
//                     ? null
//                     : () {
//                         setState(() {
//                           if (isStartDate) {
//                             if (_selectedStartDateTime != null) {
//                               _selectedStartDateTime = DateTime(
//                                 date.year,
//                                 date.month,
//                                 date.day,
//                                 _selectedStartDateTime!.hour,
//                                 _selectedStartDateTime!.minute,
//                               );
//                             } else {
//                               _selectedStartDateTime = DateTime(
//                                   date.year, date.month, date.day, 12, 0);
//                             }
//                           } else {
//                             if (_selectedEndDateTime != null) {
//                               _selectedEndDateTime = DateTime(
//                                 date.year,
//                                 date.month,
//                                 date.day,
//                                 _selectedEndDateTime!.hour,
//                                 _selectedEndDateTime!.minute,
//                               );
//                             } else {
//                               _selectedEndDateTime = DateTime(
//                                   date.year, date.month, date.day, 12, 0);
//                             }
//                           }
//                         });
//                         // Also update the modal state for real-time visual feedback
//                         setModalState(() {});
//                       },
//                 child: Container(
//                   decoration: BoxDecoration(
//                     gradient: isSelected
//                         ? LinearGradient(
//                             colors: [
//                               Colors.orange.shade400,
//                               Colors.deepOrange.shade600,
//                             ],
//                           )
//                         : null,
//                     color: isToday && !isSelected
//                         ? Colors.orange.withOpacity(0.2)
//                         : isPast
//                             ? null
//                             : Colors.white.withOpacity(0.05),
//                     borderRadius: BorderRadius.circular(12),
//                     border: isSelected
//                         ? Border.all(color: Colors.white, width: 2)
//                         : isToday && !isSelected
//                             ? Border.all(
//                                 color: const Color(0xFFFF9800), width: 2)
//                             : Border.all(
//                                 color: Colors.white.withOpacity(0.1), width: 1),
//                     boxShadow: isSelected
//                         ? [
//                             BoxShadow(
//                               color: const Color(0xFFFF9800).withOpacity(0.5),
//                               blurRadius: 8,
//                               offset: const Offset(0, 2),
//                             ),
//                           ]
//                         : isToday && !isSelected
//                             ? [
//                                 BoxShadow(
//                                   color:
//                                       const Color(0xFFFF9800).withOpacity(0.3),
//                                   blurRadius: 4,
//                                   offset: const Offset(0, 1),
//                                 ),
//                               ]
//                             : null,
//                   ),
//                   child: Center(
//                     child: Text(
//                       day.toString(),
//                       style: TextStyle(
//                         color: isPast
//                             ? Colors.white.withOpacity(0.3)
//                             : isSelected
//                                 ? Colors.white
//                                 : isToday
//                                     ? const Color(0xFFFF9800)
//                                     : Colors.white.withOpacity(0.9),
//                         fontSize: isSelected ? 18 : 16,
//                         fontWeight: isSelected
//                             ? FontWeight.w900
//                             : isToday
//                                 ? FontWeight.bold
//                                 : FontWeight.w500,
//                       ),
//                     ),
//                   ),
//                 ),
//               );
//             },
//           ),
//         ),
//       ],
//     );
//   }

//   // Build modern time slots with 12-hour format and 15-minute intervals
//   Widget _buildModernTimeSlots(
//       {required bool isStartTime, required StateSetter setModalState}) {
//     final timeSlots = <Map<String, dynamic>>[];

//     // Generate time slots from 6 AM to 11:45 PM with 15-minute intervals
//     for (int hour = 6; hour < 24; hour++) {
//       for (int minute = 0; minute < 60; minute += 15) {
//         final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
//         final period = hour >= 12 ? 'PM' : 'AM';
//         final timeString =
//             '${displayHour}:${minute.toString().padLeft(2, '0')} $period';

//         timeSlots.add({
//           'display': timeString,
//           'hour': hour,
//           'minute': minute,
//         });
//       }
//     }

//     return GridView.builder(
//       gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//         crossAxisCount: 3,
//         childAspectRatio: 2.2,
//         mainAxisSpacing: 12,
//         crossAxisSpacing: 12,
//       ),
//       itemCount: timeSlots.length,
//       itemBuilder: (context, index) {
//         final timeSlot = timeSlots[index];
//         final displayTime = timeSlot['display'] as String;
//         final hour = timeSlot['hour'] as int;
//         final minute = timeSlot['minute'] as int;

//         final currentDateTime =
//             isStartTime ? _selectedStartDateTime : _selectedEndDateTime;
//         final isSelected = currentDateTime != null &&
//             currentDateTime.hour == hour &&
//             currentDateTime.minute == minute;

//         return GestureDetector(
//           onTap: () {
//             setState(() {
//               if (isStartTime) {
//                 if (_selectedStartDateTime != null) {
//                   _selectedStartDateTime = DateTime(
//                     _selectedStartDateTime!.year,
//                     _selectedStartDateTime!.month,
//                     _selectedStartDateTime!.day,
//                     hour,
//                     minute,
//                   );
//                 } else {
//                   final now = DateTime.now();
//                   _selectedStartDateTime =
//                       DateTime(now.year, now.month, now.day, hour, minute);
//                 }
//               } else {
//                 if (_selectedEndDateTime != null) {
//                   _selectedEndDateTime = DateTime(
//                     _selectedEndDateTime!.year,
//                     _selectedEndDateTime!.month,
//                     _selectedEndDateTime!.day,
//                     hour,
//                     minute,
//                   );
//                 } else {
//                   final now = DateTime.now();
//                   _selectedEndDateTime =
//                       DateTime(now.year, now.month, now.day, hour, minute);
//                 }
//               }
//             });
//             // Also update the modal state for real-time visual feedback
//             setModalState(() {});
//           },
//           child: Container(
//             decoration: BoxDecoration(
//               gradient: isSelected
//                   ? LinearGradient(
//                       begin: Alignment.topLeft,
//                       end: Alignment.bottomRight,
//                       colors: [
//                         Colors.orange.shade300,
//                         Colors.orange.shade500,
//                         Colors.deepOrange.shade600,
//                       ],
//                     )
//                   : null,
//               color: isSelected ? null : Colors.grey.shade800,
//               borderRadius: BorderRadius.circular(12),
//               border: Border.all(
//                 color: isSelected
//                     ? Colors.orange.shade400
//                     : Colors.white.withOpacity(0.2),
//                 width: isSelected ? 2 : 1,
//               ),
//               boxShadow: isSelected
//                   ? [
//                       BoxShadow(
//                         color: Colors.orange.withOpacity(0.5),
//                         blurRadius: 8,
//                         offset: const Offset(0, 3),
//                       ),
//                       BoxShadow(
//                         color: Colors.orange.withOpacity(0.2),
//                         blurRadius: 15,
//                         offset: const Offset(0, 6),
//                       ),
//                     ]
//                   : [
//                       BoxShadow(
//                         color: Colors.black.withOpacity(0.3),
//                         blurRadius: 4,
//                         offset: const Offset(0, 2),
//                       ),
//                     ],
//             ),
//             child: Center(
//               child: Text(
//                 displayTime,
//                 style: TextStyle(
//                   color:
//                       isSelected ? Colors.white : Colors.white.withOpacity(0.8),
//                   fontSize: 14,
//                   fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
//                 ),
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   // Helper method to get month name
//   String _getMonthName(int month) {
//     const months = [
//       'January',
//       'February',
//       'March',
//       'April',
//       'May',
//       'June',
//       'July',
//       'August',
//       'September',
//       'October',
//       'November',
//       'December'
//     ];
//     return months[month - 1];
//   }

//   // Helper method to format time in 12-hour format
//   String _formatTime12Hour(DateTime dateTime) {
//     final hour = dateTime.hour;
//     final minute = dateTime.minute;
//     final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
//     final period = hour >= 12 ? 'PM' : 'AM';
//     return '${displayHour}:${minute.toString().padLeft(2, '0')} $period';
//   }

//   // Helper method to get recurring days text
//   String _getRecurringDaysText() {
//     if (_selectedRecurringDays.isEmpty) return 'No days selected';

//     final dayNames = [
//       'Sunday',
//       'Monday',
//       'Tuesday',
//       'Wednesday',
//       'Thursday',
//       'Friday',
//       'Saturday'
//     ];
//     final selectedDayNames =
//         _selectedRecurringDays.map((index) => dayNames[index]).toList();

//     if (selectedDayNames.length == 7) {
//       return 'Every day';
//     } else if (selectedDayNames.length == 1) {
//       return 'Every ${selectedDayNames.first}';
//     } else if (selectedDayNames.length == 2) {
//       return 'Every ${selectedDayNames.join(' and ')}';
//     } else {
//       final lastDay = selectedDayNames.removeLast();
//       return 'Every ${selectedDayNames.join(', ')}, and $lastDay';
//     }
//   }
// }
