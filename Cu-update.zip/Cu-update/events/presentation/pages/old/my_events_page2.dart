// import 'package:flutter/material.dart';
// import 'package:check_up_app/features/events/domain/models/event_model.dart';
// import 'package:check_up_app/features/search/presentation/widgets/common_filter_row.dart';
// import 'package:check_up_app/features/tickets/presentation/pages/ticket_detail_page.dart';
// import 'package:check_up_app/features/tickets/domain/models/ticket_model.dart';
// import 'package:check_up_app/features/events/presentation/pages/host_event_detail_page.dart';
// import 'package:check_up_app/features/events/presentation/pages/event_detail_page.dart';
// import 'package:check_up_app/features/events/presentation/pages/manage_event_page.dart';
// import 'package:check_up_app/features/events/presentation/pages/edit_event_page.dart';
// import '../widgets/event_card.dart';
// import '../../../../core/widgets/unified_tab_bar.dart';

// /// A page that displays the user's events
// class MyEventsPage extends StatefulWidget {
//   /// Creates a [MyEventsPage] instance
//   const MyEventsPage({Key? key}) : super(key: key);

//   @override
//   State<MyEventsPage> createState() => _MyEventsPageState();
// }

// class _MyEventsPageState extends State<MyEventsPage>
//     with TickerProviderStateMixin {
//   late TabController _tabController;

//   bool _isLoading = true;
//   String _selectedTimeFilter = 'Popular'; // Default selected filter
//   DateTime? _selectedDate; // null means show all events
//   DateTime _currentMonth = DateTime.now();
//   bool _isCalendarExpanded = false;

//   // Sample events for demonstration
//   List<EventModel> _attendingEventsToday = [];
//   List<EventModel> _attendingEventsUpcoming = [];
//   List<EventModel> _hostingEventsToday = [];
//   List<EventModel> _hostingEventsUpcoming = [];
//   List<EventModel> _pastEvents = [];

//   @override
//   void initState() {
//     super.initState();
//     _tabController = TabController(length: 2, vsync: this);
//     _loadEvents();
//   }

//   @override
//   void dispose() {
//     _tabController.dispose();
//     super.dispose();
//   }

//   Future<void> _loadEvents() async {
//     setState(() {
//       _isLoading = true;
//     });

//     try {
//       // Simulate loading events from a service
//       await Future.delayed(const Duration(milliseconds: 500));

//       // Create sample events
//       final now = DateTime.now();

//       // Sample attending events for today with different registration statuses
//       _attendingEventsToday = [
//         PickupRunEvent(
//           id: 'event1',
//           title: 'Afternoon Pickup Game',
//           description: 'Casual pickup game at Downtown Recreation Center',
//           dateTime: DateTime(
//               now.year, now.month, now.day, 17, 30), // Today at 5:30 PM
//           location: 'Downtown Recreation Center',
//           bannerImageUrl: 'assets/images/basketball_thumbnail.png',
//           category: 'Basketball',
//           isFree: true,
//           maxPlayers: 10,
//           currentPlayers: 6,
//           skillLevel: 'Intermediate',
//           registrationStatus: RegistrationStatus.approved,
//         ),
//         TournamentEvent(
//           id: '2',
//           title: 'Evening 3v3 Tournament',
//           description: 'Quick evening tournament with small teams',
//           dateTime:
//               DateTime(now.year, now.month, now.day, 20, 0), // Today at 8:00 PM
//           location: 'City Sports Complex',
//           bannerImageUrl: null,
//           category: 'Basketball',
//           isFree: false,
//           price: 15.0,
//           numberOfTeams: 8,
//           format: '3v3 Single Elimination',
//           prizePool: 500.0,
//           registrationDeadline:
//               DateTime(now.year, now.month, now.day, 19, 0), // Today at 7:00 PM
//           registrationStatus: RegistrationStatus.pending,
//         ),
//         DonationEvent(
//           id: '3',
//           title: 'Charity Basketball Game',
//           description: 'Fundraising event for local youth programs',
//           dateTime:
//               DateTime(now.year, now.month, now.day, 14, 0), // Today at 2:00 PM
//           location: 'Community Center',
//           bannerImageUrl: 'assets/images/charity_event.png',
//           category: 'Charity',
//           isFree: false,
//           price: 10.0,
//           donationGoal: 5000.0,
//           currentAmount: 3200.0,
//           beneficiary: 'Youth Sports Foundation',
//           hasTaxReceipts: true,
//           registrationStatus: RegistrationStatus.rejected,
//         ),
//       ];

//       // Sample attending events upcoming (not today) with different registration statuses
//       _attendingEventsUpcoming = [
//         PickupRunEvent(
//           id: 'event2',
//           title: 'Lakefront Morning Run',
//           description: 'Early morning pickup game at Lakefront Park',
//           dateTime: now.add(const Duration(days: 5, hours: -2)),
//           location: 'Lakefront Park Courts',
//           category: 'Basketball',
//           isFree: true,
//           maxPlayers: 8,
//           currentPlayers: 3,
//           skillLevel: 'All Levels',
//           registrationStatus: RegistrationStatus.approved,
//         ),
//         TournamentEvent(
//           id: 'event3',
//           title: 'Weekend 3v3 Tournament',
//           description: 'Competitive 3v3 tournament with prizes',
//           dateTime: now.add(const Duration(days: 6)),
//           location: 'Westside Community Center',
//           category: 'Basketball',
//           isFree: false,
//           price: 15.0,
//           numberOfTeams: 16,
//           format: '3v3 Single Elimination',
//           prizePool: 500.0,
//           registrationDeadline: now.add(const Duration(days: 2)),
//         ),
//       ];

//       // Sample hosting events for today
//       _hostingEventsToday = [
//         PickupRunEvent(
//           id: 'event4',
//           title: 'Evening Shootaround',
//           description: 'Casual evening shootaround and pickup games',
//           dateTime:
//               DateTime(now.year, now.month, now.day, 20, 0), // Today at 8:00 PM
//           location: 'Northside YMCA',
//           bannerImageUrl: 'assets/images/basketball_thumbnail.png',
//           category: 'Basketball',
//           isFree: true,
//           maxPlayers: 12,
//           currentPlayers: 4,
//           skillLevel: 'Beginner',
//         ),
//       ];

//       // Sample hosting events upcoming (not today)
//       _hostingEventsUpcoming = [
//         DonationEvent(
//           id: 'event5',
//           title: 'Charity Basketball Event',
//           description:
//               'Basketball event to raise money for local youth programs',
//           dateTime: now.add(const Duration(days: 10)),
//           location: 'Southside Park',
//           category: 'Charity',
//           isFree: false,
//           price: 5.0,
//           donationGoal: 2000.0,
//           currentAmount: 750.0,
//           beneficiary: 'Youth Basketball Foundation',
//           hasTaxReceipts: true,
//         ),
//       ];

//       // Sample past events
//       _pastEvents = [
//         TournamentEvent(
//           id: 'event3',
//           title: 'Weekend 3v3 Tournament',
//           description: 'Competitive 3v3 tournament with prizes',
//           dateTime: now.subtract(const Duration(days: 3)),
//           location: 'Westside Community Center',
//           category: 'Basketball',
//           isFree: false,
//           price: 15.0,
//           numberOfTeams: 16,
//           format: '3v3 Single Elimination',
//           prizePool: 500.0,
//           registrationDeadline: now.subtract(const Duration(days: 10)),
//         ),
//         PickupRunEvent(
//           id: 'event6',
//           title: 'Sunday Morning Pickup',
//           description: 'Casual pickup games on Sunday morning',
//           dateTime: now.subtract(const Duration(days: 7)),
//           location: 'Downtown Recreation Center',
//           bannerImageUrl: 'assets/images/basketball_thumbnail.png',
//           category: 'Basketball',
//           isFree: true,
//           maxPlayers: 10,
//           currentPlayers: 8,
//           skillLevel: 'All Levels',
//         ),
//         DonationEvent(
//           id: 'event7',
//           title: 'Youth Basketball Fundraiser',
//           description: 'Fundraiser event for local youth basketball programs',
//           dateTime: now.subtract(const Duration(days: 14)),
//           location: 'Southside Park',
//           category: 'Charity',
//           isFree: false,
//           price: 10.0,
//           donationGoal: 1500.0,
//           currentAmount: 1750.0,
//           beneficiary: 'City Youth Basketball Association',
//           hasTaxReceipts: true,
//         ),
//       ];

//       setState(() {
//         _isLoading = false;
//       });
//     } catch (e) {
//       setState(() {
//         _isLoading = false;
//       });
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Error loading events: $e')),
//       );
//     }
//   }

//   // Simplified method to refresh the UI
//   void _applyFilter() {
//     setState(() {});
//   }

//   // Calendar widget
//   Widget _buildCalendarWidget() {
//     return Container(
//       margin: const EdgeInsets.fromLTRB(16, 24, 16, 20),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topCenter,
//           end: Alignment.bottomCenter,
//           colors: [Color(0xFF2C2C2C), Color(0xFF1F1F1F), Color(0xFF0A0A0A)],
//         ),
//         borderRadius: BorderRadius.circular(20),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.4),
//             blurRadius: 20,
//             spreadRadius: 0,
//             offset: Offset(0, 10),
//           ),
//           BoxShadow(
//             color: Color(0xFFFF9800).withOpacity(0.1),
//             blurRadius: 30,
//             spreadRadius: -5,
//             offset: Offset(0, 0),
//           ),
//         ],
//       ),
//       child: Column(
//         children: [
//           // Month header with navigation and expand/collapse
//           Padding(
//             padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Container(
//                   width: 44,
//                   height: 44,
//                   decoration: BoxDecoration(
//                     color: _isCalendarExpanded
//                         ? Color(0xFF3A3A3A)
//                         : Color(0xFF2A2A2A),
//                     borderRadius: BorderRadius.circular(12),
//                     border: Border.all(
//                       color: _isCalendarExpanded
//                           ? Color(0xFFFF9800).withOpacity(0.3)
//                           : Colors.transparent,
//                       width: 1,
//                     ),
//                   ),
//                   child: IconButton(
//                     onPressed: _isCalendarExpanded
//                         ? () {
//                             setState(() {
//                               _currentMonth = DateTime(
//                                   _currentMonth.year, _currentMonth.month - 1);
//                             });
//                           }
//                         : null,
//                     icon: Icon(
//                       Icons.chevron_left_rounded,
//                       color:
//                           _isCalendarExpanded ? Colors.white : Colors.grey[500],
//                       size: 20,
//                     ),
//                     padding: EdgeInsets.zero,
//                   ),
//                 ),
//                 Expanded(
//                   child: GestureDetector(
//                     onTap: () {
//                       setState(() {
//                         _isCalendarExpanded = !_isCalendarExpanded;
//                       });
//                     },
//                     child: Container(
//                       padding:
//                           EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//                       margin: EdgeInsets.symmetric(horizontal: 12),
//                       decoration: BoxDecoration(
//                         color: Color(0xFF3A3A3A).withOpacity(0.6),
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(
//                           color: Color(0xFFFF9800).withOpacity(0.2),
//                           width: 1,
//                         ),
//                       ),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           Text(
//                             '${_getMonthName(_currentMonth.month)} ${_currentMonth.year}',
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 18,
//                               fontWeight: FontWeight.w600,
//                               letterSpacing: 0.5,
//                             ),
//                           ),
//                           SizedBox(width: 8),
//                           Container(
//                             padding: EdgeInsets.all(4),
//                             decoration: BoxDecoration(
//                               color: Color(0xFFFF9800).withOpacity(0.15),
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//                             child: Icon(
//                               _isCalendarExpanded
//                                   ? Icons.expand_less_rounded
//                                   : Icons.expand_more_rounded,
//                               color: Color(0xFFFF9800),
//                               size: 20,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//                 Container(
//                   width: 44,
//                   height: 44,
//                   decoration: BoxDecoration(
//                     color: _isCalendarExpanded
//                         ? Color(0xFF3A3A3A)
//                         : Color(0xFF2A2A2A),
//                     borderRadius: BorderRadius.circular(12),
//                     border: Border.all(
//                       color: _isCalendarExpanded
//                           ? Color(0xFFFF9800).withOpacity(0.3)
//                           : Colors.transparent,
//                       width: 1,
//                     ),
//                   ),
//                   child: IconButton(
//                     onPressed: _isCalendarExpanded
//                         ? () {
//                             setState(() {
//                               _currentMonth = DateTime(
//                                   _currentMonth.year, _currentMonth.month + 1);
//                             });
//                           }
//                         : null,
//                     icon: Icon(
//                       Icons.chevron_right_rounded,
//                       color:
//                           _isCalendarExpanded ? Colors.white : Colors.grey[500],
//                       size: 20,
//                     ),
//                     padding: EdgeInsets.zero,
//                   ),
//                 ),
//               ],
//             ),
//           ),

//           // Calendar content (always show day labels and at least first week)
//           Column(
//             children: [
//               // Day labels
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 20),
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceAround,
//                   children: ['S', 'M', 'T', 'W', 'T', 'F', 'S']
//                       .map((day) => Container(
//                             width: 36,
//                             height: 36,
//                             alignment: Alignment.center,
//                             child: Text(
//                               day,
//                               style: TextStyle(
//                                 color: Color(0xFFFF9800).withOpacity(0.7),
//                                 fontSize: 13,
//                                 fontWeight: FontWeight.w600,
//                                 letterSpacing: 0.5,
//                               ),
//                             ),
//                           ))
//                       .toList(),
//                 ),
//               ),

//               // Calendar grid (first week when collapsed, full month when expanded)
//               Padding(
//                 padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
//                 child: _buildCalendarGrid(),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildCalendarGrid() {
//     final now = DateTime.now();
//     final daysInMonth =
//         DateTime(_currentMonth.year, _currentMonth.month + 1, 0).day;
//     final firstDayOfMonth =
//         DateTime(_currentMonth.year, _currentMonth.month, 1);
//     final firstWeekday =
//         firstDayOfMonth.weekday % 7; // 0 = Sunday, 1 = Monday, etc.

//     List<Widget> dayWidgets = [];

//     // Add empty cells for days before the first day of the month
//     for (int i = 0; i < firstWeekday; i++) {
//       dayWidgets.add(Container());
//     }

//     // Determine how many days to show based on expanded state
//     int daysToShow;
//     if (_isCalendarExpanded) {
//       // Show full month when expanded
//       daysToShow = daysInMonth;
//     } else {
//       // Show only first week when collapsed (7 days minus empty cells)
//       daysToShow = 7 - firstWeekday;
//     }

//     // Add day cells
//     for (int day = 1; day <= daysToShow; day++) {
//       final date = DateTime(_currentMonth.year, _currentMonth.month, day);
//       final isToday = date.day == now.day &&
//           date.month == now.month &&
//           date.year == now.year;
//       final isSelected = _selectedDate != null &&
//           _selectedDate!.day == date.day &&
//           _selectedDate!.month == date.month &&
//           _selectedDate!.year == date.year;
//       final hasEvents = _hasEventsOnDate(date);

//       dayWidgets.add(
//         GestureDetector(
//           onTap: () {
//             setState(() {
//               _selectedDate = date;
//               // Don't auto-collapse, let user control expansion
//             });
//           },
//           child: Container(
//             width: 36,
//             height: 36,
//             margin: const EdgeInsets.all(4),
//             decoration: BoxDecoration(
//               gradient: isSelected
//                   ? LinearGradient(
//                       begin: Alignment.topLeft,
//                       end: Alignment.bottomRight,
//                       colors: [Color(0xFFFF9800), Color(0xFFFF6F00)],
//                     )
//                   : isToday
//                       ? LinearGradient(
//                           begin: Alignment.topLeft,
//                           end: Alignment.bottomRight,
//                           colors: [
//                             Color(0xFFFF9800).withOpacity(0.3),
//                             Color(0xFFFF6F00).withOpacity(0.2)
//                           ],
//                         )
//                       : null,
//               color: !isSelected && !isToday
//                   ? Color(0xFF3A3A3A).withOpacity(0.3)
//                   : null,
//               borderRadius: BorderRadius.circular(12),
//               border: Border.all(
//                 color: hasEvents && !isSelected
//                     ? Color(0xFFFF9800).withOpacity(0.4)
//                     : Colors.transparent,
//                 width: 1.5,
//               ),
//               boxShadow: isSelected
//                   ? [
//                       BoxShadow(
//                         color: Color(0xFFFF9800).withOpacity(0.4),
//                         blurRadius: 8,
//                         spreadRadius: 0,
//                         offset: Offset(0, 4),
//                       ),
//                     ]
//                   : null,
//             ),
//             child: Stack(
//               children: [
//                 Center(
//                   child: Text(
//                     day.toString(),
//                     style: TextStyle(
//                       color: isSelected
//                           ? Colors.white
//                           : isToday
//                               ? Colors.white
//                               : Colors.grey[300],
//                       fontSize: 15,
//                       fontWeight: isToday || isSelected
//                           ? FontWeight.w700
//                           : FontWeight.w500,
//                       letterSpacing: 0.3,
//                     ),
//                   ),
//                 ),
//                 if (hasEvents && !isSelected)
//                   Positioned(
//                     bottom: 4,
//                     right: 4,
//                     child: Container(
//                       width: 6,
//                       height: 6,
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [Color(0xFFFF9800), Color(0xFFFF6F00)],
//                         ),
//                         shape: BoxShape.circle,
//                         boxShadow: [
//                           BoxShadow(
//                             color: Color(0xFFFF9800).withOpacity(0.6),
//                             blurRadius: 4,
//                             spreadRadius: 0,
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//               ],
//             ),
//           ),
//         ),
//       );
//     }

//     return GridView.count(
//       crossAxisCount: 7,
//       shrinkWrap: true,
//       physics: const NeverScrollableScrollPhysics(),
//       children: dayWidgets,
//       childAspectRatio: 1.0,
//       mainAxisSpacing: 4,
//       crossAxisSpacing: 4,
//     );
//   }

//   String _getMonthName(int month) {
//     const months = [
//       'January',
//       'February',
//       'March',
//       'April',
//       'May',
//       'June',
//       'July',
//       'August',
//       'September',
//       'October',
//       'November',
//       'December'
//     ];
//     return months[month - 1];
//   }

//   bool _hasEventsOnDate(DateTime date) {
//     // Check if any events occur on this date
//     final allEvents = [
//       ..._attendingEventsToday,
//       ..._attendingEventsUpcoming,
//       ..._hostingEventsToday,
//       ..._hostingEventsUpcoming,
//       ..._pastEvents,
//     ];

//     return allEvents.any((event) =>
//         event.dateTime.day == date.day &&
//         event.dateTime.month == date.month &&
//         event.dateTime.year == date.year);
//   }

//   String _getFormattedDate(DateTime date) {
//     final now = DateTime.now();
//     if (date.day == now.day &&
//         date.month == now.month &&
//         date.year == now.year) {
//       return 'Today';
//     } else if (date.day == now.day + 1 &&
//         date.month == now.month &&
//         date.year == now.year) {
//       return 'Tomorrow';
//     } else {
//       return '${_getMonthName(date.month)} ${date.day}, ${date.year}';
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFF121212),
//       appBar: AppBar(
//         title: const Text(
//           'My Events',
//           style: TextStyle(
//             color: Colors.white,
//             fontWeight: FontWeight.w600,
//             fontSize: 20,
//             letterSpacing: 0.3,
//           ),
//         ),
//         backgroundColor: const Color(0xFF1E1E1E),
//         elevation: 0,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.white),
//           onPressed: () {
//             Navigator.pop(context);
//           },
//         ),
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.notifications_none, color: Colors.white),
//             onPressed: () {
//               ScaffoldMessenger.of(context).showSnackBar(
//                 const SnackBar(content: Text('Notifications')),
//               );
//             },
//           ),
//           IconButton(
//             icon: const Icon(Icons.settings_outlined, color: Colors.white),
//             onPressed: () {
//               ScaffoldMessenger.of(context).showSnackBar(
//                 const SnackBar(content: Text('Settings')),
//               );
//             },
//           ),
//         ],
//         bottom: UnifiedTabBar(
//           controller: _tabController,
//           tabs: [
//             UnifiedTab(
//               text: 'ATTENDING',
//               icon: Icons.event,
//               count: _attendingEventsToday.length +
//                   _attendingEventsUpcoming.length,
//             ),
//             UnifiedTab(
//               text: 'HOSTING',
//               icon: Icons.event_note,
//               count: _hostingEventsToday.length + _hostingEventsUpcoming.length,
//             ),
//           ],
//         ),
//       ),
//       body: _isLoading
//           ? const Center(
//               child: CircularProgressIndicator(
//                 color: Colors.orange,
//               ),
//             )
//           : RefreshIndicator(
//               onRefresh: _loadEvents,
//               color: Colors.orange,
//               backgroundColor: Colors.grey[900],
//               child: SingleChildScrollView(
//                 physics: const AlwaysScrollableScrollPhysics(),
//                 child: Column(
//                   children: [
//                     // Calendar widget at the top
//                     _buildCalendarWidget(),

//                     // Create New Event button
//                     Container(
//                       margin: const EdgeInsets.fromLTRB(16, 20, 16, 20),
//                       width: double.infinity,
//                       height: 68,
//                       child: ElevatedButton(
//                         onPressed: () {
//                           // Navigate to create event page
//                           ScaffoldMessenger.of(context).showSnackBar(
//                             const SnackBar(content: Text('Create New Event')),
//                           );
//                         },
//                         style: ElevatedButton.styleFrom(
//                           backgroundColor: Colors.transparent,
//                           foregroundColor: Colors.white,
//                           elevation: 0,
//                           padding: EdgeInsets.zero,
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(34),
//                           ),
//                         ),
//                         child: Container(
//                           decoration: BoxDecoration(
//                             gradient: LinearGradient(
//                               colors: [
//                                 Color(0xFFFF9800),
//                                 Color(0xFFFF6B00),
//                                 Color(0xFFFF5722)
//                               ],
//                               begin: Alignment.topLeft,
//                               end: Alignment.bottomRight,
//                             ),
//                             borderRadius: BorderRadius.circular(34),
//                             boxShadow: [
//                               BoxShadow(
//                                 color: Color(0xFFFF9800).withOpacity(0.5),
//                                 blurRadius: 20,
//                                 spreadRadius: 2,
//                                 offset: Offset(0, 8),
//                               ),
//                               BoxShadow(
//                                 color: Color(0xFFFF5722).withOpacity(0.3),
//                                 blurRadius: 30,
//                                 spreadRadius: -5,
//                                 offset: Offset(0, 0),
//                               ),
//                             ],
//                           ),
//                           child: Row(
//                             mainAxisAlignment: MainAxisAlignment.center,
//                             children: [
//                               Container(
//                                 padding: EdgeInsets.all(12),
//                                 decoration: BoxDecoration(
//                                   color: Colors.white.withOpacity(0.25),
//                                   shape: BoxShape.circle,
//                                   boxShadow: [
//                                     BoxShadow(
//                                       color: Colors.black.withOpacity(0.1),
//                                       blurRadius: 8,
//                                       offset: Offset(0, 2),
//                                     ),
//                                   ],
//                                 ),
//                                 child: Icon(
//                                   Icons.add_rounded,
//                                   color: Colors.white,
//                                   size: 28,
//                                 ),
//                               ),
//                               SizedBox(width: 16),
//                               Text(
//                                 'Create New Event',
//                                 style: TextStyle(
//                                   color: Colors.white,
//                                   fontSize: 20,
//                                   fontWeight: FontWeight.w700,
//                                   letterSpacing: 0.8,
//                                   fontFamily: 'Montserrat',
//                                   shadows: [
//                                     Shadow(
//                                       offset: Offset(0, 2),
//                                       blurRadius: 4,
//                                       color: Colors.black.withOpacity(0.2),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ),
//                       ),
//                     ),

//                     // Time filter row (Popular, Today, This Week, etc.)
//                     Padding(
//                       padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
//                       child: CommonFilterRow(
//                         selectedFilter: _selectedTimeFilter,
//                         onFilterSelected: (filter) {
//                           setState(() {
//                             _selectedTimeFilter = filter;
//                           });
//                         },
//                         dropdownOptions: const ['Popular', 'Nearby', 'Friends'],
//                         regularFilters: const [
//                           'Today',
//                           'This Week',
//                           'Future',
//                           'Past'
//                         ],
//                       ),
//                     ),

//                     // Tab content that switches based on selected tab
//                     SizedBox(
//                       height: 600, // Fixed height for TabBarView
//                       child: TabBarView(
//                         controller: _tabController,
//                         children: [
//                           // ATTENDING Tab
//                           _buildEventTab(
//                             false, // attending events
//                             _selectedTimeFilter,
//                           ),
//                           // HOSTING Tab
//                           _buildEventTab(
//                             true, // hosting events
//                             _selectedTimeFilter,
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//     );
//   }

//   Widget _buildEventTab(bool isHosting, String timeFilter) {
//     // Get all events based on tab
//     final allEvents = [
//       ...(isHosting ? _hostingEventsToday : _attendingEventsToday),
//       ...(isHosting ? _hostingEventsUpcoming : _attendingEventsUpcoming),
//       if (timeFilter == 'Past') ..._pastEvents,
//     ];

//     List<EventModel> filteredEvents = allEvents;

//     // Filter by selected date if a date is selected
//     if (_selectedDate != null) {
//       filteredEvents = allEvents.where((event) {
//         return event.dateTime.day == _selectedDate!.day &&
//             event.dateTime.month == _selectedDate!.month &&
//             event.dateTime.year == _selectedDate!.year;
//       }).toList();
//     }

//     // Apply additional time filter if needed
//     if (timeFilter != 'Popular' &&
//         timeFilter != 'Nearby' &&
//         timeFilter != 'Friends') {
//       final now = DateTime.now();
//       filteredEvents = filteredEvents.where((event) {
//         switch (timeFilter) {
//           case 'Today':
//             return event.dateTime.day == now.day &&
//                 event.dateTime.month == now.month &&
//                 event.dateTime.year == now.year;
//           case 'This Week':
//             final weekFromNow = now.add(const Duration(days: 7));
//             return event.dateTime.isAfter(now) &&
//                 event.dateTime.isBefore(weekFromNow);
//           case 'Future':
//             return event.dateTime.isAfter(now);
//           case 'Past':
//             return event.dateTime.isBefore(now);
//           default:
//             return true;
//         }
//       }).toList();
//     }

//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         // Events Section
//         Padding(
//           padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
//           child: Row(
//             children: [
//               Text(
//                 _selectedDate != null
//                     ? 'Events for ${_getFormattedDate(_selectedDate!)}'
//                     : isHosting
//                         ? 'All Hosted Events'
//                         : 'All Events',
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//               if (_selectedDate != null) ...[
//                 SizedBox(width: 8),
//                 GestureDetector(
//                   onTap: () {
//                     setState(() {
//                       _selectedDate = null;
//                     });
//                   },
//                   child: Container(
//                     padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                     decoration: BoxDecoration(
//                       color: Color(0xFFFF9800).withOpacity(0.2),
//                       borderRadius: BorderRadius.circular(12),
//                       border: Border.all(color: Color(0xFFFF9800), width: 1),
//                     ),
//                     child: Text(
//                       'Clear',
//                       style: TextStyle(
//                         color: Color(0xFFFF9800),
//                         fontSize: 12,
//                         fontWeight: FontWeight.w600,
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             ],
//           ),
//         ),

//         if (filteredEvents.isEmpty)
//           _buildEmptyState(
//               isHosting,
//               _selectedDate != null
//                   ? _getFormattedDate(_selectedDate!)
//                   : 'All Events')
//         else
//           ListView.builder(
//             shrinkWrap: true,
//             physics: const NeverScrollableScrollPhysics(),
//             itemCount: filteredEvents.length,
//             itemBuilder: (context, index) {
//               return EventCard(
//                 event: filteredEvents[index],
//                 onTap: () {
//                   if (isHosting) {
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                         builder: (context) => HostEventDetailPage(
//                           eventId: filteredEvents[index].id,
//                           title: filteredEvents[index].title,
//                         ),
//                       ),
//                     );
//                   } else {
//                     // Navigate to attendee event detail page
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                         builder: (context) => EventDetailPage(
//                           eventId: filteredEvents[index].id,
//                           title: filteredEvents[index].title,
//                           eventType: filteredEvents[index].category,
//                         ),
//                       ),
//                     );
//                   }
//                 },
//                 // Custom buttons for Attending tab
//                 isAttending: !isHosting,
//                 // Add onEdit callback for hosting events
//                 onEdit: isHosting
//                     ? () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(
//                             builder: (context) => EditEventPage(
//                               event: filteredEvents[index],
//                             ),
//                           ),
//                         );
//                       }
//                     : null,
//                 onViewTickets: isHosting
//                     ? () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(
//                             builder: (context) => ManageEventPage(
//                               eventId: filteredEvents[index].id,
//                               title: filteredEvents[index].title,
//                             ),
//                           ),
//                         );
//                       }
//                     : () {
//                         // For attending tab, navigate to ticket detail page
//                         // Get a sample ticket for this event
//                         final sampleTicket = TicketModel.getSampleTickets(
//                                 filteredEvents[index].id ?? 'unknown',
//                                 filteredEvents[index].title)
//                             .first;

//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(
//                             builder: (context) =>
//                                 TicketDetailPage(ticket: sampleTicket),
//                           ),
//                         );
//                       },
//               );
//             },
//           ),

//         const SizedBox(height: 24),
//       ],
//     );
//   }

//   Widget _buildEmptyState(bool isHosting, String timeFilter) {
//     return Container(
//       margin: const EdgeInsets.all(24),
//       padding: const EdgeInsets.all(32),
//       decoration: BoxDecoration(
//         color: const Color(0xFF2A2A2A),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: Colors.grey.withOpacity(0.2)),
//       ),
//       child: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(
//               isHosting ? Icons.event_available : Icons.event_note,
//               size: 64,
//               color: Colors.orange.withOpacity(0.7),
//             ),
//             const SizedBox(height: 24),
//             Text(
//               'No ${timeFilter} Events',
//               style: const TextStyle(
//                 color: Colors.white,
//                 fontSize: 20,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             const SizedBox(height: 16),
//             Text(
//               isHosting
//                   ? 'You haven\'t created any $timeFilter events yet'
//                   : 'You\'re not attending any $timeFilter events yet',
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                 color: Colors.grey[400],
//                 fontSize: 16,
//               ),
//             ),
//             const SizedBox(height: 24),
//             ElevatedButton.icon(
//               onPressed: () {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(
//                       content: Text(
//                           '${isHosting ? "Create" : "Find"} events action')),
//                 );
//               },
//               icon: Icon(isHosting ? Icons.add : Icons.search),
//               label: Text(isHosting ? 'Create Event' : 'Find Events'),
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: Colors.orange,
//                 foregroundColor: Colors.white,
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(20),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   void _showDeleteConfirmation(EventModel event) {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: Colors.grey[900],
//         title: const Text(
//           'Delete Event',
//           style: TextStyle(color: Colors.white),
//         ),
//         content: Text(
//           'Are you sure you want to delete "${event.title}"? This action cannot be undone.',
//           style: TextStyle(color: Colors.grey[300]),
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text(
//               'Cancel',
//               style: TextStyle(color: Colors.grey),
//             ),
//           ),
//           TextButton(
//             onPressed: () {
//               Navigator.pop(context);
//               ScaffoldMessenger.of(context).showSnackBar(
//                 SnackBar(content: Text('Deleted ${event.title}')),
//               );
//             },
//             child: const Text(
//               'Delete',
//               style: TextStyle(color: Colors.red),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
