// import 'package:flutter/material.dart';
// import 'package:check_up_app/features/players/presentation/pages/player_profile_page.dart';
// import 'package:check_up_app/features/tickets/presentation/pages/ticket_payment_page.dart';

// import 'package:check_up_app/features/search/presentation/widgets/espn_score_card.dart';
// import 'package:check_up_app/features/feed/presentation/widgets/create_post_widget.dart';
// import 'package:check_up_app/features/feed/presentation/widgets/feed_post.dart';
// import 'package:check_up_app/features/feed/domain/models/feed_post_model.dart';
// import 'package:check_up_app/features/feed/data/feed_data_provider.dart';
// import 'package:check_up_app/features/feed/presentation/widgets/share_modal.dart';
// import 'package:check_up_app/features/brackets/presentation/pages/bracket_detail_page.dart';
// import 'package:check_up_app/features/brackets/domain/models/bracket_model.dart';
// import 'dart:async';

// /// A placeholder page for displaying event details.
// class EventDetailPage extends StatefulWidget {
//   /// The unique identifier for the event.
//   final String? eventId;

//   /// The title of the event.
//   final String? title;

//   /// The type of event for specialized content rendering.
//   final String? eventType;

//   /// Creates an [EventDetailPage] instance.
//   const EventDetailPage({
//     Key? key,
//     this.eventId,
//     this.title,
//     this.eventType,
//   }) : super(key: key);

//   @override
//   State<EventDetailPage> createState() => _EventDetailPageState();
// }

// class _EventDetailPageState extends State<EventDetailPage> with TickerProviderStateMixin {
//   // Helper method to build tags
//   Widget _buildTag(String label) {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//       decoration: BoxDecoration(
//         color: Colors.black.withOpacity(0.3),
//         borderRadius: BorderRadius.circular(20),
//         border: Border.all(color: Colors.grey[700]!, width: 1),
//       ),
//       child: Text(
//         label,
//         style: TextStyle(color: Colors.grey[300], fontSize: 12),
//       ),
//     );
//   }

//   // Controller for the image carousel
//   late PageController _pageController;
//   int _currentPage = 0;
//   Timer? _timer;

//   // State for collapsible sections
//   bool _isDetailsExpanded = false;
//   late List<FeedPostModel> _feedPosts;

//   // Sample event images
//   final List<String> eventImages = [
//     'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=1000',
//     'https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=1000',
//     'https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=1000',
//     'https://images.unsplash.com/photo-1505666287802-931dc83a5dc7?q=80&w=1000',
//   ];

//   @override
//   void initState() {
//     super.initState();
//     _pageController = PageController(initialPage: 0);
//     _startAutoScroll();
//     _loadFeedData();
//   }

//   void _loadFeedData() {
//     final feedDataProvider = FeedDataProvider();
//     _feedPosts = feedDataProvider.getFeedPosts().take(3).toList();
//   }

//   @override
//   void dispose() {
//     _pageController.dispose();
//     _timer?.cancel();
//     super.dispose();
//   }

//   void _startAutoScroll() {
//     _timer = Timer.periodic(const Duration(seconds: 5), (timer) {
//       if (_currentPage < eventImages.length - 1) {
//         _currentPage++;
//       } else {
//         _currentPage = 0;
//       }

//       if (_pageController.hasClients) {
//         _pageController.animateToPage(
//           _currentPage,
//           duration: const Duration(milliseconds: 800),
//           curve: Curves.easeInOut,
//         );
//       }
//     });
//   }

//   // Build a player avatar for the players section
//   Widget _buildPlayerAvatar(String name, String distance, bool isOnline) {
//     // Generate a unique player ID based on the name
//     final String playerId = name.toLowerCase().replaceAll(' ', '_');

//     return GestureDetector(
//       onTap: () {
//         // Navigate to player profile when tapped
//         Navigator.push(
//           context,
//           MaterialPageRoute(
//             builder: (context) => PlayerProfilePage(
//               playerId: playerId,
//               playerName: name,
//             ),
//           ),
//         );
//       },
//       child: Container(
//         width: 80,
//         margin: const EdgeInsets.only(right: 16),
//         child: Column(
//           children: [
//             Stack(
//               alignment: Alignment.bottomRight,
//               children: [
//                 Container(
//                   width: 60,
//                   height: 60,
//                   decoration: BoxDecoration(
//                     shape: BoxShape.circle,
//                     border: Border.all(color: Colors.orange, width: 2),
//                     color: Colors.orange[300],
//                   ),
//                   child: const Center(
//                     child: Icon(
//                       Icons.sentiment_very_satisfied,
//                       color: Colors.black,
//                       size: 40,
//                     ),
//                   ),
//                 ),
//                 if (isOnline)
//                   Container(
//                     width: 12,
//                     height: 12,
//                     decoration: BoxDecoration(
//                       color: Colors.green,
//                       shape: BoxShape.circle,
//                       border:
//                           Border.all(color: const Color(0xFF1A1A1A), width: 2),
//                     ),
//                   ),
//               ],
//             ),
//             const SizedBox(height: 6),
//             Text(
//               name,
//               style: const TextStyle(color: Colors.white, fontSize: 12),
//               textAlign: TextAlign.center,
//             ),
//             Text(
//               distance,
//               style: TextStyle(color: Colors.grey[500], fontSize: 10),
//               textAlign: TextAlign.center,
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   // Build a create post section for the feed
//   Widget _buildCreatePostSection() {
//     return Container(
//       margin: const EdgeInsets.only(bottom: 16),
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.grey[900],
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: Colors.grey[800]!, width: 1),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.2),
//             blurRadius: 8,
//             offset: const Offset(0, 2),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Container(
//                 width: 40,
//                 height: 40,
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   gradient: LinearGradient(
//                     colors: [Colors.orange[300]!, Colors.orange[500]!],
//                     begin: Alignment.topLeft,
//                     end: Alignment.bottomRight,
//                   ),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withOpacity(0.3),
//                       blurRadius: 8,
//                       offset: const Offset(0, 2),
//                     ),
//                   ],
//                   border: Border.all(color: Colors.orange[700]!, width: 2),
//                 ),
//                 child: const Center(
//                   child: Icon(
//                     Icons.sentiment_very_satisfied,
//                     color: Colors.white,
//                     size: 24,
//                   ),
//                 ),
//               ),
//               const SizedBox(width: 12),
//               Expanded(
//                 child: TextField(
//                   decoration: InputDecoration(
//                     hintText: 'Share your thoughts about this event...',
//                     hintStyle: TextStyle(color: Colors.grey[500]),
//                     border: InputBorder.none,
//                     contentPadding: const EdgeInsets.symmetric(vertical: 8),
//                   ),
//                   style: const TextStyle(color: Colors.white),
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 16),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               TextButton.icon(
//                 onPressed: () {},
//                 icon: Icon(Icons.photo_camera,
//                     color: Colors.orange[400], size: 20),
//                 label: Text(
//                   'Add Photo',
//                   style: TextStyle(color: Colors.orange[400]),
//                 ),
//                 style: TextButton.styleFrom(
//                   padding: const EdgeInsets.symmetric(horizontal: 12),
//                 ),
//               ),
//               ElevatedButton(
//                 onPressed: () {},
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.orange[400],
//                   foregroundColor: Colors.white,
//                   padding:
//                       const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(20),
//                   ),
//                 ),
//                 child: const Text('Post',
//                     style: TextStyle(fontWeight: FontWeight.bold)),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   // Build a feed item for the event feed section
//   Widget _buildFeedItem({
//     required String username,
//     required String profileImage,
//     required String content,
//     required String timeAgo,
//     required int likes,
//     bool hasImage = false,
//     String imageUrl = '',
//   }) {
//     return Container(
//       decoration: BoxDecoration(
//         color: Colors.grey[900],
//         borderRadius: BorderRadius.circular(12),
//       ),
//       padding: const EdgeInsets.all(12),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // User info row
//           Row(
//             children: [
//               // Profile image
//               CircleAvatar(
//                 radius: 18,
//                 backgroundColor: Colors.orange,
//                 backgroundImage: NetworkImage(profileImage),
//                 onBackgroundImageError: (_, __) {},
//               ),
//               const SizedBox(width: 10),
//               // Username and time
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     username,
//                     style: const TextStyle(
//                       color: Colors.white,
//                       fontWeight: FontWeight.bold,
//                       fontSize: 14,
//                     ),
//                   ),
//                   Text(
//                     timeAgo,
//                     style: TextStyle(
//                       color: Colors.grey[400],
//                       fontSize: 12,
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),

//           const SizedBox(height: 12),

//           // Comment content
//           Text(
//             content,
//             style: const TextStyle(color: Colors.white, fontSize: 14),
//           ),

//           // Optional image
//           if (hasImage) ...[
//             const SizedBox(height: 12),
//             ClipRRect(
//               borderRadius: BorderRadius.circular(8),
//               child: Image.network(
//                 imageUrl,
//                 height: 180,
//                 width: double.infinity,
//                 fit: BoxFit.cover,
//                 loadingBuilder: (context, child, loadingProgress) {
//                   if (loadingProgress == null) return child;
//                   return Container(
//                     height: 180,
//                     color: Colors.grey[800],
//                     child: const Center(
//                       child: CircularProgressIndicator(color: Colors.orange),
//                     ),
//                   );
//                 },
//                 errorBuilder: (context, error, stackTrace) {
//                   return Container(
//                     height: 180,
//                     color: Colors.grey[800],
//                     child: const Center(
//                       child: Icon(Icons.error_outline, color: Colors.orange),
//                     ),
//                   );
//                 },
//               ),
//             ),
//           ],

//           const SizedBox(height: 12),

//           // Likes and comments row
//           Row(
//             children: [
//               Icon(Icons.favorite, color: Colors.red[400], size: 18),
//               const SizedBox(width: 4),
//               Text(
//                 '$likes',
//                 style: TextStyle(color: Colors.grey[400], fontSize: 14),
//               ),
//               const SizedBox(width: 16),
//               const Icon(Icons.chat_bubble_outline,
//                   color: Colors.grey, size: 18),
//               const SizedBox(width: 4),
//               Text(
//                 'Reply',
//                 style: TextStyle(color: Colors.grey[400], fontSize: 14),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   // Method to get specialized content based on event type
//   Widget? _getSpecializedContent() {
//     if (widget.eventType == null) return null;

//     switch (widget.eventType!.toLowerCase()) {
//       case 'league games':
//       case 'league':
//         return _buildLeagueSection();
//       default:
//         // All other event-specific content is now in the main event details section
//         return null;
//     }
//   }

//   // Tournament-specific section
//   Widget _buildTournamentSection() {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 16),
//       padding: const EdgeInsets.all(20),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [Colors.grey[800]!, Colors.grey[900]!],
//         ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: Colors.orange.withOpacity(0.3), width: 1),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(8),
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
//                   ),
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: const Icon(Icons.emoji_events,
//                     color: Colors.white, size: 20),
//               ),
//               const SizedBox(width: 12),
//               const Text(
//                 'Tournament Bracket',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 16),
//           const Text(
//             'Quarterfinals - Live Updates',
//             style: TextStyle(color: Colors.grey, fontSize: 14),
//           ),
//           const SizedBox(height: 12),
//           Container(
//             padding: const EdgeInsets.all(12),
//             decoration: BoxDecoration(
//               color: Colors.black.withOpacity(0.3),
//               borderRadius: BorderRadius.circular(8),
//             ),
//             child: const Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text('Lakers',
//                     style: TextStyle(
//                         color: Colors.orange, fontWeight: FontWeight.bold)),
//                 Text('92 - 85',
//                     style: TextStyle(
//                         color: Colors.white, fontWeight: FontWeight.bold)),
//                 Text('Warriors', style: TextStyle(color: Colors.white)),
//               ],
//             ),
//           ),
//           const SizedBox(height: 12),
//           Container(
//             padding: const EdgeInsets.all(16),
//             decoration: BoxDecoration(
//               color: Colors.green.withOpacity(0.1),
//               borderRadius: BorderRadius.circular(12),
//               border: Border.all(color: Colors.green.withOpacity(0.3)),
//             ),
//             child: const Row(
//               children: [
//                 Icon(Icons.monetization_on, color: Colors.green, size: 24),
//                 SizedBox(width: 12),
//                 Text(
//                   'Prize Pool: \$5,000',
//                   style: TextStyle(
//                     color: Colors.green,
//                     fontSize: 16,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   // League-specific section
//   Widget _buildLeagueSection() {
//     // Sample scores data
//     final scores = [
//       {'team1': 'Lakers', 'team2': 'Warriors', 'score1': 108, 'score2': 112},
//       {'team1': 'Celtics', 'team2': 'Heat', 'score1': 95, 'score2': 88},
//       {'team1': 'Nets', 'team2': 'Knicks', 'score1': 102, 'score2': 99},
//       {'team1': 'Bulls', 'team2': 'Bucks', 'score1': 87, 'score2': 94},
//     ];
    
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 16),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 20),
//             child: Row(
//               children: [
//                 Container(
//                   padding: const EdgeInsets.all(8),
//                   decoration: BoxDecoration(
//                     gradient: LinearGradient(
//                       colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
//                     ),
//                     borderRadius: BorderRadius.circular(8),
//                   ),
//                   child: const Icon(Icons.sports_basketball,
//                       color: Colors.white, size: 20),
//                 ),
//                 const SizedBox(width: 12),
//                 const Text(
//                   'League Games',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 18,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           const SizedBox(height: 16),
//           SizedBox(
//             height: 220, // Reduced height for better proportions
//             child: ListView.builder(
//               scrollDirection: Axis.horizontal,
//               padding: const EdgeInsets.symmetric(horizontal: 20),
//               itemCount: scores.length,
//               itemBuilder: (context, index) {
//                 final score = scores[index];
//                 return Container(
//                   width: 280, // Reduced width for better proportions
//                   margin: EdgeInsets.only(
//                     right: index < scores.length - 1 ? 16 : 0,
//                   ),
//                   child: EspnScoreCard(
//                     homeTeamName: score['team1'] as String,
//                     awayTeamName: score['team2'] as String,
//                     homeScore: score['score1'] as int,
//                     awayScore: score['score2'] as int,
//                     gameStatus: 'Final',
//                     gameDateTime: DateTime.now(),
//                     courtName: 'Rucker Park',
//                     courtLocation: 'Harlem, NY',
//                     hostName: 'Event Host',
//                     leagueName: 'Basketball League',
//                     homeTeamLogoUrl: null,
//                     awayTeamLogoUrl: null,
//                     onViewFullScore: () {
//                       // Handle view full score
//                     },
//                     onShare: () {
//                       // Handle share
//                     },
//                   ),
//                 );
//               },
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Color _getStatusColor(String status) {
//     switch (status) {
//       case 'live':
//         return Colors.red;
//       case 'final':
//         return Colors.green;
//       case 'upcoming':
//       default:
//         return Colors.orange;
//     }
//   }

//   Widget _buildMatchupCard(
//     String homeTeam,
//     String awayTeam,
//     String time,
//     String date, {
//     String status = 'upcoming',
//     int? homeScore,
//     int? awayScore,
//   }) {
//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 20),
//       width: double.infinity,
//       height: 120,
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [Colors.grey[800]!, Colors.grey[900]!],
//         ),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: Colors.orange.withOpacity(0.3), width: 1),
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(8),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             // Simple status header
//             Text(
//               status == 'final' ? 'FINAL' : (status == 'live' ? 'LIVE' : time),
//               style: TextStyle(
//                 color: _getStatusColor(status),
//                 fontSize: 11,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             // Compact teams row
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: [
//                 // Away team
//                 Column(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     Container(
//                       width: 32,
//                       height: 32,
//                       decoration: BoxDecoration(
//                         color: Colors.blue[700],
//                         shape: BoxShape.circle,
//                       ),
//                       child: Center(
//                         child: Text(
//                           awayTeam.substring(0, 1),
//                           style: const TextStyle(
//                             color: Colors.white,
//                             fontSize: 14,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                       ),
//                     ),
//                     const SizedBox(height: 4),
//                     Text(
//                       awayTeam,
//                       style: const TextStyle(
//                         color: Colors.white,
//                         fontSize: 10,
//                         fontWeight: FontWeight.w500,
//                       ),
//                     ),
//                     if (awayScore != null)
//                       Text(
//                         awayScore.toString(),
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontSize: 14,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                   ],
//                 ),
//                 // VS or score separator
//                 Text(
//                   status == 'upcoming' ? 'VS' : '-',
//                   style: const TextStyle(
//                     color: Colors.grey,
//                     fontSize: 12,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//                 // Home team
//                 Column(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     Container(
//                       width: 32,
//                       height: 32,
//                       decoration: BoxDecoration(
//                         color: Colors.red[700],
//                         shape: BoxShape.circle,
//                       ),
//                       child: Center(
//                         child: Text(
//                           homeTeam.substring(0, 1),
//                           style: const TextStyle(
//                             color: Colors.white,
//                             fontSize: 14,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                       ),
//                     ),
//                     const SizedBox(height: 4),
//                     Text(
//                       homeTeam,
//                       style: const TextStyle(
//                         color: Colors.white,
//                         fontSize: 10,
//                         fontWeight: FontWeight.w500,
//                       ),
//                     ),
//                     if (homeScore != null)
//                       Text(
//                         homeScore.toString(),
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontSize: 14,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                   ],
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   // Training-specific section
//   Widget _buildTrainingSection() {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 16),
//       padding: const EdgeInsets.all(20),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [Colors.grey[800]!, Colors.grey[900]!],
//         ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: Colors.orange.withOpacity(0.3), width: 1),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(8),
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
//                   ),
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: const Icon(Icons.fitness_center,
//                     color: Colors.white, size: 20),
//               ),
//               const SizedBox(width: 12),
//               const Text(
//                 'Training Session',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 16),
//           _buildTrainingItem('Ball Handling Drills', '30 min'),
//           _buildTrainingItem('Shooting Technique', '45 min'),
//           _buildTrainingItem('Defensive Positioning', '30 min'),
//           const SizedBox(height: 12),
//           Container(
//             padding: const EdgeInsets.all(12),
//             decoration: BoxDecoration(
//               color: Colors.purple.withOpacity(0.1),
//               borderRadius: BorderRadius.circular(8),
//               border: Border.all(color: Colors.purple.withOpacity(0.3)),
//             ),
//             child: const Row(
//               children: [
//                 Icon(Icons.person, color: Colors.purple, size: 20),
//                 SizedBox(width: 8),
//                 Text(
//                   'Coach Mike Johnson - 15 years experience',
//                   style: TextStyle(color: Colors.white, fontSize: 14),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildTrainingItem(String item, String duration) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4),
//       child: Row(
//         children: [
//           Container(
//             width: 6,
//             height: 6,
//             decoration: const BoxDecoration(
//                 color: Colors.orange, shape: BoxShape.circle),
//           ),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Text(item,
//                 style: const TextStyle(color: Colors.white, fontSize: 14)),
//           ),
//           Text(duration,
//               style: const TextStyle(color: Colors.grey, fontSize: 12)),
//         ],
//       ),
//     );
//   }

//   // Camp-specific section
//   Widget _buildCampSection() {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 16),
//       padding: const EdgeInsets.all(20),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [Colors.grey[800]!, Colors.grey[900]!],
//         ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: Colors.orange.withOpacity(0.3), width: 1),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(8),
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
//                   ),
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: const Icon(Icons.school, color: Colors.white, size: 20),
//               ),
//               const SizedBox(width: 12),
//               const Text(
//                 '5-Day Basketball Camp',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 16),
//           _buildCampDay('Day 1', 'Fundamentals & Assessment'),
//           _buildCampDay('Day 2', 'Shooting & Ball Handling'),
//           _buildCampDay('Day 3', 'Defense & Rebounding'),
//           _buildCampDay('Day 4', 'Team Play & Strategy'),
//           _buildCampDay('Day 5', 'Scrimmage & Awards'),
//         ],
//       ),
//     );
//   }

//   Widget _buildCampDay(String day, String activities) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4),
//       child: Row(
//         children: [
//           Container(
//             padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//             decoration: BoxDecoration(
//               color: Colors.orange.withOpacity(0.2),
//               borderRadius: BorderRadius.circular(6),
//             ),
//             child: Text(
//               day,
//               style: const TextStyle(
//                   color: Colors.orange,
//                   fontSize: 12,
//                   fontWeight: FontWeight.bold),
//             ),
//           ),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Text(activities,
//                 style: const TextStyle(color: Colors.white, fontSize: 14)),
//           ),
//         ],
//       ),
//     );
//   }

//   // Donation-specific section
//   Widget _buildDonationSection() {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 16),
//       padding: const EdgeInsets.all(20),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [Colors.grey[800]!, Colors.grey[900]!],
//         ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: Colors.orange.withOpacity(0.3), width: 1),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(8),
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
//                   ),
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: const Icon(Icons.volunteer_activism,
//                     color: Colors.white, size: 20),
//               ),
//               const SizedBox(width: 12),
//               const Text(
//                 'Fundraising Goal',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 16),
//           const Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text(
//                 '\$3,250 raised',
//                 style: TextStyle(
//                     color: Colors.green,
//                     fontSize: 20,
//                     fontWeight: FontWeight.bold),
//               ),
//               Text('Goal: \$5,000',
//                   style: TextStyle(color: Colors.grey, fontSize: 14)),
//             ],
//           ),
//           const SizedBox(height: 12),
//           LinearProgressIndicator(
//             value: 0.65,
//             backgroundColor: Colors.grey[700],
//             valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
//             minHeight: 8,
//           ),
//           const SizedBox(height: 8),
//           const Text(
//             '65% of goal reached • 47 donors',
//             style: TextStyle(color: Colors.grey, fontSize: 12),
//           ),
//         ],
//       ),
//     );
//   }

//   // Special event-specific section
//   Widget _buildSpecialEventSection() {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 16),
//       padding: const EdgeInsets.all(20),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [Colors.grey[800]!, Colors.grey[900]!],
//         ),
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: Colors.orange.withOpacity(0.3), width: 1),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(8),
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
//                   ),
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: const Icon(Icons.celebration,
//                     color: Colors.white, size: 20),
//               ),
//               const SizedBox(width: 12),
//               const Text(
//                 'Special Features',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 16),
//           _buildSpecialFeature('Meet & Greet with NBA Legends'),
//           _buildSpecialFeature('Autograph Session'),
//           _buildSpecialFeature('Professional Photography'),
//           _buildSpecialFeature('VIP Seating Area'),
//           const SizedBox(height: 12),
//           Container(
//             padding: const EdgeInsets.all(12),
//             decoration: BoxDecoration(
//               color: Colors.amber.withOpacity(0.1),
//               borderRadius: BorderRadius.circular(8),
//               border: Border.all(color: Colors.amber.withOpacity(0.3)),
//             ),
//             child: const Row(
//               children: [
//                 Icon(Icons.star, color: Colors.amber, size: 20),
//                 SizedBox(width: 8),
//                 Text(
//                   'Special Guest: Magic Johnson',
//                   style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 14,
//                       fontWeight: FontWeight.bold),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildSpecialFeature(String feature) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4),
//       child: Row(
//         children: [
//           const Icon(Icons.star, color: Colors.orange, size: 16),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Text(feature,
//                 style: const TextStyle(color: Colors.white, fontSize: 14)),
//           ),
//         ],
//       ),
//     );
//   }

//   // Dynamic event details based on event type
//   List<Widget> _buildEventSpecificDetails() {
//     final eventType = widget.eventType?.toLowerCase() ?? 'tournament';
    
//     switch (eventType) {
//       case 'training':
//         return _buildTrainingDetails();
//       case 'camp':
//         return _buildCampDetails();
//       case 'charity':
//       case 'donation':
//         return _buildCharityDetails();
//       case 'special':
//         return _buildSpecialEventDetails();
//       case 'tournament':
//       case 'league':
//       default:
//         return _buildTournamentDetails();
//     }
//   }

//   List<Widget> _buildTrainingDetails() {
//     return [
//       const Text(
//         'Join our intensive basketball training session designed to improve your fundamental skills and game performance.',
//         style: TextStyle(color: Colors.white, fontSize: 15, height: 1.5),
//       ),
//       const SizedBox(height: 16),
//       Container(
//         padding: const EdgeInsets.all(12),
//         decoration: BoxDecoration(
//           color: Colors.orange.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: Colors.orange.withOpacity(0.3)),
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Row(
//               children: [
//                 Icon(Icons.fitness_center, color: Colors.orange, size: 18),
//                 SizedBox(width: 8),
//                 Text('Training Schedule', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
//               ],
//             ),
//             const SizedBox(height: 8),
//             _buildTrainingItem('Ball Handling Drills', '30 min'),
//             _buildTrainingItem('Shooting Technique', '45 min'),
//             _buildTrainingItem('Defensive Positioning', '30 min'),
//           ],
//         ),
//       ),
//       const SizedBox(height: 12),
//       Container(
//         padding: const EdgeInsets.all(12),
//         decoration: BoxDecoration(
//           color: Colors.purple.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: Colors.purple.withOpacity(0.3)),
//         ),
//         child: const Row(
//           children: [
//             Icon(Icons.person, color: Colors.purple, size: 18),
//             SizedBox(width: 8),
//             Text('Coach Mike Johnson - 15 years experience', style: TextStyle(color: Colors.white, fontSize: 14)),
//           ],
//         ),
//       ),
//       const SizedBox(height: 16),
//       Wrap(
//         spacing: 8,
//         runSpacing: 8,
//         children: [
//           _buildTag('All Skill Levels'),
//           _buildTag('Professional Coach'),
//           _buildTag('Equipment Provided'),
//         ],
//       ),
//     ];
//   }

//   List<Widget> _buildCampDetails() {
//     return [
//       const Text(
//         'Experience our comprehensive 5-day basketball camp designed to develop fundamental skills and basketball IQ.',
//         style: TextStyle(color: Colors.white, fontSize: 15, height: 1.5),
//       ),
//       const SizedBox(height: 16),
//       Container(
//         padding: const EdgeInsets.all(12),
//         decoration: BoxDecoration(
//           color: Colors.blue.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: Colors.blue.withOpacity(0.3)),
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Row(
//               children: [
//                 Icon(Icons.school, color: Colors.blue, size: 18),
//                 SizedBox(width: 8),
//                 Text('Camp Schedule', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
//               ],
//             ),
//             const SizedBox(height: 8),
//             _buildCampDay('Day 1', 'Fundamentals & Assessment'),
//             _buildCampDay('Day 2', 'Shooting & Ball Handling'),
//             _buildCampDay('Day 3', 'Defense & Rebounding'),
//             _buildCampDay('Day 4', 'Team Play & Strategy'),
//             _buildCampDay('Day 5', 'Scrimmage & Awards'),
//           ],
//         ),
//       ),
//       const SizedBox(height: 16),
//       Wrap(
//         spacing: 8,
//         runSpacing: 8,
//         children: [
//           _buildTag('Ages 8-16'),
//           _buildTag('Lunch Included'),
//           _buildTag('Awards Ceremony'),
//           _buildTag('Professional Coaching'),
//         ],
//       ),
//     ];
//   }

//   List<Widget> _buildSpecialEventDetails() {
//     return [
//       const Text(
//         'Join us for an exclusive basketball event featuring special guests, unique experiences, and unforgettable moments.',
//         style: TextStyle(color: Colors.white, fontSize: 15, height: 1.5),
//       ),
//       const SizedBox(height: 16),
//       Container(
//         padding: const EdgeInsets.all(12),
//         decoration: BoxDecoration(
//           color: Colors.amber.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: Colors.amber.withOpacity(0.3)),
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Row(
//               children: [
//                 Icon(Icons.celebration, color: Colors.amber, size: 18),
//                 SizedBox(width: 8),
//                 Text('Special Features', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
//               ],
//             ),
//             const SizedBox(height: 8),
//             _buildSpecialFeature('Meet & Greet with NBA Legends'),
//             _buildSpecialFeature('Autograph Session'),
//             _buildSpecialFeature('Professional Photography'),
//             _buildSpecialFeature('VIP Seating Area'),
//           ],
//         ),
//       ),
//       const SizedBox(height: 12),
//       Container(
//         padding: const EdgeInsets.all(12),
//         decoration: BoxDecoration(
//           color: Colors.purple.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: Colors.purple.withOpacity(0.3)),
//         ),
//         child: const Row(
//           children: [
//             Icon(Icons.star, color: Colors.purple, size: 18),
//             SizedBox(width: 8),
//             Text('Special Guest: Magic Johnson', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
//           ],
//         ),
//       ),
//       const SizedBox(height: 16),
//       Wrap(
//         spacing: 8,
//         runSpacing: 8,
//         children: [
//           _buildTag('VIP Experience'),
//           _buildTag('Limited Seating'),
//           _buildTag('Photo Opportunities'),
//           _buildTag('Exclusive Access'),
//         ],
//       ),
//     ];
//   }

//   List<Widget> _buildCharityDetails() {
//     return [
//       const Text(
//         'Support a great cause while enjoying basketball! All proceeds go directly to local youth basketball programs.',
//         style: TextStyle(color: Colors.white, fontSize: 15, height: 1.5),
//       ),
//       const SizedBox(height: 16),
//       Container(
//         padding: const EdgeInsets.all(12),
//         decoration: BoxDecoration(
//           color: Colors.green.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: Colors.green.withOpacity(0.3)),
//         ),
//         child: const Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(
//               children: [
//                 Icon(Icons.favorite, color: Colors.green, size: 18),
//                 SizedBox(width: 8),
//                 Text('Charity Impact', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
//               ],
//             ),
//             SizedBox(height: 8),
//             Text('• Fund new basketball equipment for local schools', style: TextStyle(color: Colors.white, fontSize: 14)),
//             Text('• Support youth coaching programs', style: TextStyle(color: Colors.white, fontSize: 14)),
//             Text('• Provide scholarships for basketball camps', style: TextStyle(color: Colors.white, fontSize: 14)),
//           ],
//         ),
//       ),
//       const SizedBox(height: 16),
//       Wrap(
//         spacing: 8,
//         runSpacing: 8,
//         children: [
//           _buildTag('Good Cause'),
//           _buildTag('Tax Deductible'),
//           _buildTag('Community Impact'),
//           _buildTag('Youth Support'),
//         ],
//       ),
//     ];
//   }

//   List<Widget> _buildTournamentDetails() {
//     return [
//       const Text(
//         'Join us for an exciting basketball tournament! Perfect for players of all skill levels looking to compete in a friendly but competitive environment.',
//         style: TextStyle(color: Colors.white, fontSize: 15, height: 1.5),
//       ),
//       const SizedBox(height: 12),
//       const Text(
//         'What to bring: Basketball shoes, water bottle, and your A-game. Teams will be formed on-site, so feel free to come solo or with friends!',
//         style: TextStyle(color: Colors.grey, fontSize: 14, height: 1.5),
//       ),
//       const SizedBox(height: 16),
//       Wrap(
//         spacing: 8,
//         runSpacing: 8,
//         children: [
//           _buildTag('Beginner Friendly'),
//           _buildTag('Prizes'),
//           _buildTag('Refreshments'),
//           _buildTag('Indoor Court'),
//         ],
//       ),
//     ];
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       // Ensure the content is properly sized and prevent overflow
//       resizeToAvoidBottomInset: true,
//       appBar: AppBar(
//         title: Image.asset(
//           'assets/images/checkup_main-1.png',
//           height: 32,
//           fit: BoxFit.contain,
//           errorBuilder: (context, error, stackTrace) {
//             // Fallback to text if image fails to load
//             return Text(widget.title ?? 'Event Details');
//           },
//         ),
//         backgroundColor: Colors.black,
//         foregroundColor: Colors.white,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back),
//           onPressed: () => Navigator.of(context).pop(),
//         ),
//         actions: [
//           Container(
//             margin: const EdgeInsets.only(right: 16),
//             decoration: BoxDecoration(
//               gradient: const LinearGradient(
//                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//               ),
//               borderRadius: BorderRadius.circular(20),
//               boxShadow: [
//                 BoxShadow(
//                   color: const Color(0xFFFF9800).withOpacity(0.3),
//                   blurRadius: 8,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Material(
//               color: Colors.transparent,
//               child: InkWell(
//                 onTap: () {
//                   // Show the share modal with event details
//                   ShareModal.show(
//                     context: context,
//                     postId: widget.eventId ?? 'default_event_id',
//                     postContent: '${widget.title ?? 'Event'} - Check out this amazing event!',
//                     shareUrl: 'https://checkup.app/events/${widget.eventId ?? 'default_event_id'}',
//                   );
//                 },
//                 borderRadius: BorderRadius.circular(20),
//                 child: Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//                   child: Row(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       const Icon(
//                         Icons.share,
//                         color: Colors.white,
//                         size: 16,
//                       ),
//                       const SizedBox(width: 6),
//                       const Text(
//                         'Share',
//                         style: TextStyle(
//                           color: Colors.white,
//                           fontSize: 14,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//       body: Container(
//         color: Colors.black,
//         child: SingleChildScrollView(
//           // Add padding at the bottom to account for the fixed ticket section
//           padding: const EdgeInsets.only(bottom: 80),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               // Event image carousel (1:1 aspect ratio)
//               AspectRatio(
//                 aspectRatio: 1.0,
//                 child: Container(
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(0),
//                     boxShadow: [
//                       BoxShadow(
//                         color: Colors.black.withOpacity(0.3),
//                         blurRadius: 10,
//                         spreadRadius: 2,
//                       ),
//                     ],
//                   ),
//                   child: Stack(
//                     children: [
//                       // Image carousel
//                       PageView.builder(
//                         controller: _pageController,
//                         onPageChanged: (int page) {
//                           setState(() {
//                             _currentPage = page;
//                           });
//                         },
//                         itemCount: eventImages.length,
//                         itemBuilder: (context, index) {
//                           return Image.network(
//                             eventImages[index],
//                             fit: BoxFit.cover,
//                             loadingBuilder: (context, child, loadingProgress) {
//                               if (loadingProgress == null) return child;
//                               return Container(
//                                 color: Colors.grey[900],
//                                 child: const Center(
//                                   child: CircularProgressIndicator(
//                                       color: Colors.orange),
//                                 ),
//                               );
//                             },
//                             errorBuilder: (context, error, stackTrace) {
//                               return Container(
//                                 color: Colors.grey[900],
//                                 child: const Center(
//                                   child: Icon(Icons.error_outline,
//                                       color: Colors.orange, size: 50),
//                                 ),
//                               );
//                             },
//                           );
//                         },
//                       ),

//                       // Gradient overlay at bottom
//                       Positioned(
//                         bottom: 0,
//                         left: 0,
//                         right: 0,
//                         height: 100,
//                         child: Container(
//                           decoration: BoxDecoration(
//                             gradient: LinearGradient(
//                               begin: Alignment.bottomCenter,
//                               end: Alignment.topCenter,
//                               colors: [
//                                 Colors.black.withOpacity(0.8),
//                                 Colors.transparent,
//                               ],
//                             ),
//                           ),
//                         ),
//                       ),

//                       // Price label with gradient (top left)
//                       Positioned(
//                         top: 16,
//                         left: 16,
//                         child: Container(
//                           padding: const EdgeInsets.symmetric(
//                               horizontal: 20, vertical: 12),
//                           decoration: BoxDecoration(
//                             gradient: LinearGradient(
//                               begin: Alignment.topLeft,
//                               end: Alignment.bottomRight,
//                               colors: [
//                                 Colors.orange[400]!,
//                                 Colors.deepOrange[700]!,
//                               ],
//                             ),
//                             borderRadius: BorderRadius.circular(20),
//                             boxShadow: [
//                               BoxShadow(
//                                 color: Colors.black.withOpacity(0.4),
//                                 blurRadius: 10,
//                                 spreadRadius: 1,
//                                 offset: const Offset(0, 3),
//                               ),
//                             ],
//                             border: Border.all(
//                               color: Colors.white.withOpacity(0.3),
//                               width: 1,
//                             ),
//                           ),
//                           child: const Text(
//                             '\$15.00',
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.w900,
//                               fontSize: 18,
//                               letterSpacing: 0.8,
//                               shadows: [
//                                 Shadow(
//                                   offset: Offset(0, 1),
//                                   blurRadius: 2,
//                                   color: Color.fromRGBO(0, 0, 0, 0.5),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                       ),

//                       // Share button moved to AppBar

//                       // Game type pill (bottom left)
//                       Positioned(
//                         bottom: 16,
//                         left: 16,
//                         child: Container(
//                           padding: const EdgeInsets.symmetric(
//                               horizontal: 14, vertical: 8),
//                           decoration: BoxDecoration(
//                             color: Colors.black.withOpacity(0.7),
//                             borderRadius: BorderRadius.circular(20),
//                           ),
//                           child: const Text(
//                             '3v3 Tournament',
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.bold,
//                               fontSize: 12,
//                             ),
//                           ),
//                         ),
//                       ),

//                       // Page indicator dots (bottom center)
//                       Positioned(
//                         bottom: 16,
//                         left: 0,
//                         right: 0,
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: List.generate(
//                             eventImages.length,
//                             (index) => Container(
//                               width: 8,
//                               height: 8,
//                               margin: const EdgeInsets.symmetric(horizontal: 4),
//                               decoration: BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: _currentPage == index
//                                     ? Colors.orange
//                                     : Colors.white.withOpacity(0.5),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),

//               // Event details
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     // Event title
//                     Text(
//                       widget.title ?? 'Event Title',
//                       style: const TextStyle(
//                         color: Colors.white,
//                         fontSize: 24,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                     const SizedBox(height: 16),

//                     // Event info section with black gradient and orange accents
//                     Container(
//                       width: double.infinity,
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
//                           begin: Alignment.centerLeft,
//                           end: Alignment.centerRight,
//                         ),
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Color(0xFFFF9800), width: 1),
//                       ),
//                       child: Row(
//                         children: [
//                           Container(
//                             padding: const EdgeInsets.all(12),
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                             child: const Icon(Icons.calendar_today,
//                                 color: Colors.white, size: 24),
//                           ),
//                           const SizedBox(width: 16),
//                           Expanded(
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const Text(
//                                   'June 15, 2025',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 22,
//                                     fontWeight: FontWeight.bold,
//                                     letterSpacing: 0.5,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                                 const SizedBox(height: 4),
//                                 const Text(
//                                   '7:00 PM - 9:30 PM',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 16,
//                                     fontWeight: FontWeight.w500,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 24),

//                     // Host info (moved below time and date)
//                     Container(
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         color: Colors.grey[900],
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Colors.grey[700]!, width: 1),
//                       ),
//                       child: Row(
//                         children: [
//                           Container(
//                             width: 50,
//                             height: 50,
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               shape: BoxShape.circle,
//                             ),
//                             child: const Center(
//                               child: Icon(Icons.person, color: Colors.white, size: 24),
//                             ),
//                           ),
//                           const SizedBox(width: 16),
//                           Expanded(
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const Text(
//                                   'John Smith',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 18,
//                                     fontWeight: FontWeight.bold,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                                 const SizedBox(height: 2),
//                                 Row(
//                                   children: [
//                                     Icon(Icons.verified, color: Colors.orange, size: 16),
//                                     const SizedBox(width: 4),
//                                     Text(
//                                       'Event Organizer',
//                                       style: TextStyle(
//                                         color: Colors.grey[400],
//                                         fontSize: 14,
//                                         fontFamily: 'Montserrat',
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                           Container(
//                             padding: const EdgeInsets.symmetric(
//                                 horizontal: 16, vertical: 8),
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               borderRadius: BorderRadius.circular(20),
//                             ),
//                             child: const Text(
//                               'Contact',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.w600,
//                                 fontSize: 12,
//                                 fontFamily: 'Montserrat',
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 16),

//                     // Court location section with modern styling
//                     Container(
//                       margin: const EdgeInsets.only(bottom: 16),
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         color: Colors.grey[900],
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Colors.grey[700]!, width: 1),
//                       ),
//                       child: Row(
//                         children: [
//                           Container(
//                             width: 50,
//                             height: 50,
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                             child: const Icon(
//                               Icons.sports_basketball,
//                               color: Colors.white,
//                               size: 24,
//                             ),
//                           ),
//                           const SizedBox(width: 16),
//                           Expanded(
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const Text(
//                                   'Rucker Park',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 18,
//                                     fontWeight: FontWeight.bold,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                                 const SizedBox(height: 4),
//                                 Row(
//                                   children: [
//                                     const Icon(Icons.location_on,
//                                         color: Colors.orange, size: 16),
//                                     const SizedBox(width: 4),
//                                     Text(
//                                       'Harlem, New York',
//                                       style: TextStyle(
//                                         color: Colors.grey[400],
//                                         fontSize: 14,
//                                         fontFamily: 'Montserrat',
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                           Container(
//                             padding: const EdgeInsets.symmetric(
//                                 horizontal: 16, vertical: 8),
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               borderRadius: BorderRadius.circular(20),
//                             ),
//                             child: const Text(
//                               'Directions',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.w600,
//                                 fontSize: 12,
//                                 fontFamily: 'Montserrat',
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),

//                     // Description - Collapsible Event Details
//                     Container(
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
//                           begin: Alignment.centerLeft,
//                           end: Alignment.centerRight,
//                         ),
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Color(0xFFFF9800), width: 1),
//                       ),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           // Header row with expand/collapse button
//                           InkWell(
//                             onTap: () {
//                               setState(() {
//                                 _isDetailsExpanded = !_isDetailsExpanded;
//                               });
//                             },
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Row(
//                                   children: [
//                                     Container(
//                                       padding: const EdgeInsets.all(8),
//                                       decoration: BoxDecoration(
//                                         gradient: LinearGradient(
//                                           colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                           begin: Alignment.centerLeft,
//                                           end: Alignment.centerRight,
//                                         ),
//                                         borderRadius: BorderRadius.circular(8),
//                                       ),
//                                       child: const Icon(Icons.description_outlined,
//                                           color: Colors.white, size: 16),
//                                     ),
//                                     const SizedBox(width: 12),
//                                     const Text(
//                                       'Event Details',
//                                       style: TextStyle(
//                                         color: Colors.white,
//                                         fontSize: 18,
//                                         fontWeight: FontWeight.bold,
//                                         fontFamily: 'Montserrat',
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                                 Icon(
//                                   _isDetailsExpanded
//                                       ? Icons.keyboard_arrow_up
//                                       : Icons.keyboard_arrow_down,
//                                   color: Colors.orange,
//                                 ),
//                               ],
//                             ),
//                           ),

//                           // Preview and expandable content
//                           const SizedBox(height: 12),
//                           Text(
//                             'Join us for an exciting basketball tournament at the legendary Rucker Park. This event brings together players of all skill levels for competitive games and community building.',
//                             style: TextStyle(
//                               color: Colors.grey[300],
//                               fontSize: 14,
//                               height: 1.4,
//                               fontFamily: 'Montserrat',
//                             ),
//                             maxLines: _isDetailsExpanded ? null : 2,
//                             overflow: _isDetailsExpanded ? TextOverflow.visible : TextOverflow.ellipsis,
//                           ),
                          
//                           // Expandable additional content
//                           AnimatedCrossFade(
//                             firstChild: const SizedBox(height: 0),
//                             secondChild: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const SizedBox(height: 12),
//                                 Text(
//                                   'Tournament Format:\n• Single elimination bracket\n• 5v5 full court games\n• 20-minute games\n• Professional referees\n\nWhat to Bring:\n• Basketball shoes\n• Water bottle\n• Team jersey (optional)\n\nPrizes:\n• \$500 winning team\n• \$200 runner-up\n• MVP trophy',
//                                   style: TextStyle(
//                                     color: Colors.grey[300],
//                                     fontSize: 14,
//                                     height: 1.4,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             crossFadeState: _isDetailsExpanded
//                                 ? CrossFadeState.showSecond
//                                 : CrossFadeState.showFirst,
//                             duration: const Duration(milliseconds: 300),
//                           ),
                          
//                           const SizedBox(height: 8),
//                           Text(
//                             _isDetailsExpanded ? 'Tap to see less...' : 'Tap to see more details...',
//                             style: TextStyle(
//                               color: Colors.orange,
//                               fontSize: 12,
//                               fontStyle: FontStyle.italic,
//                               fontFamily: 'Montserrat',
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 24),

//                     // Tournament Brackets section (only show for tournament events)
//                     if (widget.eventType?.toLowerCase() == 'tournament') ...[
//                       GestureDetector(
//                         onTap: () {
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                               builder: (context) => BracketDetailPage(
//                                 bracket: BracketModel(
//                                   id: 'tournament_bracket_${widget.eventId}',
//                                   name: widget.title ?? 'Tournament Bracket',
//                                   description: 'Tournament bracket for ${widget.title}',
//                                   startDate: DateTime.now(),
//                                   participantCount: 8,
//                                   status: BracketStatus.inProgress,
//                                   createdBy: 'Tournament Organizer',
//                                   createdAt: DateTime.now(),
//                                   rounds: [],
//                                   sport: 'Basketball',
//                                 ),
//                               ),
//                             ),
//                           );
//                         },
//                         child: Container(
//                           padding: const EdgeInsets.all(20),
//                           decoration: BoxDecoration(
//                             gradient: const LinearGradient(
//                               begin: Alignment.topLeft,
//                               end: Alignment.bottomRight,
//                               colors: [
//                                 Color(0xFF3A3A3A),
//                                 Color(0xFF2A2A2A),
//                                 Color(0xFF1A1A1A),
//                                 Color(0xFF0A0A0A),
//                               ],
//                               stops: [0.0, 0.3, 0.7, 1.0],
//                             ),
//                             borderRadius: BorderRadius.circular(16),
//                             border: Border.all(
//                               color: Colors.white.withOpacity(0.08),
//                               width: 0.5,
//                             ),
//                             boxShadow: [
//                               BoxShadow(
//                                 color: Colors.white.withOpacity(0.03),
//                                 blurRadius: 1,
//                                 offset: const Offset(0, 1),
//                               ),
//                               BoxShadow(
//                                 color: Colors.black.withOpacity(0.4),
//                                 blurRadius: 12,
//                                 offset: const Offset(0, 4),
//                               ),
//                             ],
//                           ),
//                           child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               // Header matching tournament bracket widget
//                               Row(
//                                 children: [
//                                   Container(
//                                     width: 44,
//                                     height: 44,
//                                     decoration: BoxDecoration(
//                                       gradient: LinearGradient(
//                                         colors: [
//                                           Colors.orange.shade400,
//                                           Colors.deepOrange.shade600,
//                                         ],
//                                       ),
//                                       borderRadius: BorderRadius.circular(12),
//                                       boxShadow: [
//                                         BoxShadow(
//                                           color: Colors.orange.withOpacity(0.3),
//                                           blurRadius: 6,
//                                           offset: const Offset(0, 2),
//                                         ),
//                                       ],
//                                     ),
//                                     child: const Icon(
//                                       Icons.account_tree,
//                                       color: Colors.white,
//                                       size: 22,
//                                     ),
//                                   ),
//                                   const SizedBox(width: 16),
//                                   Expanded(
//                                     child: Column(
//                                       crossAxisAlignment: CrossAxisAlignment.start,
//                                       children: [
//                                         const Text(
//                                           'Tournament Bracket',
//                                           style: TextStyle(
//                                             color: Colors.white,
//                                             fontSize: 18,
//                                             fontWeight: FontWeight.w700,
//                                             fontFamily: 'Montserrat',
//                                           ),
//                                         ),
//                                         const SizedBox(height: 4),
//                                         const Text(
//                                           '8 teams • Single Elimination',
//                                           style: TextStyle(
//                                             color: Colors.white70,
//                                             fontSize: 14,
//                                             fontFamily: 'Montserrat',
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                   Container(
//                                     padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                                     decoration: BoxDecoration(
//                                       gradient: const LinearGradient(
//                                         begin: Alignment.topLeft,
//                                         end: Alignment.bottomRight,
//                                         colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                       ),
//                                       borderRadius: BorderRadius.circular(20),
//                                       boxShadow: [
//                                         BoxShadow(
//                                           color: const Color(0xFFFF5722).withOpacity(0.3),
//                                           blurRadius: 8,
//                                           offset: const Offset(0, 2),
//                                         ),
//                                       ],
//                                     ),
//                                     child: const Text(
//                                       'Quarterfinals',
//                                       style: TextStyle(
//                                         color: Colors.white,
//                                         fontSize: 12,
//                                         fontWeight: FontWeight.bold,
//                                         letterSpacing: 0.2,
//                                         fontFamily: 'Montserrat',
//                                       ),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                               const SizedBox(height: 20),
                              
//                               // Horizontal scrolling bracket cards matching tournament widget style
//                               SizedBox(
//                                 height: 100,
//                                 child: ListView.builder(
//                                   scrollDirection: Axis.horizontal,
//                                   padding: const EdgeInsets.only(left: 4, right: 4),
//                                   itemCount: 4,
//                                   itemBuilder: (context, index) {
//                                     final matches = [
//                                       {'team1': 'Lakers', 'team2': 'Warriors', 'score1': 92, 'score2': 85, 'isComplete': true, 'winner': 'Lakers'},
//                                       {'team1': 'Celtics', 'team2': 'Heat', 'score1': 78, 'score2': 82, 'isComplete': true, 'winner': 'Heat'},
//                                       {'team1': 'Nets', 'team2': 'Knicks', 'score1': null, 'score2': null, 'isComplete': false, 'winner': null},
//                                       {'team1': 'Bulls', 'team2': 'Bucks', 'score1': null, 'score2': null, 'isComplete': false, 'winner': null},
//                                     ];
                                    
//                                     final match = matches[index];
//                                     final isComplete = match['isComplete'] as bool;
//                                     final winner = match['winner'] as String?;
                                    
//                                     return Container(
//                                       width: 160,
//                                       height: 100,
//                                       margin: EdgeInsets.only(right: index < 3 ? 12 : 0),
//                                       decoration: BoxDecoration(
//                                         gradient: const LinearGradient(
//                                           colors: [
//                                             Color(0xFF2A2A2A),
//                                             Color(0xFF1A1A1A),
//                                           ],
//                                         ),
//                                         borderRadius: BorderRadius.circular(12),
//                                         border: Border.all(
//                                           color: isComplete 
//                                               ? Colors.orange.shade400.withOpacity(0.3)
//                                               : Colors.white.withOpacity(0.08),
//                                           width: 0.5,
//                                         ),
//                                         boxShadow: [
//                                           BoxShadow(
//                                             color: Colors.black.withOpacity(0.3),
//                                             blurRadius: 8,
//                                             offset: const Offset(0, 4),
//                                           ),
//                                         ],
//                                       ),
//                                       child: Padding(
//                                         padding: const EdgeInsets.all(10),
//                                         child: Column(
//                                           mainAxisAlignment: MainAxisAlignment.center,
//                                           children: [
//                                             // Team 1
//                                             Row(
//                                               children: [
//                                                 Container(
//                                                   width: 20,
//                                                   height: 20,
//                                                   decoration: BoxDecoration(
//                                                     gradient: LinearGradient(
//                                                       colors: winner == match['team1']
//                                                           ? [Colors.orange.shade400, Colors.deepOrange.shade600]
//                                                           : [const Color(0xFF3A3A3A), const Color(0xFF2A2A2A)],
//                                                     ),
//                                                     borderRadius: BorderRadius.circular(4),
//                                                   ),
//                                                   child: const Icon(
//                                                     Icons.group,
//                                                     color: Colors.white,
//                                                     size: 10,
//                                                   ),
//                                                 ),
//                                                 const SizedBox(width: 6),
//                                                 Expanded(
//                                                   child: Text(
//                                                     match['team1'] as String,
//                                                     style: TextStyle(
//                                                       color: winner == match['team1'] ? Colors.orange.shade200 : Colors.white,
//                                                       fontSize: 11,
//                                                       fontWeight: winner == match['team1'] ? FontWeight.w700 : FontWeight.w500,
//                                                       fontFamily: 'Montserrat',
//                                                     ),
//                                                     overflow: TextOverflow.ellipsis,
//                                                   ),
//                                                 ),
//                                                 if (match['score1'] != null)
//                                                   Container(
//                                                     padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
//                                                     decoration: BoxDecoration(
//                                                       color: winner == match['team1']
//                                                           ? Colors.orange.shade400.withOpacity(0.2)
//                                                           : Colors.white.withOpacity(0.1),
//                                                       borderRadius: BorderRadius.circular(3),
//                                                     ),
//                                                     child: Text(
//                                                       match['score1'].toString(),
//                                                       style: TextStyle(
//                                                         color: winner == match['team1'] ? Colors.orange.shade200 : Colors.white,
//                                                         fontSize: 11,
//                                                         fontWeight: FontWeight.w700,
//                                                         fontFamily: 'Montserrat',
//                                                       ),
//                                                     ),
//                                                   ),
//                                               ],
//                                             ),
//                                             const SizedBox(height: 4),
//                                             Container(
//                                               height: 0.5,
//                                               color: Colors.white.withOpacity(0.1),
//                                             ),
//                                             const SizedBox(height: 4),
//                                             // Team 2
//                                             Row(
//                                               children: [
//                                                 Container(
//                                                   width: 20,
//                                                   height: 20,
//                                                   decoration: BoxDecoration(
//                                                     gradient: LinearGradient(
//                                                       colors: winner == match['team2']
//                                                           ? [Colors.orange.shade400, Colors.deepOrange.shade600]
//                                                           : [const Color(0xFF3A3A3A), const Color(0xFF2A2A2A)],
//                                                     ),
//                                                     borderRadius: BorderRadius.circular(4),
//                                                   ),
//                                                   child: const Icon(
//                                                     Icons.group,
//                                                     color: Colors.white,
//                                                     size: 10,
//                                                   ),
//                                                 ),
//                                                 const SizedBox(width: 6),
//                                                 Expanded(
//                                                   child: Text(
//                                                     match['team2'] as String,
//                                                     style: TextStyle(
//                                                       color: winner == match['team2'] ? Colors.orange.shade200 : Colors.white,
//                                                       fontSize: 11,
//                                                       fontWeight: winner == match['team2'] ? FontWeight.w700 : FontWeight.w500,
//                                                       fontFamily: 'Montserrat',
//                                                     ),
//                                                     overflow: TextOverflow.ellipsis,
//                                                   ),
//                                                 ),
//                                                 if (match['score2'] != null)
//                                                   Container(
//                                                     padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
//                                                     decoration: BoxDecoration(
//                                                       color: winner == match['team2']
//                                                           ? Colors.orange.shade400.withOpacity(0.2)
//                                                           : Colors.white.withOpacity(0.1),
//                                                       borderRadius: BorderRadius.circular(3),
//                                                     ),
//                                                     child: Text(
//                                                       match['score2'].toString(),
//                                                       style: TextStyle(
//                                                         color: winner == match['team2'] ? Colors.orange.shade200 : Colors.white,
//                                                         fontSize: 11,
//                                                         fontWeight: FontWeight.w700,
//                                                         fontFamily: 'Montserrat',
//                                                       ),
//                                                     ),
//                                                   ),
//                                               ],
//                                             ),
//                                             if (!isComplete) ...[
//                                               const SizedBox(height: 4),
//                                               Text(
//                                                 'Upcoming',
//                                                 style: TextStyle(
//                                                   color: Colors.orange.shade400,
//                                                   fontSize: 9,
//                                                   fontWeight: FontWeight.w500,
//                                                   fontFamily: 'Montserrat',
//                                                 ),
//                                               ),
//                                             ],
//                                           ],
//                                         ),
//                                       ),
//                                     );
//                                   },
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ),
//                       ),
//                       const SizedBox(height: 24),
//                     ],

//                     // Event Activity/Players section with modern styling
//                     Container(
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
//                           begin: Alignment.centerLeft,
//                           end: Alignment.centerRight,
//                         ),
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Color(0xFFFF9800), width: 1),
//                       ),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Row(
//                             children: [
//                               Container(
//                                 padding: const EdgeInsets.all(8),
//                                 decoration: BoxDecoration(
//                                   gradient: LinearGradient(
//                                     colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                     begin: Alignment.centerLeft,
//                                     end: Alignment.centerRight,
//                                   ),
//                                   borderRadius: BorderRadius.circular(8),
//                                 ),
//                                 child: const Icon(Icons.people_alt_outlined,
//                                     color: Colors.white, size: 16),
//                               ),
//                               const SizedBox(width: 12),
//                               const Text(
//                                 'Event Activity',
//                                 style: TextStyle(
//                                   color: Colors.white,
//                                   fontSize: 18,
//                                   fontWeight: FontWeight.bold,
//                                   fontFamily: 'Montserrat',
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 12),
//                           Row(
//                             children: [
//                               Text(
//                                 '24 registered',
//                                 style: TextStyle(
//                                   color: Colors.grey[400], 
//                                   fontSize: 14,
//                                   fontFamily: 'Montserrat',
//                                 ),
//                               ),
//                               const SizedBox(width: 8),
//                               Container(
//                                 width: 4,
//                                 height: 4,
//                                 decoration: BoxDecoration(
//                                   color: Colors.grey[600],
//                                   shape: BoxShape.circle,
//                                 ),
//                               ),
//                               const SizedBox(width: 8),
//                               Text(
//                                 '8 spots left',
//                                 style: TextStyle(
//                                   color: Colors.grey[400], 
//                                   fontSize: 14,
//                                   fontFamily: 'Montserrat',
//                                 ),
//                               ),
//                               const Spacer(),
//                               Container(
//                                 padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                                 decoration: BoxDecoration(
//                                   gradient: LinearGradient(
//                                     colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                     begin: Alignment.centerLeft,
//                                     end: Alignment.centerRight,
//                                   ),
//                                   borderRadius: BorderRadius.circular(16),
//                                 ),
//                                 child: const Text(
//                                   'Join',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontWeight: FontWeight.w600,
//                                     fontSize: 12,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 16),
//                           // Player avatars with proper spacing
//                           SingleChildScrollView(
//                             scrollDirection: Axis.horizontal,
//                             padding: EdgeInsets.zero,
//                             child: Row(
//                               children: [
//                                 _buildPlayerAvatar('Michael J.', '0.5 mi', true),
//                                 const SizedBox(width: 12),
//                                 _buildPlayerAvatar('Kobe B.', '1.2 mi', true),
//                                 const SizedBox(width: 12),
//                                 _buildPlayerAvatar('LeBron J.', '0.8 mi', true),
//                                 const SizedBox(width: 12),
//                                 _buildPlayerAvatar('Stephen C.', '1.5 mi', false),
//                                 const SizedBox(width: 16), // Extra padding at end
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 24),

//                     // Specialized content based on event type
//                     if (_getSpecializedContent() != null) ...[
//                       _getSpecializedContent()!,
//                       const SizedBox(height: 24),
//                     ],

//                     // Feed section
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         const Text(
//                           'Feed',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 18,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                         TextButton(
//                           onPressed: () {},
//                           child: Text(
//                             'See All',
//                             style: TextStyle(color: Colors.orange[400]),
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(height: 12),

//                     // Create post widget from feed page
//                     CreatePostWidget(
//                       placeholder: "What's happening?",
//                       profileImagePath: 'assets/images/main_btn.png',
//                       isAssetImage: true,
//                       onTap: () {
//                         // Handle create post tap
//                       },
//                       onCameraTap: () {
//                         // Handle camera tap
//                       },
//                     ),
//                     const SizedBox(height: 16),

//                     // Feed posts from feed page
//                     ..._feedPosts.map((post) => Padding(
//                       padding: const EdgeInsets.only(bottom: 16),
//                       child: FeedPost(
//                         post: post,
//                         onLikeTap: () {},
//                         onCommentTap: () {},
//                         onRepostTap: () {},
//                         onShareTap: () {},
//                       ),
//                     )).toList(),

//                     const SizedBox(height: 32),

//                     // Spacer at the bottom (register button moved to bottom bar)
//                     const SizedBox(height: 32),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//       // Fixed bottom section for tickets - smaller and more compact to prevent overflow
//       bottomNavigationBar: Material(
//         color: Colors.black,
//         elevation: 8,
//         child: SafeArea(
//           child: Container(
//             height: 56, // Compact height
//             decoration: BoxDecoration(
//               color: Colors.black,
//               border: Border(
//                 top: BorderSide(color: Colors.grey[900]!, width: 1),
//               ),
//             ),
//             padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//             child: Row(
//               children: [
//                 // Price section
//                 Expanded(
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       const Text(
//                         'Standard Ticket',
//                         style: TextStyle(
//                           color: Colors.white,
//                           fontSize: 11,
//                           fontWeight: FontWeight.w500,
//                         ),
//                       ),
//                       Row(
//                         children: [
//                           const Text(
//                             '\$10.00',
//                             style: TextStyle(
//                               color: Colors.orange,
//                               fontSize: 18,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                           const SizedBox(width: 8),
//                           Container(
//                             padding: const EdgeInsets.symmetric(
//                                 horizontal: 6, vertical: 2),
//                             decoration: BoxDecoration(
//                               color: Colors.green.withOpacity(0.2),
//                               borderRadius: BorderRadius.circular(10),
//                               border: Border.all(
//                                   color: Colors.green[700]!, width: 1),
//                             ),
//                             child: const Text(
//                               '12 spots',
//                               style: TextStyle(
//                                 color: Colors.green,
//                                 fontSize: 10,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//                 // View tickets button - more compact
//                 Container(
//                   height: 38,
//                   decoration: BoxDecoration(
//                     gradient: const LinearGradient(
//                       colors: [Colors.orange, Colors.deepOrange],
//                       begin: Alignment.centerLeft,
//                       end: Alignment.centerRight,
//                     ),
//                     borderRadius: BorderRadius.circular(19),
//                     boxShadow: [
//                       BoxShadow(
//                         color: Colors.orange.withOpacity(0.3),
//                         blurRadius: 6,
//                         spreadRadius: 0,
//                         offset: const Offset(0, 2),
//                       ),
//                     ],
//                   ),
//                   child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                           builder: (context) => TicketPaymentPage(
//                             eventId: widget.eventId ?? 'default_event_id',
//                             eventName: widget.title ?? 'Event Title',
//                             ticketPrice: 25.00,
//                             eventLocation: 'Venice Beach Courts',
//                             eventDateTime:
//                                 DateTime.now().add(const Duration(days: 3)),
//                           ),
//                         ),
//                       );
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: Colors.transparent,
//                       foregroundColor: Colors.white,
//                       shadowColor: Colors.transparent,
//                       elevation: 0,
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(19),
//                       ),
//                       padding: const EdgeInsets.symmetric(horizontal: 14),
//                     ),
//                     child: const Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(Icons.confirmation_number_outlined, size: 14),
//                         SizedBox(width: 4),
//                         Text(
//                           'View Tickets',
//                           style: TextStyle(
//                             fontSize: 12,
//                             fontWeight: FontWeight.bold,
//                             letterSpacing: 0.3,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
