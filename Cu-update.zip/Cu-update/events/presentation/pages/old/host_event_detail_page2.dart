// import 'package:flutter/material.dart';
// import 'dart:async';
// import 'package:check_up_app/features/events/presentation/pages/manage_event_page.dart';
// import 'package:check_up_app/features/players/presentation/pages/player_profile_page.dart';
// import 'package:check_up_app/features/tickets/presentation/pages/ticket_payment_page.dart';
// import 'package:check_up_app/features/search/presentation/widgets/espn_score_card.dart';
// import 'package:check_up_app/features/feed/presentation/widgets/create_post_widget.dart';
// import 'package:check_up_app/features/feed/presentation/widgets/feed_post.dart';
// import 'package:check_up_app/features/feed/domain/models/feed_post_model.dart';
// import 'package:check_up_app/features/feed/data/feed_data_provider.dart';
// import 'package:check_up_app/features/feed/presentation/widgets/share_modal.dart';

// /// A page for displaying event details from the host's perspective.
// class HostEventDetailPage extends StatefulWidget {
//   /// The unique identifier for the event.
//   final String? eventId;

//   /// The title of the event.
//   final String? title;

//   /// Creates a [HostEventDetailPage] instance.
//   const HostEventDetailPage({
//     Key? key,
//     this.eventId,
//     this.title,
//   }) : super(key: key);

//   @override
//   State<HostEventDetailPage> createState() => _HostEventDetailPageState();
// }

// class _HostEventDetailPageState extends State<HostEventDetailPage> with TickerProviderStateMixin {
//   // Helper method to build tags
//   Widget _buildTag(String label) {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//       decoration: BoxDecoration(
//         color: Colors.black.withOpacity(0.3),
//         borderRadius: BorderRadius.circular(20),
//         border: Border.all(color: Colors.grey[700]!, width: 1),
//       ),
//       child: Text(
//         label,
//         style: TextStyle(color: Colors.grey[300], fontSize: 12),
//       ),
//     );
//   }

//   // Controller for the image carousel
//   late PageController _pageController;
//   int _currentPage = 0;
//   Timer? _timer;
  
//   // State for collapsible sections
//   bool _isDetailsExpanded = false;
//   late List<FeedPostModel> _feedPosts;
  
//   // Sample event images
//   final List<String> eventImages = [
//     'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=1000',
//     'https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=1000',
//     'https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=1000',
//     'https://images.unsplash.com/photo-1505666287802-931dc83a5dc7?q=80&w=1000',
//   ];
  
//   @override
//   void initState() {
//     super.initState();
//     _pageController = PageController(initialPage: 0);
//     _startAutoScroll();
//     _loadFeedData();
//   }

//   Future<void> _loadFeedData() async {
//     try {
//       final feedDataProvider = FeedDataProvider();
//       final feedData = feedDataProvider.getFeedPosts();
//       setState(() {
//         _feedPosts = feedData;
//       });
//     } catch (e) {
//       setState(() {
//         _feedPosts = [];
//       });
//     }
//   }
  
//   @override
//   void dispose() {
//     _pageController.dispose();
//     _timer?.cancel();
//     super.dispose();
//   }
  
//   void _startAutoScroll() {
//     _timer = Timer.periodic(const Duration(seconds: 5), (timer) {
//       if (_currentPage < eventImages.length - 1) {
//         _currentPage++;
//       } else {
//         _currentPage = 0;
//       }
      
//       if (_pageController.hasClients) {
//         _pageController.animateToPage(
//           _currentPage,
//           duration: const Duration(milliseconds: 800),
//           curve: Curves.easeInOut,
//         );
//       }
//     });
//   }

//   // Build a player avatar for the players section
//   Widget _buildPlayerAvatar(String name, String distance, bool isOnline) {
//     return Container(
//       width: 80,
//       margin: const EdgeInsets.only(right: 16),
//       child: Column(
//         children: [
//           Stack(
//             alignment: Alignment.bottomRight,
//             children: [
//               Container(
//                 width: 60,
//                 height: 60,
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   border: Border.all(color: Colors.orange, width: 2),
//                   image: DecorationImage(
//                     image: NetworkImage('https://i.pravatar.cc/150?u=$name'),
//                     fit: BoxFit.cover,
//                   ),
//                 ),
//               ),
//               if (isOnline)
//                 Container(
//                   width: 12,
//                   height: 12,
//                   decoration: BoxDecoration(
//                     color: Colors.green,
//                     shape: BoxShape.circle,
//                     border: Border.all(color: const Color(0xFF1A1A1A), width: 2),
//                   ),
//                 ),
//             ],
//           ),
//           const SizedBox(height: 6),
//           Text(
//             name,
//             style: const TextStyle(color: Colors.white, fontSize: 12),
//             textAlign: TextAlign.center,
//           ),
//           Text(
//             distance,
//             style: TextStyle(color: Colors.grey[500], fontSize: 10),
//             textAlign: TextAlign.center,
//           ),
//         ],
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       // Ensure the content is properly sized and prevent overflow
//       resizeToAvoidBottomInset: true,
//       appBar: AppBar(
//         title: Image.asset(
//           'assets/images/checkup_main-1.png',
//           height: 32,
//           fit: BoxFit.contain,
//           errorBuilder: (context, error, stackTrace) {
//             // Fallback to text if image fails to load
//             return Text(widget.title ?? 'Event Details');
//           },
//         ),
//         backgroundColor: Colors.black,
//         foregroundColor: Colors.white,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back),
//           onPressed: () => Navigator.of(context).pop(),
//         ),
//         actions: [
//           Container(
//             margin: const EdgeInsets.only(right: 16),
//             decoration: BoxDecoration(
//               gradient: const LinearGradient(
//                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                 begin: Alignment.topLeft,
//                 end: Alignment.bottomRight,
//               ),
//               borderRadius: BorderRadius.circular(20),
//               boxShadow: [
//                 BoxShadow(
//                   color: const Color(0xFFFF9800).withOpacity(0.3),
//                   blurRadius: 8,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ),
//             child: Material(
//               color: Colors.transparent,
//               child: InkWell(
//                 onTap: () {
//                   // Show the share modal with event details
//                   ShareModal.show(
//                     context: context,
//                     postId: widget.eventId ?? 'default_event_id',
//                     postContent: '${widget.title ?? 'Event'} - Check out this amazing event!',
//                     shareUrl: 'https://checkup.app/events/${widget.eventId ?? 'default_event_id'}',
//                   );
//                 },
//                 borderRadius: BorderRadius.circular(20),
//                 child: Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//                   child: Row(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       const Icon(
//                         Icons.share,
//                         color: Colors.white,
//                         size: 16,
//                       ),
//                       const SizedBox(width: 6),
//                       const Text(
//                         'Share',
//                         style: TextStyle(
//                           color: Colors.white,
//                           fontSize: 14,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//       body: Container(
//         decoration: const BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Color(0xFF0A0A0A), Color(0xFF1A1A1A)],
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//           ),
//         ),
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.only(bottom: 80),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               // Event image carousel (1:1 aspect ratio)
//               AspectRatio(
//                 aspectRatio: 1.0,
//                 child: Container(
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(0),
//                     boxShadow: [
//                       BoxShadow(
//                         color: Colors.black.withOpacity(0.3),
//                         blurRadius: 10,
//                         spreadRadius: 2,
//                       ),
//                     ],
//                   ),
//                   child: Stack(
//                     children: [
//                       // Image carousel
//                       PageView.builder(
//                         controller: _pageController,
//                         onPageChanged: (int page) {
//                           setState(() {
//                             _currentPage = page;
//                           });
//                         },
//                         itemCount: eventImages.length,
//                         itemBuilder: (context, index) {
//                           return Image.network(
//                             eventImages[index],
//                             fit: BoxFit.cover,
//                             loadingBuilder: (context, child, loadingProgress) {
//                               if (loadingProgress == null) return child;
//                               return Container(
//                                 color: Colors.grey[900],
//                                 child: const Center(
//                                   child: CircularProgressIndicator(color: Colors.orange),
//                                 ),
//                               );
//                             },
//                             errorBuilder: (context, error, stackTrace) {
//                               return Container(
//                                 color: Colors.grey[900],
//                                 child: const Center(
//                                   child: Icon(Icons.error_outline, color: Colors.orange, size: 50),
//                                 ),
//                               );
//                             },
//                           );
//                         },
//                       ),

//                       // Gradient overlay at bottom
//                       Positioned(
//                         bottom: 0,
//                         left: 0,
//                         right: 0,
//                         height: 100,
//                         child: Container(
//                           decoration: BoxDecoration(
//                             gradient: LinearGradient(
//                               begin: Alignment.bottomCenter,
//                               end: Alignment.topCenter,
//                               colors: [
//                                 Colors.black.withOpacity(0.8),
//                                 Colors.transparent,
//                               ],
//                             ),
//                           ),
//                         ),
//                       ),

//                       // HOST badge (top left)
//                       Positioned(
//                         top: 16,
//                         left: 16,
//                         child: Container(
//                           padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
//                           decoration: BoxDecoration(
//                             gradient: LinearGradient(
//                               begin: Alignment.topLeft,
//                               end: Alignment.bottomRight,
//                               colors: [Colors.orange[400]!, Colors.deepOrange[700]!],
//                             ),
//                             borderRadius: BorderRadius.circular(20),
//                             boxShadow: [
//                               BoxShadow(
//                                 color: Colors.black.withOpacity(0.4),
//                                 blurRadius: 10,
//                                 spreadRadius: 1,
//                                 offset: const Offset(0, 3),
//                               ),
//                             ],
//                             border: Border.all(
//                               color: Colors.white.withOpacity(0.3),
//                               width: 1,
//                             ),
//                           ),
//                           child: const Text(
//                             'HOST',
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.w900,
//                               fontSize: 14,
//                               letterSpacing: 0.8,
//                               shadows: [
//                                 Shadow(
//                                   offset: Offset(0, 1),
//                                   blurRadius: 2,
//                                   color: Color.fromRGBO(0, 0, 0, 0.5),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                       ),

//                       // Game type pill (bottom left)
//                       Positioned(
//                         bottom: 16,
//                         left: 16,
//                         child: Container(
//                           padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
//                           decoration: BoxDecoration(
//                             color: Colors.black.withOpacity(0.7),
//                             borderRadius: BorderRadius.circular(20),
//                           ),
//                           child: const Text(
//                             '3v3 Tournament',
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.bold,
//                               fontSize: 12,
//                             ),
//                           ),
//                         ),
//                       ),

//                       // Page indicator dots (bottom center)
//                       Positioned(
//                         bottom: 16,
//                         left: 0,
//                         right: 0,
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: List.generate(
//                             eventImages.length,
//                             (index) => Container(
//                               width: 8,
//                               height: 8,
//                               margin: const EdgeInsets.symmetric(horizontal: 4),
//                               decoration: BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: _currentPage == index
//                                     ? Colors.orange
//                                     : Colors.white.withOpacity(0.5),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
              
//               // Event details
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     // Event title
//                     Text(
//                       widget.title ?? '3v3 Summer Tournament',
//                       style: const TextStyle(
//                         color: Colors.white,
//                         fontSize: 24,
//                         fontWeight: FontWeight.bold,
//                         fontFamily: 'Montserrat',
//                       ),
//                     ),
//                     const SizedBox(height: 16),

//                     // Event info section with black gradient and orange accents
//                     Container(
//                       width: double.infinity,
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
//                           begin: Alignment.centerLeft,
//                           end: Alignment.centerRight,
//                         ),
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Color(0xFFFF9800), width: 1),
//                       ),
//                       child: Row(
//                         children: [
//                           Container(
//                             padding: const EdgeInsets.all(12),
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                             child: const Icon(Icons.calendar_today,
//                                 color: Colors.white, size: 24),
//                           ),
//                           const SizedBox(width: 16),
//                           Expanded(
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const Text(
//                                   'June 15, 2025',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 22,
//                                     fontWeight: FontWeight.bold,
//                                     letterSpacing: 0.5,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                                 const SizedBox(height: 4),
//                                 const Text(
//                                   '7:00 PM - 9:30 PM',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 16,
//                                     fontWeight: FontWeight.w500,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 24),

//                     // Host info (moved below time and date)
//                     Container(
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         color: Colors.grey[900],
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Colors.grey[700]!, width: 1),
//                       ),
//                       child: Row(
//                         children: [
//                           Container(
//                             width: 50,
//                             height: 50,
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               shape: BoxShape.circle,
//                             ),
//                             child: const Center(
//                               child: Icon(Icons.person, color: Colors.white, size: 24),
//                             ),
//                           ),
//                           const SizedBox(width: 16),
//                           Expanded(
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const Text(
//                                   'You (Host)',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 18,
//                                     fontWeight: FontWeight.bold,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                                 const SizedBox(height: 2),
//                                 Row(
//                                   children: [
//                                     Icon(Icons.verified, color: Colors.orange, size: 16),
//                                     const SizedBox(width: 4),
//                                     Text(
//                                       'Event Organizer',
//                                       style: TextStyle(
//                                         color: Colors.grey[400],
//                                         fontSize: 14,
//                                         fontFamily: 'Montserrat',
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                           Container(
//                             padding: const EdgeInsets.symmetric(
//                                 horizontal: 16, vertical: 8),
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               borderRadius: BorderRadius.circular(20),
//                             ),
//                             child: const Text(
//                               'Contact',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.w600,
//                                 fontSize: 12,
//                                 fontFamily: 'Montserrat',
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 16),

//                     // Court location section with modern styling
//                     Container(
//                       margin: const EdgeInsets.only(bottom: 16),
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         color: Colors.grey[900],
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Colors.grey[700]!, width: 1),
//                       ),
//                       child: Row(
//                         children: [
//                           Container(
//                             width: 50,
//                             height: 50,
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                             child: const Icon(
//                               Icons.sports_basketball,
//                               color: Colors.white,
//                               size: 24,
//                             ),
//                           ),
//                           const SizedBox(width: 16),
//                           Expanded(
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const Text(
//                                   'Rucker Park',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: 18,
//                                     fontWeight: FontWeight.bold,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                                 const SizedBox(height: 4),
//                                 Row(
//                                   children: [
//                                     const Icon(Icons.location_on,
//                                         color: Colors.orange, size: 16),
//                                     const SizedBox(width: 4),
//                                     Text(
//                                       'Harlem, New York',
//                                       style: TextStyle(
//                                         color: Colors.grey[400],
//                                         fontSize: 14,
//                                         fontFamily: 'Montserrat',
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                           Container(
//                             padding: const EdgeInsets.symmetric(
//                                 horizontal: 16, vertical: 8),
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                 begin: Alignment.centerLeft,
//                                 end: Alignment.centerRight,
//                               ),
//                               borderRadius: BorderRadius.circular(20),
//                             ),
//                             child: const Text(
//                               'Directions',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.w600,
//                                 fontSize: 12,
//                                 fontFamily: 'Montserrat',
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),

//                     // Description - Collapsible Event Details
//                     Container(
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
//                           begin: Alignment.centerLeft,
//                           end: Alignment.centerRight,
//                         ),
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Color(0xFFFF9800), width: 1),
//                       ),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           // Header row with expand/collapse button
//                           InkWell(
//                             onTap: () {
//                               setState(() {
//                                 _isDetailsExpanded = !_isDetailsExpanded;
//                               });
//                             },
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Row(
//                                   children: [
//                                     Container(
//                                       padding: const EdgeInsets.all(8),
//                                       decoration: BoxDecoration(
//                                         gradient: LinearGradient(
//                                           colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                           begin: Alignment.centerLeft,
//                                           end: Alignment.centerRight,
//                                         ),
//                                         borderRadius: BorderRadius.circular(8),
//                                       ),
//                                       child: const Icon(Icons.description_outlined,
//                                           color: Colors.white, size: 16),
//                                     ),
//                                     const SizedBox(width: 12),
//                                     const Text(
//                                       'Event Details',
//                                       style: TextStyle(
//                                         color: Colors.white,
//                                         fontSize: 18,
//                                         fontWeight: FontWeight.bold,
//                                         fontFamily: 'Montserrat',
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                                 Icon(
//                                   _isDetailsExpanded
//                                       ? Icons.keyboard_arrow_up
//                                       : Icons.keyboard_arrow_down,
//                                   color: Colors.orange,
//                                 ),
//                               ],
//                             ),
//                           ),
                          
//                           // Animated content section
//                           AnimatedCrossFade(
//                             firstChild: Container(
//                               margin: const EdgeInsets.only(top: 12),
//                               child: Text(
//                                 'Join us for an exciting 3v3 basketball tournament at the legendary Rucker Park! This event is perfect for players of all skill levels.',
//                                 style: TextStyle(
//                                   color: Colors.grey[300],
//                                   fontSize: 14,
//                                   height: 1.5,
//                                   fontFamily: 'Montserrat',
//                                 ),
//                               ),
//                             ),
//                             secondChild: Container(
//                               margin: const EdgeInsets.only(top: 12),
//                               child: Column(
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   Text(
//                                     'Join us for an exciting 3v3 basketball tournament at the legendary Rucker Park! This event is perfect for players of all skill levels looking to compete in a fun, energetic environment.',
//                                     style: TextStyle(
//                                       color: Colors.grey[300],
//                                       fontSize: 14,
//                                       height: 1.5,
//                                       fontFamily: 'Montserrat',
//                                     ),
//                                   ),
//                                   const SizedBox(height: 12),
//                                   const Text(
//                                     'Tournament Format:',
//                                     style: TextStyle(
//                                       color: Colors.white,
//                                       fontSize: 14,
//                                       fontWeight: FontWeight.bold,
//                                       fontFamily: 'Montserrat',
//                                     ),
//                                   ),
//                                   const SizedBox(height: 8),
//                                   Text(
//                                     '• Single elimination bracket\n• 10-minute games\n• First team to 21 points wins\n• Win by 2 points\n• 1 and 2-point scoring',
//                                     style: TextStyle(
//                                       color: Colors.grey[300],
//                                       fontSize: 14,
//                                       height: 1.5,
//                                       fontFamily: 'Montserrat',
//                                     ),
//                                   ),
//                                   const SizedBox(height: 12),
//                                   const Text(
//                                     'Prizes:',
//                                     style: TextStyle(
//                                       color: Colors.white,
//                                       fontSize: 14,
//                                       fontWeight: FontWeight.bold,
//                                       fontFamily: 'Montserrat',
//                                     ),
//                                   ),
//                                   const SizedBox(height: 8),
//                                   Text(
//                                     '• 1st Place: \$300 + Championship Trophies\n• 2nd Place: \$150\n• MVP Award: Custom Basketball',
//                                     style: TextStyle(
//                                       color: Colors.grey[300],
//                                       fontSize: 14,
//                                       height: 1.5,
//                                       fontFamily: 'Montserrat',
//                                     ),
//                                   ),
//                                   const SizedBox(height: 12),
//                                   Text(
//                                     _isDetailsExpanded ? 'Tap to see less...' : '',
//                                     style: TextStyle(
//                                       color: Colors.orange,
//                                       fontSize: 12,
//                                       fontStyle: FontStyle.italic,
//                                       fontFamily: 'Montserrat',
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                             crossFadeState: _isDetailsExpanded
//                                 ? CrossFadeState.showSecond
//                                 : CrossFadeState.showFirst,
//                             duration: const Duration(milliseconds: 300),
//                           ),
                          
//                           if (!_isDetailsExpanded)
//                             Container(
//                               margin: const EdgeInsets.only(top: 8),
//                               child: Text(
//                                 'Tap to see more details...',
//                                 style: TextStyle(
//                                   color: Colors.orange,
//                                   fontSize: 12,
//                                   fontStyle: FontStyle.italic,
//                                   fontFamily: 'Montserrat',
//                                 ),
//                               ),
//                             ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 16),
                    
//                     // Event Activity/Players section with modern styling
//                     Container(
//                       padding: const EdgeInsets.all(16),
//                       decoration: BoxDecoration(
//                         gradient: LinearGradient(
//                           colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
//                           begin: Alignment.centerLeft,
//                           end: Alignment.centerRight,
//                         ),
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: Color(0xFFFF9800), width: 1),
//                       ),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Row(
//                             children: [
//                               Container(
//                                 padding: const EdgeInsets.all(8),
//                                 decoration: BoxDecoration(
//                                   gradient: LinearGradient(
//                                     colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                     begin: Alignment.centerLeft,
//                                     end: Alignment.centerRight,
//                                   ),
//                                   borderRadius: BorderRadius.circular(8),
//                                 ),
//                                 child: const Icon(Icons.people_alt_outlined,
//                                     color: Colors.white, size: 16),
//                               ),
//                               const SizedBox(width: 12),
//                               const Text(
//                                 'Event Activity',
//                                 style: TextStyle(
//                                   color: Colors.white,
//                                   fontSize: 18,
//                                   fontWeight: FontWeight.bold,
//                                   fontFamily: 'Montserrat',
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 12),
//                           Row(
//                             children: [
//                               Text(
//                                 '24 registered',
//                                 style: TextStyle(
//                                   color: Colors.grey[400], 
//                                   fontSize: 14,
//                                   fontFamily: 'Montserrat',
//                                 ),
//                               ),
//                               const SizedBox(width: 8),
//                               Container(
//                                 width: 4,
//                                 height: 4,
//                                 decoration: BoxDecoration(
//                                   color: Colors.grey[600],
//                                   shape: BoxShape.circle,
//                                 ),
//                               ),
//                               const SizedBox(width: 8),
//                               Text(
//                                 '8 spots left',
//                                 style: TextStyle(
//                                   color: Colors.grey[400], 
//                                   fontSize: 14,
//                                   fontFamily: 'Montserrat',
//                                 ),
//                               ),
//                               const Spacer(),
//                               Container(
//                                 padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                                 decoration: BoxDecoration(
//                                   gradient: LinearGradient(
//                                     colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
//                                     begin: Alignment.centerLeft,
//                                     end: Alignment.centerRight,
//                                   ),
//                                   borderRadius: BorderRadius.circular(16),
//                                 ),
//                                 child: const Text(
//                                   'Manage',
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontWeight: FontWeight.w600,
//                                     fontSize: 12,
//                                     fontFamily: 'Montserrat',
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                           const SizedBox(height: 16),
//                           // Player avatars with proper spacing
//                           SingleChildScrollView(
//                             scrollDirection: Axis.horizontal,
//                             padding: EdgeInsets.zero,
//                             child: Row(
//                               children: [
//                                 _buildPlayerAvatar('Michael J.', '0.5 mi', true),
//                                 const SizedBox(width: 12),
//                                 _buildPlayerAvatar('Kobe B.', '1.2 mi', true),
//                                 const SizedBox(width: 12),
//                                 _buildPlayerAvatar('LeBron J.', '0.8 mi', true),
//                                 const SizedBox(width: 12),
//                                 _buildPlayerAvatar('Stephen C.', '1.5 mi', false),
//                                 const SizedBox(width: 16), // Extra padding at end
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     const SizedBox(height: 24),
                    
//                     // Feed section
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         const Text(
//                           'Feed',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 18,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                         TextButton(
//                           onPressed: () {},
//                           child: Text(
//                             'See All',
//                             style: TextStyle(color: Colors.orange[400]),
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(height: 12),

//                     // Create post widget from feed page
//                     CreatePostWidget(
//                       placeholder: "What's happening?",
//                       profileImagePath: 'assets/images/main_btn.png',
//                       isAssetImage: true,
//                       onTap: () {
//                         // Handle create post tap
//                       },
//                       onCameraTap: () {
//                         // Handle camera tap
//                       },
//                     ),
//                     const SizedBox(height: 16),

//                     // Feed posts from feed page
//                     ..._feedPosts.map((post) => Padding(
//                       padding: const EdgeInsets.only(bottom: 16),
//                       child: FeedPost(
//                         post: post,
//                         onLikeTap: () {},
//                         onCommentTap: () {},
//                         onRepostTap: () {},
//                         onShareTap: () {},
//                       ),
//                     )).toList(),
                    
//                     const SizedBox(height: 32),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//       bottomNavigationBar: Material(
//         color: Colors.black,
//         elevation: 8,
//         child: SafeArea(
//           child: Container(
//             height: 56,
//             decoration: BoxDecoration(
//               color: Colors.black,
//               border: Border(
//                 top: BorderSide(color: Colors.grey[900]!, width: 1),
//               ),
//             ),
//             padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//             child: Row(
//               children: [
//                 // Event status section
//                 Expanded(
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       const Text(
//                         'Event Status',
//                         style: TextStyle(
//                           color: Colors.white,
//                           fontSize: 11,
//                           fontWeight: FontWeight.w500,
//                         ),
//                       ),
//                       Row(
//                         children: [
//                           Container(
//                             width: 8,
//                             height: 8,
//                             decoration: const BoxDecoration(
//                               color: Colors.green,
//                               shape: BoxShape.circle,
//                             ),
//                           ),
//                           const SizedBox(width: 6),
//                           const Text(
//                             'Published',
//                             style: TextStyle(
//                               color: Colors.green,
//                               fontSize: 14,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//                 // Manage event button
//                 Container(
//                   height: 38,
//                   decoration: BoxDecoration(
//                     gradient: const LinearGradient(
//                       colors: [Colors.orange, Colors.deepOrange],
//                       begin: Alignment.centerLeft,
//                       end: Alignment.centerRight,
//                     ),
//                     borderRadius: BorderRadius.circular(19),
//                     boxShadow: [
//                       BoxShadow(
//                         color: Colors.orange.withOpacity(0.3),
//                         blurRadius: 6,
//                         spreadRadius: 0,
//                         offset: const Offset(0, 2),
//                       ),
//                     ],
//                   ),
//                   child: ElevatedButton(
//                     onPressed: () {
//                       // Navigate to the manage event page
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                           builder: (context) => ManageEventPage(
//                             eventId: widget.eventId,
//                             title: widget.title ?? '3v3 Summer Tournament',
//                           ),
//                         ),
//                       );
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: Colors.transparent,
//                       foregroundColor: Colors.white,
//                       shadowColor: Colors.transparent,
//                       elevation: 0,
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(19),
//                       ),
//                       padding: const EdgeInsets.symmetric(horizontal: 14),
//                     ),
//                     child: const Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(Icons.settings, size: 14),
//                         SizedBox(width: 4),
//                         Text(
//                           'Manage Event',
//                           style: TextStyle(
//                             fontSize: 12,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
  
  
//   // Build a create post section for the feed
//   Widget _buildCreatePostSection() {
//     return Container(
//       margin: const EdgeInsets.only(bottom: 16),
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.grey[900],
//         borderRadius: BorderRadius.circular(16),
//         border: Border.all(color: Colors.grey[800]!, width: 1),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.2),
//             blurRadius: 8,
//             offset: const Offset(0, 2),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Container(
//                 width: 40,
//                 height: 40,
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   gradient: LinearGradient(
//                     colors: [Colors.orange[300]!, Colors.orange[500]!],
//                     begin: Alignment.topLeft,
//                     end: Alignment.bottomRight,
//                   ),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withOpacity(0.3),
//                       blurRadius: 8,
//                       offset: const Offset(0, 2),
//                     ),
//                   ],
//                   border: Border.all(color: Colors.orange[700]!, width: 2),
//                 ),
//                 child: const Center(
//                   child: Icon(
//                     Icons.sentiment_very_satisfied,
//                     color: Colors.white,
//                     size: 24,
//                   ),
//                 ),
//               ),
//               const SizedBox(width: 12),
//               Expanded(
//                 child: TextField(
//                   decoration: InputDecoration(
//                     hintText: 'Share your thoughts about this event...',
//                     hintStyle: TextStyle(color: Colors.grey[500]),
//                     border: InputBorder.none,
//                     contentPadding: const EdgeInsets.symmetric(vertical: 8),
//                   ),
//                   style: const TextStyle(color: Colors.white),
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 16),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               TextButton.icon(
//                 onPressed: () {},
//                 icon: Icon(Icons.photo_camera, color: Colors.orange[400], size: 20),
//                 label: Text(
//                   'Add Photo',
//                   style: TextStyle(color: Colors.orange[400]),
//                 ),
//                 style: TextButton.styleFrom(
//                   padding: const EdgeInsets.symmetric(horizontal: 12),
//                 ),
//               ),
//               ElevatedButton(
//                 onPressed: () {},
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.orange[400],
//                   foregroundColor: Colors.white,
//                   padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(20),
//                   ),
//                 ),
//                 child: const Text('Post', style: TextStyle(fontWeight: FontWeight.bold)),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   // Build a feed item for the event feed section
//   Widget _buildFeedItem({
//     required String username,
//     required String profileImage,
//     required String content,
//     required String timeAgo,
//     required int likes,
//     bool hasImage = false,
//     String imageUrl = '',
//   }) {
//     return Container(
//       decoration: BoxDecoration(
//         color: Colors.grey[900],
//         borderRadius: BorderRadius.circular(12),
//       ),
//       padding: const EdgeInsets.all(12),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // User info row
//           Row(
//             children: [
//               // Profile image
//               CircleAvatar(
//                 radius: 18,
//                 backgroundColor: Colors.orange,
//                 backgroundImage: NetworkImage(profileImage),
//                 onBackgroundImageError: (_, __) {},
//               ),
//               const SizedBox(width: 10),
//               // Username and time
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     username,
//                     style: const TextStyle(
//                       color: Colors.white,
//                       fontWeight: FontWeight.bold,
//                       fontSize: 14,
//                     ),
//                   ),
//                   Text(
//                     timeAgo,
//                     style: TextStyle(
//                       color: Colors.grey[400],
//                       fontSize: 12,
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
          
//           const SizedBox(height: 12),
          
//           // Comment content
//           Text(
//             content,
//             style: const TextStyle(color: Colors.white, fontSize: 14),
//           ),
          
//           // Optional image
//           if (hasImage) ...[  
//             const SizedBox(height: 12),
//             ClipRRect(
//               borderRadius: BorderRadius.circular(8),
//               child: Image.network(
//                 imageUrl,
//                 height: 180,
//                 width: double.infinity,
//                 fit: BoxFit.cover,
//                 loadingBuilder: (context, child, loadingProgress) {
//                   if (loadingProgress == null) return child;
//                   return Container(
//                     height: 180,
//                     color: Colors.grey[800],
//                     child: const Center(
//                       child: CircularProgressIndicator(color: Colors.orange),
//                     ),
//                   );
//                 },
//                 errorBuilder: (context, error, stackTrace) {
//                   return Container(
//                     height: 180,
//                     color: Colors.grey[800],
//                     child: const Center(
//                       child: Icon(Icons.error_outline, color: Colors.orange),
//                     ),
//                   );
//                 },
//               ),
//             ),
//           ],
          
//           const SizedBox(height: 12),
          
//           // Likes and comments row
//           Row(
//             children: [
//               Icon(Icons.favorite, color: Colors.red[400], size: 18),
//               const SizedBox(width: 4),
//               Text(
//                 '$likes',
//                 style: TextStyle(color: Colors.grey[400], fontSize: 14),
//               ),
//               const SizedBox(width: 16),
//               const Icon(Icons.chat_bubble_outline, color: Colors.grey, size: 18),
//               const SizedBox(width: 4),
//               Text(
//                 'Reply',
//                 style: TextStyle(color: Colors.grey[400], fontSize: 14),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }
