// import 'package:flutter/material.dart';
// import 'package:check_up_app/core/theme/app_colors.dart';
// import 'package:check_up_app/features/events/domain/models/event_type.dart';
// import 'package:check_up_app/features/events/domain/models/location_model.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_type_selector.dart';
// import 'package:check_up_app/features/events/presentation/widgets/dynamic_event_form_fields.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_preview.dart';
// import 'package:check_up_app/features/events/presentation/widgets/modern_date_time_picker.dart';
// import 'package:check_up_app/features/events/presentation/widgets/enhanced_location_selector.dart';
// import 'package:check_up_app/features/events/presentation/widgets/registration_pricing_form.dart';
// import 'package:check_up_app/features/events/presentation/widgets/event_specific_details.dart';
// import 'package:check_up_app/features/search/domain/models/team_model.dart';

// /// A page for creating events with dynamic form fields based on event type
// class CreateEventPage extends StatefulWidget {
//   /// Creates a [CreateEventPage] instance
//   const CreateEventPage({Key? key}) : super(key: key);

//   @override
//   State<CreateEventPage> createState() => _CreateEventPageState();
// }

// class _CreateEventPageState extends State<CreateEventPage> {
//   // Step tracking
//   int _currentStep = 0;
  
//   // Event type selection
//   EventType? _selectedEventType;
  
//   // Common form controllers
//   final TextEditingController _titleController = TextEditingController();
//   final TextEditingController _descriptionController = TextEditingController();
//   DateTime? _selectedDateTime;
//   final TextEditingController _locationController = TextEditingController();
//   LocationModel? _selectedLocation;
//   bool _isLocationPrivate = false;
//   bool _isEventPrivate = false;
//   bool _isFree = true;
//   final TextEditingController _priceController = TextEditingController();
//   String? _selectedSkillLevel;
  
//   // Pickup Run fields
//   final _maxPlayersController = TextEditingController();
  
//   // Tournament fields
//   final _numberOfTeamsController = TextEditingController();
//   String? _selectedFormat;
//   final _prizePoolController = TextEditingController();
//   DateTime? _registrationDeadline;
//   bool _wantToAddTeams = false; // Toggle for adding teams now
//   List<TeamModel> _selectedTeams = []; // List of selected teams
//   bool _useManualTeamInput = false; // Toggle between search and manual input
  
//   // League Games fields
//   String? _selectedSeason;
//   String? _selectedGameType;
  
//   // One-on-One fields
//   final _player1Controller = TextEditingController();
//   final _player2Controller = TextEditingController();
//   String? _selectedGameFormat;
  
//   // Donation fields
//   final _donationGoalController = TextEditingController();
//   final _beneficiaryController = TextEditingController();
//   bool _hasTaxReceipts = false; // Used for charity events
  
//   // Registration & Pricing fields
//   final _capacityController = TextEditingController();
//   bool _isRegistrationOpen = true; // Always open by default since we removed the toggle
  
//   // Ticket types
//   List<Map<String, dynamic>> _ticketTypes = [];
//   final _ticketNameController = TextEditingController();
//   final _ticketPriceController = TextEditingController();
//   final _ticketQuantityController = TextEditingController();
  
//   // Legacy pricing fields (will be replaced by ticket types)
//   bool _hasEarlyBirdPricing = false;
//   final _earlyBirdPriceController = TextEditingController();
//   DateTime? _earlyBirdDeadline;
  
//   // Waiver fields
//   bool _requiresWaiver = false;
//   final _waiverTextController = TextEditingController();
//   String? _selectedWaiverTemplate;
  
//   // Custom registration questions
//   bool _hasCustomQuestions = false;
//   List<Map<String, dynamic>> _customQuestions = [];
//   final _questionTextController = TextEditingController();
//   final _questionOptionsController = TextEditingController();
  
//   @override
//   void dispose() {
//     _titleController.dispose();
//     _descriptionController.dispose();
//     _locationController.dispose();
//     _priceController.dispose();
//     _maxPlayersController.dispose();
//     _numberOfTeamsController.dispose();
//     _prizePoolController.dispose();
//     _player1Controller.dispose();
//     _player2Controller.dispose();
//     _donationGoalController.dispose();
//     _beneficiaryController.dispose();
//     _capacityController.dispose();
    
//     // Ticket type controllers
//     _ticketNameController.dispose();
//     _ticketPriceController.dispose();
//     _ticketQuantityController.dispose();
    
//     // Legacy pricing controllers
//     _earlyBirdPriceController.dispose();
//     _waiverTextController.dispose();
    
//     // Custom questions controllers
//     _questionTextController.dispose();
//     _questionOptionsController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.primaryBlack,
//       appBar: AppBar(
//         backgroundColor: AppColors.primaryBlack,
//         elevation: 0,
//         title: const Text(
//           'Create Event',
//           style: TextStyle(
//             color: Colors.white,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back, color: Colors.white),
//           onPressed: () => Navigator.of(context).pop(),
//         ),
//         actions: [
//           TextButton(
//             onPressed: _saveDraft,
//             child: ShaderMask(
//               shaderCallback: (Rect bounds) {
//                 return AppColors.orangeGradient.createShader(bounds);
//               },
//               child: const Text(
//                 'Save Draft',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//       body: _buildBody(),
//       bottomNavigationBar: _buildBottomBar(),
//     );
//   }

//   Widget _buildBody() {
//     return SingleChildScrollView(
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // Removed step indicators for question-based flow
//           const SizedBox(height: 16),
//           _buildCurrentStep(),
//           if (_currentStep == 3) ... [
//             const SizedBox(height: 24),
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16),
//               child: EventPreview(
//                 title: _titleController.text,
//                 dateTime: _selectedDateTime,
//                 location: _locationController.text,
//                 eventType: _selectedEventType,
//                 isFree: _isFree,
//                 price: _isFree ? null : double.tryParse(_priceController.text),
//                 isPrivate: _isEventPrivate,
//               ),
//             ),
//           ],
//           const SizedBox(height: 100), // Extra space at bottom for scrolling
//         ],
//       ),
//     );
//   }

//   Widget _buildProgressIndicator() {
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 16.0),
//       child: Row(
//         children: [
//           _buildStepIndicator(0, 'Type'),
//           _buildStepConnector(0),
//           _buildStepIndicator(1, 'Info'),
//           _buildStepConnector(1),
//           _buildStepIndicator(2, 'Pricing'),
//           _buildStepConnector(2),
//           _buildStepIndicator(3, 'Preview'),
//         ],
//       ),
//     );
//   }

//   Widget _buildStepIndicator(int step, String label) {
//     final isActive = _currentStep >= step;
//     final isCurrent = _currentStep == step;
    
//     return Expanded(
//       child: Column(
//         children: [
//           Container(
//             width: 40.0,
//             height: 40.0,
//             decoration: BoxDecoration(
//               shape: BoxShape.circle,
//               gradient: isActive ? AppColors.orangeGradient : null,
//               color: isActive ? null : AppColors.darkGray,
//               border: Border.all(
//                 color: isCurrent ? Colors.white : Colors.transparent,
//                 width: 2,
//               ),
//             ),
//             child: Center(
//               child: Text(
//                 '${step + 1}',
//                 style: TextStyle(
//                   color: isActive ? Colors.white : Colors.grey[400],
//                   fontWeight: FontWeight.bold,
//                   fontSize: 16,
//                 ),
//               ),
//             ),
//           ),
//           const SizedBox(height: 4),
//           Text(
//             label,
//             style: TextStyle(
//               color: isActive ? Colors.white : Colors.grey[400],
//               fontSize: 11,
//             ),
//             textAlign: TextAlign.center,
//             maxLines: 1,
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildStepConnector(int step) {
//     final isActive = _currentStep > step;
    
//     return Container(
//       width: 40.0,
//       height: 4.0,
//       decoration: BoxDecoration(
//         gradient: isActive ? AppColors.orangeGradient : null,
//         color: isActive ? null : AppColors.darkGray,
//       ),
//     );
//   }

//   Widget _buildCurrentStep() {
//     switch (_currentStep) {
//       case 0:
//         return Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 16.0),
//           child: EventTypeSelector(
//             selectedType: _selectedEventType,
//             onTypeSelected: (type) {
//               setState(() {
//                 _selectedEventType = type;
//                 _currentStep = 1;
//               });
//             },
//           ),
//         );
//       case 1:
//         return _buildTitleStep();
//       case 2:
//         return _buildDescriptionStep();
//       case 3:
//         return _buildDateTimeStep();
//       case 4:
//         return _buildLocationStep();
//       case 5:
//         return _buildPrivacyStep();
//       case 6:
//         return _buildSkillLevelStep();
//       case 7:
//         return _buildRegistrationStep();
//       case 8:
//         return _buildTicketTypesStep();
//       case 9:
//         return _buildPreviewStep();
//       default:
//         return _buildTitleStep();
//     }
//   }
//       case 2:
//         return Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 16.0),
//           child: RegistrationPricingForm(
//             // Event-specific details section
//             eventSpecificDetailsBuilder: _selectedEventType != null ? () {
//               // Return the appropriate event-specific details based on event type
//               switch (_selectedEventType!) {
//                 case EventType.camp:
//                   return EventSpecificDetails(
//                     eventType: _selectedEventType!,
//                     numberOfDaysController: _numberOfTeamsController, // Reusing numberOfTeamsController for days
//                     maxParticipantsController: _maxPlayersController,
//                     registrationDeadline: _registrationDeadline,
//                     onRegistrationDeadlineSelected: (deadline) {
//                       setState(() {
//                         _registrationDeadline = deadline;
//                       });
//                     },
//                   );
//                 case EventType.tournament:
//                   return EventSpecificDetails(
//                     eventType: _selectedEventType!,
//                     numberOfTeamsController: _numberOfTeamsController,
//                     prizePoolController: _prizePoolController,
//                     selectedFormat: _selectedFormat,
//                     onFormatSelected: (format) {
//                       setState(() {
//                         _selectedFormat = format;
//                       });
//                     },
//                     registrationDeadline: _registrationDeadline,
//                     onRegistrationDeadlineSelected: (deadline) {
//                       setState(() {
//                         _registrationDeadline = deadline;
//                       });
//                     },
//                     wantToAddTeams: _wantToAddTeams,
//                     onWantToAddTeamsChanged: (value) {
//                       setState(() {
//                         _wantToAddTeams = value;
//                       });
//                     },
//                   );
//                 case EventType.training:
//                   return EventSpecificDetails(
//                     eventType: _selectedEventType!,
//                     maxParticipantsController: _maxPlayersController,
//                     selectedSkillLevel: _selectedSkillLevel,
//                     onSkillLevelSelected: (level) {
//                       setState(() {
//                         _selectedSkillLevel = level;
//                       });
//                     },
//                   );
//                 case EventType.donationBased:
//                   return EventSpecificDetails(
//                     eventType: _selectedEventType!,
//                     donationGoalController: _donationGoalController,
//                     beneficiaryController: _beneficiaryController,
//                     hasTaxReceipts: _hasTaxReceipts,
//                     onTaxReceiptsChanged: (value) {
//                       setState(() {
//                         _hasTaxReceipts = value;
//                       });
//                     },
//                   );
//                 case EventType.oneOff:
//                   return EventSpecificDetails(
//                     eventType: _selectedEventType!,
//                     selectedSeason: _selectedSeason,
//                     onSeasonSelected: (season) {
//                       setState(() {
//                         _selectedSeason = season;
//                       });
//                     },
//                     selectedGameType: _selectedGameType,
//                     onGameTypeSelected: (gameType) {
//                       setState(() {
//                         _selectedGameType = gameType;
//                       });
//                     },
//                     registrationDeadline: _registrationDeadline,
//                     onRegistrationDeadlineSelected: (deadline) {
//                       setState(() {
//                         _registrationDeadline = deadline;
//                       });
//                     },
//                     wantToAddTeams: _wantToAddTeams,
//                     onWantToAddTeamsChanged: (value) {
//                       setState(() {
//                         _wantToAddTeams = value;
//                       });
//                     },
//                   );
//                 case EventType.pickupRun:
//                   return EventSpecificDetails(
//                     eventType: _selectedEventType!,
//                     maxParticipantsController: _maxPlayersController,
//                     selectedSkillLevel: _selectedSkillLevel,
//                     onSkillLevelSelected: (level) {
//                       setState(() {
//                         _selectedSkillLevel = level;
//                       });
//                     },
//                   );
//                 default:
//                   return const SizedBox.shrink(); // No specific details for special events
//               }
//             } : null,
            
//             // Registration settings
//             capacityController: _capacityController,
//             isRegistrationOpen: _isRegistrationOpen,
//             onRegistrationStatusChanged: (value) {
//               setState(() {
//                 _isRegistrationOpen = value;
//               });
//             },
            
//             // Ticket types settings
//             ticketTypes: _ticketTypes,
//             onTicketTypesUpdated: (tickets) {
//               setState(() {
//                 _ticketTypes = tickets;
//               });
//             },
//             ticketNameController: _ticketNameController,
//             ticketPriceController: _ticketPriceController,
//             ticketQuantityController: _ticketQuantityController,
            
//             // Custom questions settings
//             hasCustomQuestions: _hasCustomQuestions,
//             onCustomQuestionsChanged: (value) {
//               setState(() {
//                 _hasCustomQuestions = value;
//               });
//             },
//             customQuestions: _customQuestions,
//             onCustomQuestionsUpdated: (questions) {
//               setState(() {
//                 _customQuestions = questions;
//               });
//             },
//             questionTextController: _questionTextController,
//             questionOptionsController: _questionOptionsController,
            
//             // Early bird pricing settings (legacy)
//             hasEarlyBirdPricing: _hasEarlyBirdPricing,
//             onEarlyBirdPricingChanged: (value) {
//               setState(() {
//                 _hasEarlyBirdPricing = value;
//               });
//             },
//             earlyBirdPriceController: _earlyBirdPriceController,
//             earlyBirdDeadline: _earlyBirdDeadline,
//             onEarlyBirdDeadlineSelected: (date) {
//               setState(() {
//                 _earlyBirdDeadline = date;
//               });
//             },
            
//             // Waiver settings
//             requiresWaiver: _requiresWaiver,
//             onWaiverRequirementChanged: (value) {
//               setState(() {
//                 _requiresWaiver = value;
//               });
//             },
//             waiverTextController: _waiverTextController,
//             selectedWaiverTemplate: _selectedWaiverTemplate,
//             onWaiverTemplateSelected: (template) {
//               setState(() {
//                 _selectedWaiverTemplate = template;
//               });
//             },
//           ),
//         );
//       case 3:
//         return Container(); // Preview is shown in _buildBody
//       default:
//         return Container();
//     }
//   }

//   Widget _buildBottomBar() {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: AppColors.primaryBlack,
//         border: Border(
//           top: BorderSide(color: AppColors.darkGray, width: 1),
//         ),
//       ),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           if (_currentStep > 0)
//             TextButton(
//               onPressed: _previousStep,
//               child: const Text(
//                 'Back',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 16,
//                 ),
//               ),
//             )
//           else
//             const SizedBox.shrink(),
//           Container(
//             decoration: _isNextButtonEnabled() ? BoxDecoration(
//               gradient: AppColors.orangeGradient,
//               borderRadius: BorderRadius.circular(24),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.orange.withOpacity(0.3),
//                   blurRadius: 8,
//                   offset: const Offset(0, 4),
//                 ),
//               ],
//             ) : BoxDecoration(
//               color: AppColors.darkGray,
//               borderRadius: BorderRadius.circular(24),
//             ),
//             child: ElevatedButton(
//               onPressed: _isNextButtonEnabled() ? _nextStep : null,
//               style: ElevatedButton.styleFrom(
//                 padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(24),
//                 ),
//                 backgroundColor: Colors.transparent,
//                 elevation: 0,
//                 shadowColor: Colors.transparent,
//               ),
//               child: Text(
//                 _currentStep == 3 ? 'Create Event' : 'Next',
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 16,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   bool _isNextButtonEnabled() {
//     // Always return true to enable navigation through all tabs
//     // This allows viewing the preview tab regardless of form completion
//     return true;
//   }

//   void _nextStep() {
//     if (_currentStep < 3) {
//       // If no event type is selected in step 0, default to the first type to avoid null issues
//       if (_currentStep == 0 && _selectedEventType == null) {
//         setState(() {
//           _selectedEventType = EventType.pickupRun; // Default to first event type
//           _currentStep++;
//         });
//       } else {
//         setState(() {
//           _currentStep++;
//         });
//       }
//     } else {
//       _createEvent();
//     }
//   }

//   void _previousStep() {
//     if (_currentStep > 0) {
//       setState(() {
//         _currentStep--;
//       });
//     }
//   }

//   void _saveDraft() {
//     // Show a snackbar to indicate the draft was saved
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         content: Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               colors: [
//                 Colors.orange[400]!,
//                 Colors.deepOrange[700]!,
//               ],
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//             ),
//             borderRadius: BorderRadius.circular(8),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.orange.withOpacity(0.3),
//                 blurRadius: 8,
//                 offset: const Offset(0, 4),
//               ),
//             ],
//           ),
//           child: const Text('Draft saved successfully'),
//         ),
//       ),
//     );
//   }
  
//   void _createEvent() {
//     // Collect all the event data
//     Map<String, dynamic> eventData = {
//       'title': _titleController.text,
//       'description': _descriptionController.text,
//       'location': _locationController.text,
//       'dateTime': _selectedDateTime,
//       'eventType': _selectedEventType,
//       'isPrivate': _isEventPrivate,
//       'isLocationPrivate': _isLocationPrivate,
//       'isFree': _isFree && _ticketTypes.isEmpty,
//       'price': _isFree ? null : double.tryParse(_priceController.text),
//       'registrationData': {
//         'isRegistrationOpen': _isRegistrationOpen,
//         'capacityLimit': _capacityController.text,
//         'ticketTypes': _ticketTypes,
//         // Legacy pricing fields (kept for backward compatibility)
//         'hasEarlyBirdPricing': _hasEarlyBirdPricing,
//         'earlyBirdPrice': _earlyBirdPriceController.text,
//         'earlyBirdDeadline': _earlyBirdDeadline,
//         'requiresWaiver': _requiresWaiver,
//         'selectedWaiverTemplate': _selectedWaiverTemplate,
//         'hasCustomQuestions': _hasCustomQuestions,
//         'customQuestions': _customQuestions,
//       }
//     };
    
//     // Use eventData for API calls or database operations
//     print('Event created with data: $eventData');
    
//     // In a real app, we would save this data to a database or API
//     // For now, just show a success message
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         content: Container(
//           padding: const EdgeInsets.all(16),
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               colors: [
//                 Colors.orange[400]!,
//                 Colors.deepOrange[700]!,
//               ],
//               begin: Alignment.topLeft,
//               end: Alignment.bottomRight,
//             ),
//             borderRadius: BorderRadius.circular(8),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.orange.withOpacity(0.3),
//                 blurRadius: 8,
//                 offset: const Offset(0, 4),
//               ),
//             ],
//           ),
//           child: const Text('Event created successfully'),
//         ),
//       ),
//     );
    
//     // Navigate back after creating the event
//     Navigator.of(context).pop();
//   }

//   Widget _buildTitleStep() {
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Spacer(),
//           const Text(
//             'What would you like to call your event?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 32),
//           TextField(
//             controller: _titleController,
//             style: const TextStyle(color: Colors.white, fontSize: 18),
//             decoration: InputDecoration(
//               hintText: 'Enter event title...',
//               hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
//               filled: true,
//               fillColor: AppColors.secondaryBlack,
//               border: OutlineInputBorder(
//                 borderRadius: BorderRadius.circular(12),
//                 borderSide: BorderSide.none,
//               ),
//               contentPadding: const EdgeInsets.all(20),
//             ),
//           ),
//           const Spacer(),
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               onPressed: () {
//                 setState(() {
//                   _currentStep = 2;
//                 });
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primaryOrange,
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//               ),
//               child: const Text(
//                 'Continue',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildDescriptionStep() {
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Spacer(),
//           const Text(
//             'How would you describe your event?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 32),
//           TextField(
//             controller: _descriptionController,
//             maxLines: 4,
//             style: const TextStyle(color: Colors.white, fontSize: 18),
//             decoration: InputDecoration(
//               hintText: 'Tell people what your event is about...',
//               hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
//               filled: true,
//               fillColor: AppColors.secondaryBlack,
//               border: OutlineInputBorder(
//                 borderRadius: BorderRadius.circular(12),
//                 borderSide: BorderSide.none,
//               ),
//               contentPadding: const EdgeInsets.all(20),
//             ),
//           ),
//           const Spacer(),
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               onPressed: () {
//                 setState(() {
//                   _currentStep = 3;
//                 });
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primaryOrange,
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//               ),
//               child: const Text(
//                 'Continue',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildDateTimeStep() {
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Spacer(),
//           const Text(
//             'When is your event happening?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 32),
//           ModernDateTimePicker(
//             selectedDateTime: _selectedDateTime,
//             onDateTimeSelected: (dateTime) {
//               setState(() {
//                 _selectedDateTime = dateTime;
//               });
//             },
//           ),
//           const Spacer(),
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               onPressed: () {
//                 setState(() {
//                   _currentStep = 4;
//                 });
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primaryOrange,
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//               ),
//               child: const Text(
//                 'Continue',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildLocationStep() {
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Spacer(),
//           const Text(
//             'Where is your event taking place?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 32),
//           EnhancedLocationSelector(
//             selectedLocation: _selectedLocation,
//             isLocationPrivate: _isLocationPrivate,
//             onLocationSelected: (location) {
//               setState(() {
//                 _selectedLocation = location;
//               });
//             },
//             onPrivacyChanged: (value) {
//               setState(() {
//                 _isLocationPrivate = value;
//               });
//             },
//             locationController: _locationController,
//           ),
//           const Spacer(),
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               onPressed: () {
//                 setState(() {
//                   _currentStep = 5;
//                 });
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primaryOrange,
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//               ),
//               child: const Text(
//                 'Continue',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildPrivacyStep() {
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Spacer(),
//           const Text(
//             'Who can see and join your event?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 32),
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               color: AppColors.secondaryBlack,
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Column(
//               children: [
//                 Row(
//                   children: [
//                     Icon(
//                       _isEventPrivate ? Icons.lock : Icons.public,
//                       color: Colors.white,
//                     ),
//                     const SizedBox(width: 12),
//                     Expanded(
//                       child: Text(
//                         _isEventPrivate ? 'Private Event' : 'Public Event',
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontSize: 18,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                     Switch(
//                       value: !_isEventPrivate,
//                       onChanged: (value) {
//                         setState(() {
//                           _isEventPrivate = !value;
//                         });
//                       },
//                       activeColor: AppColors.primaryOrange,
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 12),
//                 Text(
//                   _isEventPrivate 
//                     ? 'Only people you invite can see and join this event'
//                     : 'Anyone can see and join this event',
//                   style: TextStyle(
//                     color: Colors.white.withOpacity(0.7),
//                     fontSize: 14,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           const Spacer(),
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               onPressed: () {
//                 setState(() {
//                   _currentStep = 6;
//                 });
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primaryOrange,
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//               ),
//               child: const Text(
//                 'Continue',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildSkillLevelStep() {
//     final skillLevels = ['Beginner', 'Intermediate', 'Advanced', 'All Levels'];
    
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Spacer(),
//           const Text(
//             'What skill level is this event for?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 32),
//           ...skillLevels.map((level) => Container(
//             margin: const EdgeInsets.only(bottom: 12),
//             child: InkWell(
//               onTap: () {
//                 setState(() {
//                   _selectedSkillLevel = level;
//                   _currentStep = 7;
//                 });
//               },
//               child: Container(
//                 padding: const EdgeInsets.all(20),
//                 decoration: BoxDecoration(
//                   color: _selectedSkillLevel == level 
//                     ? AppColors.primaryOrange.withOpacity(0.2)
//                     : AppColors.secondaryBlack,
//                   borderRadius: BorderRadius.circular(12),
//                   border: Border.all(
//                     color: _selectedSkillLevel == level 
//                       ? AppColors.primaryOrange 
//                       : Colors.transparent,
//                     width: 2,
//                   ),
//                 ),
//                 child: Row(
//                   children: [
//                     Icon(
//                       _getSkillLevelIcon(level),
//                       color: _selectedSkillLevel == level 
//                         ? AppColors.primaryOrange 
//                         : Colors.white,
//                       size: 24,
//                     ),
//                     const SizedBox(width: 16),
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             level,
//                             style: TextStyle(
//                               color: _selectedSkillLevel == level 
//                                 ? AppColors.primaryOrange 
//                                 : Colors.white,
//                               fontSize: 18,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                           Text(
//                             _getSkillLevelDescription(level),
//                             style: TextStyle(
//                               color: Colors.white.withOpacity(0.7),
//                               fontSize: 14,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     if (_selectedSkillLevel == level)
//                       Icon(
//                         Icons.check_circle,
//                         color: AppColors.primaryOrange,
//                         size: 24,
//                       ),
//                   ],
//                 ),
//               ),
//             ),
//           )).toList(),
//           const Spacer(),
//         ],
//       ),
//     );
//   }

//   Widget _buildRegistrationStep() {
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Spacer(),
//           const Text(
//             'How many people can join your event?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 32),
//           TextField(
//             controller: _capacityController,
//             keyboardType: TextInputType.number,
//             style: const TextStyle(color: Colors.white, fontSize: 18),
//             decoration: InputDecoration(
//               hintText: 'Enter maximum capacity...',
//               hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
//               filled: true,
//               fillColor: AppColors.secondaryBlack,
//               border: OutlineInputBorder(
//                 borderRadius: BorderRadius.circular(12),
//                 borderSide: BorderSide.none,
//               ),
//               contentPadding: const EdgeInsets.all(20),
//               prefixIcon: Icon(
//                 Icons.group,
//                 color: Colors.white.withOpacity(0.6),
//               ),
//             ),
//           ),
//           const SizedBox(height: 24),
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               color: AppColors.secondaryBlack,
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Row(
//               children: [
//                 Icon(
//                   _isRegistrationOpen ? Icons.how_to_reg : Icons.block,
//                   color: Colors.white,
//                 ),
//                 const SizedBox(width: 12),
//                 Expanded(
//                   child: Text(
//                     _isRegistrationOpen ? 'Registration Open' : 'Registration Closed',
//                     style: const TextStyle(
//                       color: Colors.white,
//                       fontSize: 18,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                 ),
//                 Switch(
//                   value: _isRegistrationOpen,
//                   onChanged: (value) {
//                     setState(() {
//                       _isRegistrationOpen = value;
//                     });
//                   },
//                   activeColor: AppColors.primaryOrange,
//                 ),
//               ],
//             ),
//           ),
//           const Spacer(),
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               onPressed: () {
//                 setState(() {
//                   _currentStep = 8;
//                 });
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primaryOrange,
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//               ),
//               child: const Text(
//                 'Continue',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildTicketTypesStep() {
//     return Padding(
//       padding: const EdgeInsets.all(24.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Spacer(),
//           const Text(
//             'How much does it cost to join?',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 28,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//           const SizedBox(height: 32),
//           Container(
//             padding: const EdgeInsets.all(20),
//             decoration: BoxDecoration(
//               color: AppColors.secondaryBlack,
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Column(
//               children: [
//                 Row(
//                   children: [
//                     Icon(
//                       _isFree ? Icons.money_off : Icons.attach_money,
//                       color: Colors.white,
//                     ),
//                     const SizedBox(width: 12),
//                     Expanded(
//                       child: Text(
//                         _isFree ? 'Free Event' : 'Paid Event',
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontSize: 18,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                     Switch(
//                       value: _isFree,
//                       onChanged: (value) {
//                         setState(() {
//                           _isFree = value;
//                         });
//                       },
//                       activeColor: AppColors.primaryOrange,
//                     ),
//                   ],
//                 ),
//                 if (!_isFree) ...[
//                   const SizedBox(height: 20),
//                   TextField(
//                     controller: _priceController,
//                     keyboardType: TextInputType.number,
//                     style: const TextStyle(color: Colors.white, fontSize: 18),
//                     decoration: InputDecoration(
//                       hintText: 'Enter price per person...',
//                       hintStyle: TextStyle(color: Colors.white.withOpacity(0.6)),
//                       filled: true,
//                       fillColor: AppColors.darkGray,
//                       border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(12),
//                         borderSide: BorderSide.none,
//                       ),
//                       contentPadding: const EdgeInsets.all(20),
//                       prefixIcon: Icon(
//                         Icons.attach_money,
//                         color: Colors.white.withOpacity(0.6),
//                       ),
//                     ),
//                   ),
//                 ],
//               ],
//             ),
//           ),
//           const Spacer(),
//           SizedBox(
//             width: double.infinity,
//             child: ElevatedButton(
//               onPressed: () {
//                 setState(() {
//                   _currentStep = 9;
//                 });
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: AppColors.primaryOrange,
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//               ),
//               child: const Text(
//                 'Continue',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   IconData _getSkillLevelIcon(String level) {
//     switch (level) {
//       case 'Beginner':
//         return Icons.school;
//       case 'Intermediate':
//         return Icons.trending_up;
//       case 'Advanced':
//         return Icons.star;
//       case 'All Levels':
//         return Icons.groups;
//       default:
//         return Icons.help;
//     }
//   }

//   String _getSkillLevelDescription(String level) {
//     switch (level) {
//       case 'Beginner':
//         return 'Perfect for those just starting out';
//       case 'Intermediate':
//         return 'For players with some experience';
//       case 'Advanced':
//         return 'For highly skilled and competitive players';
//       case 'All Levels':
//         return 'Welcome to players of any skill level';
//       default:
//         return '';
//     }
//   }
// }
