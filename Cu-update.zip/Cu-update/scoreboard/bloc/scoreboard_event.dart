import 'package:equatable/equatable.dart';
import '../domain/models/team_model.dart';
import '../domain/models/player_model.dart';

abstract class ScoreboardEvent extends Equatable {
  const ScoreboardEvent();

  @override
  List<Object?> get props => [];
}

class ScoreboardInitialized extends ScoreboardEvent {
  final List<TeamModel>? teams;
  final List<dynamic>? gameActions;
  final bool startWithSettings;

  const ScoreboardInitialized({
    this.teams,
    this.gameActions,
    this.startWithSettings = false,
  });

  @override
  List<Object?> get props => [teams, gameActions, startWithSettings];
}

class ScoreboardTeamSelected extends ScoreboardEvent {
  final TeamModel team;

  const ScoreboardTeamSelected(this.team);

  @override
  List<Object?> get props => [team];
}

class ScoreboardScoreUpdated extends ScoreboardEvent {
  final TeamModel team;
  final int points;
  final PlayerModel player;
  final String actionName;

  const ScoreboardScoreUpdated({
    required this.team,
    required this.points,
    required this.player,
    required this.actionName,
  });

  @override
  List<Object?> get props => [team, points, player, actionName];
}

class ScoreboardPeriodIncremented extends ScoreboardEvent {
  const ScoreboardPeriodIncremented();
}

class ScoreboardLiveToggled extends ScoreboardEvent {
  const ScoreboardLiveToggled();
}

class ScoreboardUndoRequested extends ScoreboardEvent {
  const ScoreboardUndoRequested();
}

class ScoreboardSettingsUpdated extends ScoreboardEvent {
  final List<TeamModel> updatedTeams;
  final int updatedPeriod;

  const ScoreboardSettingsUpdated({
    required this.updatedTeams,
    required this.updatedPeriod,
  });

  @override
  List<Object?> get props => [updatedTeams, updatedPeriod];
}
