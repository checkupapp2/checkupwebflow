import 'package:equatable/equatable.dart';
import '../domain/models/team_model.dart';
import '../domain/models/game_action_model.dart';

enum ScoreboardStatus {
  initial,
  loading,
  ready,
  error,
}

class ScoreboardState extends Equatable {
  const ScoreboardState({
    this.status = ScoreboardStatus.initial,
    this.teams = const [],
    this.selectedTeam,
    this.currentPeriod = 1,
    this.isLive = false,
    this.gameActions = const [],
    this.undoStack = const [],
    this.error,
  });

  final ScoreboardStatus status;
  final List<TeamModel> teams;
  final TeamModel? selectedTeam;
  final int currentPeriod;
  final bool isLive;
  final List<GameActionModel> gameActions;
  final List<Map<String, dynamic>> undoStack;
  final String? error;

  // Helper getters
  bool get hasTeams => teams.isNotEmpty;
  bool get canUndo => undoStack.isNotEmpty;
  TeamModel? get homeTeam => teams.isNotEmpty ? teams[0] : null;
  TeamModel? get awayTeam => teams.length > 1 ? teams[1] : null;

  ScoreboardState copyWith({
    ScoreboardStatus? status,
    List<TeamModel>? teams,
    TeamModel? selectedTeam,
    int? currentPeriod,
    bool? isLive,
    List<GameActionModel>? gameActions,
    List<Map<String, dynamic>>? undoStack,
    String? error,
  }) {
    return ScoreboardState(
      status: status ?? this.status,
      teams: teams ?? this.teams,
      selectedTeam: selectedTeam ?? this.selectedTeam,
      currentPeriod: currentPeriod ?? this.currentPeriod,
      isLive: isLive ?? this.isLive,
      gameActions: gameActions ?? this.gameActions,
      undoStack: undoStack ?? this.undoStack,
      error: error,
    );
  }

  @override
  List<Object?> get props => [
        status,
        teams,
        selectedTeam,
        currentPeriod,
        isLive,
        gameActions,
        undoStack,
        error,
      ];
}
