import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../domain/models/team_model.dart';
import '../domain/models/player_model.dart';

enum ScoreboardSettingsStatus {
  initial,
  loading,
  ready,
  clockRunning,
  clockPaused,
  saving,
  error,
}

class ScoreboardSettingsState {
  const ScoreboardSettingsState({
    this.status = ScoreboardSettingsStatus.initial,
    this.teams = const [],
    this.currentPeriod = 1,
    this.minutes = 12,
    this.seconds = 0,
    this.isClockRunning = false,
    this.currentTabIndex = 0,
    this.error,
  });

  final ScoreboardSettingsStatus status;
  final List<TeamModel> teams;
  final int currentPeriod;
  final int minutes;
  final int seconds;
  final bool isClockRunning;
  final int currentTabIndex;
  final String? error;

  // Helper getters
  bool get hasError => error != null;
  bool get isLoading => status == ScoreboardSettingsStatus.loading;
  bool get isSaving => status == ScoreboardSettingsStatus.saving;
  String get formattedTime =>
      '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';

  ScoreboardSettingsState copyWith({
    ScoreboardSettingsStatus? status,
    List<TeamModel>? teams,
    int? currentPeriod,
    int? minutes,
    int? seconds,
    bool? isClockRunning,
    int? currentTabIndex,
    String? error,
  }) {
    return ScoreboardSettingsState(
      status: status ?? this.status,
      teams: teams ?? this.teams,
      currentPeriod: currentPeriod ?? this.currentPeriod,
      minutes: minutes ?? this.minutes,
      seconds: seconds ?? this.seconds,
      isClockRunning: isClockRunning ?? this.isClockRunning,
      currentTabIndex: currentTabIndex ?? this.currentTabIndex,
      error: error,
    );
  }
}

class ScoreboardSettingsCubit extends Cubit<ScoreboardSettingsState> {
  Timer? _clockTimer;

  ScoreboardSettingsCubit() : super(const ScoreboardSettingsState());

  @override
  Future<void> close() {
    _clockTimer?.cancel();
    return super.close();
  }

  /// Initialize settings with existing teams and period
  void initialize(List<TeamModel> teams, int currentPeriod) {
    emit(state.copyWith(status: ScoreboardSettingsStatus.loading));

    try {
      List<TeamModel> editedTeams;

      if (teams.isEmpty) {
        // Create default teams
        final team1 = TeamModel(
          name: 'Team 1',
          color: Colors.red,
          players: _createDefaultPlayers('Team 1'),
        );

        final team2 = TeamModel(
          name: 'Team 2',
          color: Colors.blue,
          players: _createDefaultPlayers('Team 2'),
        );

        editedTeams = [team1, team2];
      } else if (teams.length == 1) {
        editedTeams = teams.map((team) => team.copyWith()).toList();

        final team2 = TeamModel(
          name: 'Team 2',
          color: Colors.blue,
          players: _createDefaultPlayers('Team 2'),
        );

        editedTeams.add(team2);
      } else {
        editedTeams = teams.map((team) => team.copyWith()).toList();
      }

      emit(state.copyWith(
        status: ScoreboardSettingsStatus.ready,
        teams: editedTeams,
        currentPeriod: currentPeriod,
        error: null,
      ));
    } catch (error) {
      emit(state.copyWith(
        status: ScoreboardSettingsStatus.error,
        error: error.toString(),
      ));
    }
  }

  /// Update team information
  void updateTeam(int teamIndex, TeamModel updatedTeam) {
    if (teamIndex < 0 || teamIndex >= state.teams.length) return;

    final updatedTeams = List<TeamModel>.from(state.teams);
    updatedTeams[teamIndex] = updatedTeam;

    emit(state.copyWith(teams: updatedTeams));
  }

  /// Update current period
  void updatePeriod(int period) {
    emit(state.copyWith(currentPeriod: period));
  }

  /// Update clock time
  void updateClockTime(int minutes, int seconds) {
    emit(state.copyWith(
      minutes: minutes.clamp(0, 99),
      seconds: seconds.clamp(0, 59),
    ));
  }

  /// Start the game clock
  void startClock() {
    if (state.isClockRunning) return;

    emit(state.copyWith(
      isClockRunning: true,
      status: ScoreboardSettingsStatus.clockRunning,
    ));

    _clockTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (isClosed) {
        timer.cancel();
        return;
      }

      int newSeconds = state.seconds - 1;
      int newMinutes = state.minutes;

      if (newSeconds < 0) {
        if (newMinutes > 0) {
          newMinutes--;
          newSeconds = 59;
        } else {
          // Time's up
          timer.cancel();
          emit(state.copyWith(
            isClockRunning: false,
            status: ScoreboardSettingsStatus.ready,
            minutes: 0,
            seconds: 0,
          ));
          return;
        }
      }

      emit(state.copyWith(
        minutes: newMinutes,
        seconds: newSeconds,
      ));
    });
  }

  /// Pause the game clock
  void pauseClock() {
    _clockTimer?.cancel();
    emit(state.copyWith(
      isClockRunning: false,
      status: ScoreboardSettingsStatus.clockPaused,
    ));
  }

  /// Reset the game clock
  void resetClock() {
    _clockTimer?.cancel();
    emit(state.copyWith(
      isClockRunning: false,
      minutes: 12,
      seconds: 0,
      status: ScoreboardSettingsStatus.ready,
    ));
  }

  /// Change tab
  void changeTab(int tabIndex) {
    emit(state.copyWith(currentTabIndex: tabIndex));
  }

  /// Save settings
  Future<void> saveSettings() async {
    emit(state.copyWith(status: ScoreboardSettingsStatus.saving));

    try {
      // Simulate save operation
      await Future.delayed(const Duration(milliseconds: 500));

      emit(state.copyWith(
        status: ScoreboardSettingsStatus.ready,
        error: null,
      ));
    } catch (error) {
      emit(state.copyWith(
        status: ScoreboardSettingsStatus.error,
        error: error.toString(),
      ));
    }
  }

  /// Clear error
  void clearError() {
    emit(state.copyWith(error: null));
  }

  /// Create default players for a team
  List<PlayerModel> _createDefaultPlayers(String teamName) {
    return [
      PlayerModel(
        id: '${teamName.toLowerCase().replaceAll(' ', '_')}_1',
        name: 'Player 1',
        number: 1,
        position: 'Guard',
      ),
      PlayerModel(
        id: '${teamName.toLowerCase().replaceAll(' ', '_')}_2',
        name: 'Player 2',
        number: 2,
        position: 'Forward',
      ),
      PlayerModel(
        id: '${teamName.toLowerCase().replaceAll(' ', '_')}_3',
        name: 'Player 3',
        number: 3,
        position: 'Center',
      ),
      PlayerModel(
        id: '${teamName.toLowerCase().replaceAll(' ', '_')}_4',
        name: 'Player 4',
        number: 4,
        position: 'Guard',
      ),
      PlayerModel(
        id: '${teamName.toLowerCase().replaceAll(' ', '_')}_5',
        name: 'Player 5',
        number: 5,
        position: 'Forward',
      ),
    ];
  }
}
