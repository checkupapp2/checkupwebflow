import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../data/scoreboard_data_provider.dart';
import '../domain/models/team_model.dart';
import '../domain/models/player_model.dart';
import '../domain/models/game_action_model.dart';
import 'scoreboard_event.dart';
import 'scoreboard_state.dart';

class ScoreboardBloc extends Bloc<ScoreboardEvent, ScoreboardState> {
  final ScoreboardDataProvider _dataProvider;

  ScoreboardBloc({
    ScoreboardDataProvider? dataProvider,
  })  : _dataProvider = dataProvider ?? ScoreboardDataProvider(),
        super(const ScoreboardState()) {
    on<ScoreboardInitialized>(_onInitialized);
    on<ScoreboardTeamSelected>(_onTeamSelected);
    on<ScoreboardScoreUpdated>(_onScoreUpdated);
    on<ScoreboardPeriodIncremented>(_onPeriodIncremented);
    on<ScoreboardLiveToggled>(_onLiveToggled);
    on<ScoreboardUndoRequested>(_onUndoRequested);
    on<ScoreboardSettingsUpdated>(_onSettingsUpdated);
  }

  Future<void> _onInitialized(
    ScoreboardInitialized event,
    Emitter<ScoreboardState> emit,
  ) async {
    emit(state.copyWith(status: ScoreboardStatus.loading));

    try {
      // Use provided teams if available, otherwise use mock teams
      final teams = event.teams ?? _dataProvider.getMockTeams();

      // Use provided game actions if available, otherwise use mock actions
      final gameActions = event.gameActions != null
          ? (event.gameActions as List).cast<GameActionModel>()
          : _dataProvider.getRecentActions();

      // Default to first team (Home team)
      final selectedTeam = teams.isNotEmpty ? teams[0] : null;

      emit(state.copyWith(
        status: ScoreboardStatus.ready,
        teams: teams,
        selectedTeam: selectedTeam,
        currentPeriod: 1,
        gameActions: gameActions,
        undoStack: [],
        error: null,
      ));
    } catch (error) {
      debugPrint('ScoreboardBloc: Error during initialization: $error');
      emit(state.copyWith(
        status: ScoreboardStatus.error,
        error: error.toString(),
      ));
    }
  }

  void _onTeamSelected(
    ScoreboardTeamSelected event,
    Emitter<ScoreboardState> emit,
  ) {
    emit(state.copyWith(selectedTeam: event.team));
  }

  void _onScoreUpdated(
    ScoreboardScoreUpdated event,
    Emitter<ScoreboardState> emit,
  ) {
    try {
      // Create a new game action
      final GameActionType actionType =
          _getGameActionTypeFromName(event.actionName);

      final newAction = GameActionModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: actionType,
        playerId: event.player.id,
        teamId: event.team.name,
        period: state.currentPeriod,
        timestamp: DateTime.now(),
      );

      // Store previous state for undo
      final undoData = {
        'type': 'score_update',
        'team': event.team,
        'points': event.points,
        'player': event.player,
        'actionName': event.actionName,
        'previousTeamScore': event.team.score,
        'previousPlayerPoints': event.player.points,
        'gameAction': newAction,
      };

      // Create updated teams list
      final updatedTeams = state.teams.map((team) {
        if (team.name == event.team.name) {
          // Update team score
          final updatedTeam = team.copyWith(score: team.score + event.points);

          // Update player points
          final updatedPlayers = team.players.map((player) {
            if (player.id == event.player.id) {
              return player.copyWith(points: player.points + event.points);
            }
            return player;
          }).toList();

          return updatedTeam.copyWith(players: updatedPlayers);
        }
        return team;
      }).toList();

      // Update selected team reference
      final updatedSelectedTeam = updatedTeams.firstWhere(
        (team) => team.name == state.selectedTeam?.name,
        orElse: () => updatedTeams.first,
      );

      // Add the game action to the list
      final updatedGameActions = List<GameActionModel>.from(state.gameActions)
        ..add(newAction);

      // Add to undo stack
      final updatedUndoStack = List<Map<String, dynamic>>.from(state.undoStack)
        ..add(undoData);

      emit(state.copyWith(
        teams: updatedTeams,
        selectedTeam: updatedSelectedTeam,
        gameActions: updatedGameActions,
        undoStack: updatedUndoStack,
      ));
    } catch (error) {
      debugPrint('ScoreboardBloc: Error updating score: $error');
      emit(state.copyWith(
        status: ScoreboardStatus.error,
        error: error.toString(),
      ));
    }
  }

  void _onPeriodIncremented(
    ScoreboardPeriodIncremented event,
    Emitter<ScoreboardState> emit,
  ) {
    // Most basketball games have 4 periods (quarters)
    final newPeriod = state.currentPeriod < 4
        ? state.currentPeriod + 1
        : state.currentPeriod + 1; // Overtime periods

    emit(state.copyWith(currentPeriod: newPeriod));
  }

  void _onLiveToggled(
    ScoreboardLiveToggled event,
    Emitter<ScoreboardState> emit,
  ) {
    emit(state.copyWith(isLive: !state.isLive));
  }

  void _onUndoRequested(
    ScoreboardUndoRequested event,
    Emitter<ScoreboardState> emit,
  ) {
    if (state.undoStack.isEmpty) return;

    try {
      final undoStack = List<Map<String, dynamic>>.from(state.undoStack);
      final lastAction = undoStack.removeLast();

      if (lastAction['type'] == 'score_update') {
        final TeamModel team = lastAction['team'];
        final PlayerModel player = lastAction['player'];
        final int previousTeamScore = lastAction['previousTeamScore'];
        final int previousPlayerPoints = lastAction['previousPlayerPoints'];
        final GameActionModel gameAction = lastAction['gameAction'];

        // Create updated teams list with restored scores
        final updatedTeams = state.teams.map((t) {
          if (t.name == team.name) {
            // Restore team score
            final restoredTeam = t.copyWith(score: previousTeamScore);

            // Restore player points
            final restoredPlayers = t.players.map((p) {
              if (p.id == player.id) {
                return p.copyWith(points: previousPlayerPoints);
              }
              return p;
            }).toList();

            return restoredTeam.copyWith(players: restoredPlayers);
          }
          return t;
        }).toList();

        // Update selected team reference
        final updatedSelectedTeam = updatedTeams.firstWhere(
          (t) => t.name == state.selectedTeam?.name,
          orElse: () => updatedTeams.first,
        );

        // Remove the game action
        final updatedGameActions = state.gameActions
            .where((action) => action.id != gameAction.id)
            .toList();

        emit(state.copyWith(
          teams: updatedTeams,
          selectedTeam: updatedSelectedTeam,
          gameActions: updatedGameActions,
          undoStack: undoStack,
        ));
      }
    } catch (error) {
      debugPrint('ScoreboardBloc: Error during undo: $error');
      emit(state.copyWith(
        status: ScoreboardStatus.error,
        error: error.toString(),
      ));
    }
  }

  void _onSettingsUpdated(
    ScoreboardSettingsUpdated event,
    Emitter<ScoreboardState> emit,
  ) {
    // Update selected team reference to match updated teams
    final updatedSelectedTeam = event.updatedTeams.firstWhere(
      (team) => team.name == state.selectedTeam?.name,
      orElse: () => event.updatedTeams.first,
    );

    emit(state.copyWith(
      teams: event.updatedTeams,
      currentPeriod: event.updatedPeriod,
      selectedTeam: updatedSelectedTeam,
    ));
  }

  /// Convert action name to GameActionType
  GameActionType _getGameActionTypeFromName(String actionName) {
    // Handle missed shots
    if (actionName.startsWith('Missed')) {
      if (actionName.contains('3-Pointer')) {
        return GameActionType.missedThree;
      } else if (actionName.contains('Free Throw')) {
        return GameActionType.missedFreeThrow;
      } else {
        return GameActionType.missedFieldGoal;
      }
    }

    // Handle made shots and other actions
    switch (actionName) {
      case 'Field Goal':
        return GameActionType.fieldGoal;
      case '3-Pointer':
        return GameActionType.threePointer;
      case 'Free Throw':
        return GameActionType.freeThrow;
      case 'Assist':
        return GameActionType.assist;
      case 'Rebound':
        return GameActionType.rebound;
      case 'Block':
        return GameActionType.block;
      case 'Steal':
        return GameActionType.steal;
      case 'Turnover':
        return GameActionType.turnover;
      case 'Foul':
        return GameActionType.foul;
      default:
        return GameActionType.fieldGoal;
    }
  }
}
