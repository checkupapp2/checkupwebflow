import 'package:flutter/material.dart';
import 'player_model.dart';

/// Model class for a basketball team
class TeamModel {
  /// Team name
  final String name;
  
  /// Team logo or image URL
  final String? logoUrl;
  
  /// Team color
  final Color color;
  
  /// Current score
  int score;
  
  /// List of players on the team
  final List<PlayerModel> players;
  
  /// Constructor
  TeamModel({
    required this.name,
    this.logoUrl,
    required this.color,
    this.score = 0,
    required this.players,
  });
  
  /// Create a copy of this model with given fields replaced
  TeamModel copyWith({
    String? name,
    String? logoUrl,
    Color? color,
    int? score,
    List<PlayerModel>? players,
  }) {
    return TeamModel(
      name: name ?? this.name,
      logoUrl: logoUrl ?? this.logoUrl,
      color: color ?? this.color,
      score: score ?? this.score,
      players: players ?? this.players,
    );
  }
}
