

/// Types of game actions
enum GameActionType {
  /// Field goal (2 points)
  fieldGoal,
  
  /// Three-point shot
  threePointer,
  
  /// Free throw (1 point)
  freeThrow,
  
  /// Missed field goal
  missedFieldGoal,
  
  /// Missed three-pointer
  missedThree,
  
  /// Missed free throw
  missedFreeThrow,
  
  /// Assist
  assist,
  
  /// Rebound
  rebound,
  
  /// Block
  block,
  
  /// Steal
  steal,
  
  /// Turnover
  turnover,
  
  /// Foul
  foul,
}

/// Model class for a game action
class GameActionModel {
  /// Action ID
  final String id;
  
  /// Type of action
  final GameActionType type;
  
  /// Player ID who performed the action
  final String playerId;
  
  /// Assisting player ID (if applicable)
  final String? assistedByPlayerId;
  
  /// Team ID
  final String teamId;
  
  /// Period/quarter when the action occurred
  final int period;
  
  /// Timestamp of the action
  final DateTime timestamp;
  
  /// Constructor
  GameActionModel({
    required this.id,
    required this.type,
    required this.playerId,
    this.assistedByPlayerId,
    required this.teamId,
    required this.period,
    required this.timestamp,
  });
  
  /// Get the point value of this action
  int get pointValue {
    switch (type) {
      case GameActionType.fieldGoal:
        return 2;
      case GameActionType.threePointer:
        return 3;
      case GameActionType.freeThrow:
        return 1;
      default:
        return 0;
    }
  }
}
