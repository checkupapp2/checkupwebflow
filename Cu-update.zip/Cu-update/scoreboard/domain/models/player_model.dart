import 'package:flutter/material.dart';

/// Model class for a basketball player
class PlayerModel {
  /// Player ID
  final String id;
  
  /// Player name
  final String name;
  
  /// Player number
  final int number;
  
  /// Player position
  final String? position;
  
  /// Player photo URL
  final String? photoUrl;
  
  /// Points scored
  int points;
  
  /// Rebounds
  int rebounds;
  
  /// Assists
  int assists;
  
  /// Constructor
  PlayerModel({
    required this.id,
    required this.name,
    required this.number,
    this.position,
    this.photoUrl,
    this.points = 0,
    this.rebounds = 0,
    this.assists = 0,
  });
  
  /// Create a copy of this model with given fields replaced
  PlayerModel copyWith({
    String? id,
    String? name,
    int? number,
    String? position,
    String? photoUrl,
    int? points,
    int? rebounds,
    int? assists,
  }) {
    return PlayerModel(
      id: id ?? this.id,
      name: name ?? this.name,
      number: number ?? this.number,
      position: position ?? this.position,
      photoUrl: photoUrl ?? this.photoUrl,
      points: points ?? this.points,
      rebounds: rebounds ?? this.rebounds,
      assists: assists ?? this.assists,
    );
  }
}
