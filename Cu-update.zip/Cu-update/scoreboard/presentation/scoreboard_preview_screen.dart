import 'package:flutter/material.dart';
import '../data/scoreboard_data_provider.dart';
import 'scoreboard_screen.dart';
import 'scoreboard_settings_screen.dart';
import '../domain/models/team_model.dart';

/// Scoreboard Preview Screen for setting up the scoreboard before starting a game
class ScoreboardPreviewScreen extends StatefulWidget {
  /// Constructor
  const ScoreboardPreviewScreen({Key? key}) : super(key: key);

  @override
  State<ScoreboardPreviewScreen> createState() =>
      _ScoreboardPreviewScreenState();
}

class _ScoreboardPreviewScreenState extends State<ScoreboardPreviewScreen> {
  final ScoreboardDataProvider _dataProvider = ScoreboardDataProvider();

  // Mock data for user's scoreboards - in a real app this would come from a service
  final List<Map<String, dynamic>> _userScoreboards = [
    {
      'id': '1',
      'team1': 'Lakers',
      'team2': 'Warriors',
      'score1': 78,
      'score2': 82,
      'status': 'ongoing',
      'period': 'Q4 2:45',
      'lastUpdated': DateTime.now().subtract(const Duration(minutes: 5)),
    },
    {
      'id': '2',
      'team1': 'Celtics',
      'team2': 'Heat',
      'score1': 95,
      'score2': 88,
      'status': 'completed',
      'period': 'Final',
      'lastUpdated': DateTime.now().subtract(const Duration(hours: 2)),
    },
    {
      'id': '3',
      'team1': 'Bulls',
      'team2': 'Knicks',
      'score1': 45,
      'score2': 42,
      'status': 'paused',
      'period': 'Halftime',
      'lastUpdated': DateTime.now().subtract(const Duration(minutes: 15)),
    },
  ];

  @override
  void initState() {
    super.initState();
  }

  void _navigateToScoreboard() {
    // For Quick Play, use default teams with generic players and empty game actions
    final defaultTeams = _dataProvider.getDefaultTeams();
    final emptyGameActions = _dataProvider.getEmptyGameActions();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ScoreboardScreen(
          teams: defaultTeams,
          gameActions: emptyGameActions,
        ),
      ),
    );
  }

  void _navigateToManualTeamSetup() {
    // Start with empty teams for manual setup
    final emptyTeams = _dataProvider.getEmptyTeams();
    final emptyGameActions = _dataProvider.getEmptyGameActions();

    // Navigate directly to the settings screen instead of showing the scoreboard first
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ScoreboardSettingsScreen(
          teams: emptyTeams,
          currentPeriod: 1,
          onSettingsSaved: (updatedTeams, updatedPeriod) {
            // When settings are saved, navigate to the scoreboard with the updated teams
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => ScoreboardScreen(
                  teams: updatedTeams,
                  gameActions: emptyGameActions,
                  startWithSettings: false, // Don't open settings again
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildModernOptionCard({
    required String title,
    required String description,
    required IconData icon,
    required VoidCallback onTap,
    bool isHighlighted = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFFF9800), // Bold orange
              Color(0xFFFF5722), // Deep orange
              Color(0xFF000000), // Black
            ],
            stops: [0.0, 0.6, 1.0],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFFFF9800),
            width: 3,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFF9800).withOpacity(0.4),
              blurRadius: 20,
              spreadRadius: 2,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 15,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.transparent,
                Colors.black.withOpacity(0.3),
              ],
            ),
            borderRadius: BorderRadius.circular(17),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Colors.white, Color(0xFFF5F5F5)],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Icon(
                    icon,
                    color: const Color(0xFFFF9800),
                    size: 28,
                  ),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Montserrat',
                          letterSpacing: 0.5,
                          shadows: [
                            Shadow(
                              color: Colors.black,
                              offset: Offset(1, 1),
                              blurRadius: 2,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _getShortDescription(title),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          height: 1.2,
                          shadows: [
                            Shadow(
                              color: Colors.black,
                              offset: Offset(0.5, 0.5),
                              blurRadius: 1,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Colors.white, Color(0xFFF0F0F0)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.arrow_forward_rounded,
                    color: Color(0xFFFF9800),
                    size: 20,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _getShortDescription(String title) {
    switch (title) {
      case 'Quick Play':
        return 'Ready to go!';
      case 'Manual Team Setup':
        return 'Custom teams';
      default:
        return 'Get started';
    }
  }

  Widget _buildEmptyScoreboardsState() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF1A1A1A).withOpacity(0.6),
            const Color(0xFF0A0A0A).withOpacity(0.4),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFFF9800).withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.scoreboard_outlined,
            color: Colors.grey[400],
            size: 32,
          ),
          const SizedBox(height: 8),
          Text(
            'No scoreboards yet',
            style: TextStyle(
              color: Colors.grey[300],
              fontSize: 14,
              fontWeight: FontWeight.w600,
              fontFamily: 'Montserrat',
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Start a game to see it here',
            style: TextStyle(
              color: Colors.grey[500],
              fontSize: 12,
              fontFamily: 'Montserrat',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScoreboardCard(Map<String, dynamic> scoreboard) {
    final isOngoing = scoreboard['status'] == 'ongoing';
    final isPaused = scoreboard['status'] == 'paused';
    final isCompleted = scoreboard['status'] == 'completed';

    Color statusColor = Colors.grey;
    IconData statusIcon = Icons.check_circle;

    if (isOngoing) {
      statusColor = Colors.green;
      statusIcon = Icons.play_circle_filled;
    } else if (isPaused) {
      statusColor = Colors.orange;
      statusIcon = Icons.pause_circle_filled;
    } else if (isCompleted) {
      statusColor = Colors.blue;
      statusIcon = Icons.check_circle;
    }

    return GestureDetector(
      onTap: () => _resumeScoreboard(scoreboard),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF1A1A1A).withOpacity(0.8),
              const Color(0xFF0A0A0A).withOpacity(0.6),
            ],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isOngoing || isPaused
                ? const Color(0xFFFF9800).withOpacity(0.4)
                : const Color(0xFFFF9800).withOpacity(0.2),
            width: isOngoing || isPaused ? 1.5 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            // Status indicator
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: statusColor.withOpacity(0.5),
                  width: 1,
                ),
              ),
              child: Icon(
                statusIcon,
                color: statusColor,
                size: 16,
              ),
            ),
            const SizedBox(width: 12),

            // Game info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        scoreboard['team1'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Montserrat',
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${scoreboard['score1']}',
                        style: const TextStyle(
                          color: Color(0xFFFF9800),
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '-',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${scoreboard['score2']}',
                        style: const TextStyle(
                          color: Color(0xFFFF9800),
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        scoreboard['team2'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Montserrat',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Text(
                        scoreboard['period'],
                        style: TextStyle(
                          color: isOngoing ? Colors.green : Colors.grey[400],
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Montserrat',
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '•',
                        style: TextStyle(
                          color: Colors.grey[500],
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _formatLastUpdated(scoreboard['lastUpdated']),
                        style: TextStyle(
                          color: Colors.grey[500],
                          fontSize: 11,
                          fontFamily: 'Montserrat',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Continue arrow
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFFFF9800).withOpacity(0.2),
                    const Color(0xFFFF5722).withOpacity(0.1),
                  ],
                ),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: const Color(0xFFFF9800).withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Icon(
                isCompleted ? Icons.visibility : Icons.play_arrow,
                color: const Color(0xFFFF9800),
                size: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatLastUpdated(DateTime lastUpdated) {
    final now = DateTime.now();
    final difference = now.difference(lastUpdated);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  void _resumeScoreboard(Map<String, dynamic> scoreboard) {
    // Create teams based on the scoreboard data
    final teams = [
      TeamModel(
        name: scoreboard['team1'],
        color: const Color(0xFFFF9800),
        score: scoreboard['score1'],
        players: [],
      ),
      TeamModel(
        name: scoreboard['team2'],
        color: const Color(0xFFFF5722),
        score: scoreboard['score2'],
        players: [],
      ),
    ];

    final emptyGameActions = _dataProvider.getEmptyGameActions();

    // Navigate to the scoreboard with existing data
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ScoreboardScreen(
          teams: teams,
          gameActions: emptyGameActions,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0A0A0A),
              Color(0xFF000000),
              Color(0xFF1A1A1A),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Custom App Bar
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.arrow_back_ios_new,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      ).createShader(bounds),
                      child: const Text(
                        'Scoreboard Setup',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Montserrat',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header section with radial gradient overlay
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: RadialGradient(
                            center: Alignment.topCenter,
                            radius: 1.5,
                            colors: [
                              const Color(0xFFFF9800).withOpacity(0.08),
                              Colors.transparent,
                            ],
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ShaderMask(
                                shaderCallback: (bounds) =>
                                    const LinearGradient(
                                  colors: [
                                    Color(0xFFFF9800),
                                    Color(0xFFFF5722)
                                  ],
                                ).createShader(bounds),
                                child: const Text(
                                  'Choose Your Game',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Montserrat',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Select your basketball setup',
                                style: TextStyle(
                                  color: Colors.grey[300],
                                  fontSize: 14,
                                  fontFamily: 'Montserrat',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Organized Games Section
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [
                                        Color(0xFFFF9800),
                                        Color(0xFFFF5722)
                                      ],
                                    ),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Icon(
                                    Icons.sports_basketball,
                                    color: Colors.white,
                                    size: 14,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Text(
                                  'Organized Games',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Montserrat',
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                          ],
                        ),
                      ),

                      // Quick Play option
                      _buildModernOptionCard(
                        title: 'Quick Play',
                        description:
                            'Start instantly with pre-configured teams',
                        icon: Icons.flash_on_rounded,
                        onTap: _navigateToScoreboard,
                      ),

                      // Manual Team Setup option
                      _buildModernOptionCard(
                        title: 'Manual Team Setup',
                        description: 'Create and customize teams from scratch',
                        icon: Icons.tune_rounded,
                        onTap: _navigateToManualTeamSetup,
                      ),

                      const SizedBox(height: 16),

                      // Your Scoreboards Section
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [
                                        Color(0xFFFF9800),
                                        Color(0xFFFF5722)
                                      ],
                                    ),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Icon(
                                    Icons.history_rounded,
                                    color: Colors.white,
                                    size: 14,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Text(
                                  'Your Scoreboards',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Montserrat',
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Continue where you left off',
                              style: TextStyle(
                                color: Colors.grey[400],
                                fontSize: 12,
                                fontFamily: 'Montserrat',
                              ),
                            ),
                            const SizedBox(height: 12),
                          ],
                        ),
                      ),

                      // User's Scoreboards List
                      if (_userScoreboards.isEmpty)
                        _buildEmptyScoreboardsState()
                      else
                        ..._userScoreboards
                            .map((scoreboard) =>
                                _buildScoreboardCard(scoreboard))
                            .toList(),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
