import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';

import '../bloc/scoreboard_bloc.dart';
import '../bloc/scoreboard_event.dart';
import '../bloc/scoreboard_state.dart';
import '../domain/models/team_model.dart';
import '../domain/models/game_action_model.dart';
import 'scoreboard_settings_screen.dart';
import 'live_confirmation_dialog.dart';
import 'widgets/score_header.dart';
import 'widgets/scoring_tab.dart';
import 'widgets/play_by_play_tab.dart';
import 'widgets/roster_tab.dart';
import 'widgets/stats_tab.dart';

/// BLoC-powered Scoreboard screen for tracking game scores and stats
class ScoreboardScreenBloc extends StatelessWidget {
  /// Teams to display on the scoreboard
  final List<TeamModel>? teams;

  /// Game actions to display in the play-by-play tab
  final List<GameActionModel>? gameActions;

  /// Whether to open settings screen immediately
  final bool startWithSettings;

  /// Constructor
  const ScoreboardScreenBloc({
    Key? key,
    this.teams,
    this.gameActions,
    this.startWithSettings = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider<ScoreboardBloc>(
      create: (_) => GetIt.I<ScoreboardBloc>()
        ..add(ScoreboardInitialized(
          teams: teams,
          gameActions: gameActions,
          startWithSettings: startWithSettings,
        )),
      child: const _ScoreboardScreenContent(),
    );
  }
}

class _ScoreboardScreenContent extends StatefulWidget {
  const _ScoreboardScreenContent();

  @override
  State<_ScoreboardScreenContent> createState() =>
      _ScoreboardScreenContentState();
}

class _ScoreboardScreenContentState extends State<_ScoreboardScreenContent>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);

    // Handle startWithSettings after build completes
    // This functionality is now handled in the BLoC initialization
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ScoreboardBloc, ScoreboardState>(
      listener: (context, state) {
        if (state.status == ScoreboardStatus.error) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.error ?? 'An error occurred'),
              backgroundColor: Colors.red,
            ),
          );
        }
      },
      builder: (context, state) {
        if (state.status == ScoreboardStatus.loading) {
          return _buildLoadingState();
        }

        if (state.status == ScoreboardStatus.error) {
          return _buildErrorState(context, state.error);
        }

        if (!state.hasTeams) {
          return _buildEmptyState(context);
        }

        return _buildScoreboardContent(context, state);
      },
    );
  }

  Widget _buildLoadingState() {
    return const Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: CircularProgressIndicator(
          color: Color(0xFFFF9800),
        ),
      ),
    );
  }

  Widget _buildErrorState(BuildContext context, String? error) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Scoreboard',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, color: Colors.red, size: 64),
            const SizedBox(height: 16),
            Text(
              error ?? 'An error occurred',
              style: const TextStyle(color: Colors.white, fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                context
                    .read<ScoreboardBloc>()
                    .add(const ScoreboardInitialized());
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF9800),
              ),
              child: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Scoreboard',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: const Center(
        child: Text(
          'No teams available',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
      ),
    );
  }

  Widget _buildScoreboardContent(BuildContext context, ScoreboardState state) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Scoreboard',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          // Live/Private Toggle
          Container(
            margin: const EdgeInsets.only(right: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  state.isLive ? Icons.visibility : Icons.visibility_off,
                  color: Colors.grey[400],
                  size: 16,
                ),
                const SizedBox(width: 4),
                Text(
                  state.isLive ? 'LIVE' : 'PRIVATE',
                  style: TextStyle(
                    color: state.isLive ? Colors.red : Colors.grey[400],
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(width: 4),
                GestureDetector(
                  onTap: () => _handleLiveToggle(context, state),
                  child: Container(
                    width: 40,
                    height: 20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: state.isLive ? Colors.red : Colors.grey[700],
                    ),
                    child: AnimatedAlign(
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeInOut,
                      alignment: state.isLive
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        width: 16,
                        height: 16,
                        margin: const EdgeInsets.all(2),
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.white),
            onPressed: () => _openSettings(context, state),
          ),
        ],
      ),
      body: Container(
        color: Colors.black,
        child: SafeArea(
          top: false, // Let AppBar handle top safe area
          child: NestedScrollView(
            headerSliverBuilder:
                (BuildContext context, bool innerBoxIsScrolled) {
              return <Widget>[
                SliverToBoxAdapter(
                  child: Column(
                    children: [
                      // Score header - now scrollable
                      ScoreHeader(
                        homeTeam: state.homeTeam!,
                        awayTeam: state.awayTeam!,
                        currentPeriod: state.currentPeriod,
                        onTeamSelected: (team) {
                          context
                              .read<ScoreboardBloc>()
                              .add(ScoreboardTeamSelected(team));
                        },
                        selectedTeam: state.selectedTeam!,
                        onPeriodChanged: () {
                          context
                              .read<ScoreboardBloc>()
                              .add(const ScoreboardPeriodIncremented());
                        },
                      ),

                      // Tab bar - now scrollable with content
                      Container(
                        decoration: BoxDecoration(
                          color: Color(0xFF1A1A1A),
                          border: Border(
                            bottom: BorderSide(
                              color: Colors.grey[800]!,
                              width: 1,
                            ),
                          ),
                        ),
                        child: TabBar(
                          controller: _tabController,
                          labelColor: Colors.white,
                          unselectedLabelColor: Colors.grey[400],
                          labelStyle: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            letterSpacing: 0.3,
                          ),
                          unselectedLabelStyle: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            letterSpacing: 0.2,
                          ),
                          indicatorColor: Color(0xFFFF9800),
                          indicatorWeight: 3,
                          indicatorPadding:
                              EdgeInsets.symmetric(horizontal: 16),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 8),
                          labelPadding:
                              const EdgeInsets.symmetric(horizontal: 8),
                          dividerColor: Colors.transparent,
                          tabs: [
                            Tab(
                              icon: Icon(Icons.sports_basketball, size: 16),
                              text: 'Scoring',
                            ),
                            Tab(
                              icon: Icon(Icons.list_alt, size: 16),
                              text: 'Plays',
                            ),
                            Tab(
                              icon: Icon(Icons.people, size: 16),
                              text: 'Roster',
                            ),
                            Tab(
                              icon: Icon(Icons.bar_chart, size: 16),
                              text: 'Stats',
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ];
            },
            body: Container(
              color: Colors.black,
              child: TabBarView(
                controller: _tabController,
                children: [
                  // Scoring tab
                  Container(
                    color: Colors.black,
                    child: ScoringTab(
                      selectedTeam: state.selectedTeam!,
                      onScoreUpdated: (team, points,
                          {required player, required actionName}) {
                        context
                            .read<ScoreboardBloc>()
                            .add(ScoreboardScoreUpdated(
                              team: team,
                              points: points,
                              player: player,
                              actionName: actionName,
                            ));
                      },
                      canUndo: state.canUndo,
                      onUndo: () {
                        context
                            .read<ScoreboardBloc>()
                            .add(const ScoreboardUndoRequested());
                      },
                    ),
                  ),

                  // Play by Play tab
                  Container(
                    color: Colors.black,
                    padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).padding.bottom + 16,
                    ),
                    child: PlayByPlayTab(
                      teams: state.teams,
                      selectedTeam: state.selectedTeam!,
                      gameActions: state.gameActions,
                    ),
                  ),

                  // Roster tab
                  Container(
                    color: Colors.black,
                    padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).padding.bottom + 16,
                    ),
                    child: RosterTab(
                      teams: state.teams,
                      selectedTeam: state.selectedTeam!,
                      onTeamSelected: (team) {
                        context
                            .read<ScoreboardBloc>()
                            .add(ScoreboardTeamSelected(team));
                      },
                    ),
                  ),

                  // Stats tab
                  Container(
                    color: Colors.black,
                    padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).padding.bottom + 16,
                    ),
                    child: StatsTab(
                      teams: state.teams,
                      selectedTeam: state.selectedTeam!,
                      gameActions: state.gameActions,
                      onTeamSelected: (team) {
                        context
                            .read<ScoreboardBloc>()
                            .add(ScoreboardTeamSelected(team));
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _handleLiveToggle(BuildContext context, ScoreboardState state) {
    // If already live, just toggle off directly
    if (state.isLive) {
      context.read<ScoreboardBloc>().add(const ScoreboardLiveToggled());
      return;
    }

    // If going from private to live, show confirmation dialog
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return LiveConfirmationDialog(
          onConfirm: (String location) {
            // Toggle to live after confirmation
            context.read<ScoreboardBloc>().add(const ScoreboardLiveToggled());
            // Note: Scorecard generation would be handled here in a full implementation
          },
          onCancel: () {
            // Do nothing - dialog already closed
          },
        );
      },
    );
  }

  void _openSettings(BuildContext context, ScoreboardState state) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => ScoreboardSettingsScreen(
          teams: state.teams,
          currentPeriod: state.currentPeriod,
          onSettingsSaved: (updatedTeams, updatedPeriod) {
            context.read<ScoreboardBloc>().add(ScoreboardSettingsUpdated(
                  updatedTeams: updatedTeams,
                  updatedPeriod: updatedPeriod,
                ));
          },
        ),
      ),
    );
  }
}
