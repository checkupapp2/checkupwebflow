import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../search/domain/models/court_model.dart';
import '../../search/data/courts_search_repository.dart';

/// Clean confirmation dialog for going live with the scoreboard
class LiveConfirmationDialog extends StatefulWidget {
  final Function(String location) onConfirm;
  final VoidCallback onCancel;
  final List<String>? teamNames;
  final String? hostName;

  const LiveConfirmationDialog({
    super.key,
    required this.onConfirm,
    required this.onCancel,
    this.teamNames,
    this.hostName,
  });

  @override
  State<LiveConfirmationDialog> createState() => _LiveConfirmationDialogState();
}

class _LiveConfirmationDialogState extends State<LiveConfirmationDialog> {
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _homeTeamController = TextEditingController();
  final TextEditingController _awayTeamController = TextEditingController();
  final TextEditingController _hostNameController = TextEditingController();

  List<CourtModel> _courts = [];
  List<CourtModel> _filteredCourts = [];
  bool _showSuggestions = false;

  @override
  void initState() {
    super.initState();
    // Pre-populate team names if provided
    if (widget.teamNames != null && widget.teamNames!.length >= 2) {
      _homeTeamController.text = widget.teamNames![0];
      _awayTeamController.text = widget.teamNames![1];
    }
    // Pre-populate host name if provided
    if (widget.hostName != null) {
      _hostNameController.text = widget.hostName!;
    }
    // Pre-populate location with default city and state
    _locationController.text = 'Chicago, Illinois';
    // Load courts for search
    _loadCourts();
  }

  void _loadCourts() {
    // Create mock courts for now - in production this would use the repository
    _courts = [
      CourtModel(
        id: '1',
        name: 'Venice Beach Courts',
        city: 'Venice',
        state: 'CA',
        followers: 1250,
        imageUrl: '',
        isVerified: true,
      ),
      CourtModel(
        id: '2',
        name: 'Rucker Park',
        city: 'New York',
        state: 'NY',
        followers: 2100,
        imageUrl: '',
        isVerified: true,
      ),
      CourtModel(
        id: '3',
        name: 'Drew League Court',
        city: 'Los Angeles',
        state: 'CA',
        followers: 1800,
        imageUrl: '',
        isVerified: true,
      ),
      CourtModel(
        id: '4',
        name: 'Dyckman Park',
        city: 'New York',
        state: 'NY',
        followers: 950,
        imageUrl: '',
        isVerified: false,
      ),
      CourtModel(
        id: '5',
        name: 'Hoops in the Hood',
        city: 'Chicago',
        state: 'IL',
        followers: 750,
        imageUrl: '',
        isVerified: false,
      ),
    ];
    _filteredCourts = _courts;
  }

  void _filterCourts(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredCourts = _courts;
        _showSuggestions = false;
      } else {
        _filteredCourts = _courts.where((court) {
          return court.name.toLowerCase().contains(query.toLowerCase()) ||
              court.city.toLowerCase().contains(query.toLowerCase()) ||
              court.state.toLowerCase().contains(query.toLowerCase());
        }).toList();
        _showSuggestions = true;
      }
    });
  }

  void _selectCourt(CourtModel court) {
    setState(() {
      _locationController.text = '${court.name}, ${court.city}, ${court.state}';
      _showSuggestions = false;
    });
  }

  @override
  void dispose() {
    _locationController.dispose();
    _homeTeamController.dispose();
    _awayTeamController.dispose();
    _hostNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2A2A2A),
              Color(0xFF1A1A1A),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFFFF9800).withOpacity(0.3),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 20,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildMessage(),
            const SizedBox(height: 20),
            _buildGameInfo(),
            const SizedBox(height: 20),
            _buildLocationInput(),
            const SizedBox(height: 24),
            _buildButtons(context),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        // Live icon
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Colors.red, Color(0xFFFF5722)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.red.withOpacity(0.4),
                blurRadius: 15,
                spreadRadius: 2,
              ),
            ],
          ),
          child: const Icon(
            Icons.public,
            color: Colors.white,
            size: 30,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'Make Public?',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildMessage() {
    return Column(
      children: [
        const Text(
          'Share your game on the public scores list',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),
        Text(
          'Your game will appear in the public scores tab where everyone can view the results and follow along.',
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
            height: 1.4,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildGameInfo() {
    final homeTeam = _homeTeamController.text.isNotEmpty
        ? _homeTeamController.text
        : 'Player 1';
    final awayTeam = _awayTeamController.text.isNotEmpty
        ? _awayTeamController.text
        : 'Player 2';
    final hostName =
        _hostNameController.text.isNotEmpty ? _hostNameController.text : 'Host';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[800]!.withOpacity(0.6),
            Colors.grey[900]!.withOpacity(0.8),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFFF6B35).withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // Teams display
          Row(
            children: [
              Expanded(
                child: Text(
                  homeTeam,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF6B35), Color(0xFFFF8A50)],
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'VS',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Expanded(
                child: Text(
                  awayTeam,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Host info
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.person,
                color: const Color(0xFFFF6B35),
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                'Hosted by $hostName',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLocationInput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[800]!.withOpacity(0.6),
            Colors.grey[900]!.withOpacity(0.8),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFFF6B35).withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.location_on,
            color: const Color(0xFFFF6B35),
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Location',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _locationController.text,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[800]!.withOpacity(0.8),
            Colors.grey[900]!.withOpacity(0.9),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFFF6B35).withOpacity(0.3),
          width: 1,
        ),
      ),
      child: TextField(
        controller: controller,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
        textCapitalization: TextCapitalization.words,
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
          ),
          prefixIcon: Icon(
            icon,
            color: const Color(0xFFFF6B35),
            size: 20,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 12,
          ),
        ),
      ),
    );
  }

  Widget _buildButtons(BuildContext context) {
    return Row(
      children: [
        // Cancel button
        Expanded(
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: Colors.grey[600]!,
                width: 1,
              ),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () {
                  HapticFeedback.lightImpact();
                  Navigator.of(context).pop();
                  widget.onCancel();
                },
                borderRadius: BorderRadius.circular(24),
                child: const Center(
                  child: Text(
                    'Cancel',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 16),
        // Confirm button
        Expanded(
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Colors.red, Color(0xFFFF5722)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.red.withOpacity(0.4),
                  blurRadius: 8,
                  spreadRadius: 0,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () {
                  HapticFeedback.mediumImpact();
                  Navigator.of(context).pop();
                  widget.onConfirm(_locationController.text.trim());
                },
                borderRadius: BorderRadius.circular(24),
                child: const Center(
                  child: Text(
                    'Make Public',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
