import 'package:flutter/material.dart';
import '../data/scoreboard_data_provider.dart';
import '../domain/models/team_model.dart';
import '../domain/models/player_model.dart';
import '../domain/models/game_action_model.dart';
import 'scoreboard_settings_screen.dart';
import 'live_confirmation_dialog.dart';
import 'widgets/score_header.dart';
import 'widgets/scoring_tab.dart';
import 'widgets/play_by_play_tab.dart';
import 'widgets/roster_tab.dart';
import 'widgets/stats_tab.dart';

/// Scoreboard screen for tracking game scores and stats
class ScoreboardScreen extends StatefulWidget {
  /// Teams to display on the scoreboard
  final List<TeamModel>? teams;

  /// Game actions to display in the play-by-play tab
  final List<GameActionModel>? gameActions;

  /// Whether to open settings screen immediately
  final bool startWithSettings;

  /// Constructor
  const ScoreboardScreen({
    Key? key,
    this.teams,
    this.gameActions,
    this.startWithSettings = false,
  }) : super(key: key);

  @override
  State<ScoreboardScreen> createState() => _ScoreboardScreenState();
}

class _ScoreboardScreenState extends State<ScoreboardScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final ScoreboardDataProvider _dataProvider = ScoreboardDataProvider();
  late List<TeamModel> _teams;
  late int _currentPeriod;
  late TeamModel _selectedTeam;
  bool _isLive = false; // Toggle for live/private scoreboard

  late List<GameActionModel> _gameActions;
  final List<Map<String, dynamic>> _undoStack =
      []; // Stack for undo functionality

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);

    // Use provided teams if available, otherwise use default teams for a fresh game
    _teams = widget.teams ?? _dataProvider.getDefaultTeams();

    // Use provided game actions if available, otherwise use empty actions for a fresh game
    _gameActions = widget.gameActions ?? _dataProvider.getEmptyGameActions();

    // Always start with period 1 for a fresh game
    _currentPeriod = 1;

    // Default to first team for Quick Play (Home team) or first team for mock data
    _selectedTeam =
        _teams[0]; // Default to first team (Home team for Quick Play)

    // If startWithSettings is true, open settings screen after build completes
    if (widget.startWithSettings) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _openSettings();
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  /// Update score and record game action
  void _updateScore(TeamModel team, int points,
      {required PlayerModel player, required String actionName}) {
    // Create a new game action
    final GameActionType actionType = _getGameActionTypeFromName(actionName);

    final newAction = GameActionModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      type: actionType,
      playerId: player.id,
      teamId: team.name,
      period: _currentPeriod,
      timestamp: DateTime.now(),
    );

    // Store previous state for undo
    final undoData = {
      'type': 'score_update',
      'team': team,
      'points': points,
      'player': player,
      'actionName': actionName,
      'previousTeamScore': team.score,
      'previousPlayerPoints': player.points,
      'gameAction': newAction,
    };

    setState(() {
      // Update team score
      team.score += points;

      // Update player points
      final playerIndex = team.players.indexWhere((p) => p.id == player.id);
      if (playerIndex != -1) {
        team.players[playerIndex] = team.players[playerIndex]
            .copyWith(points: team.players[playerIndex].points + points);
      }

      // Add the game action to the list
      _gameActions.add(newAction);

      // Add to undo stack
      _undoStack.add(undoData);
    });
  }

  /// Convert action name to GameActionType
  GameActionType _getGameActionTypeFromName(String actionName) {
    // Handle missed shots
    if (actionName.startsWith('Missed')) {
      if (actionName.contains('3-Pointer')) {
        return GameActionType.missedThree;
      } else if (actionName.contains('Free Throw')) {
        return GameActionType.missedFreeThrow;
      } else {
        return GameActionType.missedFieldGoal;
      }
    }

    // Handle made shots and other actions
    switch (actionName) {
      case 'Field Goal':
        return GameActionType.fieldGoal;
      case '3-Pointer':
        return GameActionType.threePointer;
      case 'Free Throw':
        return GameActionType.freeThrow;
      case 'Assist':
        return GameActionType.assist;
      case 'Rebound':
        return GameActionType.rebound;
      case 'Block':
        return GameActionType.block;
      case 'Steal':
        return GameActionType.steal;
      case 'Turnover':
        return GameActionType.turnover;
      case 'Foul':
        return GameActionType.foul;
      default:
        return GameActionType.fieldGoal;
    }
  }

  void _selectTeam(TeamModel team) {
    setState(() {
      _selectedTeam = team;
    });
  }

  /// Increment the period (quarter/half)
  void _incrementPeriod() {
    setState(() {
      // Basketball games: Q1-Q4, then OT1-OT4, then reset to Q1
      if (_currentPeriod < 8) {
        _currentPeriod++;
      } else {
        // Reset to Q1 after OT4
        _currentPeriod = 1;
      }
    });
  }

  void _handleLiveToggle() {
    // If already live, just toggle off directly
    if (_isLive) {
      setState(() {
        _isLive = false;
      });
      return;
    }

    // If going from private to public, show information collection dialog
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return LiveConfirmationDialog(
          teamNames: _teams.map((team) => team.name).toList(),
          hostName:
              'You', // Default host name - could be enhanced with actual user data
          onConfirm: (String location) {
            // Toggle to public after confirmation
            setState(() {
              _isLive = true;
            });
            // Store location and create public score card
            _createPublicScoreCard(location);
          },
          onCancel: () {
            // Do nothing - dialog already closed
          },
        );
      },
    );
  }

  /// Create public score card for the scores list
  void _createPublicScoreCard(String location) {
    // This would integrate with the scores system to create a public score card
    // For now, we'll show a compact success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Game is now public'),
        backgroundColor: const Color(0xFFFF6B35),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  void _openSettings() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => ScoreboardSettingsScreen(
          teams: _teams,
          currentPeriod: _currentPeriod,
          onSettingsSaved: (updatedTeams, updatedPeriod) {
            setState(() {
              _teams = updatedTeams;
              _currentPeriod = updatedPeriod;
              // Make sure selected team reference is updated
              _selectedTeam = _teams.firstWhere(
                (team) => team.name == _selectedTeam.name,
                orElse: () => _teams.first,
              );
            });
          },
        ),
      ),
    );
  }

  /// Handle undo functionality
  void _handleUndo() {
    if (_undoStack.isEmpty) return;

    final lastAction = _undoStack.removeLast();

    if (lastAction['type'] == 'score_update') {
      final TeamModel team = lastAction['team'];
      final PlayerModel player = lastAction['player'];
      final int previousTeamScore = lastAction['previousTeamScore'];
      final int previousPlayerPoints = lastAction['previousPlayerPoints'];
      final GameActionModel gameAction = lastAction['gameAction'];

      setState(() {
        // Restore team score
        team.score = previousTeamScore;

        // Restore player points
        final playerIndex = team.players.indexWhere((p) => p.id == player.id);
        if (playerIndex != -1) {
          team.players[playerIndex] =
              team.players[playerIndex].copyWith(points: previousPlayerPoints);
        }

        // Remove the game action
        _gameActions.removeWhere((action) => action.id == gameAction.id);
      });

      // Show confirmation
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Undid: ${lastAction['actionName']} by ${player.name}'),
          duration: const Duration(seconds: 2),
          backgroundColor: const Color(0xFFFF9800),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Scoreboard',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          // Live/Private Toggle
          Container(
            margin: const EdgeInsets.only(right: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  _isLive ? Icons.visibility : Icons.visibility_off,
                  color: Colors.grey[400],
                  size: 16,
                ),
                const SizedBox(width: 4),
                Text(
                  _isLive ? 'LIVE' : 'PRIVATE',
                  style: TextStyle(
                    color: _isLive ? Colors.red : Colors.grey[400],
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(width: 4),
                GestureDetector(
                  onTap: _handleLiveToggle,
                  child: Container(
                    width: 40,
                    height: 20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: _isLive ? Colors.red : Colors.grey[700],
                    ),
                    child: AnimatedAlign(
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeInOut,
                      alignment: _isLive
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        width: 16,
                        height: 16,
                        margin: const EdgeInsets.all(2),
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.white),
            onPressed: _openSettings,
          ),
        ],
      ),
      body: Container(
        color: Colors.black,
        child: NestedScrollView(
          headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
            return <Widget>[
              SliverToBoxAdapter(
                child: Column(
                  children: [
                    // Score header - now scrollable
                    ScoreHeader(
                      homeTeam: _teams[0],
                      awayTeam: _teams[1],
                      currentPeriod: _currentPeriod,
                      onTeamSelected: _selectTeam,
                      selectedTeam: _selectedTeam,
                      onPeriodChanged: _incrementPeriod,
                      onOpenSettings: _openSettings,
                    ),

                    // Tab bar - now scrollable with content
                    Container(
                      decoration: BoxDecoration(
                        color: Color(0xFF1A1A1A),
                        border: Border(
                          bottom: BorderSide(
                            color: Colors.grey[800]!,
                            width: 1,
                          ),
                        ),
                      ),
                      child: TabBar(
                        controller: _tabController,
                        labelColor: Colors.white,
                        unselectedLabelColor: Colors.grey[400],
                        labelStyle: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                          letterSpacing: 0.3,
                        ),
                        unselectedLabelStyle: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.2,
                        ),
                        indicatorColor: Color(0xFFFF9800),
                        indicatorWeight: 3,
                        indicatorPadding: EdgeInsets.symmetric(horizontal: 16),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 8),
                        labelPadding: const EdgeInsets.symmetric(horizontal: 8),
                        dividerColor: Colors.transparent,
                        tabs: [
                          Tab(
                            icon: Icon(Icons.sports_basketball, size: 16),
                            text: 'Scoring',
                          ),
                          Tab(
                            icon: Icon(Icons.list_alt, size: 16),
                            text: 'Plays',
                          ),
                          Tab(
                            icon: Icon(Icons.people, size: 16),
                            text: 'Roster',
                          ),
                          Tab(
                            icon: Icon(Icons.bar_chart, size: 16),
                            text: 'Stats',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ];
          },
          body: SafeArea(
            top: false, // Don't add top padding since we have header above
            child: Container(
              color: Colors.black,
              child: TabBarView(
                controller: _tabController,
                children: [
                  // Scoring tab
                  Container(
                    color: Colors.black,
                    child: ScoringTab(
                      selectedTeam: _selectedTeam,
                      onScoreUpdated: _updateScore,
                      canUndo: _undoStack.isNotEmpty,
                      onUndo: _handleUndo,
                    ),
                  ),

                  // Play by Play tab
                  Container(
                    color: Colors.black,
                    child: PlayByPlayTab(
                      teams: _teams,
                      selectedTeam: _selectedTeam,
                      gameActions: _gameActions,
                    ),
                  ),

                  // Roster tab
                  Container(
                    color: Colors.black,
                    child: RosterTab(
                      teams: _teams,
                      selectedTeam: _selectedTeam,
                      onTeamSelected: (team) {
                        setState(() {
                          _selectedTeam = team;
                        });
                      },
                    ),
                  ),

                  // Stats tab
                  Container(
                    color: Colors.black,
                    child: StatsTab(
                      teams: _teams,
                      selectedTeam: _selectedTeam,
                      gameActions: _gameActions,
                      onTeamSelected: (team) {
                        setState(() {
                          _selectedTeam = team;
                        });
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
