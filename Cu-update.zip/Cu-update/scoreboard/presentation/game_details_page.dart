import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../domain/models/team_model.dart';
import '../domain/models/player_model.dart';
import 'package:share_plus/share_plus.dart';
import '../../search/presentation/widgets/espn_score_card.dart';

class GameDetailsPage extends StatefulWidget {
  final List<TeamModel> teams;
  final List<Map<String, dynamic>> gameActions;

  const GameDetailsPage({
    Key? key,
    required this.teams,
    required this.gameActions,
  }) : super(key: key);

  @override
  State<GameDetailsPage> createState() => _GameDetailsPageState();
}

class _GameDetailsPageState extends State<GameDetailsPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isSharing = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Determine winner
    TeamModel? winner;
    bool isTie = false;
    
    if (widget.teams.length >= 2) {
      if (widget.teams[0].score > widget.teams[1].score) {
        winner = widget.teams[0];
      } else if (widget.teams[1].score > widget.teams[0].score) {
        winner = widget.teams[1];
      } else {
        isTie = true;
      }
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            // Modern header with game status and share button
            _buildModernHeader(),
            
            // Main game card
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildGameCard(),
                    const SizedBox(height: 20),
                    _buildTabContent(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  /// Build modern header with back button, status, and share
  Widget _buildModernHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          // Back button
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Colors.grey[800],
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white, size: 20),
              onPressed: () => Navigator.pop(context),
              padding: EdgeInsets.zero,
            ),
          ),
          
          const Spacer(),
          
          // Game status
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.grey[800],
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text(
              'FINAL',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          
          const Spacer(),
          
          // Share button
          Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              ),
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: const Icon(Icons.share, color: Colors.white, size: 20),
              onPressed: _isSharing ? null : _shareGameResults,
              padding: EdgeInsets.zero,
            ),
          ),
        ],
      ),
    );
  }
  
  /// Build main game card with modern design
  Widget _buildGameCard() {
    return EspnScoreCard(
      homeTeamName: widget.teams.isNotEmpty ? widget.teams[0].name : 'Lakers',
      awayTeamName: widget.teams.length > 1 ? widget.teams[1].name : 'Celtics',
      homeScore: widget.teams.isNotEmpty ? widget.teams[0].score : 108,
      awayScore: widget.teams.length > 1 ? widget.teams[1].score : 102,
      gameStatus: 'Final',
      gameDateTime: DateTime(2025, 6, 10, 19, 30), // June 10, 2025 • 7:30 PM
      courtName: 'Downtown Arena',
      courtLocation: 'Los Angeles, CA',
      hostName: 'John Smith',
      leagueName: 'Summer League',
      onViewFullScore: () {
        // Already on the full score page, so just show a message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('You are already viewing the full score'),
            backgroundColor: Colors.orange,
          ),
        );
      },
      onShare: _shareGameResults,
    );
  }
  
  /// Build tab content with modern styling
  Widget _buildTabContent() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // Tab bar
          Container(
            padding: const EdgeInsets.all(4),
            child: Row(
              children: [
                Expanded(
                  child: _buildTabButton('Play by Play', 0, true),
                ),
                Expanded(
                  child: _buildTabButton('Feed', 1, false),
                ),
                Expanded(
                  child: _buildTabButton('Stats', 2, false),
                ),
              ],
            ),
          ),
          
          // Tab content
          Container(
            padding: const EdgeInsets.all(16),
            child: _buildTimelineTab(),
          ),
        ],
      ),
    );
  }
  
  /// Build individual tab button
  Widget _buildTabButton(String title, int index, bool isSelected) {
    return Container(
      height: 40,
      margin: const EdgeInsets.symmetric(horizontal: 2),
      child: ElevatedButton(
        onPressed: () {
          // Handle tab selection
          HapticFeedback.lightImpact();
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: isSelected ? null : Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          padding: EdgeInsets.zero,
        ),
        child: Container(
          decoration: isSelected
              ? BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: BorderRadius.circular(8),
                )
              : null,
          child: Center(
            child: Text(
              title,
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.grey[400],
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Summary tab showing final score and winner
  Widget _buildSummaryTab(TeamModel? winner, bool isTie) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Game result card
          Card(
            elevation: 8,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            clipBehavior: Clip.antiAlias,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    const Color(0xFF333333),
                    const Color(0xFF1A1A1A),
                  ],
                ),
              ),
              child: Column(
                children: [
                  // Header
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Colors.orange, Colors.deepOrange],
                      ),
                    ),
                    child: Center(
                      child: Text(
                        isTie ? 'GAME TIED' : winner != null ? '${winner.name} WINS!' : 'GAME OVER',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                  
                  // Score display
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        for (int i = 0; i < widget.teams.length && i < 2; i++) ...[
                          if (i > 0) ...[
                            const Padding(
                              padding: EdgeInsets.symmetric(horizontal: 16),
                              child: Text(
                                '-',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 32,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                          Column(
                            children: [
                              Container(
                                width: 60,
                                height: 60,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: widget.teams[i].color,
                                  boxShadow: [
                                    BoxShadow(
                                      color: widget.teams[i].color.withOpacity(0.5),
                                      blurRadius: 10,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    widget.teams[i].name.substring(0, 1),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 28,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                widget.teams[i].name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                '${widget.teams[i].score}',
                                style: TextStyle(
                                  color: winner == widget.teams[i] ? Colors.orange : Colors.white,
                                  fontSize: 48,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Top performers
          const Text(
            'TOP PERFORMERS',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 16),
          
          // Top scorers list
          _buildTopPerformers(),
          
          const SizedBox(height: 24),
          
          // Share button
          ElevatedButton.icon(
            onPressed: _isSharing ? null : _shareGameResults,
            icon: const Icon(Icons.share),
            label: Text(_isSharing ? 'Sharing...' : 'Share Game Results'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 4,
            ),
          ),
        ],
      ),
    );
  }

  // Stats tab showing detailed team and player statistics
  Widget _buildStatsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final team in widget.teams) ...[
            // Team header
            Container(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    team.color,
                    team.color.withOpacity(0.7),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Text(
                    team.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '${team.score} PTS',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            
            // Player stats
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              color: const Color(0xFF222222),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    // Header row
                    const Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: Text(
                            'PLAYER',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            'PTS',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        Expanded(
                          child: Text(
                            'REB',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        Expanded(
                          child: Text(
                            'AST',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                    const Divider(color: Colors.grey, height: 24),
                    
                    // Player rows
                    for (final player in team.players) ...[
                      Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: Row(
                              children: [
                                Container(
                                  width: 32,
                                  height: 32,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: team.color.withOpacity(0.2),
                                  ),
                                  child: Center(
                                    child: Text(
                                      '${player.number}',
                                      style: TextStyle(
                                        color: team.color,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    player.name,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w500,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Text(
                              '${player.points}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              '${player.rebounds}',
                              style: const TextStyle(
                                color: Colors.white,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              '${player.assists}',
                              style: const TextStyle(
                                color: Colors.white,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                      if (player != team.players.last)
                        const Divider(color: Colors.grey, height: 16, thickness: 0.5),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ],
      ),
    );
  }

  // Timeline tab showing game actions in chronological order
  Widget _buildTimelineTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: widget.gameActions.length,
      itemBuilder: (context, index) {
        // Display actions in reverse chronological order (most recent first)
        final action = widget.gameActions[widget.gameActions.length - 1 - index];
        final player = action['player'] as PlayerModel?;
        final team = action['team'] as TeamModel?;
        final actionType = action['type'] as String?;
        final actionName = action['action'] as String?;
        final points = action['points'] as int?;
        
        IconData actionIcon;
        Color actionColor;
        
        if (actionType == 'score') {
          actionIcon = Icons.sports_basketball;
          actionColor = Colors.orange;
        } else if (actionType == 'rebound') {
          actionIcon = Icons.catching_pokemon;
          actionColor = Colors.blue;
        } else if (actionType == 'assist') {
          actionIcon = Icons.handshake;
          actionColor = Colors.green;
        } else if (actionType == 'block') {
          actionIcon = Icons.block;
          actionColor = Colors.red;
        } else if (actionType == 'steal') {
          actionIcon = Icons.swipe;
          actionColor = Colors.purple;
        } else {
          actionIcon = Icons.sports;
          actionColor = Colors.grey;
        }
        
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          color: const Color(0xFF222222),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: actionColor.withOpacity(0.2),
              child: Icon(actionIcon, color: actionColor),
            ),
            title: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: player?.name ?? 'Unknown Player',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  TextSpan(
                    text: ' - $actionName',
                    style: TextStyle(
                      color: Colors.grey[300],
                    ),
                  ),
                  if (points != null) ...[
                    TextSpan(
                      text: ' ($points pts)',
                      style: const TextStyle(
                        color: Colors.orange,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            subtitle: team != null
                ? Text(
                    team.name,
                    style: TextStyle(
                      color: team.color,
                    ),
                  )
                : null,
            trailing: Text(
              '${index + 1}',
              style: TextStyle(
                color: Colors.grey[500],
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      },
    );
  }

  // Bottom bar with additional actions
  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF222222),
            const Color(0xFF111111),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildBottomBarButton(
            icon: Icons.home,
            label: 'Home',
            onTap: () => Navigator.of(context).popUntil((route) => route.isFirst),
          ),
          _buildBottomBarButton(
            icon: Icons.share,
            label: 'Share',
            onTap: _shareGameResults,
          ),
          _buildBottomBarButton(
            icon: Icons.replay,
            label: 'New Game',
            onTap: () {
              Navigator.of(context).pop();
              // Additional logic for starting a new game could be added here
            },
          ),
        ],
      ),
    );
  }

  // Helper method for bottom bar buttons
  Widget _buildBottomBarButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.orange),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Build top performers section
  Widget _buildTopPerformers() {
    // Get all players from all teams
    final allPlayers = widget.teams.expand((team) => team.players).toList();
    
    // Sort by points
    allPlayers.sort((a, b) => b.points.compareTo(a.points));
    
    // Take top 3 or fewer if not enough players
    final topScorers = allPlayers.take(3).toList();
    
    return Column(
      children: [
        for (final player in topScorers) ...[
          Card(
            elevation: 4,
            color: const Color(0xFF222222),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  // Player avatar/number
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.orange,
                          Colors.deepOrange,
                        ],
                      ),
                    ),
                    child: Center(
                      child: Text(
                        '${player.number}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  // Player info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          player.name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _getTeamForPlayer(player)?.name ?? 'Unknown Team',
                          style: TextStyle(
                            color: _getTeamForPlayer(player)?.color ?? Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Stats
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '${player.points}',
                        style: const TextStyle(
                          color: Colors.orange,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Text(
                        'PTS',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ],
    );
  }

  // Helper method to find team for a player
  TeamModel? _getTeamForPlayer(PlayerModel player) {
    for (final team in widget.teams) {
      if (team.players.contains(player)) {
        return team;
      }
    }
    return null;
  }

  // Share game results
  void _shareGameResults() async {
    if (_isSharing) return;
    
    setState(() {
      _isSharing = true;
    });
    
    try {
      // Build share text
      final buffer = StringBuffer();
      
      // Game result
      TeamModel? winner;
      bool isTie = false;
      
      if (widget.teams.length >= 2) {
        if (widget.teams[0].score > widget.teams[1].score) {
          winner = widget.teams[0];
        } else if (widget.teams[1].score > widget.teams[0].score) {
          winner = widget.teams[1];
        } else {
          isTie = true;
        }
      }
      
      if (isTie) {
        buffer.writeln('🏀 Game Tied! 🏀');
      } else if (winner != null) {
        buffer.writeln('🏀 ${winner.name} Wins! 🏀');
      }
      
      buffer.writeln();
      
      // Final score
      for (int i = 0; i < widget.teams.length && i < 2; i++) {
        buffer.writeln('${widget.teams[i].name}: ${widget.teams[i].score}');
      }
      
      buffer.writeln('\n📊 Top Performers:');
      
      // Get all players from all teams
      final allPlayers = widget.teams.expand((team) => team.players).toList();
      
      // Sort by points
      allPlayers.sort((a, b) => b.points.compareTo(a.points));
      
      // Take top 3 or fewer if not enough players
      final topScorers = allPlayers.take(3).toList();
      
      for (final player in topScorers) {
        final team = _getTeamForPlayer(player);
        buffer.writeln('${player.name} (${team?.name ?? "Team"}): ${player.points} pts');
      }
      
      buffer.writeln('\nShared from Check Up App');
      
      // Use share_plus package to share the text
      await Share.share(
        buffer.toString(),
        subject: 'Game Results',
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error sharing: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isSharing = false;
        });
      }
    }
  }
}
