import 'package:flutter/material.dart';
import 'dart:async';
import '../domain/models/team_model.dart';
import '../domain/models/player_model.dart';

/// Modern, mobile-friendly settings screen for the scoreboard
class ScoreboardSettingsScreen extends StatefulWidget {
  /// Teams to edit
  final List<TeamModel> teams;

  /// Current period
  final int currentPeriod;

  /// Callback when settings are saved
  final Function(List<TeamModel>, int) onSettingsSaved;

  /// Constructor
  const ScoreboardSettingsScreen({
    Key? key,
    required this.teams,
    required this.currentPeriod,
    required this.onSettingsSaved,
  }) : super(key: key);

  @override
  State<ScoreboardSettingsScreen> createState() =>
      _ScoreboardSettingsScreenState();
}

class _ScoreboardSettingsScreenState extends State<ScoreboardSettingsScreen>
    with TickerProviderStateMixin {
  late List<TeamModel> _editedTeams;
  late int _editedPeriod;
  late TabController _tabController;

  // Game clock variables
  int _minutes = 12;
  int _seconds = 0;
  bool _isClockRunning = false;
  late Timer _timer;

  // Shot clock variables
  int _shotClockSeconds = 24;
  bool _isShotClockRunning = false;
  late Timer _shotClockTimer;

  // Text editing controllers for clock
  final TextEditingController _minutesController =
      TextEditingController(text: '12');
  final TextEditingController _secondsController =
      TextEditingController(text: '00');

  @override
  void initState() {
    super.initState();
    _editedTeams = List.from(widget.teams);
    _editedPeriod = widget.currentPeriod;
    _tabController = TabController(length: 2, vsync: this);

    // Initialize clock values from current game state if available
    // In a real app, this would come from the actual game clock
    _minutesController.text = _minutes.toString().padLeft(2, '0');
    _secondsController.text = _seconds.toString().padLeft(2, '0');
  }

  @override
  void dispose() {
    if (_isClockRunning) {
      _timer.cancel();
    }
    if (_isShotClockRunning) {
      _shotClockTimer.cancel();
    }
    _minutesController.dispose();
    _secondsController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Column(
          children: [
            // Modern header with gradient
            _buildModernHeader(),

            // Tab content
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildGameTab(),
                  _buildRosterTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Modern header with gradient background
  Widget _buildModernHeader() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A1A1A), Color(0xFF0A0A0A)],
        ),
      ),
      child: Column(
        children: [
          // App bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            child: Row(
              children: [
                // Back button
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back_ios,
                        color: Colors.white, size: 20),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
                const SizedBox(width: 16),
                // Title
                const Expanded(
                  child: Text(
                    'Game Settings',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                // Save button
                _buildSaveButton(),
              ],
            ),
          ),

          // Modern tab selector
          _buildTabSelector(),
        ],
      ),
    );
  }

  // Save button with gradient
  Widget _buildSaveButton() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.orange.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _saveSettings,
          borderRadius: BorderRadius.circular(12),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            child: Text(
              'Save',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Modern tab selector
  Widget _buildTabSelector() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey[400],
        labelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 16,
          letterSpacing: 0.5,
        ),
        unselectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 16,
        ),
        tabs: const [
          Tab(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.sports_basketball, size: 20),
                  SizedBox(width: 8),
                  Text('Game'),
                ],
              ),
            ),
          ),
          Tab(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.people, size: 20),
                  SizedBox(width: 8),
                  Text('Roster'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Modern Game tab with teams and controls
  Widget _buildGameTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Teams Section
          _buildSection(
            title: 'Teams',
            icon: Icons.groups,
            child: _buildTeamsCard(),
          ),

          const SizedBox(height: 24),

          // Game Controls Section
          _buildSection(
            title: 'Game Controls',
            icon: Icons.timer,
            child: _buildGameControlsCard(),
          ),

          const SizedBox(height: 100), // Bottom padding
        ],
      ),
    );
  }

  // Section wrapper with icon and title
  Widget _buildSection({
    required String title,
    required IconData icon,
    required Widget child,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header
        Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
        child,
      ],
    );
  }

  // Modern teams card
  Widget _buildTeamsCard() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A1A1A), Color(0xFF111111)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Current teams display
            if (_editedTeams.isNotEmpty) ...[
              _buildCurrentTeamsDisplay(),
              const SizedBox(height: 20),
            ],

            // Team action buttons
            _buildTeamActionButtons(),
          ],
        ),
      ),
    );
  }

  // Current teams display
  Widget _buildCurrentTeamsDisplay() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Current Teams',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            // Home team
            Expanded(
              child: _buildTeamDisplayCard(_editedTeams[0], 'HOME'),
            ),
            if (_editedTeams.length > 1) ...[
              const SizedBox(width: 12),
              // Away team
              Expanded(
                child: _buildTeamDisplayCard(_editedTeams[1], 'AWAY'),
              ),
            ],
          ],
        ),
      ],
    );
  }

  // Team display card
  Widget _buildTeamDisplayCard(TeamModel team, String label) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: team.color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          // Team color indicator
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: team.color,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: team.color.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            team.name,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // Team action buttons
  Widget _buildTeamActionButtons() {
    return Column(
      children: [
        // Create Team button
        _buildActionButton(
          title: 'Create Team',
          subtitle: 'Add a new custom team',
          icon: Icons.add_circle_outline,
          onTap: _showCreateTeamDialog,
        ),
      ],
    );
  }

  // Action button
  Widget _buildActionButton({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.grey[400],
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Game controls card with clock, period, and shot clock
  Widget _buildGameControlsCard() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A1A1A), Color(0xFF111111)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Game Clock
            _buildGameClock(),
            const SizedBox(height: 24),
            // Period and Shot Clock row
            Row(
              children: [
                Expanded(child: _buildPeriodControl()),
                const SizedBox(width: 16),
                Expanded(child: _buildShotClockControl()),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Game clock control
  Widget _buildGameClock() {
    return Column(
      children: [
        const Text(
          'Game Clock',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 12),
        // Clock display
        Container(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.4),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.orange.withOpacity(0.3)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Minutes
              SizedBox(
                width: 60,
                child: TextField(
                  controller: _minutesController,
                  keyboardType: TextInputType.number,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.orange,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.zero,
                  ),
                  onChanged: (value) {
                    if (value.isNotEmpty) {
                      setState(() {
                        _minutes = int.tryParse(value) ?? _minutes;
                      });
                    }
                  },
                ),
              ),
              const Text(
                ':',
                style: TextStyle(
                  color: Colors.orange,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'monospace',
                ),
              ),
              // Seconds
              SizedBox(
                width: 60,
                child: TextField(
                  controller: _secondsController,
                  keyboardType: TextInputType.number,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.orange,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.zero,
                  ),
                  onChanged: (value) {
                    if (value.isNotEmpty) {
                      setState(() {
                        _seconds = int.tryParse(value) ?? _seconds;
                        if (_seconds > 59) {
                          _seconds = 59;
                          _secondsController.text = '59';
                        }
                      });
                    }
                  },
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // Clock controls
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildControlButton(
              icon: Icons.refresh,
              onTap: _resetClock,
              isSecondary: true,
            ),
            const SizedBox(width: 16),
            _buildControlButton(
              icon: _isClockRunning ? Icons.pause : Icons.play_arrow,
              onTap: _toggleClock,
              isSecondary: false,
            ),
          ],
        ),
      ],
    );
  }

  // Period control
  Widget _buildPeriodControl() {
    return Column(
      children: [
        const Text(
          'Period',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: _showPeriodPicker,
          child: Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.4),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.orange.withOpacity(0.3)),
            ),
            child: Center(
              child: Text(
                _editedPeriod > 4 ? 'OT${_editedPeriod - 4}' : '$_editedPeriod',
                style: const TextStyle(
                  color: Colors.orange,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildControlButton(
              icon: Icons.remove,
              onTap: () {
                setState(() {
                  if (_editedPeriod > 1) {
                    _editedPeriod--;
                  } else {
                    _editedPeriod = 8;
                  }
                });
              },
              isSecondary: true,
              size: 36,
            ),
            const SizedBox(width: 12),
            _buildControlButton(
              icon: Icons.add,
              onTap: () {
                setState(() {
                  if (_editedPeriod < 8) {
                    _editedPeriod++;
                  } else {
                    _editedPeriod = 1;
                  }
                });
              },
              isSecondary: true,
              size: 36,
            ),
          ],
        ),
      ],
    );
  }

  // Shot clock control
  Widget _buildShotClockControl() {
    return Column(
      children: [
        const Text(
          'Shot Clock',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: _showShotClockPicker,
          child: Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: _isShotClockRunning && _shotClockSeconds <= 5
                  ? Colors.red.withOpacity(0.3)
                  : Colors.black.withOpacity(0.4),
              shape: BoxShape.circle,
              border: Border.all(
                color: _isShotClockRunning && _shotClockSeconds <= 5
                    ? Colors.red
                    : Colors.orange.withOpacity(0.3),
              ),
            ),
            child: Center(
              child: Text(
                '$_shotClockSeconds',
                style: TextStyle(
                  color: _isShotClockRunning && _shotClockSeconds <= 5
                      ? Colors.red
                      : Colors.orange,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildControlButton(
              icon: Icons.refresh,
              onTap: _resetShotClock,
              isSecondary: true,
              size: 36,
            ),
            const SizedBox(width: 12),
            _buildControlButton(
              icon: _isShotClockRunning ? Icons.pause : Icons.play_arrow,
              onTap: _toggleShotClock,
              isSecondary: false,
              size: 36,
            ),
          ],
        ),
      ],
    );
  }

  // Control button
  Widget _buildControlButton({
    required IconData icon,
    required VoidCallback onTap,
    required bool isSecondary,
    double size = 48,
  }) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: isSecondary
            ? null
            : const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              ),
        color: isSecondary ? Colors.white.withOpacity(0.1) : null,
        shape: BoxShape.circle,
        boxShadow: isSecondary
            ? null
            : [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(size / 2),
          child: Icon(
            icon,
            color: Colors.white,
            size: size * 0.4,
          ),
        ),
      ),
    );
  }

  // Roster tab with team management
  Widget _buildRosterTab() {
    if (_editedTeams.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.groups_outlined,
                color: Colors.grey,
                size: 40,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'No Teams Selected',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Add teams in the Game tab to manage rosters',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    }

    return DefaultTabController(
      length: _editedTeams.length,
      child: Column(
        children: [
          // Team tabs
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Colors.grey.withOpacity(0.2),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: TabBar(
              isScrollable: false,
              indicator: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.orange.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.grey[400],
              labelStyle: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
                letterSpacing: 0.5,
              ),
              unselectedLabelStyle: const TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              labelPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              tabs: _editedTeams
                  .map((team) => Tab(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 20,
                                height: 20,
                                decoration: BoxDecoration(
                                  color: team.color,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.3),
                                    width: 1,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text(
                                  team.name,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ))
                  .toList(),
            ),
          ),

          // Team roster content
          Expanded(
            child: TabBarView(
              children: _editedTeams.map((team) {
                final teamIndex = _editedTeams.indexOf(team);
                return _buildTeamRoster(team, teamIndex);
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  // Build roster for a specific team
  Widget _buildTeamRoster(TeamModel team, int teamIndex) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Team info header
          _buildTeamInfoHeader(team, teamIndex),

          const SizedBox(height: 24),

          // Players section
          _buildPlayersSection(team, teamIndex),

          const SizedBox(height: 100), // Bottom padding
        ],
      ),
    );
  }

  // Team info header
  Widget _buildTeamInfoHeader(TeamModel team, int teamIndex) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            team.color.withOpacity(0.2),
            team.color.withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: team.color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              // Team color circle
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: team.color,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: team.color.withOpacity(0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.sports_basketball,
                  color: Colors.white,
                  size: 30,
                ),
              ),
              const SizedBox(width: 16),
              // Team details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      team.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      teamIndex == 0 ? 'HOME TEAM' : 'AWAY TEAM',
                      style: TextStyle(
                        color: team.color,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${team.players.length} Players',
                      style: TextStyle(
                        color: Colors.grey[300],
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
              // Edit team button
              Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: IconButton(
                  onPressed: () => _editTeamInfo(team, teamIndex),
                  icon: const Icon(
                    Icons.edit,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Players section
  Widget _buildPlayersSection(TeamModel team, int teamIndex) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header
        Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.people, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 12),
            const Text(
              'Players',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
            ),
            const Spacer(),
            // Add player button
            Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => _addPlayer(team, teamIndex),
                  borderRadius: BorderRadius.circular(12),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.add, color: Colors.white, size: 16),
                        SizedBox(width: 4),
                        Text(
                          'Add Player',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: 16),

        // Players list
        if (team.players.isEmpty)
          _buildEmptyPlayersState(team, teamIndex)
        else
          ...team.players.asMap().entries.map((entry) {
            final index = entry.key;
            final player = entry.value;
            return _buildPlayerCard(player, team, teamIndex, index);
          }).toList(),
      ],
    );
  }

  // Empty players state
  Widget _buildEmptyPlayersState(TeamModel team, int teamIndex) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(
            Icons.person_add_outlined,
            color: Colors.grey[400],
            size: 48,
          ),
          const SizedBox(height: 16),
          Text(
            'No Players Added',
            style: TextStyle(
              color: Colors.grey[300],
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tap "Add Player" to start building your roster',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  // Player card
  Widget _buildPlayerCard(
      PlayerModel player, TeamModel team, int teamIndex, int playerIndex) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF222222), Color(0xFF111111)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: team.color.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _editPlayer(team, teamIndex, playerIndex),
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Player number
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        team.color,
                        team.color.withOpacity(0.7),
                      ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: team.color.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      '${player.number}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                // Player info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        player.name,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: team.color.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              player.position ?? 'PG',
                              style: TextStyle(
                                color: team.color,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '${player.points} PTS',
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Edit button
                Icon(
                  Icons.chevron_right,
                  color: Colors.grey[400],
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Clock control methods
  void _toggleClock() {
    setState(() {
      _isClockRunning = !_isClockRunning;
      if (_isClockRunning) {
        _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
          setState(() {
            if (_seconds > 0) {
              _seconds--;
            } else if (_minutes > 0) {
              _minutes--;
              _seconds = 59;
            } else {
              _isClockRunning = false;
              timer.cancel();
            }
            _minutesController.text = _minutes.toString().padLeft(2, '0');
            _secondsController.text = _seconds.toString().padLeft(2, '0');
          });
        });
      } else {
        _timer.cancel();
      }
    });
  }

  void _resetClock() {
    setState(() {
      _isClockRunning = false;
      if (_isClockRunning) {
        _timer.cancel();
      }
      _minutes = 12;
      _seconds = 0;
      _minutesController.text = '12';
      _secondsController.text = '00';
    });
  }

  // Shot clock methods
  void _toggleShotClock() {
    setState(() {
      _isShotClockRunning = !_isShotClockRunning;
      if (_isShotClockRunning) {
        _shotClockTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
          setState(() {
            if (_shotClockSeconds > 0) {
              _shotClockSeconds--;
            } else {
              _isShotClockRunning = false;
              timer.cancel();
            }
          });
        });
      } else {
        _shotClockTimer.cancel();
      }
    });
  }

  void _resetShotClock() {
    setState(() {
      _isShotClockRunning = false;
      if (_isShotClockRunning) {
        _shotClockTimer.cancel();
      }
      _shotClockSeconds = 24;
    });
  }

  // Team management methods

  // Show dialog to select which team to replace
  Future<int?> _showTeamReplaceDialog() async {
    return showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text(
          'Replace Team',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'You already have 2 teams. Which team would you like to replace?',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 16),
            ...List.generate(_editedTeams.length, (index) {
              final team = _editedTeams[index];
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () => Navigator.pop(context, index),
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: team.color.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                              color: team.color,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              team.name,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Text(
                            index == 0 ? 'HOME' : 'AWAY',
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }

  void _showCreateTeamDialog() {
    final nameController = TextEditingController();
    Color selectedColor = Colors.blue; // Default color
    bool hasMaxTeams = _editedTeams.length >= 2;
    int? teamToReplaceIndex;

    // If we have max teams, first ask which team to replace
    if (hasMaxTeams) {
      _showTeamReplaceDialog().then((replaceIndex) {
        if (replaceIndex != null) {
          teamToReplaceIndex = replaceIndex;
          _showTeamCreationForm(
              nameController, selectedColor, teamToReplaceIndex);
        }
      });
    } else {
      _showTeamCreationForm(nameController, selectedColor, null);
    }
  }

  void _showTeamCreationForm(TextEditingController nameController,
      Color initialColor, int? replaceIndex) {
    Color selectedColor = initialColor;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.add_circle_outline,
                  color: Colors.white, size: 18),
            ),
            const SizedBox(width: 12),
            const Text(
              'Create New Team',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Team name input
              const Text(
                'Team Name',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: nameController,
                autofocus: true,
                style: const TextStyle(color: Colors.white, fontSize: 16),
                decoration: InputDecoration(
                  hintText: 'Enter team name...',
                  hintStyle: TextStyle(color: Colors.grey[400]),
                  filled: true,
                  fillColor: Colors.black.withOpacity(0.3),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[600]!),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                        const BorderSide(color: Colors.orange, width: 2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),

              const SizedBox(height: 24),

              // Team color picker
              const Text(
                'Team Color',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),

              StatefulBuilder(
                builder: (context, setDialogState) => Column(
                  children: [
                    // Color preview
                    Container(
                      width: double.infinity,
                      height: 60,
                      decoration: BoxDecoration(
                        color: selectedColor,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: selectedColor.withOpacity(0.4),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.sports_basketball,
                                color: Colors.white, size: 24),
                            const SizedBox(width: 8),
                            Text(
                              nameController.text.isEmpty
                                  ? 'Team Preview'
                                  : nameController.text,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Color options
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        Colors.red,
                        Colors.blue,
                        Colors.green,
                        Colors.orange,
                        Colors.purple,
                        Colors.teal,
                        Colors.pink,
                        Colors.indigo,
                        Colors.amber,
                        Colors.cyan,
                        Colors.lime,
                        Colors.deepOrange,
                      ].map((color) {
                        final isSelected = selectedColor == color;
                        return GestureDetector(
                          onTap: () {
                            setDialogState(() {
                              selectedColor = color;
                            });
                          },
                          child: Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: color,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: isSelected
                                    ? Colors.white
                                    : Colors.transparent,
                                width: 3,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: color.withOpacity(0.3),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: isSelected
                                ? const Icon(Icons.check,
                                    color: Colors.white, size: 24)
                                : null,
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Info message
              if (replaceIndex != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.orange.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline, color: Colors.orange, size: 16),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'This will replace ${_editedTeams[replaceIndex].name}',
                          style: TextStyle(
                            color: Colors.orange,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        actions: [
          // Cancel button
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.grey, fontSize: 16),
            ),
          ),

          // Create button
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                final teamName = nameController.text.trim();
                if (teamName.isEmpty) {
                  // Show error - could add a snackbar here
                  return;
                }

                // Create new team
                final newTeam = TeamModel(
                  name: teamName,
                  color: selectedColor,
                  players: [], // Start with empty roster
                );

                setState(() {
                  if (replaceIndex != null) {
                    // Replace existing team
                    _editedTeams[replaceIndex] = newTeam;
                  } else {
                    // Add new team
                    _editedTeams.add(newTeam);
                  }
                });

                Navigator.pop(context);

                // Show success message
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      replaceIndex != null
                          ? 'Team replaced successfully!'
                          : 'Team created successfully!',
                    ),
                    backgroundColor: Colors.green,
                    duration: const Duration(seconds: 2),
                  ),
                );
              },
              child: const Text(
                'Create Team',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Player management methods
  void _addPlayer(TeamModel team, int teamIndex) {
    _showUserSearchDialog(team, teamIndex);
  }

  // Show user search dialog for adding players
  void _showUserSearchDialog(TeamModel team, int teamIndex) {
    final searchController = TextEditingController();
    List<Map<String, dynamic>> searchResults = [];
    bool isSearching = false;

    // Mock users data - in real app this would come from your user service
    final mockUsers = [
      {
        'id': '1',
        'name': 'Alex Johnson',
        'username': 'alexj',
        'profileImageUrl': 'https://i.pravatar.cc/150?u=alex',
        'position': 'PG',
        'isActive': true,
      },
      {
        'id': '2',
        'name': 'Sarah Williams',
        'username': 'sarahw',
        'profileImageUrl': 'https://i.pravatar.cc/150?u=sarah',
        'position': 'SG',
        'isActive': false,
      },
      {
        'id': '3',
        'name': 'Mike Davis',
        'username': 'miked',
        'profileImageUrl': 'https://i.pravatar.cc/150?u=mike',
        'position': 'SF',
        'isActive': true,
      },
      {
        'id': '4',
        'name': 'Jordan Smith',
        'username': 'jordans',
        'profileImageUrl': 'https://i.pravatar.cc/150?u=jordan',
        'position': 'PF',
        'isActive': true,
      },
      {
        'id': '5',
        'name': 'Taylor Brown',
        'username': 'taylorb',
        'profileImageUrl': 'https://i.pravatar.cc/150?u=taylor',
        'position': 'C',
        'isActive': false,
      },
      {
        'id': '6',
        'name': 'Chris Wilson',
        'username': 'chrisw',
        'profileImageUrl': 'https://i.pravatar.cc/150?u=chris',
        'position': 'PG',
        'isActive': true,
      },
      {
        'id': '7',
        'name': 'Maya Patel',
        'username': 'mayap',
        'profileImageUrl': 'https://i.pravatar.cc/150?u=maya',
        'position': 'SG',
        'isActive': true,
      },
    ];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child:
                    const Icon(Icons.person_add, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 12),
              const Text(
                'Add Player',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          content: SizedBox(
            width: double.maxFinite,
            height: 500,
            child: Column(
              children: [
                // Search field
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2A2A),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.grey[700]!, width: 1),
                  ),
                  child: TextField(
                    controller: searchController,
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                    onChanged: (value) {
                      setDialogState(() {
                        isSearching = value.isNotEmpty;
                        if (value.isEmpty) {
                          searchResults = [];
                        } else {
                          searchResults = mockUsers.where((user) {
                            return (user['name'] as String)
                                    .toLowerCase()
                                    .contains(value.toLowerCase()) ||
                                (user['username'] as String)
                                    .toLowerCase()
                                    .contains(value.toLowerCase());
                          }).toList();
                        }
                      });
                    },
                    decoration: InputDecoration(
                      hintText: 'Search for players...',
                      hintStyle:
                          TextStyle(color: Colors.grey[400], fontSize: 16),
                      prefixIcon: const Icon(Icons.search,
                          color: Color(0xFFFF9800), size: 24),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 16),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Search results or empty state
                Expanded(
                  child: isSearching && searchResults.isNotEmpty
                      ? ListView.builder(
                          itemCount: searchResults.length,
                          itemBuilder: (context, index) {
                            final user = searchResults[index];
                            return _buildUserSearchResult(
                                user, team, teamIndex);
                          },
                        )
                      : isSearching && searchResults.isEmpty
                          ? _buildNoResultsState()
                          : _buildSearchPromptState(),
                ),

                const SizedBox(height: 16),

                // Manual add option
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.grey[800]!,
                        Colors.grey[700]!,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _addManualPlayer(team, teamIndex);
                    },
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.person_add_alt,
                            color: Colors.white, size: 18),
                        SizedBox(width: 8),
                        Text(
                          'Add Player Manually',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                'Cancel',
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Build user search result item
  Widget _buildUserSearchResult(
      Map<String, dynamic> user, TeamModel team, int teamIndex) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[700]!, width: 1),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Stack(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: user['isActive']
                      ? [const Color(0xFF4CAF50), const Color(0xFF2E7D32)]
                      : [const Color(0xFFFF9800), const Color(0xFFFF5722)],
                ),
              ),
              child: ClipOval(
                child: user['profileImageUrl'] != null
                    ? Image.network(
                        user['profileImageUrl'],
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) => Center(
                          child: Text(
                            user['name'][0],
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      )
                    : Center(
                        child: Text(
                          user['name'][0],
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
              ),
            ),
            if (user['isActive'])
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                    border:
                        Border.all(color: const Color(0xFF2A2A2A), width: 2),
                  ),
                ),
              ),
          ],
        ),
        title: Text(
          user['name'],
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '@${user['username']}',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFFFF9800).withOpacity(0.2),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                _getPositionName(user['position']),
                style: const TextStyle(
                  color: Color(0xFFFF9800),
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
        trailing: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            ),
            borderRadius: BorderRadius.circular(8),
          ),
          child: TextButton(
            onPressed: () {
              Navigator.pop(context);
              _addUserAsPlayer(user, team, teamIndex);
            },
            child: const Text(
              'Add',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Build no results state
  Widget _buildNoResultsState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.grey[800],
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.search_off,
              color: Colors.grey,
              size: 40,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'No players found',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Try searching with a different name or username',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  // Build search prompt state
  Widget _buildSearchPromptState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              ),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.search,
              color: Colors.white,
              size: 40,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Search for players',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Start typing to find players from the Check-Up community',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  // Add user as player to team
  void _addUserAsPlayer(
      Map<String, dynamic> user, TeamModel team, int teamIndex) {
    final newPlayer = PlayerModel(
      id: user['id'],
      name: user['name'],
      number: _getNextAvailableNumber(team),
      position: user['position'],
      points: 0,
      photoUrl: user['profileImageUrl'],
    );

    setState(() {
      _editedTeams[teamIndex] = TeamModel(
        name: team.name,
        color: team.color,
        players: [...team.players, newPlayer],
      );
    });

    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${user['name']} added to ${team.name}'),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // Add manual player (original functionality)
  void _addManualPlayer(TeamModel team, int teamIndex) {
    final newPlayer = PlayerModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: 'Player ${team.players.length + 1}',
      number: _getNextAvailableNumber(team),
      position: 'PG',
      points: 0,
      photoUrl: 'https://i.pravatar.cc/150?u=Player${team.players.length + 1}',
    );

    setState(() {
      _editedTeams[teamIndex] = TeamModel(
        name: team.name,
        color: team.color,
        players: [...team.players, newPlayer],
      );
    });

    // Show edit dialog immediately for the new player
    _editPlayer(team, teamIndex, team.players.length);
  }

  int _getNextAvailableNumber(TeamModel team) {
    final usedNumbers = team.players.map((p) => p.number).toSet();
    for (int i = 1; i <= 99; i++) {
      if (!usedNumbers.contains(i)) {
        return i;
      }
    }
    return 99; // Fallback
  }

  void _editPlayer(TeamModel team, int teamIndex, int playerIndex) {
    final player = _editedTeams[teamIndex].players[playerIndex];
    final nameController = TextEditingController(text: player.name);
    final numberController =
        TextEditingController(text: player.number.toString());
    String selectedPosition = player.position ?? 'PG';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: Text(
          'Edit Player',
          style: TextStyle(color: Colors.white),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Player name
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Player Name',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[600]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.orange),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Player number
              TextField(
                controller: numberController,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Jersey Number',
                  labelStyle: TextStyle(color: Colors.grey[400]),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[600]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.orange),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Position dropdown
              StatefulBuilder(
                builder: (context, setDialogState) =>
                    DropdownButtonFormField<String>(
                  value: selectedPosition,
                  dropdownColor: const Color(0xFF2A2A2A),
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Position',
                    labelStyle: TextStyle(color: Colors.grey[400]),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey[600]!),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: Colors.orange),
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  items: ['PG', 'SG', 'SF', 'PF', 'C'].map((position) {
                    return DropdownMenuItem(
                      value: position,
                      child: Text(
                        _getPositionName(position),
                        style: const TextStyle(color: Colors.white),
                      ),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setDialogState(() {
                      selectedPosition = value!;
                    });
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          // Delete button
          if (playerIndex < _editedTeams[teamIndex].players.length)
            TextButton(
              onPressed: () {
                setState(() {
                  final updatedPlayers =
                      List<PlayerModel>.from(_editedTeams[teamIndex].players);
                  updatedPlayers.removeAt(playerIndex);
                  _editedTeams[teamIndex] = TeamModel(
                    name: team.name,
                    color: team.color,
                    players: updatedPlayers,
                  );
                });
                Navigator.pop(context);
              },
              child: const Text(
                'Delete',
                style: TextStyle(color: Colors.red),
              ),
            ),

          // Cancel button
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.grey),
            ),
          ),

          // Save button
          TextButton(
            onPressed: () {
              final name = nameController.text.trim();
              final numberText = numberController.text.trim();

              if (name.isEmpty) {
                // Show error
                return;
              }

              final number = int.tryParse(numberText) ?? player.number;

              // Check for duplicate numbers
              final otherPlayers = _editedTeams[teamIndex]
                  .players
                  .where((p) => p.id != player.id)
                  .toList();
              if (otherPlayers.any((p) => p.number == number)) {
                // Show error for duplicate number
                return;
              }

              setState(() {
                final updatedPlayer = PlayerModel(
                  id: player.id,
                  name: name,
                  number: number,
                  position: selectedPosition,
                  points: player.points,
                  photoUrl: player.photoUrl,
                );

                final updatedPlayers =
                    List<PlayerModel>.from(_editedTeams[teamIndex].players);
                if (playerIndex < updatedPlayers.length) {
                  updatedPlayers[playerIndex] = updatedPlayer;
                } else {
                  updatedPlayers.add(updatedPlayer);
                }

                _editedTeams[teamIndex] = TeamModel(
                  name: team.name,
                  color: team.color,
                  players: updatedPlayers,
                );
              });

              Navigator.pop(context);
            },
            child: const Text(
              'Save',
              style: TextStyle(color: Colors.orange),
            ),
          ),
        ],
      ),
    );
  }

  String _getPositionName(String position) {
    switch (position) {
      case 'PG':
        return 'Point Guard';
      case 'SG':
        return 'Shooting Guard';
      case 'SF':
        return 'Small Forward';
      case 'PF':
        return 'Power Forward';
      case 'C':
        return 'Center';
      default:
        return position;
    }
  }

  void _editTeamInfo(TeamModel team, int teamIndex) {
    final nameController = TextEditingController(text: team.name);
    Color selectedColor = team.color;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text(
          'Edit Team',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Team name
            TextField(
              controller: nameController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Team Name',
                labelStyle: TextStyle(color: Colors.grey[400]),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey[600]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.orange),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Color picker
            const Text(
              'Team Color',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
            const SizedBox(height: 8),
            StatefulBuilder(
              builder: (context, setDialogState) => Wrap(
                spacing: 8,
                children: [
                  Colors.red,
                  Colors.blue,
                  Colors.green,
                  Colors.orange,
                  Colors.purple,
                  Colors.teal,
                  Colors.pink,
                  Colors.indigo,
                ].map((color) {
                  return GestureDetector(
                    onTap: () {
                      setDialogState(() {
                        selectedColor = color;
                      });
                    },
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: selectedColor == color
                              ? Colors.white
                              : Colors.transparent,
                          width: 3,
                        ),
                      ),
                      child: selectedColor == color
                          ? const Icon(Icons.check,
                              color: Colors.white, size: 20)
                          : null,
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          TextButton(
            onPressed: () {
              final name = nameController.text.trim();
              if (name.isNotEmpty) {
                setState(() {
                  _editedTeams[teamIndex] = TeamModel(
                    name: name,
                    color: selectedColor,
                    players: team.players,
                  );
                });
                Navigator.pop(context);
              }
            },
            child: const Text(
              'Save',
              style: TextStyle(color: Colors.orange),
            ),
          ),
        ],
      ),
    );
  }

  // Period picker dialog
  void _showPeriodPicker() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text(
          'Select Period',
          style: TextStyle(color: Colors.white),
        ),
        content: SizedBox(
          height: 200,
          child: Column(
            children: [
              const Text(
                'Choose the game period',
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 4,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: List.generate(8, (index) {
                    final period = index + 1;
                    final isSelected = period == _editedPeriod;
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _editedPeriod = period;
                        });
                        Navigator.pop(context);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: isSelected
                              ? const LinearGradient(
                                  colors: [
                                    Color(0xFFFF9800),
                                    Color(0xFFFF5722)
                                  ],
                                )
                              : null,
                          color:
                              isSelected ? null : Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isSelected ? Colors.orange : Colors.grey,
                            width: 2,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            period > 4 ? 'OT${period - 4}' : 'Q$period',
                            style: TextStyle(
                              color:
                                  isSelected ? Colors.white : Colors.grey[300],
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }

  // Shot clock picker dialog
  void _showShotClockPicker() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text(
          'Set Shot Clock',
          style: TextStyle(color: Colors.white),
        ),
        content: SizedBox(
          height: 200,
          child: Column(
            children: [
              const Text(
                'Choose shot clock time (seconds)',
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 4,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: [14, 16, 20, 24, 30, 35].map((seconds) {
                    final isSelected = seconds == _shotClockSeconds;
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _shotClockSeconds = seconds;
                        });
                        Navigator.pop(context);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: isSelected
                              ? const LinearGradient(
                                  colors: [
                                    Color(0xFFFF9800),
                                    Color(0xFFFF5722)
                                  ],
                                )
                              : null,
                          color:
                              isSelected ? null : Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isSelected ? Colors.orange : Colors.grey,
                            width: 2,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            '$seconds',
                            style: TextStyle(
                              color:
                                  isSelected ? Colors.white : Colors.grey[300],
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }

  // Save settings with comprehensive validation and feedback
  void _saveSettings() {
    // Validate that we have at least one team
    if (_editedTeams.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select at least one team before saving.'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 3),
        ),
      );
      return;
    }

    // Update clock values from controllers
    final minutes = int.tryParse(_minutesController.text) ?? _minutes;
    final seconds = int.tryParse(_secondsController.text) ?? _seconds;

    // Validate clock values
    if (minutes < 0 || minutes > 99) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Minutes must be between 0 and 99.'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 3),
        ),
      );
      return;
    }

    if (seconds < 0 || seconds > 59) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seconds must be between 0 and 59.'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 3),
        ),
      );
      return;
    }

    // Stop any running timers before saving
    if (_isClockRunning) {
      _timer.cancel();
      setState(() {
        _isClockRunning = false;
      });
    }

    if (_isShotClockRunning) {
      _shotClockTimer.cancel();
      setState(() {
        _isShotClockRunning = false;
      });
    }

    // Show success message first
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Game settings saved successfully!\n'
          '${_editedTeams.length == 2 ? "${_editedTeams[0].name} vs ${_editedTeams[1].name}" : _editedTeams.isNotEmpty ? _editedTeams[0].name : "No teams"}\n'
          'Period: ${_editedPeriod > 4 ? "OT${_editedPeriod - 4}" : _editedPeriod}\n'
          'Clock: ${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}',
        ),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );

    // Save all settings and navigate back to the scoreboard
    widget.onSettingsSaved(_editedTeams, _editedPeriod);

    // Navigate back to the scoreboard screen
    Navigator.of(context).pop();
  }
}
