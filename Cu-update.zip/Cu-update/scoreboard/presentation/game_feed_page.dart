import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Game Feed Page that displays detailed information about a game
/// including media, stats, and play-by-play information
class GameFeedPage extends StatefulWidget {
  /// Game ID
  final String gameId;
  
  /// Home team name
  final String homeTeam;
  
  /// Home team code
  final String homeTeamCode;
  
  /// Home team score
  final int homeScore;
  
  /// Away team name
  final String awayTeam;
  
  /// Away team code
  final String awayTeamCode;
  
  /// Away team score
  final int awayScore;
  
  /// Game status (e.g., "final", "in progress", "upcoming")
  final String gameStatus;
  
  /// Game location
  final String location;
  
  /// Court name/number
  final String court;
  
  /// Game time
  final String time;
  
  /// Pool information
  final String poolInfo;

  /// Constructor
  const GameFeedPage({
    super.key,
    required this.gameId,
    required this.homeTeam,
    required this.homeTeamCode,
    required this.homeScore,
    required this.awayTeam,
    required this.awayTeamCode,
    required this.awayScore,
    required this.gameStatus,
    required this.location,
    required this.court,
    required this.time,
    required this.poolInfo,
  });

  @override
  State<GameFeedPage> createState() => _GameFeedPageState();
}

class _GameFeedPageState extends State<GameFeedPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          '${widget.homeTeamCode} vs ${widget.awayTeamCode}',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share, color: Colors.white),
            onPressed: () {
              HapticFeedback.mediumImpact();
              // Share game info
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _buildScoreHeader(),
          _buildTabBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildFeedTab(),
                _buildMediaTab(),
                _buildStatsTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScoreHeader() {
    // Determine status text and color based on game status
    String statusText;
    Color statusColor;
    
    switch (widget.gameStatus.toLowerCase()) {
      case 'in progress':
        statusText = 'LIVE';
        statusColor = Colors.green.shade600;
        break;
      case 'final':
        statusText = 'FINAL';
        statusColor = Colors.grey.shade700;
        break;
      default:
        statusText = 'UPCOMING';
        statusColor = Colors.orange.shade600;
    }
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF333333),
            const Color(0xFF222222),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          // Status and time
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: statusColor.withOpacity(0.4),
                      blurRadius: 4,
                      spreadRadius: 0,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
                child: Text(
                  statusText,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              Text(
                widget.time,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Teams and scores
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Home team
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _buildTeamLogo(widget.homeTeamCode),
                    const SizedBox(height: 8),
                    Text(
                      widget.homeTeamCode,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.homeTeam,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              
              // Score display
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: widget.gameStatus.toLowerCase() == 'in progress'
                        ? [
                            const Color(0xFF3A3A3A),
                            const Color(0xFF252525),
                            const Color(0xFF3A3A3A),
                          ]
                        : [
                            const Color(0xFF3A3A3A),
                            const Color(0xFF252525),
                          ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 6,
                      spreadRadius: 0,
                      offset: const Offset(0, 3),
                    ),
                  ],
                  border: Border.all(
                    color: widget.gameStatus.toLowerCase() == 'in progress'
                        ? Colors.green.withOpacity(0.5)
                        : const Color(0xFF444444),
                    width: widget.gameStatus.toLowerCase() == 'in progress' ? 1.5 : 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      widget.homeScore.toString(),
                      style: TextStyle(
                        color: _getScoreColor(isHome: true),
                        fontWeight: FontWeight.bold,
                        fontSize: 24,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      height: 24,
                      width: 1.5,
                      color: Colors.grey[600],
                    ),
                    const SizedBox(width: 8),
                    Text(
                      widget.awayScore.toString(),
                      style: TextStyle(
                        color: _getScoreColor(isHome: false),
                        fontWeight: FontWeight.bold,
                        fontSize: 24,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
              
              // Away team
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _buildTeamLogo(widget.awayTeamCode),
                    const SizedBox(height: 8),
                    Text(
                      widget.awayTeamCode,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.awayTeam,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          // Location and court info
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.location_on,
                color: Colors.orange.shade400,
                size: 14,
              ),
              const SizedBox(width: 4),
              Text(
                '${widget.location} • ${widget.court}',
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          
          // Pool info
          Text(
            widget.poolInfo,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF222222),
        border: Border(
          bottom: BorderSide(
            color: Color(0xFF333333),
            width: 1,
          ),
        ),
      ),
      child: TabBar(
        controller: _tabController,
        indicatorColor: Colors.orange,
        indicatorWeight: 3,
        labelColor: Colors.orange,
        unselectedLabelColor: Colors.white70,
        labelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 14,
        ),
        unselectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.normal,
          fontSize: 14,
        ),
        tabs: const [
          Tab(text: 'FEED'),
          Tab(text: 'MEDIA'),
          Tab(text: 'STATS'),
        ],
      ),
    );
  }

  Widget _buildFeedTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildFeedItem(
          icon: Icons.sports_basketball,
          title: 'Game Started',
          time: '1st Quarter - 10:00',
          description: 'The game between ${widget.homeTeam} and ${widget.awayTeam} has started!',
        ),
        _buildFeedItem(
          icon: Icons.sports_score,
          title: 'Score Update',
          time: '1st Quarter - 8:45',
          description: '${widget.homeTeamCode} 2 - 0 ${widget.awayTeamCode}',
          highlight: true,
        ),
        _buildFeedItem(
          icon: Icons.sports_score,
          title: 'Score Update',
          time: '1st Quarter - 7:30',
          description: '${widget.homeTeamCode} 2 - 3 ${widget.awayTeamCode}',
        ),
        _buildFeedItem(
          icon: Icons.timer,
          title: 'End of 1st Quarter',
          time: '1st Quarter - 0:00',
          description: '${widget.homeTeamCode} 18 - 22 ${widget.awayTeamCode}',
          highlight: true,
        ),
        // Add more feed items as needed
      ],
    );
  }

  Widget _buildFeedItem({
    required IconData icon,
    required String title,
    required String time,
    required String description,
    bool highlight = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: highlight
              ? [
                  const Color(0xFF333333),
                  const Color(0xFF282828),
                ]
              : [
                  const Color(0xFF2A2A2A),
                  const Color(0xFF222222),
                ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: highlight ? Colors.orange.withOpacity(0.5) : const Color(0xFF333333),
          width: highlight ? 1.5 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 4,
            spreadRadius: 0,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: highlight ? Colors.orange.withOpacity(0.2) : const Color(0xFF333333),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: highlight ? Colors.orange : Colors.white70,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: highlight ? Colors.orange : Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      time,
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  description,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMediaTab() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: 6, // Mock media items
      itemBuilder: (context, index) {
        return Container(
          decoration: BoxDecoration(
            color: const Color(0xFF333333),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 4,
                spreadRadius: 0,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Placeholder image
                Container(
                  color: Colors.grey[800],
                  child: Icon(
                    index % 3 == 0 ? Icons.videocam : Icons.photo,
                    color: Colors.grey[600],
                    size: 36,
                  ),
                ),
                
                // Play button for videos
                if (index % 3 == 0)
                  Center(
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.play_arrow,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatsTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildStatSection(
          title: 'Team Stats',
          stats: [
            {'label': 'Field Goals', 'home': '24/50 (48%)', 'away': '26/55 (47%)'},
            {'label': '3-Pointers', 'home': '8/20 (40%)', 'away': '10/24 (42%)'},
            {'label': 'Free Throws', 'home': '12/15 (80%)', 'away': '10/14 (71%)'},
            {'label': 'Rebounds', 'home': '32', 'away': '36'},
            {'label': 'Assists', 'home': '18', 'away': '22'},
            {'label': 'Steals', 'home': '6', 'away': '8'},
            {'label': 'Blocks', 'home': '4', 'away': '3'},
            {'label': 'Turnovers', 'home': '10', 'away': '12'},
          ],
        ),
        const SizedBox(height: 24),
        _buildPlayerStats(isHomeTeam: true),
        const SizedBox(height: 24),
        _buildPlayerStats(isHomeTeam: false),
      ],
    );
  }

  Widget _buildStatSection({
    required String title,
    required List<Map<String, String>> stats,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF222222),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color(0xFF333333),
              width: 1,
            ),
          ),
          child: Column(
            children: [
              // Header row
              Container(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                decoration: const BoxDecoration(
                  color: Color(0xFF333333),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(12),
                    topRight: Radius.circular(12),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: Text(
                        'Stat',
                        style: TextStyle(
                          color: Colors.orange.shade300,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        widget.homeTeamCode,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Expanded(
                      child: Text(
                        widget.awayTeamCode,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ),
              
              // Stat rows
              ...stats.map((stat) {
                return Container(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(
                        color: Colors.grey.shade800,
                        width: 0.5,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: Text(
                          stat['label']!,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 14,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          stat['home']!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          stat['away']!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPlayerStats({required bool isHomeTeam}) {
    final teamName = isHomeTeam ? widget.homeTeam : widget.awayTeam;
    final teamCode = isHomeTeam ? widget.homeTeamCode : widget.awayTeamCode;
    
    // Mock player data
    final players = [
      {'number': '23', 'name': 'Player One', 'pts': '18', 'reb': '5', 'ast': '7', 'min': '32'},
      {'number': '10', 'name': 'Player Two', 'pts': '15', 'reb': '3', 'ast': '4', 'min': '28'},
      {'number': '34', 'name': 'Player Three', 'pts': '12', 'reb': '8', 'ast': '2', 'min': '30'},
      {'number': '5', 'name': 'Player Four', 'pts': '8', 'reb': '2', 'ast': '6', 'min': '25'},
      {'number': '21', 'name': 'Player Five', 'pts': '6', 'reb': '4', 'ast': '1', 'min': '20'},
    ];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '$teamCode Players',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF222222),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color(0xFF333333),
              width: 1,
            ),
          ),
          child: Column(
            children: [
              // Header row
              Container(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                decoration: const BoxDecoration(
                  color: Color(0xFF333333),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(12),
                    topRight: Radius.circular(12),
                  ),
                ),
                child: Row(
                  children: [
                    const Expanded(
                      flex: 3,
                      child: Text(
                        'Player',
                        style: TextStyle(
                          color: Colors.orange,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    ...['PTS', 'REB', 'AST', 'MIN'].map((header) {
                      return Expanded(
                        child: Text(
                          header,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      );
                    }).toList(),
                  ],
                ),
              ),
              
              // Player rows
              ...players.map((player) {
                return Container(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(
                        color: Colors.grey.shade800,
                        width: 0.5,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Row(
                          children: [
                            Container(
                              width: 24,
                              height: 24,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: const Color(0xFF333333),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: const Color(0xFF444444),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                player['number']!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                player['name']!,
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 14,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                      ...['pts', 'reb', 'ast', 'min'].map((stat) {
                        return Expanded(
                          child: Text(
                            player[stat]!,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        );
                      }).toList(),
                    ],
                  ),
                );
              }).toList(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTeamLogo(String teamCode) {
    return Container(
      width: 60,
      height: 60,
      decoration: BoxDecoration(
        color: const Color(0xFF333333),
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 6,
            spreadRadius: 0,
            offset: const Offset(0, 3),
          ),
        ],
        border: Border.all(
          color: const Color(0xFF444444),
          width: 1.5,
        ),
      ),
      child: Center(
        child: Text(
          teamCode,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ),
    );
  }

  // Helper method to determine the color of the score based on game status and score comparison
  Color _getScoreColor({required bool isHome}) {
    final String status = widget.gameStatus.toLowerCase();
    
    if (status == 'final') {
      if (isHome && widget.homeScore > widget.awayScore) {
        return Colors.orange;
      } else if (!isHome && widget.awayScore > widget.homeScore) {
        return Colors.orange;
      }
    } else if (status == 'in progress') {
      if (isHome && widget.homeScore > widget.awayScore) {
        return Colors.green.shade300;
      } else if (!isHome && widget.awayScore > widget.homeScore) {
        return Colors.green.shade300;
      }
    }
    
    return Colors.white;
  }
}
