import 'package:flutter/material.dart';
import '../../domain/models/team_model.dart';
import '../../domain/models/player_model.dart';
import '../../data/scoreboard_data_provider.dart';
import '../share_score_screen.dart';

/// Scoring tab for adding points and tracking game actions
class ScoringTab extends StatefulWidget {
  /// Currently selected team
  final TeamModel selectedTeam;

  /// Callback when score is updated with player and action info
  final Function(TeamModel, int,
      {required PlayerModel player, required String actionName}) onScoreUpdated;

  /// Whether undo is available
  final bool canUndo;

  /// Callback for undo action
  final VoidCallback onUndo;

  /// Constructor
  const ScoringTab({
    Key? key,
    required this.selectedTeam,
    required this.onScoreUpdated,
    required this.canUndo,
    required this.onUndo,
  }) : super(key: key);

  @override
  State<ScoringTab> createState() => _ScoringTabState();
}

class _ScoringTabState extends State<ScoringTab> {
  PlayerModel? _selectedPlayer;
  String? _selectedAction;

  final List<Map<String, dynamic>> _scoringActions = [
    {
      'name': 'Free Throw',
      'icon': Icons.sports_basketball,
      'points': 1,
      'color': Colors.orange[300]!,
      'description': '1 PT'
    },
    {
      'name': 'Field Goal',
      'icon': Icons.sports_basketball,
      'points': 2,
      'color': Colors.orange[400]!,
      'description': '2 PT'
    },
    {
      'name': '3-Pointer',
      'icon': Icons.looks_3,
      'points': 3,
      'color': Colors.deepOrange,
      'description': '3 PT'
    },
    {
      'name': 'Assist',
      'icon': Icons.handshake,
      'points': 0,
      'color': Colors.orange[500]!,
      'description': 'AST'
    },
    {
      'name': 'Rebound',
      'icon': Icons.catching_pokemon,
      'points': 0,
      'color': Colors.orange[600]!,
      'description': 'REB'
    },
    {
      'name': 'Block',
      'icon': Icons.block,
      'points': 0,
      'color': Colors.orange[700]!,
      'description': 'BLK'
    },
    {
      'name': 'Steal',
      'icon': Icons.swipe,
      'points': 0,
      'color': Colors.orange[800]!,
      'description': 'STL'
    },
    {
      'name': 'Turnover',
      'icon': Icons.sync_problem,
      'points': 0,
      'color': Colors.orange[900]!,
      'description': 'TO'
    },
    {
      'name': 'Foul',
      'icon': Icons.pan_tool,
      'points': 0,
      'color': Colors.deepOrange[800]!,
      'description': 'FL'
    },
    {
      'name': 'Timeout',
      'icon': Icons.timer,
      'points': 0,
      'color': Colors.deepOrange[600]!,
      'description': 'TO'
    },
  ];

  // Helper getters for action data
  Map<String, int> get _pointValues {
    final map = <String, int>{};
    for (final action in _scoringActions) {
      if (action['points'] > 0) {
        map[action['name']] = action['points'];
      }
    }
    return map;
  }

  Map<String, Color> get _actionColors {
    final map = <String, Color>{};
    for (final action in _scoringActions) {
      map[action['name']] = action['color'];
    }
    return map;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Action buttons row (Undo and Game Over)
        if (_selectedAction == null) _buildActionButtonsRow(),
        // Selected action info
        if (_selectedAction != null) _buildSelectedActionInfo(),

        // Player selection
        if (_selectedAction != null && _selectedPlayer == null)
          Expanded(
            child: _buildPlayerGrid(),
          ),

        // Point buttons for scoring actions
        if (_selectedAction != null &&
            _selectedPlayer != null &&
            _pointValues.containsKey(_selectedAction))
          _buildPointButtons(),

        // Assist selection
        if (_selectedAction == 'Assist' && _selectedPlayer != null)
          _buildAssistSelection(),

        // Confirmation for non-scoring actions (except Assist which has its own flow)
        if (_selectedAction != null &&
            _selectedPlayer != null &&
            !_pointValues.containsKey(_selectedAction) &&
            _selectedAction != 'Assist')
          _buildNonScoringConfirmation(),

        // No action selected - show action grid
        if (_selectedAction == null)
          Expanded(
            child: Container(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).padding.bottom + 16,
              ),
              child: _buildActionButtons(),
            ),
          ),
      ],
    );
  }

  Widget _buildSelectedActionInfo() {
    // Find the selected action data
    final actionData = _scoringActions.firstWhere(
      (action) => action['name'] == _selectedAction,
      orElse: () => _scoringActions[0],
    );

    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              // Back button
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () {
                  setState(() {
                    if (_selectedPlayer != null) {
                      _selectedPlayer = null;
                    } else {
                      _selectedAction = null;
                    }
                  });
                },
              ),

              // Action info
              Expanded(
                child: Row(
                  children: [
                    // Action icon
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: actionData['color'].withOpacity(0.2),
                        border: Border.all(
                          color: actionData['color'],
                          width: 2,
                        ),
                      ),
                      child: Icon(
                        actionData['icon'],
                        color: actionData['color'],
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _selectedAction!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        if (_selectedPlayer != null)
                          Text(
                            '${_selectedPlayer!.name}, #${_selectedPlayer!.number}',
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 14,
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (_selectedPlayer == null)
            const Padding(
              padding: EdgeInsets.only(top: 16),
              child: Text(
                'Select a player',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 1.0,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: _scoringActions.length,
      itemBuilder: (context, index) {
        final actionData = _scoringActions[index];
        return _buildActionButton(actionData);
      },
    );
  }

  Widget _buildActionButton(Map<String, dynamic> actionData) {
    final String name = actionData['name'];
    final IconData icon = actionData['icon'];
    final Color color = actionData['color'];
    final String description = actionData['description'];

    return InkWell(
      onTap: () {
        setState(() {
          _selectedAction = name;
          // All actions should proceed to player selection
          // We'll handle recording after player selection
        });
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: const Color(0xFF1A1A1A),
          border: Border.all(
            color: const Color(0xFF333333),
            width: 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Action icon with colored circle
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.2),
                border: Border.all(
                  color: color,
                  width: 2,
                ),
              ),
              child: Icon(
                icon,
                color: color,
                size: 24,
              ),
            ),
            const SizedBox(height: 8),
            // Action name
            Text(
              name,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            // Action description (points or abbreviation)
            Text(
              description,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPointButtons() {
    return Expanded(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Did they make it?',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Made button
              _buildPointActionButton(
                label: 'Made',
                color: Colors.orange[600]!,
                icon: Icons.check,
                onTap: () {
                  // Add points to the player and team
                  final points = _pointValues[_selectedAction] ?? 0;

                  // Call the updated onScoreUpdated with player and action name
                  widget.onScoreUpdated(
                    widget.selectedTeam,
                    points,
                    player: _selectedPlayer!,
                    actionName: _selectedAction ?? 'Field Goal',
                  );

                  // We don't need to manually record the action anymore
                  // as it's now handled in the ScoreboardScreen

                  _resetSelection();
                },
              ),

              // Missed button
              _buildPointActionButton(
                label: 'Miss',
                color: Colors.grey[600]!,
                icon: Icons.close,
                onTap: () {
                  // Call the updated onScoreUpdated with player and action name
                  // For missed shots, we pass 0 points and add 'Missed' to the action name
                  widget.onScoreUpdated(
                    widget.selectedTeam,
                    0, // No points for missed shots
                    player: _selectedPlayer!,
                    actionName: 'Missed ${_selectedAction ?? 'Shot'}',
                  );

                  _resetSelection();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPointActionButton({
    required String label,
    required Color color,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 120,
        height: 120,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: color.withOpacity(0.2),
          border: Border.all(
            color: color,
            width: 2,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: color,
              size: 36,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAssistSelection() {
    return Expanded(
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Who made the assist?',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: _buildPlayerGrid(
              onPlayerSelected: (player) {
                // Call the updated onScoreUpdated with player and action name
                widget.onScoreUpdated(
                  widget.selectedTeam,
                  0, // Assist is a non-scoring action
                  player: player,
                  actionName: 'Assist',
                );
                _resetSelection();
              },
              excludePlayer: _selectedPlayer,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  _selectedAction = null;
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.orange[300],
                padding:
                    const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text('Assign Later'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNonScoringConfirmation() {
    // Find the selected action data
    final actionData = _scoringActions.firstWhere(
      (action) => action['name'] == _selectedAction,
      orElse: () => _scoringActions[0],
    );

    return Expanded(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Confirmation message
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Record ${_selectedAction} for ${_selectedPlayer!.name}?',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ),

          const SizedBox(height: 24),

          // Action buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Confirm button
              _buildPointActionButton(
                label: 'Confirm',
                color: actionData['color'],
                icon: actionData['icon'],
                onTap: () {
                  // Call the updated onScoreUpdated with player and action name
                  // For non-scoring actions, we pass 0 points
                  widget.onScoreUpdated(
                    widget.selectedTeam,
                    0, // Non-scoring action
                    player: _selectedPlayer!,
                    actionName: _selectedAction ?? '',
                  );

                  _resetSelection();
                },
              ),

              const SizedBox(width: 24),

              // Cancel button
              _buildPointActionButton(
                label: 'Cancel',
                color: Colors.grey,
                icon: Icons.cancel,
                onTap: () {
                  _resetSelection();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPlayerGrid({
    Function(PlayerModel)? onPlayerSelected,
    PlayerModel? excludePlayer,
  }) {
    final players = widget.selectedTeam.players
        .where((player) => player != excludePlayer)
        .toList();

    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 0.85,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: players.length,
      itemBuilder: (context, index) {
        final player = players[index];
        return _buildPlayerCard(
          player,
          onTap: () {
            if (onPlayerSelected != null) {
              onPlayerSelected(player);
            } else {
              setState(() {
                _selectedPlayer = player;
              });
            }
          },
        );
      },
    );
  }

  Widget _buildPlayerCard(PlayerModel player, {required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: const Color(0xFF1A1A1A),
          border: Border.all(
            color: const Color(0xFF333333),
            width: 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Player number
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.selectedTeam.color.withOpacity(0.2),
                border: Border.all(
                  color: widget.selectedTeam.color,
                  width: 2,
                ),
              ),
              child: Center(
                child: Text(
                  player.number.toString(),
                  style: TextStyle(
                    color: widget.selectedTeam.color,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            // Player name
            Text(
              player.name.split(' ').first,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
            Text(
              player.name.split(' ').last,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // Build action buttons row (Undo and Game Over)
  Widget _buildActionButtonsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Enhanced Undo button with better visibility
          Container(
            decoration: BoxDecoration(
              gradient: !widget.canUndo
                  ? LinearGradient(
                      colors: [Color(0xFF444444), Color(0xFF2A2A2A)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: !widget.canUndo
                      ? Colors.black.withOpacity(0.3)
                      : Color(0xFFFF9800).withOpacity(0.4),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton.icon(
              onPressed: !widget.canUndo ? null : widget.onUndo,
              icon: Icon(Icons.undo, size: 22),
              label: const Text('Undo',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    letterSpacing: 0.5,
                  )),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor:
                    !widget.canUndo ? Colors.grey[400] : Colors.white,
                shadowColor: Colors.transparent,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
              ),
            ),
          ),

          // Enhanced Game Over button
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFF5722), Color(0xFFD84315)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Color(0xFFFF5722).withOpacity(0.4),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton.icon(
              onPressed: _handleGameOver,
              icon: const Icon(Icons.sports_score, size: 22),
              label: const Text('Game Over',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    letterSpacing: 0.5,
                  )),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: Colors.white,
                shadowColor: Colors.transparent,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Handle game over
  void _handleGameOver() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        elevation: 16,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF333333), Color(0xFF111111)],
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Colors.orange, Colors.deepOrange],
                  ),
                ),
                child: const Center(
                  child: Text(
                    'END GAME',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ),

              // Content
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const Text(
                      'Are you sure you want to end the game?',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'This will finalize the score and show game stats.',
                      style: TextStyle(color: Colors.white70),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),

                    // Buttons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // Cancel button
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: ElevatedButton(
                              onPressed: () => Navigator.pop(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.grey.shade800,
                                foregroundColor: Colors.white,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 0,
                              ),
                              child: const Text('CANCEL'),
                            ),
                          ),
                        ),

                        // Confirm button
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.pop(context);
                                // Navigate to game details page
                                _navigateToGameDetails();
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.orange,
                                foregroundColor: Colors.white,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 0,
                              ),
                              child: const Text('CONFIRM'),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Show game summary
  void _showGameSummary() {
    // Get all teams from the data provider
    final dataProvider = ScoreboardDataProvider();
    final teams = dataProvider.getMockTeams();

    // Find winner
    TeamModel? winner;
    bool isTie = false;

    if (teams.length >= 2) {
      if (teams[0].score > teams[1].score) {
        winner = teams[0];
      } else if (teams[1].score > teams[0].score) {
        winner = teams[1];
      } else {
        isTie = true;
      }
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text(
          'Game Summary',
          style: TextStyle(color: Colors.white),
          textAlign: TextAlign.center,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Final score
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A2A),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  const Text(
                    'Final Score',
                    style: TextStyle(color: Colors.grey, fontSize: 14),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (teams.length >= 2) ...[
                        Column(
                          children: [
                            Text(
                              teams[0].name,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 16),
                            ),
                            const SizedBox(height: 4),
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: teams[0].color.withOpacity(0.2),
                                border:
                                    Border.all(color: teams[0].color, width: 2),
                              ),
                              child: Center(
                                child: Text(
                                  '${teams[0].score}',
                                  style: TextStyle(
                                    color: teams[0].color,
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16),
                          child: Text(
                            'vs',
                            style: TextStyle(color: Colors.grey, fontSize: 16),
                          ),
                        ),
                        Column(
                          children: [
                            Text(
                              teams[1].name,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 16),
                            ),
                            const SizedBox(height: 4),
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: teams[1].color.withOpacity(0.2),
                                border:
                                    Border.all(color: teams[1].color, width: 2),
                              ),
                              child: Center(
                                child: Text(
                                  '${teams[1].score}',
                                  style: TextStyle(
                                    color: teams[1].color,
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Winner announcement
            if (winner != null)
              Text(
                '${winner.name} Wins!',
                style: TextStyle(
                  color: winner.color,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              )
            else if (isTie)
              const Text(
                'It\'s a Tie!',
                style: TextStyle(
                  color: Colors.amber,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context); // Return to previous screen
            },
            child: const Text(
              'Return to Menu',
              style: TextStyle(color: Colors.white),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Reset game state
              setState(() {
                // Reset scores
                for (final team in teams) {
                  team.score = 0;
                }
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
            ),
            child: const Text('New Game'),
          ),
        ],
      ),
    );
  }

  void _resetSelection() {
    Future.delayed(const Duration(milliseconds: 300), () {
      setState(() {
        _selectedPlayer = null;
        _selectedAction = null;
      });
    });
  }

  // Navigate to share score screen
  void _navigateToGameDetails() {
    // Get all teams from the data provider
    final dataProvider = ScoreboardDataProvider();
    final teams = dataProvider.getMockTeams();

    if (teams.length >= 2) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => ShareScoreScreen(
            teams: teams,
            gameActions: const [], // Empty list since we removed local tracking
          ),
        ),
      );
    }
  }
}
