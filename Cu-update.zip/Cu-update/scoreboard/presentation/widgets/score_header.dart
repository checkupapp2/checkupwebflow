import 'package:flutter/material.dart';
import 'dart:async';
import '../../domain/models/team_model.dart';

/// Header widget displaying the current score and teams
class ScoreHeader extends StatefulWidget {
  /// Home team
  final TeamModel homeTeam;

  /// Away team
  final TeamModel awayTeam;

  /// Current period/quarter
  final int currentPeriod;

  /// Currently selected team
  final TeamModel selectedTeam;

  /// Callback when a team is selected
  final Function(TeamModel) onTeamSelected;

  /// Callback when period is changed
  final VoidCallback? onPeriodChanged;

  /// Callback to open settings
  final VoidCallback? onOpenSettings;

  /// Constructor
  const ScoreHeader({
    Key? key,
    required this.homeTeam,
    required this.awayTeam,
    required this.currentPeriod,
    required this.selectedTeam,
    required this.onTeamSelected,
    this.onPeriodChanged,
    this.onOpenSettings,
  }) : super(key: key);

  @override
  State<ScoreHeader> createState() => _ScoreHeaderState();
}

class _ScoreHeaderState extends State<ScoreHeader> {
  bool _isClockRunning = false;
  String _currentTime = '10:00';
  late Timer _timer;
  int _seconds = 600; // 10 minutes in seconds

  // Shot clock variables
  bool _isShotClockRunning = false;
  int _shotClockSeconds = 24; // 24 seconds for shot clock
  late Timer _shotClockTimer;
  String _shotClockTime = '24';

  @override
  void dispose() {
    if (_isClockRunning) {
      _timer.cancel();
    }
    if (_isShotClockRunning) {
      _shotClockTimer.cancel();
    }
    super.dispose();
  }

  void _toggleClock() {
    setState(() {
      _isClockRunning = !_isClockRunning;

      if (_isClockRunning) {
        _startClock();
        // Start shot clock in parallel with game clock
        _startShotClock();
      } else {
        _timer.cancel();
        // Stop shot clock when game clock stops
        if (_isShotClockRunning) {
          _shotClockTimer.cancel();
          _isShotClockRunning = false;
        }
      }
    });
  }

  void _startClock() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_seconds > 0) {
          _seconds--;
          _updateTimeDisplay();
        } else {
          _timer.cancel();
          _isClockRunning = false;
        }
      });
    });
  }

  void _updateTimeDisplay() {
    int minutes = _seconds ~/ 60;
    int remainingSeconds = _seconds % 60;
    _currentTime = '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  void _startShotClock() {
    setState(() {
      _isShotClockRunning = true;
    });

    _shotClockTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_shotClockSeconds > 0) {
          _shotClockSeconds--;
          _shotClockTime = _shotClockSeconds.toString();
        } else {
          // Auto-reset shot clock when it reaches 0
          _shotClockTimer.cancel();
          _shotClockSeconds = 24;
          _shotClockTime = '24';
          // Restart shot clock if game clock is still running
          if (_isClockRunning) {
            _startShotClock();
          } else {
            _isShotClockRunning = false;
          }
        }
      });
    });
  }

  void _resetShotClock() {
    setState(() {
      if (_isShotClockRunning) {
        _shotClockTimer.cancel();
      }
      _shotClockSeconds = 24;
      _shotClockTime = '24';
      // Restart shot clock if game clock is running
      if (_isClockRunning) {
        _startShotClock();
      } else {
        _isShotClockRunning = false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black,
            const Color(0xFF1A1A1A),
          ],
        ),
      ),
      child: Column(
        children: [
          // Unified Modern Scoreboard Design
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF2A2A2A),
                  Colors.black.withOpacity(0.8),
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: const Color(0xFFFF9800).withOpacity(0.4),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withOpacity(0.2),
                  blurRadius: 20,
                  spreadRadius: 2,
                  offset: const Offset(0, 4),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 15,
                  spreadRadius: 1,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                // ESPN-Style Stacked Teams and Scores
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black,
                        const Color(0xFF1A1A1A),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFFFF9800),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF9800).withOpacity(0.4),
                        blurRadius: 12,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Home Team Row
                      _buildESPNTeamRow(
                        widget.homeTeam,
                        isSelected: widget.selectedTeam == widget.homeTeam,
                        isHome: true,
                      ),

                      // Divider
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                          ),
                        ),
                      ),

                      // Away Team Row
                      _buildESPNTeamRow(
                        widget.awayTeam,
                        isSelected: widget.selectedTeam == widget.awayTeam,
                        isHome: false,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Game Controls Section
                Row(
                  children: [
                    // Period Control
                    Expanded(
                      child: _buildPeriodControl(
                        icon: Icons.sports_basketball,
                        label: widget.currentPeriod > 4
                            ? 'OT${widget.currentPeriod - 4}'
                            : 'Q${widget.currentPeriod}',
                        onTap: widget.onPeriodChanged ?? () {},
                      ),
                    ),

                    const SizedBox(width: 12),

                    // Game Clock Control
                    Expanded(
                      child: _buildGameControl(
                        icon: _isClockRunning ? Icons.pause : Icons.play_arrow,
                        label: _currentTime,
                        isActive: _isClockRunning,
                        onTap: _toggleClock,
                      ),
                    ),

                    const SizedBox(width: 12),

                    // Shot Clock Control
                    Expanded(
                      child: _buildGameControl(
                        icon: Icons.timer,
                        label: _shotClockTime,
                        isActive: _isShotClockRunning,
                        isWarning:
                            _shotClockSeconds <= 5 && _isShotClockRunning,
                        onTap: _resetShotClock, // Tap to reset shot clock
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildESPNTeamRow(TeamModel team,
      {required bool isSelected, required bool isHome}) {
    return GestureDetector(
      onTap: () => widget.onTeamSelected(team),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: isSelected
                ? [
                    const Color(0xFFFF9800).withOpacity(0.2),
                    const Color(0xFFFF5722).withOpacity(0.1),
                  ]
                : [
                    Colors.transparent,
                    Colors.transparent,
                  ],
          ),
          borderRadius: BorderRadius.circular(12),
          border: isSelected
              ? Border.all(
                  color: const Color(0xFFFF9800).withOpacity(0.5),
                  width: 1,
                )
              : null,
        ),
        child: Row(
          children: [
            // Team Logo
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    team.color.withOpacity(0.4),
                    team.color.withOpacity(0.2),
                  ],
                ),
                border: Border.all(
                  color: team.color,
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: team.color.withOpacity(0.3),
                    blurRadius: 4,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: team.logoUrl != null
                  ? ClipOval(
                      child: Image.asset(
                        team.logoUrl!,
                        fit: BoxFit.cover,
                      ),
                    )
                  : ClipOval(
                      child: Image.asset(
                        'assets/images/main_btn.png',
                        width: 18,
                        height: 18,
                        fit: BoxFit.contain,
                      ),
                    ),
            ),

            const SizedBox(width: 12),

            // Team Name and Home/Away
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    team.name,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[300],
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    isHome ? 'HOME' : 'AWAY',
                    style: TextStyle(
                      color:
                          isHome ? const Color(0xFFFF9800) : Colors.grey[500],
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),

            // Score
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFF2A2A2A),
                    const Color(0xFF1A1A1A),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: const Color(0xFFFF9800).withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Text(
                team.score.toString(),
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 24,
                  fontFamily: 'monospace',
                  shadows: [
                    Shadow(
                      blurRadius: 4.0,
                      color: Colors.black,
                      offset: Offset(1.0, 1.0),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPeriodControl({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: widget.onOpenSettings,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF4A4A4A),
              Color(0xFF1A1A1A),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.grey[400]!,
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: 24,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameControl({
    required IconData icon,
    required String label,
    required bool isActive,
    bool isWarning = false,
    required VoidCallback onTap,
    VoidCallback? onLongPress,
  }) {
    Color activeColor = isWarning ? Colors.red : const Color(0xFFFF9800);

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress ?? widget.onOpenSettings,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: isActive
                ? [
                    activeColor.withOpacity(0.3),
                    activeColor.withOpacity(0.1),
                  ]
                : [
                    const Color(0xFF3A3A3A),
                    const Color(0xFF2A2A2A),
                  ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isActive ? activeColor : Colors.grey[600]!,
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color:
                  (isActive ? activeColor : Colors.grey[600]!).withOpacity(0.3),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isActive ? activeColor : Colors.white,
              size: 24,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: isActive ? activeColor : Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
