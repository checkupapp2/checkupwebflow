import 'package:flutter/material.dart';
import '../../domain/models/team_model.dart';
import '../../domain/models/player_model.dart';
import '../../domain/models/game_action_model.dart';

/// Play-by-play tab showing game action history
class PlayByPlayTab extends StatefulWidget {
  /// List of teams
  final List<TeamModel> teams;
  
  /// Currently selected team
  final TeamModel selectedTeam;
  
  /// Game actions to display
  final List<GameActionModel> gameActions;

  /// Constructor
  const PlayByPlayTab({
    Key? key,
    required this.teams,
    required this.selectedTeam,
    required this.gameActions,
  }) : super(key: key);

  @override
  State<PlayByPlayTab> createState() => _PlayByPlayTabState();
}

class _PlayByPlayTabState extends State<PlayByPlayTab> {
  /// Selected filter - null means 'All' teams
  TeamModel? _selectedFilter;

  @override
  void initState() {
    super.initState();
    // Default to 'All' teams (null filter)
    _selectedFilter = null;
  }

  @override
  Widget build(BuildContext context) {
    // Convert game actions to play-by-play data format
    List<Map<String, dynamic>> playByPlayData = [];
    
    // If we have game actions, convert them to the display format
    if (widget.gameActions.isNotEmpty) {
      for (final action in widget.gameActions) {
        // Find the team and player based on IDs
        final team = widget.teams.firstWhere(
          (team) => team.name == action.teamId,
          orElse: () => widget.teams[0],
        );
        
        final player = team.players.firstWhere(
          (player) => player.id == action.playerId,
          orElse: () => team.players.isNotEmpty ? team.players[0] : PlayerModel(
            id: 'unknown',
            name: 'Unknown Player',
            number: 0,
          ),
        );
        
        // Format the time
        final time = '${action.timestamp.hour.toString().padLeft(2, '0')}:${action.timestamp.minute.toString().padLeft(2, '0')}';
        
        // Add the action to the play-by-play data
        playByPlayData.add({
          'time': time,
          'period': action.period,
          'team': team,
          'player': player,
          'action': _getActionName(action.type),
          'points': action.pointValue,
          'description': _getActionDescription(action.type),
        });
      }
    }
    
    // Sort by timestamp (most recent first)
    playByPlayData.sort((a, b) => b['time'].compareTo(a['time']));
    

    return Container(
      color: Colors.black,
      child: Column(
        children: [
          // Team selector
          _buildTeamSelector(),
          
          // Modern play-by-play list with enhanced mobile design
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              itemCount: playByPlayData.length,
              itemBuilder: (context, index) {
                final play = playByPlayData[index];
                final bool isSelectedTeam = play['team'] == widget.selectedTeam;
                final team = play['team'] as TeamModel;
                final player = play['player'] as PlayerModel;
                
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFF2A2A2A),
                        Color(0xFF1A1A1A),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: isSelectedTeam 
                          ? Color(0xFFFF9800).withOpacity(0.6) 
                          : Colors.grey[800]!,
                      width: isSelectedTeam ? 2 : 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isSelectedTeam 
                            ? Color(0xFFFF9800).withOpacity(0.2) 
                            : Colors.black.withOpacity(0.3),
                        blurRadius: isSelectedTeam ? 8 : 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        // Time and period section with enhanced styling
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Color(0xFF444444), Color(0xFF333333)],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Colors.grey[700]!,
                              width: 1,
                            ),
                          ),
                          child: Column(
                            children: [
                              Text(
                                play['time'],
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Color(0xFFFF9800).withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: Color(0xFFFF9800).withOpacity(0.5),
                                    width: 1,
                                  ),
                                ),
                                child: Text(
                                  'Q${play['period']}',
                                  style: TextStyle(
                                    color: Color(0xFFFF9800),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        
                        const SizedBox(width: 16),
                        
                        // Team color indicator with enhanced design
                        Container(
                          width: 6,
                          height: 50,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [team.color, team.color.withOpacity(0.7)],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                            borderRadius: BorderRadius.circular(3),
                            boxShadow: [
                              BoxShadow(
                                color: team.color.withOpacity(0.4),
                                blurRadius: 4,
                                offset: Offset(0, 1),
                              ),
                            ],
                          ),
                        ),
                        
                        const SizedBox(width: 16),
                        
                        // Player and action with enhanced layout
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Player info row
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: team.color.withOpacity(0.2),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: team.color.withOpacity(0.5),
                                        width: 1,
                                      ),
                                    ),
                                    child: Text(
                                      '#${player.number}',
                                      style: TextStyle(
                                        color: team.color,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      player.name,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 15,
                                        letterSpacing: 0.3,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  if (play['points'] > 0)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [
                                            _getPointColor(play['points']),
                                            _getPointColor(play['points']).withOpacity(0.8),
                                          ],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                        borderRadius: BorderRadius.circular(8),
                                        boxShadow: [
                                          BoxShadow(
                                            color: _getPointColor(play['points']).withOpacity(0.3),
                                            blurRadius: 4,
                                            offset: Offset(0, 1),
                                          ),
                                        ],
                                      ),
                                      child: Text(
                                        '+${play['points']}',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              // Action description
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: Colors.grey[700]!,
                                    width: 1,
                                  ),
                                ),
                                child: Text(
                                  '${play['action']} - ${play['description']}',
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 13,
                                    letterSpacing: 0.2,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
  
  /// Build modern team selector with enhanced mobile design
  Widget _buildTeamSelector() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(color: Colors.grey[800]!, width: 1),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                Icons.filter_list,
                color: Color(0xFFFF9800),
                size: 20,
              ),
              const SizedBox(width: 8),
              const Text(
                'Filter by team:',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ...widget.teams.map((team) => _buildTeamChip(team)).toList(),
              const SizedBox(width: 8),
              _buildAllTeamsChip(),
            ],
          ),
        ],
      ),
    );
  }
  
  /// Build modern team selection chip with enhanced styling
  Widget _buildTeamChip(TeamModel team) {
    final bool isSelected = team == _selectedFilter;
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedFilter = team;
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            gradient: isSelected 
                ? LinearGradient(
                    colors: [team.color, team.color.withOpacity(0.8)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : LinearGradient(
                    colors: [Color(0xFF444444), Color(0xFF333333)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(25),
            border: Border.all(
              color: isSelected ? team.color.withOpacity(0.5) : Colors.grey[700]!,
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: isSelected 
                    ? team.color.withOpacity(0.3) 
                    : Colors.black.withOpacity(0.2),
                blurRadius: isSelected ? 6 : 3,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Text(
            team.name.split(' ').last,
            style: TextStyle(
              color: Colors.white,
              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              fontSize: 14,
              letterSpacing: 0.3,
            ),
          ),
        ),
      ),
    );
  }
  
  /// Build modern "All Teams" chip with enhanced styling
  Widget _buildAllTeamsChip() {
    final bool isSelected = _selectedFilter == null;
    
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedFilter = null;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: isSelected 
              ? LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [Color(0xFF444444), Color(0xFF333333)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: isSelected ? Color(0xFFFF9800).withOpacity(0.5) : Colors.grey[700]!,
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: isSelected 
                  ? Color(0xFFFF9800).withOpacity(0.3) 
                  : Colors.black.withOpacity(0.2),
              blurRadius: isSelected ? 6 : 3,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Text(
          'All',
          style: TextStyle(
            color: Colors.white,
            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
            fontSize: 14,
            letterSpacing: 0.3,
          ),
        ),
      ),
    );
  }
  
  /// Get color based on points
  Color _getPointColor(int points) {
    switch (points) {
      case 1:
        return Colors.orange[300]!;
      case 2:
        return Colors.orange[600]!;
      case 3:
        return Colors.deepOrange;
      default:
        return Colors.black;
    }
  }
  
  /// Get action name from GameActionType
  String _getActionName(GameActionType type) {
    switch (type) {
      case GameActionType.fieldGoal:
        return 'Field Goal';
      case GameActionType.threePointer:
        return '3-Pointer';
      case GameActionType.freeThrow:
        return 'Free Throw';
      case GameActionType.assist:
        return 'Assist';
      case GameActionType.rebound:
        return 'Rebound';
      case GameActionType.block:
        return 'Block';
      case GameActionType.steal:
        return 'Steal';
      case GameActionType.turnover:
        return 'Turnover';
      case GameActionType.foul:
        return 'Foul';
      default:
        return 'Action';
    }
  }
  
  /// Get action description from GameActionType
  String _getActionDescription(GameActionType type) {
    switch (type) {
      case GameActionType.fieldGoal:
        return 'Jump shot made';
      case GameActionType.threePointer:
        return 'Three point jump shot';
      case GameActionType.freeThrow:
        return 'Free throw made';
      case GameActionType.assist:
        return 'Assist';
      case GameActionType.rebound:
        return 'Rebound';
      case GameActionType.block:
        return 'Shot blocked';
      case GameActionType.steal:
        return 'Steal';
      case GameActionType.turnover:
        return 'Turnover';
      case GameActionType.foul:
        return 'Personal foul';
      default:
        return '';
    }
  }
}
