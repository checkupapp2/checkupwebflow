import 'package:flutter/material.dart';
import '../../domain/models/team_model.dart';
import '../../domain/models/player_model.dart';
import '../../domain/models/game_action_model.dart';

/// Stats tab for displaying team and player statistics
class StatsTab extends StatelessWidget {
  /// List of teams
  final List<TeamModel> teams;

  /// Currently selected team
  final TeamModel selectedTeam;

  /// Game actions to analyze for stats
  final List<GameActionModel> gameActions;

  /// Callback when team is selected
  final Function(TeamModel)? onTeamSelected;

  /// Constructor
  const StatsTab({
    Key? key,
    required this.teams,
    required this.selectedTeam,
    required this.gameActions,
    this.onTeamSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Team selector
        _buildTeamSelector(),

        // Stats content
        Expanded(
          child: _buildStatsContent(),
        ),
      ],
    );
  }

  Widget _buildTeamSelector() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFFF9800).withOpacity(0.3),
            width: 2,
          ),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                Icons.analytics,
                color: Color(0xFFFF9800),
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Team Statistics:',
                style: TextStyle(
                  color: Color(0xFFFF9800),
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: teams.map((team) {
              final isSelected = team == selectedTeam;
              return GestureDetector(
                onTap: () {
                  if (onTeamSelected != null && !isSelected) {
                    onTeamSelected!(team);
                  }
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 6),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: isSelected
                        ? LinearGradient(
                            colors: [
                              Color(0xFFFF9800),
                              Color(0xFFE55A00),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : LinearGradient(
                            colors: [
                              Color(0xFF333333),
                              Color(0xFF2A2A2A),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                    borderRadius: BorderRadius.circular(25),
                    border: Border.all(
                      color: isSelected
                          ? Colors.white.withOpacity(0.3)
                          : team.color.withOpacity(0.5),
                      width: isSelected ? 2 : 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isSelected
                            ? Color(0xFFFF9800).withOpacity(0.3)
                            : Colors.black.withOpacity(0.2),
                        blurRadius: isSelected ? 8 : 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: team.color,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: team.color.withOpacity(0.4),
                              blurRadius: 4,
                              offset: Offset(0, 1),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        team.name,
                        style: TextStyle(
                          color: isSelected ? Colors.white : Colors.white70,
                          fontWeight:
                              isSelected ? FontWeight.w700 : FontWeight.w500,
                          fontSize: 14,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsContent() {
    // Create player stats based on available players
    final Map<String, _PlayerStats> playerStatsMap = {};

    // Initialize stats for all players on the selected team
    for (final player in selectedTeam.players) {
      playerStatsMap[player.id] = _PlayerStats(
        player: player,
        points: player.points, // Points are already tracked in the player model
        assists: 0,
        rebounds: 0,
        steals: 0,
        blocks: 0,
        fouls: 0,
      );
    }

    // Calculate stats from game actions
    for (final action in gameActions) {
      // Only process actions for the selected team
      if (action.teamId == selectedTeam.name) {
        // Find the player stats
        final playerStats = playerStatsMap[action.playerId];
        if (playerStats != null) {
          switch (action.type) {
            case GameActionType.assist:
              playerStats.assists++;
              break;
            case GameActionType.rebound:
              playerStats.rebounds++;
              break;
            case GameActionType.steal:
              playerStats.steals++;
              break;
            case GameActionType.block:
              playerStats.blocks++;
              break;
            case GameActionType.foul:
              playerStats.fouls++;
              break;
            // Points are already tracked in the player model
            default:
              break;
          }
        }
      }
    }

    // Convert map to list for display
    final List<_PlayerStats> playerStats = playerStatsMap.values.toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Team stats summary
          _buildTeamStatsSummary(playerStats),

          const SizedBox(height: 24),

          // Player stats table
          _buildPlayerStatsTable(playerStats),
        ],
      ),
    );
  }

  Widget _buildTeamStatsSummary(List<_PlayerStats> playerStats) {
    // Calculate team totals
    int totalPoints = 0;
    int totalAssists = 0;
    int totalRebounds = 0;
    int totalSteals = 0;
    int totalBlocks = 0;
    int totalFouls = 0;

    for (final stats in playerStats) {
      totalPoints += stats.points;
      totalAssists += stats.assists;
      totalRebounds += stats.rebounds;
      totalSteals += stats.steals;
      totalBlocks += stats.blocks;
      totalFouls += stats.fouls;
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Color(0xFFFF9800).withOpacity(0.3),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 12,
            offset: Offset(0, 6),
          ),
          BoxShadow(
            color: Color(0xFFFF9800).withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with icon
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFE55A00)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.sports_basketball,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                '${selectedTeam.name} Team Stats',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 18,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Stats grid with enhanced design
          Row(
            children: [
              Expanded(child: _buildStatItem('PTS', totalPoints, true)),
              const SizedBox(width: 12),
              Expanded(child: _buildStatItem('AST', totalAssists, false)),
              const SizedBox(width: 12),
              Expanded(child: _buildStatItem('REB', totalRebounds, false)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _buildStatItem('STL', totalSteals, false)),
              const SizedBox(width: 12),
              Expanded(child: _buildStatItem('BLK', totalBlocks, false)),
              const SizedBox(width: 12),
              Expanded(child: _buildStatItem('FLS', totalFouls, false)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, int value, bool isPrimary) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      decoration: BoxDecoration(
        gradient: isPrimary
            ? LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFE55A00)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : LinearGradient(
                colors: [Color(0xFF333333), Color(0xFF2A2A2A)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isPrimary ? Colors.white.withOpacity(0.3) : Colors.grey[700]!,
          width: isPrimary ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: isPrimary
                ? Color(0xFFFF9800).withOpacity(0.3)
                : Colors.black.withOpacity(0.2),
            blurRadius: isPrimary ? 8 : 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            value.toString(),
            style: TextStyle(
              color: isPrimary ? Colors.white : Colors.white70,
              fontWeight: FontWeight.w800,
              fontSize: isPrimary ? 28 : 24,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              color:
                  isPrimary ? Colors.white.withOpacity(0.9) : Colors.grey[400],
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlayerStatsTable(List<_PlayerStats> playerStats) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Player Stats',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color(0xFF333333),
              width: 1,
            ),
          ),
          child: Column(
            children: [
              // Table header
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                decoration: const BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Color(0xFF333333), width: 1),
                  ),
                ),
                child: Row(
                  children: [
                    const Expanded(
                      flex: 3,
                      child: Text(
                        'PLAYER',
                        style: TextStyle(
                          color: Colors.grey,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    ...['PTS', 'AST', 'REB', 'STL', 'BLK', 'FLS'].map((header) {
                      return Expanded(
                        child: Text(
                          header,
                          style: const TextStyle(
                            color: Colors.grey,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      );
                    }).toList(),
                  ],
                ),
              ),

              // Table rows
              ...playerStats.map((stats) {
                return Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: Color(0xFF333333), width: 1),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Row(
                          children: [
                            Container(
                              width: 30,
                              height: 30,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: selectedTeam.color.withOpacity(0.2),
                              ),
                              child: Center(
                                child: Text(
                                  stats.player.number.toString(),
                                  style: TextStyle(
                                    color: selectedTeam.color,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                stats.player.name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Text(
                          stats.points.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          stats.assists.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          stats.rebounds.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          stats.steals.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          stats.blocks.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          stats.fouls.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ],
          ),
        ),
      ],
    );
  }
}

/// Helper class for player statistics
class _PlayerStats {
  final PlayerModel player;
  int points;
  int assists;
  int rebounds;
  int steals;
  int blocks;
  int fouls;

  _PlayerStats({
    required this.player,
    required this.points,
    required this.assists,
    required this.rebounds,
    required this.steals,
    required this.blocks,
    required this.fouls,
  });
}
