import 'package:flutter/material.dart';
import '../domain/models/team_model.dart';
import '../domain/models/player_model.dart';
import 'scoreboard_screen.dart';

class TeamSelectionPage extends StatefulWidget {
  final List<TeamModel> currentTeams;
  final int? teamToReplaceIndex;
  final bool returnTeamsOnly;

  const TeamSelectionPage({
    Key? key,
    required this.currentTeams,
    this.teamToReplaceIndex,
    this.returnTeamsOnly = false,
  }) : super(key: key);

  @override
  _TeamSelectionPageState createState() => _TeamSelectionPageState();
}

class _TeamSelectionPageState extends State<TeamSelectionPage>
    with SingleTickerProviderStateMixin {
  // Demo teams for selection with realistic rosters
  final List<TeamModel> _allTeams = [
    TeamModel(name: 'Chicago Bulls', color: Colors.red, players: [
      PlayerModel(
          id: '1',
          name: 'DeMar DeRozan',
          number: 11,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=demar'),
      PlayerModel(
          id: '2',
          name: 'Zach LaVine',
          number: 8,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=zach'),
      PlayerModel(
          id: '3',
          name: 'Nikola Vucevic',
          number: 9,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=nikola'),
      PlayerModel(
          id: '4',
          name: 'Coby White',
          number: 0,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=coby'),
      PlayerModel(
          id: '5',
          name: 'Patrick Williams',
          number: 44,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=patrick'),
      PlayerModel(
          id: '6',
          name: 'Alex Caruso',
          number: 6,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=alex'),
    ]),
    TeamModel(name: 'Lakers', color: Colors.purple, players: [
      PlayerModel(
          id: '7',
          name: 'LeBron James',
          number: 23,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=lebron'),
      PlayerModel(
          id: '8',
          name: 'Anthony Davis',
          number: 3,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=anthony'),
      PlayerModel(
          id: '9',
          name: 'Russell Westbrook',
          number: 0,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=russell'),
      PlayerModel(
          id: '10',
          name: 'Austin Reaves',
          number: 15,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=austin'),
      PlayerModel(
          id: '11',
          name: 'Christian Wood',
          number: 35,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=christian'),
      PlayerModel(
          id: '12',
          name: 'D\'Angelo Russell',
          number: 1,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=dangelo'),
    ]),
    TeamModel(name: 'Celtics', color: Colors.green, players: [
      PlayerModel(
          id: '13',
          name: 'Jayson Tatum',
          number: 0,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=jayson'),
      PlayerModel(
          id: '14',
          name: 'Jaylen Brown',
          number: 7,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=jaylen'),
      PlayerModel(
          id: '15',
          name: 'Marcus Smart',
          number: 36,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=marcus'),
      PlayerModel(
          id: '16',
          name: 'Robert Williams',
          number: 44,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=robert'),
      PlayerModel(
          id: '17',
          name: 'Al Horford',
          number: 42,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=al'),
      PlayerModel(
          id: '18',
          name: 'Malcolm Brogdon',
          number: 13,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=malcolm'),
    ]),
    TeamModel(name: 'Warriors', color: Colors.blue, players: [
      PlayerModel(
          id: '19',
          name: 'Stephen Curry',
          number: 30,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=stephen'),
      PlayerModel(
          id: '20',
          name: 'Klay Thompson',
          number: 11,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=klay'),
      PlayerModel(
          id: '21',
          name: 'Draymond Green',
          number: 23,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=draymond'),
      PlayerModel(
          id: '22',
          name: 'Andrew Wiggins',
          number: 22,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=andrew'),
      PlayerModel(
          id: '23',
          name: 'Kevon Looney',
          number: 5,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=kevon'),
      PlayerModel(
          id: '24',
          name: 'Jordan Poole',
          number: 3,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=jordan'),
    ]),
    TeamModel(name: 'Heat', color: Colors.orange, players: [
      PlayerModel(
          id: '25',
          name: 'Jimmy Butler',
          number: 22,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=jimmy'),
      PlayerModel(
          id: '26',
          name: 'Bam Adebayo',
          number: 13,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=bam'),
      PlayerModel(
          id: '27',
          name: 'Tyler Herro',
          number: 14,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=tyler'),
      PlayerModel(
          id: '28',
          name: 'Kyle Lowry',
          number: 7,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=kyle'),
      PlayerModel(
          id: '29',
          name: 'Kevin Love',
          number: 42,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=kevin'),
      PlayerModel(
          id: '30',
          name: 'Duncan Robinson',
          number: 55,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=duncan'),
    ]),
    TeamModel(name: 'Rockets', color: Colors.red.shade700, players: [
      PlayerModel(
          id: '31',
          name: 'Alperen Sengun',
          number: 28,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=alperen'),
      PlayerModel(
          id: '32',
          name: 'Jalen Green',
          number: 4,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=jalen'),
      PlayerModel(
          id: '33',
          name: 'Jabari Smith Jr.',
          number: 1,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=jabari'),
      PlayerModel(
          id: '34',
          name: 'Kevin Porter Jr.',
          number: 3,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=kevinp'),
      PlayerModel(
          id: '35',
          name: 'Tari Eason',
          number: 8,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=tari'),
      PlayerModel(
          id: '36',
          name: 'Usman Garuba',
          number: 15,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=usman'),
    ]),
    TeamModel(name: 'Spurs', color: Colors.grey.shade800, players: [
      PlayerModel(
          id: '37',
          name: 'Victor Wembanyama',
          number: 1,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=victor'),
      PlayerModel(
          id: '38',
          name: 'Devin Vassell',
          number: 24,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=devin'),
      PlayerModel(
          id: '39',
          name: 'Keldon Johnson',
          number: 3,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=keldon'),
      PlayerModel(
          id: '40',
          name: 'Tre Jones',
          number: 33,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=tre'),
      PlayerModel(
          id: '41',
          name: 'Jeremy Sochan',
          number: 10,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=jeremy'),
      PlayerModel(
          id: '42',
          name: 'Malaki Branham',
          number: 22,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=malaki'),
    ]),
    TeamModel(name: 'Mavericks', color: Colors.blue.shade800, players: [
      PlayerModel(
          id: '43',
          name: 'Luka Doncic',
          number: 77,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=luka'),
      PlayerModel(
          id: '44',
          name: 'Kyrie Irving',
          number: 2,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=kyrie'),
      PlayerModel(
          id: '45',
          name: 'Christian Wood',
          number: 35,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=christianw'),
      PlayerModel(
          id: '46',
          name: 'Tim Hardaway Jr.',
          number: 11,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=tim'),
      PlayerModel(
          id: '47',
          name: 'Dwight Powell',
          number: 7,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=dwight'),
      PlayerModel(
          id: '48',
          name: 'Josh Green',
          number: 8,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=josh'),
    ]),
    TeamModel(name: 'Nets', color: Colors.black, players: [
      PlayerModel(
          id: '49',
          name: 'Mikal Bridges',
          number: 1,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=mikal'),
      PlayerModel(
          id: '50',
          name: 'Cam Thomas',
          number: 24,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=cam'),
      PlayerModel(
          id: '51',
          name: 'Nic Claxton',
          number: 33,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=nic'),
      PlayerModel(
          id: '52',
          name: 'Spencer Dinwiddie',
          number: 8,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=spencer'),
      PlayerModel(
          id: '53',
          name: 'Dorian Finney-Smith',
          number: 28,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=dorian'),
      PlayerModel(
          id: '54',
          name: 'Dennis Smith Jr.',
          number: 4,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=dennis'),
    ]),
    TeamModel(name: 'Knicks', color: Colors.blue.shade900, players: [
      PlayerModel(
          id: '55',
          name: 'Julius Randle',
          number: 30,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=julius'),
      PlayerModel(
          id: '56',
          name: 'RJ Barrett',
          number: 9,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=rj'),
      PlayerModel(
          id: '57',
          name: 'Jalen Brunson',
          number: 11,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=jalenbr'),
      PlayerModel(
          id: '58',
          name: 'Mitchell Robinson',
          number: 23,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=mitchell'),
      PlayerModel(
          id: '59',
          name: 'Quentin Grimes',
          number: 6,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=quentin'),
      PlayerModel(
          id: '60',
          name: 'Isaiah Hartenstein',
          number: 55,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=isaiah'),
    ]),
    TeamModel(name: 'Clippers', color: Colors.red.shade900, players: [
      PlayerModel(
          id: '61',
          name: 'Kawhi Leonard',
          number: 2,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=kawhi'),
      PlayerModel(
          id: '62',
          name: 'Paul George',
          number: 13,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=paul'),
      PlayerModel(
          id: '63',
          name: 'Russell Westbrook',
          number: 0,
          position: 'PG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=russellw'),
      PlayerModel(
          id: '64',
          name: 'Ivica Zubac',
          number: 40,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=ivica'),
      PlayerModel(
          id: '65',
          name: 'Marcus Morris Sr.',
          number: 8,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=marcusm'),
      PlayerModel(
          id: '66',
          name: 'Norman Powell',
          number: 24,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=norman'),
    ]),
    TeamModel(name: 'Suns', color: Colors.deepOrange, players: [
      PlayerModel(
          id: '67',
          name: 'Devin Booker',
          number: 1,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=devinb'),
      PlayerModel(
          id: '68',
          name: 'Kevin Durant',
          number: 35,
          position: 'SF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=kevind'),
      PlayerModel(
          id: '69',
          name: 'Bradley Beal',
          number: 3,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=bradley'),
      PlayerModel(
          id: '70',
          name: 'Jusuf Nurkic',
          number: 20,
          position: 'C',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=jusuf'),
      PlayerModel(
          id: '71',
          name: 'Grayson Allen',
          number: 8,
          position: 'SG',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=grayson'),
      PlayerModel(
          id: '72',
          name: 'Drew Eubanks',
          number: 14,
          position: 'PF',
          points: 0,
          photoUrl: 'https://i.pravatar.cc/150?u=drew'),
    ]),
  ];

  // Demo my teams - in a real app, this would be user-specific
  List<TeamModel> get _myTeams => [
        _allTeams.firstWhere((team) => team.name == 'Chicago Bulls'),
        _allTeams.firstWhere((team) => team.name == 'Lakers'),
      ];

  // Demo favorite teams - in a real app, this would be user-specific
  List<TeamModel> get _favoriteTeams => [
        _allTeams.firstWhere((team) => team.name == 'Chicago Bulls'),
        _allTeams.firstWhere((team) => team.name == 'Warriors'),
        _allTeams.firstWhere((team) => team.name == 'Heat'),
      ];

  late TabController _tabController;
  String _searchQuery = '';
  Set<String> _selectedTeams = {}; // Track selected teams by name
  static const int _maxTeams = 2;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    final isReplacing = widget.teamToReplaceIndex != null;
    final pageTitle = isReplacing ? 'Replace Team' : 'Choose Team';

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A1A1A),
        elevation: 0,
        title: Text(
          pageTitle,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          // Modern Tab Bar
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF2A2A2A),
              borderRadius: BorderRadius.circular(25),
            ),
            child: Row(
              children: [
                _buildTabButton('All Teams', 0),
                _buildTabButton('My Teams', 1),
                _buildTabButton('Favorites', 2),
              ],
            ),
          ),

          // Search bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A2A),
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextField(
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Search teams...',
                  hintStyle: TextStyle(color: Colors.grey.shade400),
                  prefixIcon: const Icon(Icons.search, color: Colors.grey),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 16),
                ),
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value;
                  });
                },
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Team lists in tabs
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // All Teams Tab
                _buildTeamList(_getFilteredTeams(_allTeams)),

                // My Teams Tab
                _buildTeamList(_getFilteredTeams(_myTeams)),

                // Favorites Tab
                _buildTeamList(_getFilteredTeams(_favoriteTeams)),
              ],
            ),
          ),

          // Continue Button
          if (_selectedTeams.length == _maxTeams)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.all(16),
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF9800).withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: () {
                    // Get selected teams
                    final selectedTeamModels = _allTeams
                        .where((team) => _selectedTeams.contains(team.name))
                        .toList();

                    if (widget.returnTeamsOnly) {
                      // Return teams to settings page
                      Navigator.pop(context, selectedTeamModels);
                    } else {
                      // Navigate to scoreboard page with selected teams
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ScoreboardScreen(
                            teams: selectedTeamModels,
                          ),
                        ),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                    shadowColor: Colors.transparent,
                  ),
                  child: Text(
                    'Start Game with $_maxTeams teams',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // Helper method to build modern tab buttons
  Widget _buildTabButton(String title, int index) {
    final isSelected = _tabController.index == index;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _tabController.animateTo(index);
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          decoration: BoxDecoration(
            gradient: isSelected
                ? const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  )
                : null,
            color: isSelected ? null : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
            boxShadow: isSelected
                ? [
                    BoxShadow(
                      color: const Color(0xFFFF9800).withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : [],
          ),
          child: Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.grey,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }

  // Helper method to filter teams based on search query
  List<TeamModel> _getFilteredTeams(List<TeamModel> teams) {
    if (_searchQuery.isEmpty) {
      return teams;
    }
    return teams
        .where((team) =>
            team.name.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();
  }

  // Helper method to build a team list
  Widget _buildTeamList(List<TeamModel> teams) {
    return teams.isEmpty
        ? const Center(
            child: Text(
              'No teams found',
              style: TextStyle(color: Colors.grey, fontSize: 16),
            ),
          )
        : ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: teams.length,
            itemBuilder: (context, index) {
              final team = teams[index];
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        if (_selectedTeams.contains(team.name)) {
                          _selectedTeams.remove(team.name);
                        } else if (_selectedTeams.length < _maxTeams) {
                          _selectedTeams.add(team.name);
                        }
                      });
                    },
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: const Color(0xFF222222),
                        border: Border.all(
                          color: _selectedTeams.contains(team.name)
                              ? const Color(0xFFFF9800)
                              : team.color.withOpacity(0.3),
                          width: _selectedTeams.contains(team.name) ? 2 : 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          // Team color indicator
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: team.color,
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                team.name.substring(0, 1),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),
                          // Team name
                          Expanded(
                            child: Text(
                              team.name,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          // Selection indicator
                          Container(
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _selectedTeams.contains(team.name)
                                  ? const Color(0xFFFF9800)
                                  : Colors.transparent,
                              border: Border.all(
                                color: _selectedTeams.contains(team.name)
                                    ? const Color(0xFFFF9800)
                                    : Colors.grey,
                                width: 2,
                              ),
                            ),
                            child: _selectedTeams.contains(team.name)
                                ? const Icon(
                                    Icons.check,
                                    color: Colors.white,
                                    size: 16,
                                  )
                                : null,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          );
  }
}
