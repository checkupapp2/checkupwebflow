import 'package:flutter/material.dart';
import '../domain/models/team_model.dart';
import '../domain/models/player_model.dart';
import '../domain/models/game_action_model.dart';

/// Provider class for scoreboard data
class ScoreboardDataProvider {
  /// Get mock teams for the scoreboard
  List<TeamModel> getMockTeams() {
    return [
      TeamModel(
        name: 'Maine Blizzard',
        color: Colors.blue,
        score: 4,
        players: [
          PlayerModel(
            id: '1',
            name: 'Ava Russell',
            number: 8,
            photoUrl: 'assets/images/profile1.jpg',
            position: 'G',
          ),
          PlayerModel(
            id: '2',
            name: 'Kayla Patterson',
            number: 5,
            position: 'F',
          ),
          PlayerModel(
            id: '3',
            name: 'Naomi Stewart',
            number: 13,
            position: 'C',
          ),
          PlayerModel(
            id: '4',
            name: 'Kerri Nguyen',
            number: 22,
            position: 'G',
          ),
          PlayerModel(
            id: '5',
            name: 'Skylar Carr',
            number: 31,
            position: 'F',
          ),
          PlayerModel(
            id: '6',
            name: 'Sophia Olson',
            number: 35,
            position: 'C',
          ),
        ],
      ),
      TeamModel(
        name: 'Smithfield Sharks',
        color: Colors.orange,
        score: 12,
        players: [
          PlayerModel(
            id: '7',
            name: 'Nicole Ferguson',
            number: 10,
            position: 'G',
          ),
          PlayerModel(
            id: '8',
            name: 'Ellie Miller',
            number: 20,
            position: 'F',
          ),
          PlayerModel(
            id: '9',
            name: 'Joan Chang',
            number: 21,
            position: 'C',
          ),
          PlayerModel(
            id: '10',
            name: 'Maria Cruz',
            number: 23,
            position: 'G',
          ),
          PlayerModel(
            id: '11',
            name: 'Breanna Barnes',
            number: 30,
            position: 'F',
          ),
          PlayerModel(
            id: '12',
            name: 'Gabriella Lopez',
            number: 44,
            position: 'C',
          ),
        ],
      ),
    ];
  }

  /// Get the current period
  int getCurrentPeriod() {
    return 1;
  }

  /// Get default teams with generic players for a fresh game start
  List<TeamModel> getDefaultTeams() {
    return [
      TeamModel(
        name: 'Home',
        color: Colors.blue,
        score: 0, // Start with zero score
        players: List.generate(
          5,
          (index) => PlayerModel(
            id: 'home_$index',
            name: 'Player #${index + 1}',
            number: index + 1,
            position: index == 0
                ? 'G'
                : index == 1
                    ? 'G'
                    : index == 2
                        ? 'F'
                        : index == 3
                            ? 'F'
                            : 'C',
            points: 0, // Explicitly set points to zero
          ),
        ),
      ),
      TeamModel(
        name: 'Away',
        color: Colors.red,
        score: 0, // Start with zero score
        players: List.generate(
          5,
          (index) => PlayerModel(
            id: 'away_$index',
            name: 'Player #${index + 1}',
            number: index + 1,
            position: index == 0
                ? 'G'
                : index == 1
                    ? 'G'
                    : index == 2
                        ? 'F'
                        : index == 3
                            ? 'F'
                            : 'C',
            points: 0, // Explicitly set points to zero
          ),
        ),
      ),
    ];
  }

  /// Get recent game actions for existing games
  List<GameActionModel> getRecentActions() {
    return [
      GameActionModel(
        id: '1',
        type: GameActionType.threePointer,
        playerId: '1', // Ava Russell
        teamId: 'Maine Blizzard',
        period: 1,
        timestamp: DateTime.now().subtract(const Duration(minutes: 2)),
      ),
      GameActionModel(
        id: '2',
        type: GameActionType.assist,
        playerId: '10', // Maria Cruz
        teamId: 'Smithfield Sharks',
        period: 1,
        timestamp: DateTime.now().subtract(const Duration(minutes: 3)),
      ),
      GameActionModel(
        id: '3',
        type: GameActionType.fieldGoal,
        playerId: '7', // Nicole Ferguson
        assistedByPlayerId: '10', // Maria Cruz
        teamId: 'Smithfield Sharks',
        period: 1,
        timestamp: DateTime.now().subtract(const Duration(minutes: 3)),
      ),
    ];
  }

  /// Get empty game actions for a fresh Quick Play game
  List<GameActionModel> getEmptyGameActions() {
    // Return an empty list for a fresh game start
    return [];
  }

  /// Get empty teams for manual team setup
  List<TeamModel> getEmptyTeams() {
    return [
      TeamModel(
        name: 'Team 1',
        color: Colors.blue,
        score: 0,
        players: [],
      ),
      TeamModel(
        name: 'Team 2',
        color: Colors.red,
        score: 0,
        players: [],
      ),
    ];
  }
}
