import 'package:flutter/material.dart';
import '../../domain/models/bracket_match_model.dart';
import '../../domain/models/bracket_model.dart';

/// Widget to display the championship pick at the top of the bracket detail page
class ChampionshipPickCard extends StatelessWidget {
  /// The bracket model
  final BracketModel bracket;
  
  /// The championship match
  final BracketMatchModel? championshipMatch;
  
  /// Constructor
  const ChampionshipPickCard({
    Key? key,
    required this.bracket,
    this.championshipMatch,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(16),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      clipBehavior: Clip.antiAlias,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: _getBackgroundColors(),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildHeader(),
            if (championshipMatch != null && (championshipMatch!.score1 != null || championshipMatch!.score2 != null))
              _buildChampionshipScore(championshipMatch!.score1 ?? 0, championshipMatch!.score2 ?? 0),
            _buildPickSection(),
            if (championshipMatch != null)
              _buildMatchInfo(),
          ],
        ),
      ),
    );
  }

  /// Build the header section
  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
        ),
      ),
      child: const Center(
        child: Text(
          'MY CHAMPIONSHIP PICK',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
            letterSpacing: 1.2,
          ),
        ),
      ),
    );
  }

  /// Build the championship score section
  Widget _buildChampionshipScore(int score1, int score2) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            '$score1',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 24,
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Text(
              '-',
              style: TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
          ),
          Text(
            '$score2',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 24,
            ),
          ),
        ],
      ),
    );
  }

  /// Build the pick section
  Widget _buildPickSection() {
    final userPick = bracket.userChampionPick;
    final actualChampion = bracket.actualChampion;
    
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          if (userPick != null)
            _buildTeamDisplay(
              team: userPick,
              isCorrectPick: actualChampion != null && userPick.id == actualChampion.id,
              isWrongPick: actualChampion != null && userPick.id != actualChampion.id,
              isUserPick: true,
            ),
          if (actualChampion != null && userPick?.id != actualChampion.id)
            Column(
              children: [
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Text(
                    'ACTUAL CHAMPION',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
                _buildTeamDisplay(
                  team: actualChampion,
                  isCorrectPick: false,
                  isWrongPick: false,
                  isUserPick: false,
                ),
              ],
            ),
        ],
      ),
    );
  }

  /// Build team display
  Widget _buildTeamDisplay({
    required BracketTeamModel team,
    required bool isCorrectPick,
    required bool isWrongPick,
    required bool isUserPick,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black26,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isCorrectPick
              ? Colors.green
              : isWrongPick
                  ? Colors.red
                  : Colors.transparent,
          width: 2,
        ),
      ),
      child: Row(
        children: [
          // Team logo
          if (team.logoUrl != null)
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                  image: NetworkImage(team.logoUrl!),
                  fit: BoxFit.cover,
                ),
              ),
            )
          else
            Container(
              width: 60,
              height: 60,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black38,
              ),
              child: const Icon(Icons.sports_basketball, size: 36, color: Colors.white54),
            ),
          const SizedBox(width: 16),
          
          // Team info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  team.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                if (team.record != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      team.record!,
                      style: const TextStyle(color: Colors.white70, fontSize: 14),
                    ),
                  ),
              ],
            ),
          ),
          
          // Status indicator
          if (isCorrectPick || isWrongPick)
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isCorrectPick ? Colors.green : Colors.red,
              ),
              child: Icon(
                isCorrectPick ? Icons.check : Icons.close,
                color: Colors.white,
                size: 24,
              ),
            ),
        ],
      ),
    );
  }

  /// Build match information (date, time, location)
  Widget _buildMatchInfo() {
    if (championshipMatch?.matchTime == null) return const SizedBox.shrink();
    
    final dateFormat = championshipMatch!.matchTime!.year == DateTime.now().year
        ? '${_getMonthAbbr(championshipMatch!.matchTime!.month)} ${championshipMatch!.matchTime!.day}'
        : '${_getMonthAbbr(championshipMatch!.matchTime!.month)} ${championshipMatch!.matchTime!.day}, ${championshipMatch!.matchTime!.year}';
    
    final timeStr = '${championshipMatch!.matchTime!.hour > 12 ? championshipMatch!.matchTime!.hour - 12 : championshipMatch!.matchTime!.hour}:${championshipMatch!.matchTime!.minute.toString().padLeft(2, '0')} ${championshipMatch!.matchTime!.hour >= 12 ? 'PM' : 'AM'}';
    
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black26,
      ),
      child: Column(
        children: [
          Text(
            championshipMatch!.isCompleted ? 'Final' : '$dateFormat $timeStr',
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
          if (championshipMatch!.location != null && !championshipMatch!.isCompleted)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                championshipMatch!.location!,
                style: const TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ),
        ],
      ),
    );
  }

  /// Get background colors
  List<Color> _getBackgroundColors() {
    return [const Color(0xFF1A1A1A), const Color(0xFF000000)];
  }
  
  /// Get month abbreviation
  String _getMonthAbbr(int month) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return months[month - 1];
  }
}
