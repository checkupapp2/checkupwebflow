import 'package:flutter/material.dart';
import '../../domain/models/bracket_round_model.dart';
import 'bracket_match_card.dart';

/// Widget to display a column of matches for a specific round
class BracketRoundColumn extends StatelessWidget {
  /// The round to display
  final BracketRoundModel round;

  /// Callback when a match is tapped
  final Function(String matchId)? onMatchTap;

  /// Currently selected match ID
  final String? selectedMatchId;

  /// Constructor
  const BracketRoundColumn({
    Key? key,
    required this.round,
    this.onMatchTap,
    this.selectedMatchId,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: _buildMatchesList(),
        ),
      ],
    );
  }

  /// Build the round header
  Widget _buildRoundHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1F1F1F), Color(0xFF121212)],
        ),
        border: Border(
          bottom: BorderSide(
              color: const Color(0xFFFF9800).withOpacity(0.6), width: 2),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                round.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  letterSpacing: 0.5,
                ),
              ),
              if (round.startDate != null)
                Text(
                  _getDateRangeString(),
                  style: TextStyle(
                    color: const Color(0xFFFF9800).withOpacity(0.9),
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF5722).withOpacity(0.4),
                  blurRadius: 4,
                  spreadRadius: 0,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Text(
              '${round.matches.length} matches',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Build the list of matches
  Widget _buildMatchesList() {
    // Sort matches by match number
    final sortedMatches = [...round.matches];
    sortedMatches.sort((a, b) => a.matchNumber.compareTo(b.matchNumber));

    if (sortedMatches.isEmpty) {
      return Center(
        child: Container(
          padding: const EdgeInsets.all(20),
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1F1F1F), Color(0xFF121212)],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
                color: const Color(0xFFFF9800).withOpacity(0.4), width: 1),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(
                Icons.sports_basketball,
                size: 40,
                color: Color(0xFFFF5722),
              ),
              SizedBox(height: 12),
              Text(
                'No matches in this round',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      itemCount: sortedMatches.length,
      itemBuilder: (context, index) {
        final match = sortedMatches[index];
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: selectedMatchId == match.id
                    ? const Color(0xFFFF5722).withOpacity(0.4)
                    : Colors.black.withOpacity(0.2),
                blurRadius: 6,
                spreadRadius: 1,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: BracketMatchCard(
            match: match,
            isHighlighted: selectedMatchId == match.id,
            onTap: onMatchTap != null ? () => onMatchTap!(match.id) : null,
          ),
        );
      },
    );
  }

  /// Get date range string for the round
  String _getDateRangeString() {
    if (round.startDate == null) return '';

    final startMonth = _getMonthAbbr(round.startDate!.month);
    final startDay = round.startDate!.day;

    if (round.endDate == null || round.startDate!.day == round.endDate!.day) {
      return '$startMonth $startDay';
    }

    final endMonth = _getMonthAbbr(round.endDate!.month);
    final endDay = round.endDate!.day;

    if (startMonth == endMonth) {
      return '$startMonth $startDay - $endDay';
    }

    return '$startMonth $startDay - $endMonth $endDay';
  }

  /// Get month abbreviation
  String _getMonthAbbr(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }
}
