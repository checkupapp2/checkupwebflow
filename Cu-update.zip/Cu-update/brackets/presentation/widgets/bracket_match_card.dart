import 'package:flutter/material.dart';
import '../../domain/models/bracket_match_model.dart';

/// Widget to display a match in a tournament bracket
class BracketMatchCard extends StatelessWidget {
  /// The match to display
  final BracketMatchModel match;

  /// Whether this match is highlighted
  final bool isHighlighted;

  /// Callback when the match is tapped
  final VoidCallback? onTap;

  /// Constructor
  const BracketMatchCard({
    Key? key,
    required this.match,
    this.isHighlighted = false,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      elevation: isHighlighted ? 8 : 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: _getBackgroundColors(),
            ),
            border: isHighlighted
                ? Border.all(color: const Color(0xFFFF9800), width: 2)
                : null,
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildTeamRow(match.team1, match.team1Score, isTeam1: true),
                const Divider(height: 2, thickness: 1, color: Colors.white24),
                _buildTeamRow(match.team2, match.team2Score, isTeam1: false),
                if (match.scheduledTime != null) _buildMatchInfo(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Build a row for a team in the match
  Widget _buildTeamRow(BracketTeamModel? team, int? score,
      {required bool isTeam1}) {
    final bool isWinner = match.isCompleted && match.winnerId == team?.id;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          // Seed number
          if (team != null)
            Container(
              width: 24,
              height: 24,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                '${team.seed}',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            )
          else
            Container(
              width: 24,
              height: 24,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.black38,
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                '?',
                style: TextStyle(
                  color: Colors.white54,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          const SizedBox(width: 8),

          // Team logo
          if (team?.logoUrl != null)
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                  image: NetworkImage(team!.logoUrl!),
                  fit: BoxFit.cover,
                ),
              ),
            )
          else
            Container(
              width: 24,
              height: 24,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black38,
              ),
              child: const Icon(Icons.sports_basketball,
                  size: 16, color: Colors.white54),
            ),
          const SizedBox(width: 8),

          // Team name
          Expanded(
            child: Text(
              team?.name ?? 'TBD',
              style: TextStyle(
                color: Colors.white,
                fontWeight: isWinner ? FontWeight.bold : FontWeight.normal,
                fontSize: 14,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),

          // Winner indicator (only show for completed matches)
          if (match.isCompleted && isWinner)
            Container(
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.8),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: Colors.green, width: 1),
              ),
              child: const Icon(
                Icons.emoji_events,
                color: Colors.white,
                size: 14,
              ),
            ),

          // Score
          Container(
            width: 32,
            alignment: Alignment.center,
            child: Text(
              score != null ? score.toString() : '',
              style: TextStyle(
                color: isWinner ? Colors.white : Colors.white70,
                fontWeight: isWinner ? FontWeight.bold : FontWeight.normal,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Build match information (date, time, location)
  Widget _buildMatchInfo() {
    final dateStr = match.scheduledTime!.year == DateTime.now().year
        ? '${_getMonthAbbr(match.scheduledTime!.month)} ${match.scheduledTime!.day}'
        : '${_getMonthAbbr(match.scheduledTime!.month)} ${match.scheduledTime!.day}, ${match.scheduledTime!.year}';

    final timeStr =
        '${match.scheduledTime!.hour > 12 ? match.scheduledTime!.hour - 12 : match.scheduledTime!.hour}:${match.scheduledTime!.minute.toString().padLeft(2, '0')} ${match.scheduledTime!.hour >= 12 ? 'PM' : 'AM'}';

    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (match.isCompleted)
            const Text(
              'Final',
              style: TextStyle(color: Colors.white70, fontSize: 12),
            )
          else
            Text(
              '$dateStr $timeStr',
              style: const TextStyle(color: Colors.white70, fontSize: 12),
            ),
          if (match.location != null && !match.isCompleted) ...[
            const Text(' • ',
                style: TextStyle(color: Colors.white70, fontSize: 12)),
            Text(
              match.location!,
              style: const TextStyle(color: Colors.white70, fontSize: 12),
              overflow: TextOverflow.ellipsis,
            ),
          ],
          if (match.pointsEarned != null && match.pointsEarned! > 0) ...[
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.3),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                '+${match.pointsEarned}',
                style: const TextStyle(
                  color: Colors.amber,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  /// Get background colors based on match status
  List<Color> _getBackgroundColors() {
    const Color baseStart = Color(0xFF1A1A1A);
    const Color baseEnd = Color(0xFF000000);

    if (isHighlighted) {
      return [const Color(0xFF1F1F1F), const Color(0xFF0A0A0A)];
    }

    if (!match.isCompleted) {
      return [baseStart, baseEnd];
    }

    // For completed matches
    return [baseStart, baseEnd];
  }

  /// Get month abbreviation
  String _getMonthAbbr(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }

  /// Format date string
  String get dateStr {
    if (match.scheduledTime == null) return '';
    return '${_getMonthAbbr(match.scheduledTime!.month)} ${match.scheduledTime!.day}';
  }
}
