import 'package:flutter/material.dart';
import '../../domain/models/bracket_model.dart';

/// Widget to display a bracket item in a list
class BracketListItem extends StatelessWidget {
  /// The bracket to display
  final BracketModel bracket;

  /// Callback when the bracket is tapped
  final VoidCallback onTap;

  /// Constructor
  const BracketListItem({
    super.key,
    required this.bracket,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: _getGradientColors(),
            ),
            border: Border.all(
              color: _getBorderColor(),
              width: 1.0,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(14.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        bracket.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    _buildStatusChip(),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  bracket.description,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.white.withOpacity(0.7),
                    height: 1.3,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 12),
                // Simplified footer with participant count and date
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Participant count
                    Text(
                      '${bracket.participantCount} participants',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.white60,
                      ),
                    ),
                    // Date text
                    Text(
                      _getDateText(),
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.white60,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Get gradient colors based on bracket status
  List<Color> _getGradientColors() {
    // Black gradient colors for a sleek look
    const Color baseStart = Color(0xFF2A2A2A);
    const Color baseMiddle = Color(0xFF1A1A1A);
    const Color baseEnd = Color(0xFF000000);
    return [baseStart, baseMiddle, baseEnd];
  }

  /// Get border color based on bracket status
  Color _getBorderColor() {
    // Use a more subtle border color
    switch (bracket.status) {
      case BracketStatus.upcoming:
        return const Color(0xFFFF9800).withOpacity(0.6); // Orange
      case BracketStatus.inProgress:
        return const Color(0xFFFF5722).withOpacity(0.6); // Deep Orange
      case BracketStatus.completed:
        return const Color(0xFFFF9800).withOpacity(0.4); // Muted Orange
      case BracketStatus.cancelled:
        return const Color(0xFF757575).withOpacity(0.4); // Grey
    }
  }

  /// Build status chip based on bracket status
  Widget _buildStatusChip() {
    Color chipColor;
    String statusText;

    switch (bracket.status) {
      case BracketStatus.upcoming:
        chipColor = const Color(0xFFFF9800); // Orange
        statusText = 'Upcoming';
        break;
      case BracketStatus.inProgress:
        chipColor = const Color(0xFFFF5722); // Deep Orange
        statusText = 'In Progress';
        break;
      case BracketStatus.completed:
        chipColor = const Color(0xFFFF9800).withOpacity(0.7); // Muted Orange
        statusText = 'Completed';
        break;
      case BracketStatus.cancelled:
        chipColor = Colors.grey;
        statusText = 'Cancelled';
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.black,
        border: Border.all(color: chipColor, width: 1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        statusText,
        style: TextStyle(
          color: chipColor,
          fontSize: 11,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  /// Get formatted date text
  String _getDateText() {
    if (bracket.status == BracketStatus.upcoming) {
      return 'Starts ${_formatDate(bracket.startDate)}';
    } else if (bracket.status == BracketStatus.inProgress) {
      return 'Ends ${_formatDate(bracket.endDate ?? bracket.startDate)}';
    } else {
      return 'Ended ${_formatDate(bracket.endDate ?? bracket.startDate)}';
    }
  }

  /// Format date to readable string
  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = date.difference(now).inDays;

    if (difference == 0) {
      return 'Today';
    } else if (difference == 1) {
      return 'Tomorrow';
    } else if (difference == -1) {
      return 'Yesterday';
    } else if (difference > 0 && difference < 7) {
      return 'in $difference days';
    } else if (difference < 0 && difference > -7) {
      return '${-difference} days ago';
    } else {
      return '${date.month}/${date.day}/${date.year}';
    }
  }
}
