/// Constants for bracket routes
class BracketRoutes {
  /// Route for the brackets list page
  static const String bracketsRoute = '/brackets';
  
  /// Route for the bracket detail page
  static const String bracketDetailRoute = '/brackets/detail';
  
  /// Generate route for bracket detail with ID
  static String bracketDetailWithId(String bracketId) => '$bracketDetailRoute/$bracketId';
  
  /// Route for creating a new bracket
  static const String createBracket = '/create-bracket';
  
  /// Private constructor to prevent instantiation
  BracketRoutes._();
}
