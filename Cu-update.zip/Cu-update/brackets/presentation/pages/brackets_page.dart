import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:math' as math;
import 'package:check_up_app/core/routes/app_router.dart';
import '../../data/brackets_data_provider.dart';
import '../../domain/models/bracket_model.dart';

/// Page to display list of brackets
class BracketsPage extends StatefulWidget {
  /// Constructor
  const BracketsPage({super.key});

  @override
  State<BracketsPage> createState() => _BracketsPageState();
}

class _BracketsPageState extends State<BracketsPage> {
  // Data provider for brackets
  final BracketsDataProvider _bracketsDataProvider = BracketsDataProvider();

  // List of brackets
  late List<BracketModel> _brackets;

  // Filter status
  BracketStatus? _filterStatus;

  // My Brackets filter state
  bool _showMyBrackets = false;

  // Featured brackets
  late List<BracketModel> _featuredBrackets;

  // Search functionality
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _brackets = _bracketsDataProvider.getBrackets();
    // Get a subset of brackets as featured (in a real app, this would be based on popularity, etc.)
    _featuredBrackets = List.from(_brackets)
      ..shuffle()
      ..take(math.min(3, _brackets.length));
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // Filter brackets based on status, my brackets filter, and search query
  List<BracketModel> _filterBrackets() {
    List<BracketModel> filteredBrackets = _brackets;

    // Apply My Brackets filter first
    if (_showMyBrackets) {
      // In a real app, this would filter by current user ID
      // For demo, show first 2 brackets as "user's brackets"
      filteredBrackets = _brackets.take(2).toList();
    }

    // Then apply status filter if any
    if (_filterStatus != null) {
      filteredBrackets = filteredBrackets
          .where((bracket) => bracket.status == _filterStatus)
          .toList();
    }

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      filteredBrackets = filteredBrackets.where((bracket) {
        return bracket.name
                .toLowerCase()
                .contains(_searchQuery.toLowerCase()) ||
            bracket.description
                .toLowerCase()
                .contains(_searchQuery.toLowerCase()) ||
            bracket.createdBy
                .toLowerCase()
                .contains(_searchQuery.toLowerCase());
      }).toList();
    }

    return filteredBrackets;
  }

  // Build app bar
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.black,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: Colors.white),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0xFFFF9800),
            ),
            child: const Icon(
              Icons.account_tree,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          const Text(
            'BRACKETS',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 22,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.search, color: Colors.white, size: 28),
          onPressed: () {
            // TODO: Implement search functionality
          },
        ),
      ],
    );
  }

  Widget build(BuildContext context) {
    final filteredBrackets = _filterBrackets();

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: _buildAppBar(),
      body: RefreshIndicator(
        onRefresh: () async {
          // In a real app, this would refresh data from a server
          setState(() {
            _brackets = _bracketsDataProvider.getBrackets();
            _featuredBrackets = List.from(_brackets)
              ..shuffle()
              ..take(math.min(3, _brackets.length));
          });
        },
        color: const Color(0xFFFF9800),
        backgroundColor: Colors.grey[900],
        child: CustomScrollView(
          slivers: [
            // Header Section with Gradient
            SliverToBoxAdapter(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black,
                      Colors.grey[900]!,
                    ],
                  ),
                ),
                child: Column(
                  children: [
                    _buildFilterChips(),
                    _buildCreateBracketButton(),
                  ],
                ),
              ),
            ),
            // Search Bar Section
            SliverToBoxAdapter(
              child: Container(
                margin: const EdgeInsets.fromLTRB(16, 20, 16, 12),
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF2A2A2A),
                      Color(0xFF1A1A1A),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                    BoxShadow(
                      color: const Color(0xFFFF9800).withOpacity(0.1),
                      blurRadius: 20,
                      offset: const Offset(0, 0),
                    ),
                  ],
                ),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFF1A1A1A),
                        Color(0xFF0A0A0A),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: const Color(0xFFFF9800).withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      // Search Icon
                      Container(
                        padding: const EdgeInsets.all(16),
                        child: ShaderMask(
                          shaderCallback: (bounds) => const LinearGradient(
                            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                          ).createShader(bounds),
                          child: const Icon(
                            Icons.search_rounded,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                      ),
                      // Search TextField
                      Expanded(
                        child: TextField(
                          controller: _searchController,
                          onChanged: (value) {
                            setState(() {
                              _searchQuery = value;
                            });
                          },
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Search brackets...',
                            hintStyle: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 16,
                              fontWeight: FontWeight.normal,
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                              vertical: 16,
                              horizontal: 0,
                            ),
                          ),
                        ),
                      ),
                      // Results Count
                      if (_searchQuery.isNotEmpty ||
                          _filterStatus != null ||
                          _showMyBrackets)
                        Container(
                          margin: const EdgeInsets.only(right: 16),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                const Color(0xFFFF9800),
                                const Color(0xFFFF5722),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFFF9800).withOpacity(0.3),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Text(
                            '${filteredBrackets.length}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      // Clear Search Button
                      if (_searchQuery.isNotEmpty)
                        Container(
                          margin: const EdgeInsets.only(right: 12),
                          child: GestureDetector(
                            onTap: () {
                              _searchController.clear();
                              setState(() {
                                _searchQuery = '';
                              });
                            },
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.grey[800]?.withOpacity(0.6),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(
                                Icons.clear_rounded,
                                color: Colors.grey[400],
                                size: 18,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            // Brackets List
            filteredBrackets.isEmpty
                ? SliverFillRemaining(
                    child: _buildEmptyState(),
                  )
                : SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final bracket = filteredBrackets[index];
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                          child: _buildBracketListItem(bracket),
                        );
                      },
                      childCount: filteredBrackets.length,
                    ),
                  ),
            // Bottom spacing
            const SliverToBoxAdapter(
              child: SizedBox(height: 24),
            ),
          ],
        ),
      ),
    );
  }

  // Build create bracket button
  Widget _buildCreateBracketButton() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _handleCreateBracket,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.orange.shade400,
                  Colors.deepOrange.shade600,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.add_circle_outline,
                  color: Colors.white,
                  size: 24,
                ),
                SizedBox(width: 12),
                Text(
                  'Create New Bracket',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Shimmer effect for buttons
  Widget ShimmerEffect({required Widget child}) {
    return StatefulBuilder(
      builder: (context, setBuilderState) {
        // Use a ticker for continuous animation
        WidgetsBinding.instance.addPostFrameCallback((_) {
          // Create a continuous shimmer effect
          Future.delayed(const Duration(milliseconds: 50), () {
            if (mounted) {
              setBuilderState(() {}); // Trigger rebuild for animation
            }
          });
        });

        // Get current time for animation
        final double shimmerOffset =
            (DateTime.now().millisecondsSinceEpoch % 2000) / 2000;

        return ShaderMask(
          shaderCallback: (Rect bounds) {
            return LinearGradient(
              colors: [
                Colors.white.withOpacity(0.3),
                Colors.white.withOpacity(0.8),
                Colors.white.withOpacity(0.3),
              ],
              stops: [shimmerOffset - 0.2, shimmerOffset, shimmerOffset + 0.2],
              begin: const Alignment(-1.0, -0.3),
              end: const Alignment(1.0, 0.3),
              tileMode: TileMode.mirror,
            ).createShader(bounds);
          },
          blendMode: BlendMode.srcATop,
          child: child,
        );
      },
    );
  }

  // Build filter chips for bracket status
  Widget _buildFilterChips() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            _buildMyBracketsChip(),
            const SizedBox(width: 10),
            _buildFilterChip('All', null),
            const SizedBox(width: 10),
            _buildFilterChip('Upcoming', BracketStatus.upcoming),
            const SizedBox(width: 10),
            _buildFilterChip('In Progress', BracketStatus.inProgress),
            const SizedBox(width: 10),
            _buildFilterChip('Completed', BracketStatus.completed),
          ],
        ),
      ),
    );
  }

  // Build My Brackets chip
  Widget _buildMyBracketsChip() {
    final isSelected = _showMyBrackets;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _handleMyBracketsTap(),
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            gradient: isSelected
                ? LinearGradient(
                    colors: [
                      Colors.orange.shade400,
                      Colors.deepOrange.shade600,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : LinearGradient(
                    colors: [
                      Color(0xFF2A2A2A),
                      Color(0xFF1A1A1A),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isSelected)
                const Padding(
                  padding: EdgeInsets.only(right: 6),
                  child: Icon(
                    Icons.check_circle,
                    color: Colors.white,
                    size: 16,
                  ),
                )
              else
                const Padding(
                  padding: EdgeInsets.only(right: 6),
                  child: Icon(
                    Icons.person,
                    color: Color(0xFFFF9800),
                    size: 16,
                  ),
                ),
              Text(
                'My Brackets',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                  fontSize: 14,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Build individual filter chip
  Widget _buildFilterChip(String label, BracketStatus? status) {
    final isSelected = _filterStatus == status;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _handleFilterTap(status),
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            gradient: isSelected
                ? LinearGradient(
                    colors: [
                      Colors.orange.shade400,
                      Colors.deepOrange.shade600,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : LinearGradient(
                    colors: [
                      Color(0xFF2A2A2A),
                      Color(0xFF1A1A1A),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isSelected)
                const Padding(
                  padding: EdgeInsets.only(right: 6),
                  child: Icon(
                    Icons.check_circle,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                  fontSize: 14,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Build empty state when no brackets match filter
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            ).createShader(bounds),
            child: const Icon(
              Icons.sports_basketball,
              size: 80,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            _showMyBrackets
                ? 'No brackets created yet'
                : _filterStatus == null
                    ? 'No brackets found'
                    : 'No ${_filterStatus.toString().split('.').last} brackets found',
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Create a new bracket to get started',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[400],
            ),
          ),
          const SizedBox(height: 32),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withOpacity(0.4),
                  blurRadius: 12,
                  spreadRadius: 2,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _handleCreateBracket,
                borderRadius: BorderRadius.circular(30),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                  child: ShimmerEffect(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.add, color: Colors.white, size: 24),
                        SizedBox(width: 12),
                        Text(
                          'Create Bracket',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Build popular nearby brackets section
  Widget _buildFeaturedBrackets() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xFFFF9800),
                ),
                child: const Icon(
                  Icons.location_on,
                  color: Colors.white,
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'Popular Nearby',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 160,
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            scrollDirection: Axis.horizontal,
            itemCount: _featuredBrackets.length,
            itemBuilder: (context, index) {
              final bracket = _featuredBrackets[index];
              return _buildFeaturedBracketCard(bracket);
            },
          ),
        ),
      ],
    );
  }

  // Build featured bracket card
  Widget _buildFeaturedBracketCard(BracketModel bracket) {
    return Container(
      width: 240,
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: const Color(0xFF333333),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _handleBracketTap(bracket),
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFFFF9800),
                      ),
                      child: const Icon(
                        Icons.sports_basketball,
                        color: Colors.white,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        bracket.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  '${bracket.participantCount} Teams',
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(
                      Icons.location_on,
                      size: 12,
                      color: Color(0xFFFF9800),
                    ),
                    const SizedBox(width: 4),
                    const Text(
                      '0.8 miles away',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Round ${bracket.currentRound ?? "null"}',
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                    _buildStatusChip(bracket.status),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Build status chip
  Widget _buildStatusChip(BracketStatus status) {
    Color chipColor;
    String statusText;

    switch (status) {
      case BracketStatus.upcoming:
        chipColor = Colors.blue;
        statusText = 'Upcoming';
        break;
      case BracketStatus.inProgress:
        chipColor = Colors.green;
        statusText = 'Live';
        break;
      case BracketStatus.completed:
        chipColor = Colors.purple;
        statusText = 'Completed';
        break;
      case BracketStatus.cancelled:
        chipColor = Colors.red;
        statusText = 'Cancelled';
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: chipColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        statusText,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: chipColor,
        ),
      ),
    );
  }

  // Build clean modern bracket card
  Widget _buildBracketListItem(BracketModel bracket) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF1E1E1E),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFFF6B35).withOpacity(0.15),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: () => _handleBracketTap(bracket),
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Left content
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Bracket name
                      Text(
                        bracket.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                          height: 1.3,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 8),
                      // Host with profile image
                      Row(
                        children: [
                          Container(
                            width: 20,
                            height: 20,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.orange.withOpacity(0.6),
                                width: 1.5,
                              ),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Image.network(
                                'https://i.pravatar.cc/150?u=${bracket.createdBy}',
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: LinearGradient(
                                        colors: [
                                          Colors.orange.shade300,
                                          Colors.deepOrange.shade700,
                                        ],
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        bracket.createdBy.isNotEmpty
                                            ? bracket.createdBy[0].toUpperCase()
                                            : '?',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 10,
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              bracket.createdBy,
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white.withOpacity(0.7),
                                fontWeight: FontWeight.w500,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      // Teams count
                      Row(
                        children: [
                          Icon(
                            Icons.people_outline,
                            size: 16,
                            color: const Color(0xFFFF6B35),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '${bracket.participantCount} teams',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.white.withOpacity(0.8),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Right content
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    // Action buttons row
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Edit button (only show for user's brackets)
                        if (_showMyBrackets) ...[
                          Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFF4CAF50).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: IconButton(
                              onPressed: () => _handleEditBracket(bracket),
                              icon: const Icon(
                                Icons.edit_rounded,
                                color: Color(0xFF4CAF50),
                                size: 20,
                              ),
                              padding: const EdgeInsets.all(8),
                              constraints: const BoxConstraints(),
                            ),
                          ),
                          const SizedBox(width: 8),
                        ],
                        // Share button
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF6B35).withOpacity(0.15),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: IconButton(
                            onPressed: () => _handleShareBracket(bracket),
                            icon: const Icon(
                              Icons.share_rounded,
                              color: Color(0xFFFF6B35),
                              size: 20,
                            ),
                            padding: const EdgeInsets.all(8),
                            constraints: const BoxConstraints(),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    // Date
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFF6B35), Color(0xFFFF8A50)],
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _formatDate(bracket.startDate),
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Build modern status chip
  Widget _buildModernStatusChip(BracketStatus status) {
    Color backgroundColor;
    Color textColor;
    String statusText;
    IconData icon;

    switch (status) {
      case BracketStatus.upcoming:
        backgroundColor = const Color(0xFFDBEAFE);
        textColor = const Color(0xFF1D4ED8);
        statusText = 'Upcoming';
        icon = Icons.schedule_outlined;
        break;
      case BracketStatus.inProgress:
        backgroundColor = const Color(0xFFD1FAE5);
        textColor = const Color(0xFF059669);
        statusText = 'Live';
        icon = Icons.play_circle_outline;
        break;
      case BracketStatus.completed:
        backgroundColor = const Color(0xFFF3E8FF);
        textColor = const Color(0xFF7C3AED);
        statusText = 'Completed';
        icon = Icons.check_circle_outline;
        break;
      case BracketStatus.cancelled:
        backgroundColor = const Color(0xFFFEE2E2);
        textColor = const Color(0xFFDC2626);
        statusText = 'Cancelled';
        icon = Icons.cancel_outlined;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 14,
            color: textColor,
          ),
          const SizedBox(width: 6),
          Text(
            statusText,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: textColor,
            ),
          ),
        ],
      ),
    );
  }

  // Build simple status chip
  Widget _buildSimpleStatusChip(BracketStatus status) {
    Color chipColor;
    String statusText;

    switch (status) {
      case BracketStatus.upcoming:
        chipColor = const Color(0xFF4FC3F7);
        statusText = 'Soon';
        break;
      case BracketStatus.inProgress:
        chipColor = const Color(0xFF66BB6A);
        statusText = 'Live';
        break;
      case BracketStatus.completed:
        chipColor = const Color(0xFFAB47BC);
        statusText = 'Done';
        break;
      case BracketStatus.cancelled:
        chipColor = const Color(0xFFEF5350);
        statusText = 'Cancelled';
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: chipColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        statusText,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: chipColor,
        ),
      ),
    );
  }

  // Build compact status chip
  Widget _buildCompactStatusChip(BracketStatus status) {
    Color chipColor;
    String statusText;
    IconData statusIcon;

    switch (status) {
      case BracketStatus.upcoming:
        chipColor = const Color(0xFF4FC3F7);
        statusText = 'Soon';
        statusIcon = Icons.schedule_rounded;
        break;
      case BracketStatus.inProgress:
        chipColor = const Color(0xFF66BB6A);
        statusText = 'Live';
        statusIcon = Icons.play_circle_filled_rounded;
        break;
      case BracketStatus.completed:
        chipColor = const Color(0xFFAB47BC);
        statusText = 'Done';
        statusIcon = Icons.check_circle_rounded;
        break;
      case BracketStatus.cancelled:
        chipColor = const Color(0xFFEF5350);
        statusText = 'Cancelled';
        statusIcon = Icons.cancel_rounded;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: chipColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: chipColor.withOpacity(0.4),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            statusIcon,
            size: 12,
            color: chipColor,
          ),
          const SizedBox(width: 4),
          Text(
            statusText,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: chipColor,
            ),
          ),
        ],
      ),
    );
  }

  // Handle share bracket
  void _handleShareBracket(BracketModel bracket) {
    HapticFeedback.lightImpact();

    // Show share options
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1A1A1A),
              Color(0xFF0A0A0A),
            ],
          ),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Share "${bracket.name}"',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildShareOption(Icons.link_rounded, 'Copy Link', () {
                  Navigator.pop(context);
                  _copyBracketLink(bracket);
                }),
                _buildShareOption(Icons.message_rounded, 'Message', () {
                  Navigator.pop(context);
                  _shareBracketMessage(bracket);
                }),
                _buildShareOption(Icons.more_horiz_rounded, 'More', () {
                  Navigator.pop(context);
                  _shareBracketMore(bracket);
                }),
              ],
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // Build share option
  Widget _buildShareOption(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF6B35),
                  Color(0xFFFF8A50),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // Copy bracket link
  void _copyBracketLink(BracketModel bracket) {
    Clipboard.setData(ClipboardData(
        text: 'https://app.thenetwork.com/brackets/${bracket.id}'));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Bracket link copied to clipboard'),
        backgroundColor: const Color(0xFFFF6B35),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  // Share bracket via message
  void _shareBracketMessage(BracketModel bracket) {
    // In a real app, this would open the messaging app
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Sharing "${bracket.name}" via message...'),
        backgroundColor: const Color(0xFFFF6B35),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  // Share bracket via more options
  void _shareBracketMore(BracketModel bracket) {
    // In a real app, this would open the system share sheet
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening share options for "${bracket.name}"...'),
        backgroundColor: const Color(0xFFFF6B35),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  // Format date to readable string
  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 0) {
      return 'In ${-difference.inDays} days';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      final month = _getMonthName(date.month);
      return '$month ${date.day}';
    }
  }

  // Get month name from month number
  String _getMonthName(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }

  // Handle filter tap
  void _handleFilterTap(BracketStatus? status) {
    HapticFeedback.mediumImpact();
    setState(() {
      _filterStatus = _filterStatus == status ? null : status;
      // Clear My Brackets filter when selecting status filter
      if (_filterStatus != null) {
        _showMyBrackets = false;
      }
    });
  }

  // Handle My Brackets tap
  void _handleMyBracketsTap() {
    HapticFeedback.mediumImpact();
    setState(() {
      _showMyBrackets = !_showMyBrackets;
      // Clear status filter when switching to My Brackets
      if (_showMyBrackets) {
        _filterStatus = null;
      }
    });
  }

  // Handle bracket tap
  void _handleBracketTap(BracketModel bracket) {
    HapticFeedback.mediumImpact();
    // Navigate to bracket detail page
    Navigator.pushNamed(
      context,
      '/brackets/detail',
      arguments: {'bracket': bracket},
    );
  }

  // Handle edit bracket
  void _handleEditBracket(BracketModel bracket) {
    HapticFeedback.mediumImpact();
    // Navigate to edit bracket page
    Navigator.pushNamed(
      context,
      '/brackets/edit',
      arguments: {'bracket': bracket},
    ).then((_) {
      // Refresh brackets list when returning from edit
      setState(() {
        _brackets = _bracketsDataProvider.getBrackets();
        _featuredBrackets = List.from(_brackets)
          ..shuffle()
          ..take(math.min(3, _brackets.length));
      });
    });
  }

  // Handle create bracket button tap
  void _handleCreateBracket() {
    HapticFeedback.mediumImpact();
    // Navigate to create bracket page
    Navigator.pushNamed(
      context,
      AppRouter.createBracketRoute,
    );
  }
}
