import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../domain/models/bracket_model.dart';
import '../../domain/models/bracket_match_model.dart';
import '../../domain/models/bracket_round_model.dart';
import '../widgets/bracket_round_column.dart';
import '../../../search/presentation/pages/score_detail_screen.dart';
import '../../../search/domain/models/score_model.dart';

/// Page to display a tournament bracket in detail
class BracketDetailPage extends StatefulWidget {
  /// The bracket model to display
  final BracketModel bracket;

  /// Constructor
  const BracketDetailPage({Key? key, required this.bracket}) : super(key: key);

  @override
  State<BracketDetailPage> createState() => _BracketDetailPageState();
}

class _BracketDetailPageState extends State<BracketDetailPage>
    with SingleTickerProviderStateMixin {
  /// The bracket model
  late BracketModel _bracket;

  /// Currently selected round index
  int _selectedRoundIndex = 0;

  /// Currently selected match ID
  String? _selectedMatchId;

  /// Tab controller for rounds
  late TabController _tabController;

  /// Whether the current user is the host of this bracket
  bool get _isHost {
    // TODO: Replace with actual user ID from authentication service
    const currentUserId = 'current_user_id';
    return _bracket.createdBy == currentUserId;
  }

  @override
  void initState() {
    super.initState();
    _loadBracket();
    _tabController =
        TabController(length: _bracket.rounds?.length ?? 0, vsync: this);
    _tabController.addListener(_handleTabChange);
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabChange);
    _tabController.dispose();
    super.dispose();
  }

  /// Load the bracket data
  void _loadBracket() {
    // Use the passed bracket data
    _bracket = widget.bracket;

    // Generate dynamic bracket structure for all participant counts
    _bracket = _generateDynamicBracket(_bracket);

    // Set initial selected round to current round
    if (_bracket.rounds != null && _bracket.rounds!.isNotEmpty) {
      final currentRound = _bracket.currentRound;
      if (currentRound != null) {
        _selectedRoundIndex = currentRound.roundNumber - 1;
      }
    }
  }

  /// Handle tab change
  void _handleTabChange() {
    if (_tabController.index != _selectedRoundIndex) {
      setState(() {
        _selectedRoundIndex = _tabController.index;
        _selectedMatchId = null; // Clear selected match when changing rounds
      });
    }
  }

  /// Handle match tap
  void _handleMatchTap(String matchId) {
    HapticFeedback.mediumImpact();

    final match = _findMatchById(matchId);
    if (match == null) return;

    setState(() {
      _selectedMatchId = _selectedMatchId == matchId ? null : matchId;
    });

    // Show match details or options based on match state
    if (match.team1 == null || match.team2 == null) {
      _showMatchNotReadyDialog(match);
    } else if (match.isCompleted) {
      _showCompletedMatchDetails(match);
    } else {
      _showUpcomingMatchOptions(match);
    }
  }

  /// Navigate to score detail screen for match details
  void _navigateToScoreDetail(BracketMatchModel match) {
    // Ensure both teams are available for the score detail
    if (match.team1 == null || match.team2 == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Match teams not yet determined'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    // Create ScoreModel from bracket match data
    final scoreModel = ScoreModel(
      id: match.id,
      homeTeamName: match.team1!.name,
      awayTeamName: match.team2!.name,
      homeScore: match.team1Score ?? 0,
      awayScore: match.team2Score ?? 0,
      gameDateTime: match.scheduledTime ?? DateTime.now(),
      gameStatus: match.isCompleted ? 'Final' : 'Upcoming',
      courtName: 'Court ${match.matchNumber}',
      courtLocation: match.location ?? 'Tournament Venue',
      hostName: 'Tournament Host',
      gameType: '5v5',
      leagueName: widget.bracket.name,
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ScoreDetailScreen(score: scoreModel),
      ),
    );
  }

  /// Show dialog when match teams are not ready
  void _showMatchNotReadyDialog(BracketMatchModel match) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.orange, size: 24),
            const SizedBox(width: 12),
            const Text('Match Not Ready',
                style: TextStyle(color: Colors.white)),
          ],
        ),
        content: Text(
          'This match is waiting for teams to advance from previous rounds.',
          style: TextStyle(color: Colors.white70, fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK', style: TextStyle(color: Color(0xFFFF9800))),
          ),
        ],
      ),
    );
  }

  /// Show completed match details
  void _showCompletedMatchDetails(BracketMatchModel match) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.emoji_events, color: Colors.green, size: 24),
            const SizedBox(width: 12),
            const Text('Match Complete', style: TextStyle(color: Colors.white)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          match.team1?.name ?? 'Team 1',
                          style: TextStyle(
                            color: match.winnerId == match.team1?.id
                                ? Colors.green
                                : Colors.white70,
                            fontWeight: match.winnerId == match.team1?.id
                                ? FontWeight.bold
                                : FontWeight.normal,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      Text(
                        '${match.team1Score ?? 0}',
                        style: TextStyle(
                          color: match.winnerId == match.team1?.id
                              ? Colors.green
                              : Colors.white70,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          match.team2?.name ?? 'Team 2',
                          style: TextStyle(
                            color: match.winnerId == match.team2?.id
                                ? Colors.green
                                : Colors.white70,
                            fontWeight: match.winnerId == match.team2?.id
                                ? FontWeight.bold
                                : FontWeight.normal,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      Text(
                        '${match.team2Score ?? 0}',
                        style: TextStyle(
                          color: match.winnerId == match.team2?.id
                              ? Colors.green
                              : Colors.white70,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          if (_isHost)
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _showManualScoreEntry(match);
              },
              child: const Text('Edit Score',
                  style: TextStyle(color: Color(0xFFFF9800))),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Colors.white70)),
          ),
        ],
      ),
    );
  }

  /// Show upcoming match options
  void _showUpcomingMatchOptions(BracketMatchModel match) {
    if (!_isHost) {
      _navigateToScoreDetail(match);
      return;
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
          ),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 20),

            // Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  Text(
                    '${match.team1?.name ?? "Team 1"} vs ${match.team2?.name ?? "Team 2"}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Match ${match.matchNumber} - ${_bracket.rounds![_selectedRoundIndex].name}',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Manual Score Entry
            _buildHostOption(
              icon: Icons.edit,
              title: 'Enter Final Score',
              subtitle: 'Manually enter the final score',
              onTap: () {
                Navigator.pop(context);
                _showManualScoreEntry(match);
              },
            ),
            const SizedBox(height: 12),

            // Live Scoreboard
            _buildHostOption(
              icon: Icons.live_tv,
              title: 'Live Scoreboard',
              subtitle: 'Start live scoring for this match',
              onTap: () {
                Navigator.pop(context);
                _launchLiveScoreboard(match);
              },
            ),
            const SizedBox(height: 12),

            // Cancel
            _buildHostOption(
              icon: Icons.close,
              title: 'Cancel',
              subtitle: 'Close without changes',
              onTap: () => Navigator.pop(context),
              isCancel: true,
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  /// Build a host option button
  Widget _buildHostOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool isCancel = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isCancel
                ? [const Color(0xFF2A2A2A), const Color(0xFF1A1A1A)]
                : [const Color(0xFFFF9800), const Color(0xFFFF5722)],
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: (isCancel ? Colors.black : const Color(0xFFFF5722))
                  .withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios,
                color: Colors.white70, size: 16),
          ],
        ),
      ),
    );
  }

  /// Show manual score entry dialog
  void _showManualScoreEntry(BracketMatchModel match) {
    final team1Controller = TextEditingController();
    final team2Controller = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text(
          'Enter Final Scores',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Team 1 Score
            TextField(
              controller: team1Controller,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: match.team1?.name ?? 'Team 1',
                labelStyle: const TextStyle(color: Colors.white70),
                enabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white54),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFFF9800)),
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Team 2 Score
            TextField(
              controller: team2Controller,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: match.team2?.name ?? 'Team 2',
                labelStyle: const TextStyle(color: Colors.white70),
                enabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white54),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFFF9800)),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child:
                const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              final team1Score = int.tryParse(team1Controller.text);
              final team2Score = int.tryParse(team2Controller.text);

              if (team1Score != null && team2Score != null) {
                _updateMatchScore(match, team1Score, team2Score);
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF9800),
            ),
            child: const Text('Save Scores'),
          ),
        ],
      ),
    );
  }

  /// Launch live scoreboard for a match
  void _launchLiveScoreboard(BracketMatchModel match) {
    HapticFeedback.mediumImpact();

    // Navigate to scoreboard screen with match data
    Navigator.pushNamed(
      context,
      '/scoreboard',
      arguments: {
        'match': match,
        'isHost': true,
        'onScoreUpdate': (int team1Score, int team2Score) {
          _updateMatchScore(match, team1Score, team2Score);
        },
      },
    );

    // Show confirmation snackbar
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Launching live scoreboard for ${match.team1?.name ?? "Team 1"} vs ${match.team2?.name ?? "Team 2"}'),
        backgroundColor: const Color(0xFFFF9800),
      ),
    );
  }

  /// Update match score and determine winner
  void _updateMatchScore(
      BracketMatchModel match, int team1Score, int team2Score) {
    String? winnerId;
    if (team1Score > team2Score) {
      winnerId = match.team1?.id;
    } else if (team2Score > team1Score) {
      winnerId = match.team2?.id;
    }

    // Update the match in the bracket
    final updatedMatch = match.copyWith(
      team1Score: team1Score,
      team2Score: team2Score,
      winnerId: winnerId,
      isCompleted: true,
    );

    // Update the bracket with the new match data
    _updateBracketMatch(updatedMatch);

    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Match score updated: ${match.team1?.name} $team1Score - $team2Score ${match.team2?.name}'),
        backgroundColor: Colors.green,
      ),
    );
  }

  /// Find a match by ID in the bracket
  BracketMatchModel? _findMatchById(String matchId) {
    if (_bracket.rounds == null) return null;

    for (final round in _bracket.rounds!) {
      for (final match in round.matches) {
        if (match.id == matchId) return match;
      }
    }
    return null;
  }

  /// Update a match in the bracket
  void _updateBracketMatch(BracketMatchModel updatedMatch) {
    if (_bracket.rounds == null) return;

    final updatedRounds = _bracket.rounds!.map((round) {
      final updatedMatches = round.matches.map((match) {
        return match.id == updatedMatch.id ? updatedMatch : match;
      }).toList();

      return BracketRoundModel(
        id: round.id,
        roundNumber: round.roundNumber,
        name: round.name,
        matches: updatedMatches,
        startDate: round.startDate,
        endDate: round.endDate,
      );
    }).toList();

    setState(() {
      _bracket = _bracket.copyWith(rounds: updatedRounds);
    });
  }

  /// Show share bracket options
  void _showShareBracket() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1A1A1A),
              Color(0xFF0A0A0A),
            ],
          ),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Share "${_bracket.name}"',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildShareOption(Icons.link_rounded, 'Copy Link', () {
                  Navigator.pop(context);
                  _copyBracketLink();
                }),
                _buildShareOption(Icons.message_rounded, 'Message', () {
                  Navigator.pop(context);
                  _shareBracketMessage();
                }),
                _buildShareOption(Icons.more_horiz_rounded, 'More', () {
                  Navigator.pop(context);
                  _shareBracketMore();
                }),
              ],
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  /// Build share option
  Widget _buildShareOption(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF6B35),
                  Color(0xFFFF8A50),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  /// Copy bracket link
  void _copyBracketLink() {
    Clipboard.setData(ClipboardData(
        text: 'https://app.thenetwork.com/brackets/${_bracket.id}'));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Bracket link copied to clipboard'),
        backgroundColor: const Color(0xFFFF6B35),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  /// Share bracket via message
  void _shareBracketMessage() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Sharing "${_bracket.name}" via message...'),
        backgroundColor: const Color(0xFFFF6B35),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  /// Share bracket via more options
  void _shareBracketMore() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening share options for "${_bracket.name}"...'),
        backgroundColor: const Color(0xFFFF6B35),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  /// Generate dynamic bracket structure based on participant count
  BracketModel _generateDynamicBracket(BracketModel originalBracket) {
    final participantCount = originalBracket.participantCount;

    // Create teams based on participant count
    final teams = _createTeamsForBracket(participantCount);

    // Create rounds based on participant count
    final rounds = _createRoundsForBracket(participantCount, teams);

    // Return updated bracket with dynamic structure
    return originalBracket.copyWith(
      rounds: rounds,
    );
  }

  /// Create teams for the bracket based on participant count
  Map<String, BracketTeamModel> _createTeamsForBracket(int participantCount) {
    final teams = <String, BracketTeamModel>{};

    // Comprehensive team names for all bracket sizes (up to 64 teams)
    final teamNames = [
      'Lakers',
      'Warriors',
      'Celtics',
      'Heat',
      'Bulls',
      'Knicks',
      'Nets',
      'Sixers',
      'Bucks',
      'Raptors',
      'Hawks',
      'Magic',
      'Hornets',
      'Wizards',
      'Pistons',
      'Pacers',
      'Cavaliers',
      'Thunder',
      'Nuggets',
      'Clippers',
      'Suns',
      'Jazz',
      'Blazers',
      'Kings',
      'Spurs',
      'Mavericks',
      'Rockets',
      'Grizzlies',
      'Pelicans',
      'Timberwolves',
      'Wolves',
      'Lions',
      'Tigers',
      'Eagles',
      'Falcons',
      'Ravens',
      'Cardinals',
      'Panthers',
      'Jaguars',
      'Dolphins',
      'Sharks',
      'Bears',
      'Rams',
      'Chargers',
      'Raiders',
      'Chiefs',
      'Broncos',
      'Colts',
      'Titans',
      'Texans',
      'Steelers',
      'Browns',
      'Bengals',
      'Bills',
      'Jets',
      'Patriots',
      'Giants',
      'Cowboys',
      'Redskins',
      'Packers',
      'Vikings',
      'Saints',
      'Buccaneers',
      'Seahawks'
    ];

    for (int i = 0; i < participantCount; i++) {
      final teamName = teamNames[i];

      teams['team-$i'] = BracketTeamModel(
        id: 'team-$i',
        name: teamName,
        seed: i + 1,
        logoUrl: 'https://via.placeholder.com/50x50?text=${teamName[0]}',
        abbreviation: teamName.substring(0, 3).toUpperCase(),
        record: '${20 + (i % 10)}-${5 + (i % 8)}',
      );
    }

    return teams;
  }

  /// Create rounds for the bracket based on participant count
  List<BracketRoundModel> _createRoundsForBracket(
      int participantCount, Map<String, BracketTeamModel> teams) {
    final rounds = <BracketRoundModel>[];
    final teamList = teams.values.toList();

    // Calculate number of rounds needed
    int roundCount = 0;
    int tempCount = participantCount;
    while (tempCount > 1) {
      tempCount = (tempCount / 2).ceil();
      roundCount++;
    }

    // Generate rounds in correct order (first round to finals)
    for (int roundNum = 1; roundNum <= roundCount; roundNum++) {
      // Calculate matches correctly - final round should always have 1 match
      int matchesInRound;
      if (roundNum == roundCount) {
        // Finals always has 1 match
        matchesInRound = 1;
      } else {
        // Calculate matches for non-final rounds
        matchesInRound = (participantCount / (1 << roundNum)).ceil();
        // Ensure we don't have more matches than possible
        final maxPossibleMatches =
            (participantCount / (1 << (roundNum - 1))).ceil() ~/ 2;
        matchesInRound = matchesInRound.clamp(1, maxPossibleMatches);
      }

      final matches = <BracketMatchModel>[];

      // Create matches for this round
      for (int matchNum = 1; matchNum <= matchesInRound; matchNum++) {
        BracketTeamModel? team1;
        BracketTeamModel? team2;

        // For first round, assign actual teams
        if (roundNum == 1) {
          final team1Index = (matchNum - 1) * 2;
          final team2Index = team1Index + 1;

          if (team1Index < teamList.length) {
            team1 = teamList[team1Index];
          }
          if (team2Index < teamList.length) {
            team2 = teamList[team2Index];
          }
        }

        matches.add(BracketMatchModel(
          id: 'match-r$roundNum-$matchNum',
          roundNumber: roundNum,
          matchNumber: matchNum,
          team1: team1,
          team2: team2,
          team1Score: null,
          team2Score: null,
          winnerId: null,
          isCompleted: false,
          scheduledTime: DateTime.now().add(Duration(days: roundNum)),
          location: 'Tournament Venue',
        ));
      }

      // Create round with appropriate name based on how many rounds remain
      String roundName;
      final roundsRemaining = roundCount - roundNum + 1;
      switch (roundsRemaining) {
        case 1:
          roundName = 'Finals';
          break;
        case 2:
          roundName = 'Semifinals';
          break;
        case 3:
          roundName = 'Quarterfinals';
          break;
        case 4:
          roundName = 'Round of 16';
          break;
        default:
          roundName = 'Round $roundNum';
      }

      rounds.add(BracketRoundModel(
        id: 'round-$roundNum',
        roundNumber: roundNum,
        name: roundName,
        matches: matches,
        startDate: DateTime.now().add(Duration(days: roundNum - 1)),
        endDate: DateTime.now().add(Duration(days: roundNum)),
      ));
    }

    return rounds;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF000000), Color(0xFF1A1A1A)],
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _bracket.name,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                letterSpacing: 0.3,
                color: Colors.white,
              ),
            ),
            Text(
              '${_bracket.participantCount} Teams • ${_bracket.status.toString().split('.').last.toUpperCase()}',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[400],
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
        elevation: 0,
        actions: [
          // Share Button
          Container(
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF6B35), Color(0xFFFF8A50)],
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: IconButton(
              icon: const Icon(Icons.share_rounded,
                  color: Colors.white, size: 18),
              onPressed: () {
                HapticFeedback.lightImpact();
                _showShareBracket();
              },
            ),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF121212), Color(0xFF000000)],
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Bracket title and description
              _buildBracketHeader(),

              // Round header and tabs
              _buildRoundHeader(),

              // Round content
              _buildRoundContent(),
            ],
          ),
        ),
      ),
    );
  }

  /// Build bracket title and description header
  Widget _buildBracketHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Tournament title
          Text(
            _bracket.name,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 8),

          // Tournament info row
          Row(
            children: [
              // Participant count
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF6F00)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  '${_bracket.participantCount} Teams',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(width: 12),

              // Status badge
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _getStatusColor().withOpacity(0.2),
                  border: Border.all(color: _getStatusColor(), width: 1),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  _bracket.status.toString().split('.').last.toUpperCase(),
                  style: TextStyle(
                    color: _getStatusColor(),
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),

          // Description (if available)
          if (_bracket.description != null &&
              _bracket.description!.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text(
              _bracket.description!,
              style: TextStyle(
                color: Colors.grey[300],
                fontSize: 16,
                height: 1.4,
                letterSpacing: 0.2,
              ),
            ),
          ],

          // Tournament dates (if available)
          if (_bracket.startDate != null) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(
                  Icons.calendar_today,
                  color: Colors.grey[400],
                  size: 16,
                ),
                const SizedBox(width: 8),
                Text(
                  _getDateRangeText(),
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  /// Get status color based on bracket status
  Color _getStatusColor() {
    switch (_bracket.status) {
      case BracketStatus.upcoming:
        return Colors.blue;
      case BracketStatus.inProgress:
        return Colors.orange;
      case BracketStatus.completed:
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  /// Get formatted date range text
  String _getDateRangeText() {
    if (_bracket.startDate == null) return '';

    final startDate = _bracket.startDate!;
    final endDate = _bracket.endDate;

    final startFormatted = '${_getMonthName(startDate.month)} ${startDate.day}';

    if (endDate == null || startDate.day == endDate.day) {
      return startFormatted;
    }

    final endFormatted = '${_getMonthName(endDate.month)} ${endDate.day}';
    return '$startFormatted - $endFormatted';
  }

  /// Get month name
  String _getMonthName(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }

  /// Build the round header with modern pill-shaped tabs
  Widget _buildRoundHeader() {
    if (_bracket.rounds == null || _bracket.rounds!.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Round tabs - exact design from create bracket preview
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1F1F1F), Color(0xFF121212)],
              ),
              border: const Border(
                bottom: BorderSide(color: Color(0xFFFF9800), width: 2),
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF5722).withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: _bracket.rounds!.asMap().entries.map((entry) {
                  final index = entry.key;
                  final round = entry.value;
                  final isSelected = index == _selectedRoundIndex;
                  final matchCount = round.matches.length;

                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 6),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            _selectedRoundIndex = index;
                            _tabController.animateTo(index);
                          });
                        },
                        borderRadius: BorderRadius.circular(25),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),
                            gradient: isSelected
                                ? const LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      Color(0xFFFF9800),
                                      Color(0xFFFF5722)
                                    ],
                                  )
                                : null,
                            border: !isSelected
                                ? Border.all(
                                    color: Colors.white24,
                                    width: 1,
                                  )
                                : null,
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: const Color(0xFFFF5722)
                                          .withOpacity(0.4),
                                      blurRadius: 8,
                                      offset: const Offset(0, 4),
                                    ),
                                  ]
                                : null,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                round.name,
                                style: TextStyle(
                                  color: isSelected
                                      ? Colors.white
                                      : Colors.white70,
                                  fontWeight: isSelected
                                      ? FontWeight.bold
                                      : FontWeight.w500,
                                  fontSize: isSelected ? 16 : 14,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '$matchCount matches',
                                style: TextStyle(
                                  color: isSelected
                                      ? Colors.white.withOpacity(0.9)
                                      : Colors.white54,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Build the round content
  Widget _buildRoundContent() {
    if (_bracket.rounds == null || _bracket.rounds!.isEmpty) {
      return Center(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1F1F1F), Color(0xFF121212)],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFFF9800), width: 1),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(
                Icons.sports_basketball,
                size: 48,
                color: Color(0xFFFF5722),
              ),
              SizedBox(height: 16),
              Text(
                'No rounds available',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF5722).withOpacity(0.2),
            blurRadius: 8,
            spreadRadius: 1,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: SizedBox(
        height: 600, // Fixed height for TabBarView to work in scrollable view
        child: TabBarView(
          controller: _tabController,
          children: _bracket.rounds!.map((round) {
            return Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF1A1A1A), Color(0xFF000000)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: BracketRoundColumn(
                round: round,
                onMatchTap: _handleMatchTap,
                selectedMatchId: _selectedMatchId,
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
