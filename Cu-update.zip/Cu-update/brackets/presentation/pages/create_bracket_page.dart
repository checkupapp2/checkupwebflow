import 'package:flutter/material.dart';
import '../../domain/models/team_model.dart';
import '../../domain/models/bracket_model.dart';
import '../../domain/models/bracket_round_model.dart';
import '../../domain/models/bracket_match_model.dart';
import '../../../events/domain/models/location_model.dart';
import '../../../events/presentation/widgets/enhanced_location_selector.dart';
import 'bracket_detail_page.dart';

/// Page for creating a new tournament bracket
class CreateBracketPage extends StatefulWidget {
  /// Constructor
  const CreateBracketPage({Key? key}) : super(key: key);

  @override
  State<CreateBracketPage> createState() => _CreateBracketPageState();
}

class _CreateBracketPageState extends State<CreateBracketPage>
    with SingleTickerProviderStateMixin {
  // Tab controller
  late TabController _tabController;

  // Current tab index - used in tab controller listener
  int _currentTabIndex = 0;

  // Form key for validation
  final _formKey = GlobalKey<FormState>();

  // Text editing controllers
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _teamNameController = TextEditingController();
  final _locationController = TextEditingController();

  // Custom team count
  final _customTeamCountController = TextEditingController();

  // Is using custom team count
  bool _isCustomTeamCount = false;

  // Number of teams
  int _numberOfTeams = 16;

  // State variables
  int _selectedRoundIndex = 0; // Track selected round for preview
  List<TeamModel> _teams = [];

  // Location state
  LocationModel? _selectedLocation;
  bool _isLocationPrivate = false;

  // Available team counts
  final List<int> _teamCounts = [4, 8, 16, 32, 64];

  @override
  void initState() {
    super.initState();
    // Initialize tab controller with 3 tabs: Details, Teams, and Preview
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        setState(() {
          _currentTabIndex = _tabController.index;
        });
      }
    });

    // Add some mock teams for testing
    _teams.addAll([
      TeamModel(id: '1', name: 'Lakers', colorHex: '#FDB927'),
      TeamModel(id: '2', name: 'Celtics', colorHex: '#007A33'),
      TeamModel(id: '3', name: 'Bulls', colorHex: '#CE1141'),
    ]);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _customTeamCountController.dispose();
    _teamNameController.dispose();
    _locationController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF212121), Colors.black],
            ),
          ),
        ),
        title: const Text(
          'Create New Bracket',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            letterSpacing: 0.5,
          ),
        ),
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF333333), width: 1),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white60,
              labelStyle: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
              unselectedLabelStyle: const TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 14,
              ),
              dividerColor: Colors.transparent,
              tabs: const [
                Tab(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('DETAILS'),
                  ),
                ),
                Tab(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('TEAMS'),
                  ),
                ),
                Tab(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('PREVIEW'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.black, Color(0xFF121212)],
          ),
        ),
        child: TabBarView(
          controller: _tabController,
          children: [
            // Details Tab
            Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildHeaderSection(),
                    const SizedBox(height: 24),
                    _buildFormFields(),
                    const SizedBox(height: 24),
                    _buildCreateButton(),
                  ],
                ),
              ),
            ),
            // Teams Tab
            SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildTeamsHeader(),
                  const SizedBox(height: 16),
                  _buildSectionTitle('Tournament Settings'),
                  const SizedBox(height: 16),
                  _buildTeamCountSelector(),
                  const SizedBox(height: 24),
                  _buildTeamSearchAndCreate(),
                  const SizedBox(height: 16),
                  _buildTeamsList(),
                ],
              ),
            ),
            // Preview Tab
            SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildPreviewHeader(),
                  const SizedBox(height: 24),
                  _buildBracketPreview(),
                  const SizedBox(height: 24),
                  _buildCreateButton(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF212121), Color(0xFF121212)],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF5722).withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.account_tree,
                  color: Colors.white,
                  size: 36,
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Text(
                  'Create Your Tournament Bracket',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Set up your bracket details below to get started with your tournament.',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildFormFields() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildSectionTitle('Bracket Details'),
        const SizedBox(height: 16),
        _buildTextField(
          controller: _nameController,
          label: 'Tournament Name',
          hint: 'e.g., "Summer Championship 2024"',
          icon: Icons.emoji_events_rounded,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter a tournament name';
            }
            return null;
          },
        ),
        const SizedBox(height: 20),
        _buildTextField(
          controller: _descriptionController,
          label: 'Description',
          hint: 'Tell players what this tournament is about...',
          icon: Icons.article_rounded,
          maxLines: 4,
        ),
        const SizedBox(height: 20),
        _buildLocationField(),
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFFF6B35),
            Color(0xFFFF8A50),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF6B35).withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Icon(
              title.contains('Details')
                  ? Icons.info_outline_rounded
                  : Icons.settings_rounded,
              color: Colors.white,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    int maxLines = 1,
    String? Function(String?)? validator,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFFF6B35).withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
          ),
          labelStyle: const TextStyle(
            color: Color(0xFFFF6B35),
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
          prefixIcon: Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF6B35), Color(0xFFFF8A50)],
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 20,
            ),
          ),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(
            horizontal: 20,
            vertical: maxLines > 1 ? 20 : 16,
          ),
          floatingLabelBehavior: FloatingLabelBehavior.always,
        ),
        validator: validator,
      ),
    );
  }

  /// Build location field for court selection
  Widget _buildLocationField() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFFF6B35).withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Location header
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Row(
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF6B35), Color(0xFFFF8A50)],
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.location_on,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
                const Text(
                  'Tournament Location',
                  style: TextStyle(
                    color: Color(0xFFFF6B35),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          // Location selector
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
            child: EnhancedLocationSelector(
              selectedLocation: _selectedLocation,
              isLocationPrivate: _isLocationPrivate,
              onLocationSelected: (location) {
                setState(() {
                  _selectedLocation = location;
                });
              },
              onPrivacyChanged: (isPrivate) {
                setState(() {
                  _isLocationPrivate = isPrivate;
                });
              },
              locationController: _locationController,
              hideTitle: true,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamCountSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 16, bottom: 8),
          child: Text(
            'Number of Teams',
            style: TextStyle(color: Color(0xFFFF9800), fontSize: 14),
          ),
        ),
        Container(
          height: 60,
          decoration: BoxDecoration(
            color: const Color(0xFF212121),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF424242)),
          ),
          child: Row(
            children: [
              Expanded(
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _teamCounts.length + 1, // +1 for custom option
                  itemBuilder: (context, index) {
                    // Custom option is the last item
                    if (index == _teamCounts.length) {
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _isCustomTeamCount = true;
                            // Set initial value in the text field
                            _customTeamCountController.text =
                                _numberOfTeams.toString();
                          });
                        },
                        child: Container(
                          width: 60,
                          margin: const EdgeInsets.symmetric(
                              horizontal: 4, vertical: 8),
                          decoration: BoxDecoration(
                            gradient: _isCustomTeamCount
                                ? const LinearGradient(
                                    colors: [
                                      Color(0xFFFF9800),
                                      Color(0xFFFF5722)
                                    ],
                                  )
                                : null,
                            color: _isCustomTeamCount
                                ? null
                                : const Color(0xFF333333),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Center(
                            child: Icon(
                              Icons.edit,
                              color: _isCustomTeamCount
                                  ? Colors.white
                                  : Colors.white70,
                              size: 20,
                            ),
                          ),
                        ),
                      );
                    }

                    final count = _teamCounts[index];
                    final isSelected =
                        !_isCustomTeamCount && count == _numberOfTeams;

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _isCustomTeamCount = false;
                          _numberOfTeams = count;
                        });
                      },
                      child: Container(
                        width: 60,
                        margin: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 8),
                        decoration: BoxDecoration(
                          gradient: isSelected
                              ? const LinearGradient(
                                  colors: [
                                    Color(0xFFFF9800),
                                    Color(0xFFFF5722)
                                  ],
                                )
                              : null,
                          color: isSelected ? null : const Color(0xFF333333),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(
                          child: Text(
                            count.toString(),
                            style: TextStyle(
                              color: isSelected ? Colors.white : Colors.white70,
                              fontWeight: isSelected
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        if (_isCustomTeamCount) _buildCustomTeamCountInput(),
      ],
    );
  }

  Widget _buildCustomTeamCountInput() {
    return Container(
      margin: const EdgeInsets.only(top: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF212121),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF424242)),
      ),
      child: TextFormField(
        controller: _customTeamCountController,
        keyboardType: TextInputType.number,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: 'Custom Team Count',
          hintText: 'Enter number of teams',
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
          labelStyle: const TextStyle(color: Color(0xFFFF9800)),
          prefixIcon: const Icon(Icons.groups, color: Color(0xFFFF9800)),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
        onChanged: (value) {
          if (value.isNotEmpty) {
            final customCount = int.tryParse(value);
            if (customCount != null && customCount > 0) {
              setState(() {
                _numberOfTeams = customCount;
              });
            }
          }
        },
      ),
    );
  }

  Widget _buildCreateButton() {
    String buttonText;
    Function()? onPressed;

    switch (_currentTabIndex) {
      case 0:
        buttonText = 'Continue to Teams';
        onPressed = () => _tabController.animateTo(1);
        break;
      case 1:
        buttonText = 'Continue to Preview';
        onPressed = () => _tabController.animateTo(2);
        break;
      case 2:
      default:
        buttonText = 'Create Bracket';
        onPressed = _handleCreateBracket;
        break;
    }

    return Container(
      width: double.infinity,
      height: 56,
      margin: const EdgeInsets.symmetric(vertical: 24, horizontal: 12),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.zero,
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 0,
        ),
        child: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF9800), Color(0xFFFF6B35)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF9800).withOpacity(0.25),
                blurRadius: 12,
                spreadRadius: 0,
                offset: const Offset(0, 4),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 8,
                spreadRadius: 0,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  buttonText,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    letterSpacing: 0.5,
                    color: Colors.white,
                    fontFamily: 'SF Pro Display',
                  ),
                ),
                const SizedBox(width: 8),
                const Icon(
                  Icons.arrow_forward_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _handleCreateBracket() {
    // Show loading indicator
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Creating bracket...')),
    );

    // Create bracket and navigate to detail page (allow with mock data)
    Future.delayed(const Duration(milliseconds: 800), () {
      _createBracketAndNavigate();
    });
  }

  void _createBracketAndNavigate() {
    // Create bracket model with the form data
    final bracketName =
        _nameController.text.isEmpty ? 'New Tournament' : _nameController.text;
    final description = _descriptionController.text.isEmpty
        ? 'Tournament bracket'
        : _descriptionController.text;

    // Generate bracket structure
    final rounds = _generateBracketRounds();

    final bracket = BracketModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: bracketName,
      description: description,
      startDate: DateTime.now(),
      participantCount: _numberOfTeams,
      status: BracketStatus.upcoming,
      createdBy: 'Current User',
      createdAt: DateTime.now(),
      rounds: rounds,
      sport: 'Basketball',
      location: _selectedLocation?.name ?? _locationController.text.trim(),
    );

    // Navigate to bracket detail page
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BracketDetailPage(bracket: bracket),
      ),
    ).then((_) {
      // Show success message when returning
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$bracketName created successfully!'),
          backgroundColor: const Color(0xFF4CAF50),
        ),
      );
    });
  }

  List<BracketRoundModel> _generateBracketRounds() {
    final rounds = <BracketRoundModel>[];
    int currentTeamCount = _numberOfTeams;
    int roundNumber = 1;

    // Create teams list with proper seeding
    final teamsForBracket = List<TeamModel>.from(_teams);

    // Fill remaining slots with mock teams if needed
    final mockTeamNames = [
      'Lakers',
      'Celtics',
      'Bulls',
      'Warriors',
      'Heat',
      'Spurs',
      'Knicks',
      'Nets',
      'Clippers',
      'Rockets',
      'Mavericks',
      'Nuggets',
      'Suns',
      'Jazz',
      'Blazers',
      'Kings',
      'Hawks',
      'Magic',
      'Hornets',
      'Pistons',
      'Pacers',
      'Cavaliers',
      'Bucks',
      'Raptors',
      'Sixers',
      'Wizards',
      'Thunder',
      'Pelicans',
      'Grizzlies',
      'Timberwolves',
      'Trail Blazers',
      'Mavericks'
    ];

    while (teamsForBracket.length < _numberOfTeams) {
      final mockIndex = teamsForBracket.length % mockTeamNames.length;
      final teamName = teamsForBracket.length < mockTeamNames.length
          ? mockTeamNames[mockIndex]
          : '${mockTeamNames[mockIndex]} ${(teamsForBracket.length ~/ mockTeamNames.length) + 1}';

      teamsForBracket.add(TeamModel(
        id: 'mock_${teamsForBracket.length + 1}',
        name: teamName,
        colorHex:
            '#${(0x1000000 + (teamsForBracket.length * 0x111111) % 0xffffff).toRadixString(16).substring(1)}',
      ));
    }

    // Generate rounds until we reach the final
    while (currentTeamCount > 1) {
      final matchCount = currentTeamCount ~/ 2;
      final matches = <BracketMatchModel>[];

      // Create matches for this round
      for (int i = 0; i < matchCount; i++) {
        BracketTeamModel? team1;
        BracketTeamModel? team2;

        if (roundNumber == 1) {
          // First round - use actual teams
          final team1Index = i * 2;
          final team2Index = i * 2 + 1;

          if (team1Index < teamsForBracket.length) {
            final teamModel = teamsForBracket[team1Index];
            team1 = BracketTeamModel(
              id: teamModel.id,
              name: teamModel.name,
              seed: team1Index + 1,
              logoUrl: teamModel.logoUrl,
            );
          }
          if (team2Index < teamsForBracket.length) {
            final teamModel = teamsForBracket[team2Index];
            team2 = BracketTeamModel(
              id: teamModel.id,
              name: teamModel.name,
              seed: team2Index + 1,
              logoUrl: teamModel.logoUrl,
            );
          }
        }
        // For subsequent rounds, teams will be determined by previous round winners

        final match = BracketMatchModel(
          id: 'match_${roundNumber}_${i + 1}',
          roundNumber: roundNumber,
          matchNumber: i + 1,
          team1: team1,
          team2: team2,
          scheduledTime: DateTime.now().add(Duration(days: roundNumber - 1)),
        );

        matches.add(match);
      }

      // Create round
      final roundName = _getRoundName(roundNumber - 1, _getRoundCount());
      final round = BracketRoundModel(
        id: 'round_$roundNumber',
        roundNumber: roundNumber,
        name: roundName,
        matches: matches,
        startDate: DateTime.now().add(Duration(days: roundNumber - 1)),
        endDate: DateTime.now().add(Duration(days: roundNumber)),
      );

      rounds.add(round);

      currentTeamCount = matchCount;
      roundNumber++;
    }

    return rounds;
  }

  int _getRoundCount() {
    return _numberOfTeams > 1
        ? (_numberOfTeams - 1).toRadixString(2).length
        : 1;
  }

  void _showMockBracketPreview() {
    final bracketName =
        _nameController.text.isEmpty ? 'New Tournament' : _nameController.text;

    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: double.infinity,
          constraints: const BoxConstraints(maxWidth: 500),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF212121), Colors.black],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFFF9800).withOpacity(0.5)),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF5722).withOpacity(0.3),
                blurRadius: 12,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.sports_basketball, color: Colors.white),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        bracketName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      '$_numberOfTeams Teams Tournament',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 24),
                    _buildMockBracketPreview(),
                    const SizedBox(height: 16),
                    _buildTeamPreview(),
                    const SizedBox(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text(
                            'Edit',
                            style: TextStyle(color: Color(0xFFFF9800)),
                          ),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                            // Return to brackets page
                            Navigator.pop(context);
                            // Show success message
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content:
                                    Text('$bracketName created successfully!'),
                                backgroundColor: const Color(0xFF4CAF50),
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFF5722),
                          ),
                          child: const Text('Confirm'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTeamPreview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Teams',
          style: TextStyle(
            color: Color(0xFFFF9800),
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          height: 100,
          decoration: BoxDecoration(
            color: const Color(0xFF121212),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.white24),
          ),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _teams.length,
            itemBuilder: (context, index) {
              final team = _teams[index];
              return Container(
                width: 80,
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF212121),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFF424242)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: team.colorHex != null
                            ? Color(
                                int.parse('0xFF${team.colorHex!.substring(1)}'))
                            : const Color(0xFF424242),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          team.name.substring(0, 1),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      team.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildMockBracketPreview() {
    // Calculate number of rounds based on team count
    int rounds = (_numberOfTeams - 1).toRadixString(2).length;

    return Container(
      height: 200,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white24),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(rounds, (roundIndex) {
          return Column(
            children: [
              Text(
                'Round ${roundIndex + 1}',
                style: const TextStyle(
                  color: Color(0xFFFF9800),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: Container(
                  width: 80,
                  decoration: BoxDecoration(
                    color: const Color(0xFF212121),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: const Color(0xFF424242)),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.sports_basketball,
                      color: const Color(0xFFFF9800).withOpacity(0.5),
                      size: 24,
                    ),
                  ),
                ),
              ),
            ],
          );
        }),
      ),
    );
  }

  // Teams Tab Methods

  Widget _buildTeamsHeader() {
    final progress = _teams.length / _numberOfTeams;
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A1A1A), Colors.black],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFFF9800).withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF5722).withOpacity(0.2),
            blurRadius: 12,
            spreadRadius: 2,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.groups,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Team Setup',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Build your tournament roster',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: progress >= 1.0
                        ? const LinearGradient(
                            colors: [Color(0xFF4CAF50), Color(0xFF2E7D32)],
                          )
                        : const LinearGradient(
                            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                          ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: (progress >= 1.0
                                ? Colors.green
                                : const Color(0xFFFF5722))
                            .withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        progress >= 1.0
                            ? Icons.check_circle
                            : Icons.sports_basketball,
                        color: Colors.white,
                        size: 16,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '${_teams.length}/${_numberOfTeams}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(2),
              ),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: progress.clamp(0.0, 1.0),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              progress >= 1.0
                  ? 'All teams added! Ready to continue.'
                  : 'Add ${_numberOfTeams - _teams.length} more team${_numberOfTeams - _teams.length == 1 ? '' : 's'} to complete setup',
              style: TextStyle(
                color: progress >= 1.0
                    ? const Color(0xFF4CAF50)
                    : Colors.white.withOpacity(0.6),
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTeamSearchAndCreate() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFFF6B35).withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Create Team Section
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF6B35), Color(0xFFFF8A50)],
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.add_circle_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Add Teams',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A1A),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0xFF404040),
                        width: 1,
                      ),
                    ),
                    child: TextField(
                      controller: _teamNameController,
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                      decoration: InputDecoration(
                        hintText: 'Enter team name...',
                        hintStyle: TextStyle(
                          color: Colors.grey[500],
                          fontSize: 14,
                        ),
                        prefixIcon: Icon(
                          Icons.sports_basketball_rounded,
                          color: const Color(0xFFFF6B35).withOpacity(0.7),
                          size: 20,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 14,
                        ),
                      ),
                      onSubmitted: (_) => _handleCreateTeam(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  height: 48,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF6B35), Color(0xFFFF8A50)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF6B35).withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Material(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                    child: InkWell(
                      onTap: _handleCreateTeam,
                      borderRadius: BorderRadius.circular(12),
                      child: const Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                        child: Text(
                          'Add Team',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _handleCreateTeam() {
    if (_teamNameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a team name'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    final newTeam = TeamModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: _teamNameController.text.trim(),
      colorHex:
          '#${(0x1000000 + (_teams.length * 0x111111) % 0xffffff).toRadixString(16).substring(1)}',
    );

    setState(() {
      _teams.add(newTeam);
      _teamNameController.clear();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${newTeam.name} added successfully!'),
        backgroundColor: const Color(0xFFFF6B35),
      ),
    );
  }

  void _editTeamName(TeamModel team, int index) {
    final TextEditingController editController =
        TextEditingController(text: team.name);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF2A2A2A),
        title: const Text(
          'Edit Team Name',
          style: TextStyle(color: Colors.white),
        ),
        content: TextField(
          controller: editController,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Enter team name',
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white.withOpacity(0.3)),
              borderRadius: BorderRadius.circular(8),
            ),
            focusedBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Color(0xFFFF6B35)),
              borderRadius: BorderRadius.all(Radius.circular(8)),
            ),
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'Cancel',
              style: TextStyle(color: Colors.white.withOpacity(0.7)),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (editController.text.trim().isNotEmpty) {
                setState(() {
                  _teams[index] = TeamModel(
                    id: team.id,
                    name: editController.text.trim(),
                    colorHex: team.colorHex,
                    logoUrl: team.logoUrl,
                  );
                });
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                        'Team name updated to "${editController.text.trim()}"'),
                    backgroundColor: const Color(0xFFFF6B35),
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF6B35),
              foregroundColor: Colors.white,
            ),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _removeTeam(TeamModel team) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF2A2A2A),
        title: const Text(
          'Remove Team',
          style: TextStyle(color: Colors.white),
        ),
        content: Text(
          'Are you sure you want to remove "${team.name}" from the tournament?',
          style: const TextStyle(color: Colors.white),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'Cancel',
              style: TextStyle(color: Colors.white.withOpacity(0.7)),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _teams.remove(team);
              });
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${team.name} removed from tournament'),
                  backgroundColor: Colors.redAccent,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
              foregroundColor: Colors.white,
            ),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamsList() {
    if (_teams.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 16),
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1A1A1A), Color(0xFF0F0F0F)],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: const Color(0xFFFF9800).withOpacity(0.1),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                ),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.groups,
                size: 32,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'No Teams Added Yet',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Create teams for your tournament below',
              style: TextStyle(
                color: Colors.white.withOpacity(0.6),
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A1A1A), Color(0xFF0F0F0F)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFFF9800).withOpacity(0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.check_circle,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Added Teams',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2A2A),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${_teams.length} teams',
                    style: const TextStyle(
                      color: Color(0xFFFF9800),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
          ReorderableListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _teams.length,
            onReorder: (oldIndex, newIndex) {
              setState(() {
                if (newIndex > oldIndex) {
                  newIndex -= 1;
                }
                final team = _teams.removeAt(oldIndex);
                _teams.insert(newIndex, team);
              });
            },
            itemBuilder: (context, index) {
              final team = _teams[index];
              return Container(
                key: ValueKey(team.id),
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.05),
                    width: 1,
                  ),
                ),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  leading: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.drag_handle,
                        color: Colors.white.withOpacity(0.5),
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: team.colorHex != null
                              ? Color(int.parse(
                                  '0xFF${team.colorHex!.substring(1)}'))
                              : const Color(0xFF424242),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: (team.colorHex != null
                                      ? Color(int.parse(
                                          '0xFF${team.colorHex!.substring(1)}'))
                                      : const Color(0xFF424242))
                                  .withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            team.name.substring(0, 1).toUpperCase(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  title: GestureDetector(
                    onTap: () => _editTeamName(team, index),
                    child: Text(
                      team.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  subtitle: Text(
                    'Seed ${index + 1} • Tap name to edit',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 12,
                    ),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF6B35).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: IconButton(
                          icon: const Icon(
                            Icons.edit,
                            color: Color(0xFFFF6B35),
                            size: 18,
                          ),
                          onPressed: () => _editTeamName(team, index),
                        ),
                      ),
                      const SizedBox(width: 4),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: IconButton(
                          icon: const Icon(
                            Icons.remove_circle_outline,
                            color: Colors.redAccent,
                            size: 18,
                          ),
                          onPressed: () => _removeTeam(team),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  // Preview Tab Methods

  Widget _buildPreviewHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF212121), Color(0xFF121212)],
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.account_tree, color: Color(0xFFFF9800), size: 32),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Bracket Preview',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _nameController.text.isEmpty
                      ? 'New Tournament'
                      : _nameController.text,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF333333),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              '$_numberOfTeams Teams',
              style: const TextStyle(
                color: Color(0xFFFF9800),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBracketPreview() {
    // Calculate number of rounds based on team count (used in _buildRoundTabs)

    return Column(
      children: [
        // Round tabs
        _buildRoundTabs(),

        // Bracket content
        Container(
          height: 500,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF121212),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF424242)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 10,
                spreadRadius: 1,
              ),
            ],
          ),
          child: _buildRoundContent(),
        ),
      ],
    );
  }

  // Build functional round tabs with improved design
  Widget _buildRoundTabs() {
    // Calculate number of rounds based on team count
    int roundCount =
        _numberOfTeams > 1 ? (_numberOfTeams - 1).toRadixString(2).length : 1;
    if (roundCount < 1) roundCount = 1;

    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF1F1F1F), Color(0xFF121212)],
        ),
        border: const Border(
          bottom: BorderSide(color: Color(0xFFFF9800), width: 2),
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF5722).withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: List.generate(roundCount, (index) {
            String roundName = _getRoundName(index, roundCount);
            int matchesInRound = _getMatchesInRound(index);
            bool isSelected = index == _selectedRoundIndex;
            bool hasTeams = _teams.length >= 2;

            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 6),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: hasTeams
                      ? () {
                          setState(() {
                            _selectedRoundIndex = index;
                          });
                        }
                      : null,
                  borderRadius: BorderRadius.circular(25),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      gradient: isSelected
                          ? const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                            )
                          : null,
                      border: !isSelected
                          ? Border.all(
                              color: hasTeams ? Colors.white24 : Colors.white12,
                              width: 1,
                            )
                          : null,
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: const Color(0xFFFF5722).withOpacity(0.4),
                                blurRadius: 8,
                                offset: const Offset(0, 4),
                              ),
                            ]
                          : null,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          roundName,
                          style: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : hasTeams
                                    ? Colors.white70
                                    : Colors.white38,
                            fontWeight:
                                isSelected ? FontWeight.bold : FontWeight.w500,
                            fontSize: isSelected ? 16 : 14,
                          ),
                        ),
                        if (hasTeams) ...[
                          const SizedBox(height: 2),
                          Text(
                            '$matchesInRound matches',
                            style: TextStyle(
                              color: isSelected
                                  ? Colors.white.withOpacity(0.9)
                                  : Colors.white54,
                              fontSize: 11,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  // Get round name based on index and total rounds
  String _getRoundName(int index, int totalRounds) {
    switch (totalRounds - index) {
      case 1:
        return 'Final';
      case 2:
        return 'Semifinals';
      case 3:
        return 'Quarterfinals';
      default:
        int teamsInRound = _numberOfTeams ~/ (1 << index);
        return 'Round of $teamsInRound';
    }
  }

  // Get number of matches in a specific round
  int _getMatchesInRound(int roundIndex) {
    if (_numberOfTeams < 2) return 0;
    return _numberOfTeams ~/ (1 << (roundIndex + 1));
  }

  // Build round content based on selected round
  Widget _buildRoundContent() {
    if (_teams.length < 2) {
      return _buildEmptyMatchesView();
    }

    String currentRoundName = _getRoundName(
        _selectedRoundIndex, (_numberOfTeams - 1).toRadixString(2).length);
    int matchesInRound = _getMatchesInRound(_selectedRoundIndex);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Round header
        Container(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1F1F1F), Color(0xFF121212)],
            ),
            border: Border(
              bottom: BorderSide(
                  color: const Color(0xFFFF9800).withOpacity(0.6), width: 2),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 6,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    currentRoundName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Tournament Preview',
                    style: TextStyle(
                      color: const Color(0xFFFF9800).withOpacity(0.9),
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF5722).withOpacity(0.4),
                      blurRadius: 6,
                      spreadRadius: 0,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.sports_basketball,
                      color: Colors.white,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '$matchesInRound matches',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        // Matches list
        Expanded(
          child: _selectedRoundIndex == 0
              ? _buildMatchesList(matchesInRound)
              : _buildFutureRoundPreview(currentRoundName, matchesInRound),
        ),
      ],
    );
  }

  // Build empty matches view
  Widget _buildEmptyMatchesView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFFFF9800).withOpacity(0.2),
                  const Color(0xFFFF5722).withOpacity(0.1),
                ],
              ),
            ),
            child: const Icon(
              Icons.sports_basketball,
              color: Color(0xFFFF9800),
              size: 48,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Add Teams to Preview Bracket',
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            'Go to the Teams tab to add at least 2 teams\nto see the bracket preview',
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // Build future round preview (for rounds beyond the first)
  Widget _buildFutureRoundPreview(String roundName, int matchCount) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFFFF9800).withOpacity(0.2),
                  const Color(0xFFFF5722).withOpacity(0.1),
                ],
              ),
            ),
            child: const Icon(
              Icons.schedule,
              color: Color(0xFFFF9800),
              size: 40,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            roundName,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '$matchCount matches will be determined',
            style: TextStyle(
              color: Colors.white.withOpacity(0.7),
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Teams will advance from previous rounds',
            style: TextStyle(
              color: Colors.white.withOpacity(0.5),
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // Build matches list with proper tournament seeding
  Widget _buildMatchesList(int matchCount) {
    return ListView.builder(
      itemCount: matchCount,
      itemBuilder: (context, index) {
        // Use proper tournament seeding for first round matchups
        final matchup = _getFirstRoundMatchup(index);
        final team1 = matchup['team1'] as TeamModel?;
        final team2 = matchup['team2'] as TeamModel?;
        final seed1 = matchup['seed1'] as int;
        final seed2 = matchup['seed2'] as int;

        return _buildMatchCard(index + 1, team1, team2, seed1, seed2);
      },
    );
  }

  // Get proper first round matchup with tournament seeding
  Map<String, dynamic> _getFirstRoundMatchup(int matchIndex) {
    if (_teams.isEmpty) {
      return {'team1': null, 'team2': null, 'seed1': 0, 'seed2': 0};
    }

    // Standard tournament seeding: 1 vs 16, 2 vs 15, 3 vs 14, etc.
    final seed1 = matchIndex + 1;
    final seed2 = _numberOfTeams - matchIndex;

    final team1 = (seed1 - 1) < _teams.length ? _teams[seed1 - 1] : null;
    final team2 = (seed2 - 1) < _teams.length ? _teams[seed2 - 1] : null;

    return {
      'team1': team1,
      'team2': team2,
      'seed1': seed1,
      'seed2': seed2,
    };
  }

  // Build match card with proper seeding display
  Widget _buildMatchCard(int matchNumber, TeamModel? team1, TeamModel? team2,
      int seed1, int seed2) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      clipBehavior: Clip.antiAlias,
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF212121), Color(0xFF121212)],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTeamRow(team1, seed1),
              const Divider(height: 2, thickness: 1, color: Colors.white24),
              _buildTeamRow(team2, seed2),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(
                  'Match $matchNumber',
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Build team row for match display
  Widget _buildTeamRow(TeamModel? team, int seed) {
    if (team == null) {
      return Container(
        height: 50,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: Colors.grey[700],
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  '$seed',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'TBD',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 16,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              ),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '$seed',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: team.colorHex != null
                  ? Color(int.parse('0xFF${team.colorHex!.substring(1)}'))
                  : const Color(0xFF424242),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: (team.colorHex != null
                          ? Color(
                              int.parse('0xFF${team.colorHex!.substring(1)}'))
                          : const Color(0xFF424242))
                      .withOpacity(0.3),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Center(
              child: Text(
                team.name.substring(0, 1).toUpperCase(),
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              team.name,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  // Build draggable team row in match card
  Widget _buildDraggableTeamRow(
      TeamModel? team, int seed, int matchNumber, bool isTeam1) {
    if (team == null) {
      return DragTarget<TeamModel>(
        onAccept: (draggedTeam) {
          setState(() {
            // Find the team in the list and update the match
            final teamIndex = _teams.indexOf(draggedTeam);
            if (teamIndex != -1) {
              // Calculate the position in the match
              final targetIndex = (matchNumber - 1) * 2 + (isTeam1 ? 0 : 1);
              if (targetIndex < _teams.length) {
                // Swap teams
                final temp = _teams[teamIndex];
                _teams[teamIndex] = _teams[targetIndex];
                _teams[targetIndex] = temp;
              }
            }
          });
        },
        builder: (context, candidateData, rejectedData) {
          return Container(
            height: 50,
            padding: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: candidateData.isNotEmpty
                  ? const Color(0xFFFF9800).withOpacity(0.2)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: candidateData.isNotEmpty
                  ? Border.all(color: const Color(0xFFFF9800), width: 2)
                  : Border.all(
                      color: Colors.white24,
                      width: 1,
                      style: BorderStyle.solid),
            ),
            child: Row(
              children: [
                Container(
                  width: 24,
                  height: 24,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.black38,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    '$seed',
                    style: const TextStyle(
                      color: Colors.white54,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Text(
                      '?',
                      style: TextStyle(
                        color: Colors.white54,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'Drop team here',
                    style: TextStyle(
                      color: Colors.white54,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          );
        },
      );
    }

    return Draggable<TeamModel>(
      data: team,
      feedback: Material(
        color: Colors.transparent,
        child: Container(
          width: 200,
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            ),
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: team.colorHex != null
                      ? Color(int.parse('0xFF${team.colorHex!.substring(1)}'))
                      : Colors.grey[800],
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    team.name.substring(0, 1),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  team.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
      childWhenDragging: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Container(
              width: 24,
              height: 24,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.black38,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                '$seed',
                style: const TextStyle(
                  color: Colors.white38,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: Colors.grey[800]?.withOpacity(0.5),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  team.name.substring(0, 1),
                  style: const TextStyle(
                    color: Colors.white38,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                team.name,
                style: const TextStyle(
                  color: Colors.white38,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
      child: DragTarget<TeamModel>(
        onAccept: (draggedTeam) {
          setState(() {
            // Find both teams in the list and swap them
            final draggedIndex = _teams.indexOf(draggedTeam);
            final currentIndex = _teams.indexOf(team);
            if (draggedIndex != -1 && currentIndex != -1) {
              final temp = _teams[draggedIndex];
              _teams[draggedIndex] = _teams[currentIndex];
              _teams[currentIndex] = temp;
            }
          });
        },
        builder: (context, candidateData, rejectedData) {
          return Container(
            padding: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: candidateData.isNotEmpty
                  ? const Color(0xFFFF9800).withOpacity(0.2)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: candidateData.isNotEmpty
                  ? Border.all(color: const Color(0xFFFF9800), width: 2)
                  : null,
            ),
            child: Row(
              children: [
                Container(
                  width: 24,
                  height: 24,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    '$seed',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: team.colorHex != null
                        ? Color(int.parse('0xFF${team.colorHex!.substring(1)}'))
                        : Colors.grey[800],
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      team.name.substring(0, 1),
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    team.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                const Icon(
                  Icons.drag_indicator,
                  color: Colors.white54,
                  size: 16,
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildBracketVisualization(int rounds) {
    return Row(
      children: List.generate(rounds, (roundIndex) {
        int matchesInRound = _numberOfTeams ~/ (1 << (roundIndex + 1));
        if (matchesInRound == 0) matchesInRound = 1; // Final round

        return Expanded(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  'Round ${roundIndex + 1}',
                  style: const TextStyle(
                    color: Color(0xFFFF9800),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: matchesInRound,
                  itemBuilder: (context, matchIndex) {
                    return _buildVisualizationMatchCard(roundIndex, matchIndex);
                  },
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildVisualizationMatchCard(int roundIndex, int matchIndex) {
    return Container(
      height: 80,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF212121),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF424242)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 4,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Column(
        children: [
          _buildTeamSlot('Team A'),
          Container(
            height: 1,
            color: const Color(0xFF424242),
          ),
          _buildTeamSlot('Team B'),
        ],
      ),
    );
  }

  Widget _buildTeamSlot(String placeholder) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        alignment: Alignment.centerLeft,
        child: Row(
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: const Color(0xFF333333),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Icon(
                  Icons.sports_basketball,
                  color: Color(0xFFFF9800),
                  size: 14,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              placeholder,
              style: TextStyle(
                color: Colors.white.withOpacity(0.7),
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
