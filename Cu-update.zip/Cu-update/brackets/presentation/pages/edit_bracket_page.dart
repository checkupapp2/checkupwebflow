import 'package:flutter/material.dart';
import '../../domain/models/team_model.dart';
import '../../domain/models/bracket_model.dart';
import 'bracket_detail_page.dart';

/// Page for editing an existing tournament bracket
class EditBracketPage extends StatefulWidget {
  /// The bracket to edit
  final BracketModel bracket;

  /// Constructor
  const EditBracketPage({Key? key, required this.bracket}) : super(key: key);

  @override
  State<EditBracketPage> createState() => _EditBracketPageState();
}

class _EditBracketPageState extends State<EditBracketPage>
    with SingleTickerProviderStateMixin {
  // Tab controller
  late TabController _tabController;

  // Current tab index
  int _currentTabIndex = 0;

  // Form key for validation
  final _formKey = GlobalKey<FormState>();

  // Text editing controllers
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _teamNameController = TextEditingController();

  // Number of teams
  int _numberOfTeams = 16;

  // State variables
  int _selectedRoundIndex = 0;
  List<TeamModel> _teams = [];

  // Available team counts
  final List<int> _teamCounts = [4, 8, 16, 32, 64];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(_handleTabChange);

    // Pre-populate with existing bracket data
    _loadExistingBracketData();
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabChange);
    _tabController.dispose();
    _nameController.dispose();
    _descriptionController.dispose();
    _teamNameController.dispose();
    super.dispose();
  }

  /// Load existing bracket data for editing
  void _loadExistingBracketData() {
    _nameController.text = widget.bracket.name;
    _descriptionController.text = widget.bracket.description ?? '';
    _numberOfTeams = widget.bracket.participantCount;

    // Generate teams for the bracket based on participant count
    _generateTeamsForBracket();
  }

  /// Generate teams for the bracket based on participant count
  void _generateTeamsForBracket() {
    final teams = <TeamModel>[];

    // Comprehensive team names for all bracket sizes (up to 64 teams)
    final teamNames = [
      'Lakers',
      'Warriors',
      'Celtics',
      'Heat',
      'Bulls',
      'Knicks',
      'Nets',
      'Sixers',
      'Bucks',
      'Raptors',
      'Hawks',
      'Magic',
      'Hornets',
      'Wizards',
      'Pistons',
      'Pacers',
      'Cavaliers',
      'Thunder',
      'Nuggets',
      'Clippers',
      'Suns',
      'Jazz',
      'Blazers',
      'Kings',
      'Spurs',
      'Mavericks',
      'Rockets',
      'Grizzlies',
      'Pelicans',
      'Timberwolves',
      'Wolves',
      'Lions',
      'Tigers',
      'Eagles',
      'Falcons',
      'Ravens',
      'Cardinals',
      'Panthers',
      'Jaguars',
      'Dolphins',
      'Sharks',
      'Bears',
      'Rams',
      'Chargers',
      'Raiders',
      'Chiefs',
      'Broncos',
      'Colts',
      'Titans',
      'Texans',
      'Steelers',
      'Browns',
      'Bengals',
      'Bills',
      'Jets',
      'Patriots',
      'Giants',
      'Cowboys',
      'Redskins',
      'Packers',
      'Vikings',
      'Saints',
      'Buccaneers',
      'Seahawks'
    ];

    for (int i = 0; i < _numberOfTeams; i++) {
      final teamName = teamNames[i];
      teams.add(TeamModel(
        id: 'team_${DateTime.now().millisecondsSinceEpoch}_$i',
        name: teamName,
      ));
    }

    _teams = teams;
  }

  /// Handle tab change
  void _handleTabChange() {
    if (_tabController.index != _currentTabIndex) {
      setState(() {
        _currentTabIndex = _tabController.index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Edit Bracket',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Tab bar
          _buildTabBar(),
          // Tab content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildDetailsTab(),
                _buildTeamsTab(),
                _buildPreviewTab(),
              ],
            ),
          ),
          // Update button
          _buildUpdateButton(),
        ],
      ),
    );
  }

  /// Build tab bar
  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(25),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
          ),
          borderRadius: BorderRadius.circular(25),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey,
        labelStyle: const TextStyle(fontWeight: FontWeight.bold),
        tabs: const [
          Tab(text: 'DETAILS'),
          Tab(text: 'TEAMS'),
          Tab(text: 'PREVIEW'),
        ],
      ),
    );
  }

  /// Build details tab
  Widget _buildDetailsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Tournament name
            _buildInputField(
              'Tournament Name',
              _nameController,
              'Enter tournament name',
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter a tournament name';
                }
                return null;
              },
            ),
            const SizedBox(height: 20),
            // Description
            _buildInputField(
              'Description (Optional)',
              _descriptionController,
              'Enter tournament description',
              maxLines: 3,
            ),
            const SizedBox(height: 20),
            // Team count selection
            _buildTeamCountSelection(),
          ],
        ),
      ),
    );
  }

  /// Build teams tab
  Widget _buildTeamsTab() {
    return Column(
      children: [
        // Team input section
        Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Add Teams',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _teamNameController,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'Enter team name',
                        hintStyle: TextStyle(color: Colors.grey[400]),
                        filled: true,
                        fillColor: const Color(0xFF1A1A1A),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                      ),
                      onSubmitted: (_) => _addTeam(),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _addTeam,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFF9800),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text('Add'),
                  ),
                ],
              ),
            ],
          ),
        ),
        // Teams list
        Expanded(
          child: _buildTeamsList(),
        ),
      ],
    );
  }

  /// Build preview tab
  Widget _buildPreviewTab() {
    return Column(
      children: [
        // Preview header
        Container(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              const Icon(
                Icons.account_tree,
                color: Color(0xFFFF9800),
                size: 30,
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Bracket Preview',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    _nameController.text.isEmpty
                        ? 'Tournament'
                        : _nameController.text,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                  ),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Text(
                  '${_teams.length} Teams',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
        // Round tabs
        if (_teams.length >= 2) _buildRoundTabs(),
        // Round content
        Expanded(
          child: _buildRoundContent(),
        ),
      ],
    );
  }

  /// Build input field
  Widget _buildInputField(
    String label,
    TextEditingController controller,
    String hint, {
    int maxLines = 1,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          maxLines: maxLines,
          style: const TextStyle(color: Colors.white),
          validator: validator,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: Colors.grey[400]),
            filled: true,
            fillColor: const Color(0xFF1A1A1A),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFFF9800), width: 2),
            ),
          ),
        ),
      ],
    );
  }

  /// Build team count selection
  Widget _buildTeamCountSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Number of Teams',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          children: _teamCounts.map((count) {
            final isSelected = _numberOfTeams == count;
            return GestureDetector(
              onTap: () {
                setState(() {
                  _numberOfTeams = count;
                });
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: isSelected
                      ? const LinearGradient(
                          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                        )
                      : null,
                  color: isSelected ? null : const Color(0xFF1A1A1A),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected ? Colors.transparent : Colors.grey[600]!,
                  ),
                ),
                child: Text(
                  '$count',
                  style: TextStyle(
                    color: isSelected ? Colors.white : Colors.grey[400],
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  /// Build teams list
  Widget _buildTeamsList() {
    if (_teams.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.groups,
              size: 60,
              color: Colors.grey[600],
            ),
            const SizedBox(height: 16),
            Text(
              'No teams added yet',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    }

    return ReorderableListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      itemCount: _teams.length,
      onReorder: (oldIndex, newIndex) {
        setState(() {
          if (newIndex > oldIndex) newIndex--;
          final team = _teams.removeAt(oldIndex);
          _teams.insert(newIndex, team);
        });
      },
      itemBuilder: (context, index) {
        final team = _teams[index];
        return Container(
          key: ValueKey(team.id),
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF2A2A2A),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: const Color(0xFF3A3A3A),
              width: 1,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // Team icon
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF6F00)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.account_tree,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                // Team name
                Expanded(
                  child: Text(
                    team.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // Action buttons
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Edit button
                    GestureDetector(
                      onTap: () => _editTeamName(index),
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: const Color(0xFF1976D2).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.edit_outlined,
                          color: Color(0xFF1976D2),
                          size: 18,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Delete button
                    GestureDetector(
                      onTap: () => _removeTeam(index),
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: const Color(0xFFD32F2F).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.delete_outline,
                          color: Color(0xFFD32F2F),
                          size: 18,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Drag handle
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: const Color(0xFF424242).withOpacity(0.3),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.drag_indicator,
                        color: Color(0xFF9E9E9E),
                        size: 18,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Build round tabs
  Widget _buildRoundTabs() {
    int roundCount =
        _numberOfTeams > 1 ? (_numberOfTeams - 1).toRadixString(2).length : 1;
    if (roundCount < 1) roundCount = 1;

    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF1F1F1F), Color(0xFF121212)],
        ),
        border: const Border(
          bottom: BorderSide(color: Color(0xFFFF9800), width: 2),
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF5722).withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: List.generate(roundCount, (index) {
            String roundName = _getRoundName(index, roundCount);
            int matchesInRound = _getMatchesInRound(index);
            bool isSelected = index == _selectedRoundIndex;
            bool hasTeams = _teams.length >= 2;

            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 6),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: hasTeams
                      ? () {
                          setState(() {
                            _selectedRoundIndex = index;
                          });
                        }
                      : null,
                  borderRadius: BorderRadius.circular(25),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      gradient: isSelected
                          ? const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                            )
                          : null,
                      border: !isSelected
                          ? Border.all(
                              color: hasTeams ? Colors.white24 : Colors.white12,
                              width: 1,
                            )
                          : null,
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: const Color(0xFFFF5722).withOpacity(0.4),
                                blurRadius: 8,
                                offset: const Offset(0, 4),
                              ),
                            ]
                          : null,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          roundName,
                          style: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : hasTeams
                                    ? Colors.white70
                                    : Colors.white38,
                            fontWeight:
                                isSelected ? FontWeight.bold : FontWeight.w500,
                            fontSize: isSelected ? 16 : 14,
                          ),
                        ),
                        if (hasTeams) ...[
                          const SizedBox(height: 2),
                          Text(
                            '$matchesInRound matches',
                            style: TextStyle(
                              color: isSelected
                                  ? Colors.white.withOpacity(0.9)
                                  : Colors.white54,
                              fontSize: 11,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  /// Build round content
  Widget _buildRoundContent() {
    if (_teams.length < 2) {
      return _buildEmptyMatchesView();
    }

    int matchCount = _getMatchesInRound(_selectedRoundIndex);
    return _buildMatchesList(matchCount);
  }

  /// Build empty matches view
  Widget _buildEmptyMatchesView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.account_tree,
            size: 80,
            color: Colors.grey[600],
          ),
          const SizedBox(height: 20),
          Text(
            'Add teams to see bracket preview',
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  /// Build matches list
  Widget _buildMatchesList(int matchCount) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: matchCount,
      itemBuilder: (context, index) {
        final matchup = _getFirstRoundMatchup(index);
        return _buildMatchCard(index + 1, matchup['team1'], matchup['team2'],
            matchup['seed1'], matchup['seed2']);
      },
    );
  }

  /// Build match card
  Widget _buildMatchCard(
      int matchNumber, String? team1, String? team2, int? seed1, int? seed2) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1F1F1F), Color(0xFF121212)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFFF9800).withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              'Match $matchNumber',
              style: const TextStyle(
                color: Color(0xFFFF9800),
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            _buildTeamRow(team1, seed1),
            const SizedBox(height: 8),
            Container(
              height: 1,
              color: Colors.grey[700],
            ),
            const SizedBox(height: 8),
            _buildTeamRow(team2, seed2),
          ],
        ),
      ),
    );
  }

  /// Build team row with drag functionality
  Widget _buildTeamRow(String? teamName, int? seed) {
    if (teamName == null) {
      return Row(
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: Colors.grey[700],
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(
              child: Text(
                '?',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'TBD',
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      );
    }

    return Draggable<Map<String, dynamic>>(
      data: {
        'teamName': teamName,
        'seed': seed,
      },
      feedback: Material(
        color: Colors.transparent,
        child: Container(
          width: 200,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFFFF9800),
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(
                    '$seed',
                    style: const TextStyle(
                      color: Color(0xFFFF9800),
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  teamName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
      childWhenDragging: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.grey[800]!.withOpacity(0.5),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: Colors.grey[600]!,
            style: BorderStyle.solid,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  '$seed',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                teamName,
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
      child: DragTarget<Map<String, dynamic>>(
        onAccept: (data) {
          setState(() {
            // Find the teams in the list and swap their positions
            final draggedTeamName = data['teamName'] as String;
            final draggedSeed = data['seed'] as int;

            // Find indices of both teams
            int draggedIndex =
                _teams.indexWhere((team) => team.name == draggedTeamName);
            int targetIndex =
                _teams.indexWhere((team) => team.name == teamName);

            if (draggedIndex != -1 && targetIndex != -1) {
              // Swap the teams
              final temp = _teams[draggedIndex];
              _teams[draggedIndex] = _teams[targetIndex];
              _teams[targetIndex] = temp;
            }
          });
        },
        builder: (context, candidateData, rejectedData) {
          final isHovering = candidateData.isNotEmpty;

          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: isHovering
                  ? const Color(0xFFFF9800).withOpacity(0.2)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: isHovering
                  ? Border.all(
                      color: const Color(0xFFFF9800),
                      width: 2,
                    )
                  : null,
            ),
            child: Row(
              children: [
                Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFF9800),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      '$seed',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    teamName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Icon(
                  Icons.drag_indicator,
                  color: Colors.grey[400],
                  size: 16,
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  /// Build update button
  Widget _buildUpdateButton() {
    String buttonText;
    Function()? onPressed;

    switch (_currentTabIndex) {
      case 0:
        buttonText = 'CONTINUE TO TEAMS';
        onPressed = () => _tabController.animateTo(1);
        break;
      case 1:
        buttonText = 'CONTINUE TO PREVIEW';
        onPressed = () => _tabController.animateTo(2);
        break;
      case 2:
      default:
        buttonText = 'UPDATE BRACKET';
        onPressed = _handleUpdateBracket;
        break;
    }

    return Container(
      width: double.infinity,
      height: 70,
      margin: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF5722).withOpacity(0.6),
            blurRadius: 20,
            spreadRadius: 4,
            offset: const Offset(0, 6),
          ),
          BoxShadow(
            color: const Color(0xFFFF9800).withOpacity(0.3),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.zero,
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          elevation: 0,
        ),
        child: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              stops: [0.0, 1.0],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: Center(
            child: Text(
              buttonText,
              style: const TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 20,
                letterSpacing: 1.5,
                color: Colors.white,
                fontFamily: 'System',
                shadows: [
                  Shadow(
                    color: Colors.black26,
                    offset: Offset(0, 2),
                    blurRadius: 4,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Add team
  void _addTeam() {
    final teamName = _teamNameController.text.trim();
    if (teamName.isNotEmpty && _teams.length < _numberOfTeams) {
      setState(() {
        _teams.add(TeamModel(
          id: 'team_${DateTime.now().millisecondsSinceEpoch}',
          name: teamName,
        ));
        _teamNameController.clear();
      });
    }
  }

  /// Edit team name
  void _editTeamName(int index) {
    final currentName = _teams[index].name;
    final controller = TextEditingController(text: currentName);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title:
            const Text('Edit Team Name', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: controller,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Enter team name',
            hintStyle: TextStyle(color: Colors.grey[400]),
            filled: true,
            fillColor: const Color(0xFF2A2A2A),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () {
              if (controller.text.trim().isNotEmpty) {
                setState(() {
                  _teams[index] = TeamModel(
                    id: _teams[index].id,
                    name: controller.text.trim(),
                  );
                });
                Navigator.pop(context);
              }
            },
            child:
                const Text('Save', style: TextStyle(color: Color(0xFFFF9800))),
          ),
        ],
      ),
    );
  }

  /// Remove team
  void _removeTeam(int index) {
    setState(() {
      _teams.removeAt(index);
    });
  }

  /// Get round name
  String _getRoundName(int index, int totalRounds) {
    switch (totalRounds - index) {
      case 1:
        return 'Final';
      case 2:
        return 'Semifinals';
      case 3:
        return 'Quarterfinals';
      default:
        int teamsInRound = _numberOfTeams ~/ (1 << index);
        return 'Round of $teamsInRound';
    }
  }

  /// Get matches in round
  int _getMatchesInRound(int roundIndex) {
    if (_numberOfTeams < 2) return 0;
    return _numberOfTeams ~/ (1 << (roundIndex + 1));
  }

  /// Get first round matchup
  Map<String, dynamic> _getFirstRoundMatchup(int matchIndex) {
    if (_selectedRoundIndex != 0) {
      return {
        'team1': 'Winner of Match ${matchIndex * 2 + 1}',
        'team2': 'Winner of Match ${matchIndex * 2 + 2}',
        'seed1': null,
        'seed2': null,
      };
    }

    final seed1 = matchIndex * 2 + 1;
    final seed2 = _numberOfTeams - (matchIndex * 2);

    String? team1;
    String? team2;

    if (seed1 <= _teams.length) {
      team1 = _teams[seed1 - 1].name;
    }
    if (seed2 <= _teams.length) {
      team2 = _teams[seed2 - 1].name;
    }

    return {
      'team1': team1,
      'team2': team2,
      'seed1': seed1,
      'seed2': seed2,
    };
  }

  /// Handle update bracket
  void _handleUpdateBracket() {
    if (_formKey.currentState?.validate() ?? false) {
      // Create updated bracket
      final updatedBracket = BracketModel(
        id: widget.bracket.id,
        name: _nameController.text,
        description: _descriptionController.text.isEmpty
            ? ''
            : _descriptionController.text,
        startDate: widget.bracket.startDate,
        endDate: widget.bracket.endDate,
        participantCount: _numberOfTeams,
        status: widget.bracket.status,
        createdBy: widget.bracket.createdBy,
        createdAt: widget.bracket.createdAt,
      );

      // Navigate to bracket detail page
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => BracketDetailPage(bracket: updatedBracket),
        ),
      );

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Bracket updated successfully!'),
          backgroundColor: Color(0xFFFF9800),
        ),
      );
    }
  }
}
