import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:check_up_app/core/routes/app_router.dart';
import '../../data/brackets_data_provider.dart';
import '../../domain/models/bracket_model.dart';
import '../../../search/domain/models/league_model.dart';

/// Page to display list of brackets for a specific league
class LeagueBracketsPage extends StatefulWidget {
  /// The league to display brackets for
  final LeagueModel league;

  /// Constructor
  const LeagueBracketsPage({
    super.key,
    required this.league,
  });

  @override
  State<LeagueBracketsPage> createState() => _LeagueBracketsPageState();
}

class _LeagueBracketsPageState extends State<LeagueBracketsPage> {
  // Data provider for brackets
  final BracketsDataProvider _bracketsDataProvider = BracketsDataProvider();
  
  // List of brackets
  late List<BracketModel> _brackets;
  
  // Filter status
  BracketStatus? _filterStatus;

  @override
  void initState() {
    super.initState();
    // Get brackets for this specific league
    _brackets = _bracketsDataProvider.getBracketsByLeagueId(widget.league.id);
  }

  // Filter brackets based on status
  List<BracketModel> _filterBrackets() {
    if (_filterStatus == null) {
      return _brackets;
    }
    return _brackets.where((bracket) => bracket.status == _filterStatus).toList();
  }

  // Build app bar
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2A2A2A),
              Color(0xFF121212),
            ],
          ),
        ),
      ),
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: Colors.white),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF9800),
                  Color(0xFFFF5722),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.3),
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: const Icon(
              Icons.emoji_events_outlined,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'BRACKETS',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    letterSpacing: 0.5,
                  ),
                ),
                Text(
                  widget.league.name,
                  style: TextStyle(
                    color: Colors.grey[300],
                    fontSize: 14,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.search, color: Colors.white, size: 28),
          onPressed: () {
            // TODO: Implement search functionality
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredBrackets = _filterBrackets();
    
    return Scaffold(
      backgroundColor: Color(0xFF121212),
      appBar: _buildAppBar(),
      body: RefreshIndicator(
        onRefresh: () async {
          // In a real app, this would refresh data from a server
          setState(() {
            _brackets = _bracketsDataProvider.getBrackets();
          });
        },
        color: const Color(0xFFFF9800),
        backgroundColor: Colors.grey[900],
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildFilterChips(),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _filterStatus == null 
                              ? 'All Brackets' 
                              : '${_filterStatus.toString().split('.').last} Brackets',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.grey[800],
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '${filteredBrackets.length} found',
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            filteredBrackets.isEmpty
                ? SliverFillRemaining(
                    child: _buildEmptyState(),
                  )
                : SliverList(
                    delegate: SliverChildListDelegate([
                      ...filteredBrackets.map((bracket) => Padding(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                        child: _buildBracketListItem(bracket),
                      )).toList(),
                      const SizedBox(height: 24),
                    ]),
                  ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _handleCreateBracket,
        backgroundColor: const Color(0xFFFF9800),
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  // Build filter chips for bracket status
  Widget _buildFilterChips() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: Colors.black,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(
          children: [
            _buildFilterChip('All', null),
            const SizedBox(width: 8),
            _buildFilterChip('Upcoming', BracketStatus.upcoming),
            const SizedBox(width: 8),
            _buildFilterChip('In Progress', BracketStatus.inProgress),
            const SizedBox(width: 8),
            _buildFilterChip('Completed', BracketStatus.completed),
          ],
        ),
      ),
    );
  }

  // Build individual filter chip
  Widget _buildFilterChip(String label, BracketStatus? status) {
    final isSelected = _filterStatus == status;
    
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _handleFilterTap(status),
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            gradient: isSelected 
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFFF9800),
                      Color(0xFFFF5722),
                    ],
                  )
                : LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF333333),
                      Color(0xFF222222),
                    ],
                  ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: isSelected ? [
              BoxShadow(
                color: Color(0xFFFF9800).withOpacity(0.3),
                blurRadius: 4,
                offset: Offset(0, 2),
              ),
            ] : null,
          ),
          child: Row(
            children: [
              if (isSelected)
                const Padding(
                  padding: EdgeInsets.only(right: 6),
                  child: Icon(
                    Icons.check_circle,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Build empty state when no brackets match filter
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            ).createShader(bounds),
            child: const Icon(
              Icons.emoji_events_outlined,
              size: 80,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            _filterStatus == null
                ? 'No brackets found'
                : 'No ${_filterStatus.toString().split('.').last} brackets found',
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Create a new bracket to get started',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[400],
            ),
          ),
          const SizedBox(height: 32),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withOpacity(0.4),
                  blurRadius: 12,
                  spreadRadius: 2,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _handleCreateBracket,
                borderRadius: BorderRadius.circular(30),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.add, color: Colors.white, size: 24),
                      SizedBox(width: 12),
                      Text(
                        'Create Bracket',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  // Build status chip
  Widget _buildStatusChip(BracketStatus status) {
    Color chipColor;
    String statusText;
    
    switch (status) {
      case BracketStatus.upcoming:
        chipColor = Colors.blue;
        statusText = 'Upcoming';
        break;
      case BracketStatus.inProgress:
        chipColor = Colors.green;
        statusText = 'Live';
        break;
      case BracketStatus.completed:
        chipColor = Colors.purple;
        statusText = 'Completed';
        break;
      case BracketStatus.cancelled:
        chipColor = Colors.red;
        statusText = 'Cancelled';
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: chipColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        statusText,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: chipColor,
        ),
      ),
    );
  }
  
  // Build bracket list item
  Widget _buildBracketListItem(BracketModel bracket) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF333333),
            Color(0xFF222222),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: () => _handleBracketTap(bracket),
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFFFF9800),
                      ),
                      child: const Icon(
                        Icons.emoji_events_outlined,
                        color: Colors.white,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        bracket.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    _buildStatusChip(bracket.status),
                  ],
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.only(left: 38),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${bracket.participantCount} Teams • Round ${bracket.currentRound ?? "null"}',
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(
                            Icons.calendar_today,
                            size: 14,
                            color: Color(0xFFFF9800),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            _formatDate(bracket.startDate),
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.white70,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            'By ${bracket.createdBy}',
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.white54,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
  // Format date to readable string
  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 0) {
      return 'In ${-difference.inDays} days';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      final month = _getMonthName(date.month);
      return '$month ${date.day}';
    }
  }
  
  // Get month name from month number
  String _getMonthName(int month) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return months[month - 1];
  }

  // Handle filter tap
  void _handleFilterTap(BracketStatus? status) {
    HapticFeedback.mediumImpact();
    setState(() {
      _filterStatus = _filterStatus == status ? null : status;
    });
  }

  // Handle bracket tap
  void _handleBracketTap(BracketModel bracket) {
    HapticFeedback.mediumImpact();
    // Navigate to bracket detail page
    Navigator.pushNamed(
      context,
      AppRouter.bracketDetailRoute,
      arguments: {'bracket': bracket},
    );
  }

  // Handle create bracket button tap
  void _handleCreateBracket() {
    HapticFeedback.mediumImpact();
    // Navigate to create bracket page
    Navigator.pushNamed(
      context,
      AppRouter.createBracketRoute,
    );
  }
}
