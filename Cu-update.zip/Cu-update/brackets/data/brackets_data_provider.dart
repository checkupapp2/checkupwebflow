import '../domain/models/bracket_model.dart';

/// Provider class for brackets data
class BracketsDataProvider {
  /// Get list of all brackets
  List<BracketModel> getBrackets() {
    return _getMockBrackets();
  }

  /// Get list of brackets for a specific league
  List<BracketModel> getBracketsByLeagueId(String leagueId) {
    // In a real app, this would filter brackets by league ID from a database or API
    // For now, we'll return all brackets since this is mock data
    return _getMockBrackets();
  }

  /// Get mock brackets data
  List<BracketModel> _getMockBrackets() {
    // Mock data for brackets with valid tournament sizes (4, 8, 16, 32, 64)
    return [
      BracketModel(
        id: '1',
        name: 'Summer Slam Tournament',
        description:
            '3v3 tournament with 16 teams competing for the championship',
        startDate: DateTime.now().subtract(const Duration(days: 2)),
        endDate: DateTime.now().add(const Duration(days: 5)),
        participantCount: 16,
        status: BracketStatus.inProgress,
        createdBy: 'current_user_id', // User owns this bracket
        createdAt: DateTime.now().subtract(const Duration(days: 14)),
      ),
      BracketModel(
        id: '2',
        name: 'Winter Classic',
        description: '5v5 full court tournament',
        startDate: DateTime.now().add(const Duration(days: 10)),
        endDate: DateTime.now().add(const Duration(days: 12)),
        participantCount: 8,
        status: BracketStatus.upcoming,
        createdBy: 'other_user_id', // User does not own this bracket
        createdAt: DateTime.now().subtract(const Duration(days: 5)),
      ),
      BracketModel(
        id: '3',
        name: 'Neighborhood Championship',
        description: 'Local players competing in single elimination bracket',
        startDate: DateTime.now().subtract(const Duration(days: 20)),
        endDate: DateTime.now().subtract(const Duration(days: 15)),
        participantCount: 32,
        status: BracketStatus.completed,
        createdBy: 'other_user_id', // User does not own this bracket
        createdAt: DateTime.now().subtract(const Duration(days: 30)),
      ),
      BracketModel(
        id: '4',
        name: 'Youth Development League',
        description: 'Tournament for players under 18',
        startDate: DateTime.now().add(const Duration(days: 15)),
        endDate: DateTime.now().add(const Duration(days: 18)),
        participantCount: 4,
        status: BracketStatus.upcoming,
        createdBy: 'current_user_id', // User owns this bracket
        createdAt: DateTime.now().subtract(const Duration(days: 2)),
      ),
      BracketModel(
        id: '5',
        name: 'Corporate Challenge',
        description: 'Companies competing for bragging rights',
        startDate: DateTime.now().subtract(const Duration(days: 10)),
        endDate: DateTime.now().subtract(const Duration(days: 8)),
        participantCount: 64,
        status: BracketStatus.completed,
        createdBy: 'other_user_id', // User does not own this bracket
        createdAt: DateTime.now().subtract(const Duration(days: 20)),
      ),
    ];
  }
}
