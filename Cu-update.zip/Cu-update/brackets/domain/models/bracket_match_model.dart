/// Model class for a match in a tournament bracket
class BracketMatchModel {
  /// Unique identifier for the match
  final String id;
  
  /// Round number this match belongs to (e.g., 1 for Round of 64, 2 for Round of 32)
  final int roundNumber;
  
  /// Position of this match within its round
  final int matchNumber;
  
  /// First team/player in the match
  final BracketTeamModel? team1;
  
  /// Second team/player in the match
  final BracketTeamModel? team2;
  
  /// Score for team 1
  final int? team1Score;
  
  /// Score for team 2
  final int? team2Score;
  
  /// ID of the winning team
  final String? winnerId;
  
  /// Whether the match has been completed
  final bool isCompleted;
  
  /// Date and time when the match is scheduled
  final DateTime? scheduledTime;
  
  /// Location of the match
  final String? location;
  
  /// ID of the team the user picked to win this match
  final String? userPickId;
  
  /// Points earned by the user for this match
  final int? pointsEarned;
  
  /// Constructor
  const BracketMatchModel({
    required this.id,
    required this.roundNumber,
    required this.matchNumber,
    this.team1,
    this.team2,
    this.team1Score,
    this.team2Score,
    this.winnerId,
    this.isCompleted = false,
    this.scheduledTime,
    this.location,
    this.userPickId,
    this.pointsEarned,
  });
  
  /// Alias for roundNumber to match existing code
  int get round => roundNumber;
  
  /// Alias for team1Score to match existing code
  int? get score1 => team1Score;
  
  /// Alias for team2Score to match existing code
  int? get score2 => team2Score;
  
  /// Alias for scheduledTime to match existing code
  DateTime? get matchTime => scheduledTime;
  
  /// Check if user's pick was correct
  bool get isUserPickCorrect {
    if (userPickId == null || winnerId == null || !isCompleted) return false;
    return userPickId == winnerId;
  }
  
  /// Get the winner team model
  BracketTeamModel? get winner {
    if (winnerId == null) return null;
    if (team1?.id == winnerId) return team1;
    if (team2?.id == winnerId) return team2;
    return null;
  }
  
  /// Get the loser team model
  BracketTeamModel? get loser {
    if (winnerId == null || !isCompleted) return null;
    if (team1?.id != winnerId) return team1;
    if (team2?.id != winnerId) return team2;
    return null;
  }
  
  /// Check if a team is in this match
  bool hasTeam(String teamId) {
    return team1?.id == teamId || team2?.id == teamId;
  }
  
  /// Create a copy of this model with given fields replaced
  BracketMatchModel copyWith({
    String? id,
    int? roundNumber,
    int? matchNumber,
    BracketTeamModel? team1,
    BracketTeamModel? team2,
    int? team1Score,
    int? team2Score,
    String? winnerId,
    bool? isCompleted,
    DateTime? scheduledTime,
    String? location,
  }) {
    return BracketMatchModel(
      id: id ?? this.id,
      roundNumber: roundNumber ?? this.roundNumber,
      matchNumber: matchNumber ?? this.matchNumber,
      team1: team1 ?? this.team1,
      team2: team2 ?? this.team2,
      team1Score: team1Score ?? this.team1Score,
      team2Score: team2Score ?? this.team2Score,
      winnerId: winnerId ?? this.winnerId,
      isCompleted: isCompleted ?? this.isCompleted,
      scheduledTime: scheduledTime ?? this.scheduledTime,
      location: location ?? this.location,
    );
  }
}

/// Model class for a team/player in a bracket
class BracketTeamModel {
  /// Unique identifier for the team
  final String id;
  
  /// Name of the team/player
  final String name;
  
  /// Seed number in the tournament
  final int seed;
  
  /// Logo/image URL for the team
  final String? logoUrl;
  
  /// Team abbreviation
  final String? abbreviation;
  
  /// Team record (e.g., "25-10")
  final String? record;
  
  /// Constructor
  const BracketTeamModel({
    required this.id,
    required this.name,
    required this.seed,
    this.logoUrl,
    this.abbreviation,
    this.record,
  });
  
  /// Create a copy of this model with given fields replaced
  BracketTeamModel copyWith({
    String? id,
    String? name,
    int? seed,
    String? logoUrl,
    String? abbreviation,
    String? record,
  }) {
    return BracketTeamModel(
      id: id ?? this.id,
      name: name ?? this.name,
      seed: seed ?? this.seed,
      logoUrl: logoUrl ?? this.logoUrl,
      abbreviation: abbreviation ?? this.abbreviation,
      record: record ?? this.record,
    );
  }
}
