import 'bracket_round_model.dart';
import 'bracket_match_model.dart';

/// Model class for tournament brackets
class BracketModel {
  /// Unique identifier for the bracket
  final String id;
  
  /// Name of the bracket/tournament
  final String name;
  
  /// Description of the bracket/tournament
  final String description;
  
  /// Date when the bracket/tournament starts
  final DateTime startDate;
  
  /// Date when the bracket/tournament ends
  final DateTime? endDate;
  
  /// Number of teams/players in the bracket
  final int participantCount;
  
  /// Status of the bracket (e.g., upcoming, in-progress, completed)
  final BracketStatus status;
  
  /// Creator of the bracket
  final String createdBy;
  
  /// Date when the bracket was created
  final DateTime createdAt;
  
  /// List of rounds in the tournament
  final List<BracketRoundModel>? rounds;
  
  /// Region/division name (e.g., "South", "West")
  final String? region;
  
  /// Sport or category of the tournament
  final String? sport;
  
  /// Location of the tournament
  final String? location;
  
  /// User's pick for the champion
  final BracketTeamModel? userChampionPick;
  
  /// Actual champion of the tournament
  final BracketTeamModel? actualChampion;
  
  /// Constructor
  const BracketModel({
    required this.id,
    required this.name,
    required this.description,
    required this.startDate,
    this.endDate,
    required this.participantCount,
    required this.status,
    required this.createdBy,
    required this.createdAt,
    this.rounds,
    this.region,
    this.sport,
    this.location,
    this.userChampionPick,
    this.actualChampion,
  });
  
  /// Get the current round of the tournament
  BracketRoundModel? get currentRound {
    if (rounds == null || rounds!.isEmpty) return null;
    
    // If tournament hasn't started, return the first round
    if (status == BracketStatus.upcoming) return rounds!.first;
    
    // If tournament is completed, return the last round
    if (status == BracketStatus.completed) return rounds!.last;
    
    // For in-progress tournaments, find the first incomplete round
    for (final round in rounds!) {
      if (!round.isCompleted) return round;
    }
    
    // Default to the last round if all are complete but status isn't updated
    return rounds!.last;
  }
  
  /// Get the completion percentage of the tournament
  double get completionPercentage {
    if (rounds == null || rounds!.isEmpty) return 0.0;
    
    int totalMatches = 0;
    int completedMatches = 0;
    
    for (final round in rounds!) {
      totalMatches += round.matches.length;
      completedMatches += round.matches.where((match) => match.isCompleted).length;
    }
    
    return totalMatches > 0 ? completedMatches / totalMatches : 0.0;
  }
  
  /// Create a copy of this model with given fields replaced
  BracketModel copyWith({
    String? id,
    String? name,
    String? description,
    DateTime? startDate,
    DateTime? endDate,
    int? participantCount,
    BracketStatus? status,
    String? createdBy,
    DateTime? createdAt,
    List<BracketRoundModel>? rounds,
    String? region,
    String? sport,
    String? location,
    BracketTeamModel? userChampionPick,
    BracketTeamModel? actualChampion,
  }) {
    return BracketModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      participantCount: participantCount ?? this.participantCount,
      status: status ?? this.status,
      createdBy: createdBy ?? this.createdBy,
      createdAt: createdAt ?? this.createdAt,
      rounds: rounds ?? this.rounds,
      region: region ?? this.region,
      sport: sport ?? this.sport,
      location: location ?? this.location,
      userChampionPick: userChampionPick ?? this.userChampionPick,
      actualChampion: actualChampion ?? this.actualChampion,
    );
  }
}

/// Enum for bracket status
enum BracketStatus {
  /// Bracket is upcoming and hasn't started yet
  upcoming,
  
  /// Bracket is currently in progress
  inProgress,
  
  /// Bracket has been completed
  completed,
  
  /// Bracket has been cancelled
  cancelled,
}
