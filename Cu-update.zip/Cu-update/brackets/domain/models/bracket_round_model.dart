import 'bracket_match_model.dart';

/// Model class for a round in a tournament bracket
class BracketRoundModel {
  /// Unique identifier for the round
  final String id;
  
  /// Round number (e.g., 1 for Round of 64, 2 for Round of 32)
  final int roundNumber;
  
  /// Name of the round (e.g., "Round of 64", "Sweet 16")
  final String name;
  
  /// List of matches in this round
  final List<BracketMatchModel> matches;
  
  /// Start date of the round
  final DateTime? startDate;
  
  /// End date of the round
  final DateTime? endDate;
  
  /// Constructor
  const BracketRoundModel({
    required this.id,
    required this.roundNumber,
    required this.name,
    required this.matches,
    this.startDate,
    this.endDate,
  });
  
  /// Get the number of matches in this round
  int get matchCount => matches.length;
  
  /// Get the number of teams in this round
  int get teamCount => matchCount * 2;
  
  /// Check if the round is completed
  bool get isCompleted => matches.every((match) => match.isCompleted);
  
  /// Get the completion percentage of the round
  double get completionPercentage {
    if (matches.isEmpty) return 0.0;
    final completedMatches = matches.where((match) => match.isCompleted).length;
    return completedMatches / matches.length;
  }
  
  /// Create a copy of this model with given fields replaced
  BracketRoundModel copyWith({
    String? id,
    int? roundNumber,
    String? name,
    List<BracketMatchModel>? matches,
    DateTime? startDate,
    DateTime? endDate,
  }) {
    return BracketRoundModel(
      id: id ?? this.id,
      roundNumber: roundNumber ?? this.roundNumber,
      name: name ?? this.name,
      matches: matches ?? this.matches,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
    );
  }
}

/// Helper class for common round names in tournaments
class BracketRoundNames {
  static const String roundOf64 = 'Round of 64';
  static const String roundOf32 = 'Round of 32';
  static const String sweet16 = 'Sweet 16';
  static const String elite8 = 'Elite 8';
  static const String final4 = 'Final Four';
  static const String championship = 'Championship';
  
  /// Get the standard name for a round based on the number of teams
  static String getNameByTeamCount(int teamCount) {
    switch (teamCount) {
      case 64: return roundOf64;
      case 32: return roundOf32;
      case 16: return sweet16;
      case 8: return elite8;
      case 4: return final4;
      case 2: return championship;
      default: return 'Round of $teamCount';
    }
  }
  
  /// Get the standard name for a round based on the round number in a 64-team tournament
  static String getNameByRoundNumber(int roundNumber) {
    switch (roundNumber) {
      case 1: return roundOf64;
      case 2: return roundOf32;
      case 3: return sweet16;
      case 4: return elite8;
      case 5: return final4;
      case 6: return championship;
      default: return 'Round $roundNumber';
    }
  }
}
