/// Model representing a team in a bracket
class TeamModel {
  /// Unique identifier for the team
  final String id;
  
  /// Name of the team
  final String name;
  
  /// Optional logo URL
  final String? logoUrl;
  
  /// Optional team color
  final String? colorHex;
  
  /// Optional team description
  final String? description;
  
  /// Constructor
  const TeamModel({
    required this.id,
    required this.name,
    this.logoUrl,
    this.colorHex,
    this.description,
  });
  
  /// Create a copy of this team with modified fields
  TeamModel copyWith({
    String? id,
    String? name,
    String? logoUrl,
    String? colorHex,
    String? description,
  }) {
    return TeamModel(
      id: id ?? this.id,
      name: name ?? this.name,
      logoUrl: logoUrl ?? this.logoUrl,
      colorHex: colorHex ?? this.colorHex,
      description: description ?? this.description,
    );
  }
}
