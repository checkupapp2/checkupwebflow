import 'package:equatable/equatable.dart';

class ProfileEntity extends Equatable {
  final String id;
  final String username;
  final String fullName;
  final String? profileImageUrl;

  // From screenshots
  final String? bio;
  final String? location;
  final String? email;
  final String? phone;
  final bool? isPaymentVerified;
  final String? skillLevel; // "intermediate"
  final List<String>? roles; // ["player"]
  final List<String>? favoriteContent; // ["liveGames"]
  final List<String>? preferredEvents; // ["pickup","leagues"]
  final Map<String, String>? socialLinks; // instagram/twitter/facebook

  final String? status; // short status line
  final String? checkedInAt; // e.g. "Rucker Park"
  final String? profileType; // derived from roles[0] if you want
  final String? about; // long "About Me"
  final String? careerHighlights;

  // Verification block
  final String? verificationStatus; // "unverified" | "verified" | ...
  final String? verificationReason; // nullable
  final String? personaInquiryId; // nullable

  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? authMethod; // "google"

  const ProfileEntity({
    required this.id,
    required this.username,
    required this.fullName,
    this.profileImageUrl,
    this.bio,
    this.location,
    this.email,
    this.phone,
    this.isPaymentVerified,
    this.skillLevel,
    this.roles,
    this.favoriteContent,
    this.preferredEvents,
    this.socialLinks,
    this.status,
    this.checkedInAt,
    this.profileType,
    this.about,
    this.careerHighlights,
    this.verificationStatus,
    this.verificationReason,
    this.personaInquiryId,
    this.createdAt,
    this.updatedAt,
    this.authMethod,
  });

  ProfileEntity copyWith({
    String? username,
    String? fullName,
    String? profileImageUrl,
    String? bio,
    String? location,
    String? phone,
    bool? isPaymentVerified,
    String? skillLevel,
    List<String>? roles,
    List<String>? favoriteContent,
    List<String>? preferredEvents,
    Map<String, String>? socialLinks,
    String? status,
    String? checkedInAt,
    String? profileType,
    String? about,
    String? careerHighlights,
    String? verificationStatus,
    String? verificationReason,
    String? personaInquiryId,
    DateTime? updatedAt,
  }) {
    return ProfileEntity(
      id: id,
      username: username ?? this.username,
      fullName: fullName ?? this.fullName,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      bio: bio ?? this.bio,
      location: location ?? this.location,
      email: email, // immutable here; set through auth system if you want
      phone: phone ?? this.phone,
      isPaymentVerified: isPaymentVerified ?? this.isPaymentVerified,
      skillLevel: skillLevel ?? this.skillLevel,
      roles: roles ?? this.roles,
      favoriteContent: favoriteContent ?? this.favoriteContent,
      preferredEvents: preferredEvents ?? this.preferredEvents,
      socialLinks: socialLinks ?? this.socialLinks,
      status: status ?? this.status,
      checkedInAt: checkedInAt ?? this.checkedInAt,
      profileType: profileType ?? this.profileType,
      about: about ?? this.about,
      careerHighlights: careerHighlights ?? this.careerHighlights,
      verificationStatus: verificationStatus ?? this.verificationStatus,
      verificationReason: verificationReason ?? this.verificationReason,
      personaInquiryId: personaInquiryId ?? this.personaInquiryId,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      authMethod: authMethod,
    );
  }

  @override
  List<Object?> get props => [
        id,
        username,
        fullName,
        profileImageUrl,
        bio,
        location,
        email,
        phone,
        isPaymentVerified,
        skillLevel,
        roles,
        favoriteContent,
        preferredEvents,
        socialLinks,
        status,
        checkedInAt,
        profileType,
        about,
        careerHighlights,
        verificationStatus,
        verificationReason,
        personaInquiryId,
        createdAt,
        updatedAt,
        authMethod,
      ];
}

class ProfileUpdate {
  final String fullName;
  final String username;
  final String? status;
  final String? checkedInAt;
  final Map<String, String>? socialLinks;
  final String? profileImageUrl;
  final String? profileType;
  final String? about;
  final String? careerHighlights;
  final String? bio;
  final String? location;
  final String? phone;
  final String? skillLevel;
  final List<String>? roles;
  final List<String>? favoriteContent;
  final List<String>? preferredEvents;

  ProfileUpdate({
    required this.fullName,
    required this.username,
    this.status,
    this.checkedInAt,
    this.socialLinks,
    this.profileImageUrl,
    this.profileType,
    this.about,
    this.careerHighlights,
    this.bio,
    this.location,
    this.phone,
    this.skillLevel,
    this.roles,
    this.favoriteContent,
    this.preferredEvents,
  });
}
