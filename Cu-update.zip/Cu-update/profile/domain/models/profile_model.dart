import 'player_stats_model.dart';

/// Model class for user profile data
class ProfileModel {
  /// User ID
  final String id;
  
  /// User's username
  final String username;
  
  /// User's full name
  final String fullName;
  
  /// URL to user's profile image
  final String? profileImageUrl;
  
  /// Number of followers
  final int followers;
  
  /// Number of following
  final int following;
  
  /// Number of check-ins
  final int checkIns;
  
  /// Number of games played
  final int gamesPlayed;
  
  /// Whether the user is currently online
  final bool isOnline;
  
  /// Whether the current user is following this user
  final bool isFollowing;
  
  /// Social media links
  final Map<String, String>? socialLinks;
  
  /// Current status (e.g., "Checked-in at Rucker Park")
  final String? status;
  
  /// Location of current check-in
  final String? checkedInAt;
  
  /// Player rank or level (e.g., "Superstar", "All-Star", "Rookie")
  final String? playerRank;
  
  /// Whether the user has active stories
  final bool hasActiveStories;
  
  /// Player statistics
  final PlayerStatsModel? playerStats;
  
  /// Recent games
  final List<RecentGameModel>? recentGames;
  
  /// Teams
  final List<TeamModel>? teams;
  
  /// Leagues
  final List<LeagueModel>? leagues;
  
  /// Awards
  final List<PlayerAwardModel>? awards;

  /// Constructor
  ProfileModel({
    required this.id,
    required this.username,
    required this.fullName,
    this.profileImageUrl,
    this.followers = 0,
    this.following = 0,
    this.checkIns = 0,
    this.gamesPlayed = 0,
    this.isOnline = false,
    this.isFollowing = false,
    this.socialLinks,
    this.status,
    this.checkedInAt,
    this.playerRank,
    this.hasActiveStories = false,
    this.playerStats,
    this.recentGames,
    this.teams,
    this.leagues,
    this.awards,
  });
  
  /// Create a sample profile for testing
  factory ProfileModel.sample() {
    return ProfileModel(
      id: '123',
      username: '@michael_jordan',
      fullName: 'Michael Jordan',
      profileImageUrl: 'https://randomuser.me/api/portraits/men/32.jpg',
      followers: 1256,
      following: 423,
      checkIns: 87,
      gamesPlayed: 142,
      isOnline: true,
      isFollowing: false,
      socialLinks: {
        'instagram': 'https://instagram.com/michael_jordan',
        'twitter': 'https://twitter.com/michael_jordan',
        'facebook': 'https://facebook.com/michael_jordan',
      },
      status: 'Checked-in at Rucker Park',
      checkedInAt: 'Rucker Park',
      playerRank: 'Superstar',
      hasActiveStories: true,
      playerStats: PlayerStatsModel.sample(),
      recentGames: RecentGameModel.getSampleGames(),
      teams: TeamModel.getSampleTeams(),
      leagues: LeagueModel.getSampleLeagues(),
      awards: PlayerAwardModel.getSampleAwards(),
    );
  }
}
