/// Model class for player statistics
class PlayerStatsModel {
  /// Points per game
  final double pointsPerGame;
  
  /// Assists per game
  final double assistsPerGame;
  
  /// Rebounds per game
  final double reboundsPerGame;
  
  /// Field goal percentage
  final double fieldGoalPercentage;
  
  /// Three-point percentage
  final double threePointPercentage;
  
  /// Free throw percentage
  final double freeThrowPercentage;
  
  /// Total games played
  final int gamesPlayed;
  
  /// Total wins
  final int wins;
  
  /// Total losses
  final int losses;
  
  /// Constructor
  const PlayerStatsModel({
    required this.pointsPerGame,
    required this.assistsPerGame,
    required this.reboundsPerGame,
    required this.fieldGoalPercentage,
    required this.threePointPercentage,
    required this.freeThrowPercentage,
    required this.gamesPlayed,
    required this.wins,
    required this.losses,
  });
  
  /// Create a sample player stats for testing
  factory PlayerStatsModel.sample() {
    return const PlayerStatsModel(
      pointsPerGame: 22.5,
      assistsPerGame: 5.8,
      reboundsPerGame: 7.2,
      fieldGoalPercentage: 48.3,
      threePointPercentage: 37.6,
      freeThrowPercentage: 85.2,
      gamesPlayed: 142,
      wins: 98,
      losses: 44,
    );
  }
}

/// Model class for a recent game
class RecentGameModel {
  /// Game ID
  final String id;
  
  /// Game location
  final String location;
  
  /// Game date
  final DateTime date;
  
  /// Game result (W/L)
  final String result;
  
  /// Score (e.g., "21-15")
  final String score;
  
  /// Player's points in this game
  final int playerPoints;
  
  /// Player's assists in this game
  final int playerAssists;
  
  /// Player's rebounds in this game
  final int playerRebounds;
  
  /// Game image URL
  final String? imageUrl;
  
  /// Constructor
  const RecentGameModel({
    required this.id,
    required this.location,
    required this.date,
    required this.result,
    required this.score,
    required this.playerPoints,
    required this.playerAssists,
    required this.playerRebounds,
    this.imageUrl,
  });
  
  /// Create sample recent games for testing
  static List<RecentGameModel> getSampleGames() {
    return [
      RecentGameModel(
        id: '1',
        location: 'Rucker Park Pickup',
        date: DateTime.now().subtract(const Duration(days: 2)),
        result: 'W',
        score: '21-15',
        playerPoints: 18,
        playerAssists: 6,
        playerRebounds: 4,
        imageUrl: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      ),
      RecentGameModel(
        id: '2',
        location: 'Brooklyn Bridge 3v3',
        date: DateTime.now().subtract(const Duration(days: 5)),
        result: 'W',
        score: '15-12',
        playerPoints: 12,
        playerAssists: 3,
        playerRebounds: 5,
        imageUrl: 'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      ),
      RecentGameModel(
        id: '3',
        location: 'Downtown League',
        date: DateTime.now().subtract(const Duration(days: 8)),
        result: 'L',
        score: '18-21',
        playerPoints: 14,
        playerAssists: 7,
        playerRebounds: 3,
        imageUrl: 'https://images.unsplash.com/photo-1505666287802-931dc83a5dc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      ),
      RecentGameModel(
        id: '4',
        location: 'Harlem Streetball',
        date: DateTime.now().subtract(const Duration(days: 12)),
        result: 'W',
        score: '21-14',
        playerPoints: 16,
        playerAssists: 4,
        playerRebounds: 8,
        imageUrl: 'https://images.unsplash.com/photo-1518650868956-6ded1c8a6c2f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      ),
      RecentGameModel(
        id: '5',
        location: 'Queens Community Court',
        date: DateTime.now().subtract(const Duration(days: 15)),
        result: 'W',
        score: '21-19',
        playerPoints: 20,
        playerAssists: 2,
        playerRebounds: 6,
        imageUrl: 'https://images.unsplash.com/photo-1504450758481-7338eba7524a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      ),
    ];
  }
}

/// Model class for a team
class TeamModel {
  /// Team ID
  final String id;
  
  /// Team name
  final String name;
  
  /// Team logo URL
  final String? logoUrl;
  
  /// Team record (e.g., "12-4")
  final String record;
  
  /// Team league
  final String league;
  
  /// Constructor
  const TeamModel({
    required this.id,
    required this.name,
    this.logoUrl,
    required this.record,
    required this.league,
  });
  
  /// Create sample teams for testing
  static List<TeamModel> getSampleTeams() {
    return [
      TeamModel(
        id: '1',
        name: 'Brooklyn Ballers',
        logoUrl: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80',
        record: '12-4',
        league: 'NYC Amateur League',
      ),
      TeamModel(
        id: '2',
        name: 'Harlem Hustlers',
        logoUrl: 'https://images.unsplash.com/photo-1518650868956-6ded1c8a6c2f?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80',
        record: '8-6',
        league: 'Downtown League',
      ),
    ];
  }
}

/// Model class for a league
class LeagueModel {
  /// League ID
  final String id;
  
  /// League name
  final String name;
  
  /// League logo URL
  final String? logoUrl;
  
  /// League season
  final String season;
  
  /// League location
  final String location;
  
  /// Constructor
  const LeagueModel({
    required this.id,
    required this.name,
    this.logoUrl,
    required this.season,
    required this.location,
  });
  
  /// Create sample leagues for testing
  static List<LeagueModel> getSampleLeagues() {
    return [
      LeagueModel(
        id: '1',
        name: 'NYC Amateur League',
        logoUrl: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80',
        season: 'Summer 2025',
        location: 'New York City',
      ),
      LeagueModel(
        id: '2',
        name: 'Downtown League',
        logoUrl: 'https://images.unsplash.com/photo-1518650868956-6ded1c8a6c2f?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80',
        season: 'Spring 2025',
        location: 'Manhattan',
      ),
    ];
  }
}

/// Model class for a player award/badge
class PlayerAwardModel {
  /// Award ID
  final String id;
  
  /// Award name
  final String name;
  
  /// Award description
  final String description;
  
  /// Award icon
  final String icon;
  
  /// Award color
  final String color;
  
  /// Date awarded
  final DateTime dateAwarded;
  
  /// Constructor
  const PlayerAwardModel({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    required this.color,
    required this.dateAwarded,
  });
  
  /// Create sample awards for testing
  static List<PlayerAwardModel> getSampleAwards() {
    return [
      PlayerAwardModel(
        id: '1',
        name: 'MVP',
        description: 'Most Valuable Player in the NYC Amateur League',
        icon: 'trophy',
        color: '#FFD700', // Gold
        dateAwarded: DateTime.now().subtract(const Duration(days: 30)),
      ),
      PlayerAwardModel(
        id: '2',
        name: 'ALL TOURNAMENT',
        description: 'Selected for the All-Tournament Team',
        icon: 'medal',
        color: '#CD7F32', // Bronze
        dateAwarded: DateTime.now().subtract(const Duration(days: 45)),
      ),
      PlayerAwardModel(
        id: '3',
        name: 'Hustler',
        description: 'Most steals in a single game',
        icon: 'bolt',
        color: '#FF4500', // Orange Red
        dateAwarded: DateTime.now().subtract(const Duration(days: 60)),
      ),
      PlayerAwardModel(
        id: '4',
        name: 'Crowd Favorite',
        description: 'Voted fan favorite player of the month',
        icon: 'star',
        color: '#1E90FF', // Dodger Blue
        dateAwarded: DateTime.now().subtract(const Duration(days: 90)),
      ),
      PlayerAwardModel(
        id: '5',
        name: 'Sharpshooter',
        description: 'Highest 3-point percentage in the league',
        icon: 'target',
        color: '#32CD32', // Lime Green
        dateAwarded: DateTime.now().subtract(const Duration(days: 120)),
      ),
    ];
  }
}
