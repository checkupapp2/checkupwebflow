import 'package:flutter/material.dart';

/// Enum for event type (hosting or attending)
enum ProfileEventType {
  /// User is hosting this event
  hosting,

  /// User is attending this event
  attending
}

/// Enum for event status
enum ProfileEventStatus {
  /// Event is happening today
  today,

  /// Event is upcoming
  upcoming,

  /// Event has already happened
  past
}

/// Model representing an event
class ProfileEventModel {
  /// Unique identifier for the event
  final String id;

  /// Event title
  final String title;

  /// Event location
  final String location;

  /// Game type (e.g., '3v3 Tournament', 'Open Play')
  final String gameType;

  /// Event date and time in display format
  final String date;

  /// Original DateTime for sorting and status determination
  final DateTime dateTime;

  /// Price information (e.g., 'Free', '$15 entry fee')
  final String price;

  /// Rating out of 5
  final double rating;

  /// Number of reviews/attendees
  final int reviews;

  /// Host name
  final String hostName;

  /// Thumbnail image URL
  final String thumbnailUrl;

  /// List of image URLs for the event
  final List<String> imageUrls;

  /// Whether the user is registered for this event
  final bool isRegistered;

  /// Event type (hosting or attending)
  final ProfileEventType type;

  /// Event status (today, upcoming, past)
  final ProfileEventStatus status;

  /// Number of attendees for the event
  final int attendeeCount;

  /// Color associated with the event for UI purposes
  final Color color;

  /// Icon associated with the event for UI purposes
  final IconData icon;

  /// Whether the user has confirmed attendance
  final bool isConfirmed;

  /// Optional description of the event
  final String? description;

  /// Constructor
  const ProfileEventModel({
    required this.id,
    required this.title,
    required this.location,
    required this.gameType,
    required this.date,
    required this.dateTime,
    required this.price,
    required this.rating,
    required this.reviews,
    required this.hostName,
    required this.thumbnailUrl,
    required this.imageUrls,
    this.isRegistered = false,
    required this.type,
    required this.status,
    this.attendeeCount = 0,
    this.color = Colors.blue,
    this.icon = Icons.event,
    this.isConfirmed = false,
    this.description,
  });

  /// Get sample events
  static List<ProfileEventModel> getSampleEvents() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    return [
      ProfileEventModel(
        id: '1',
        title: 'Basketball Tournament',
        location: 'Central Park, Court 3',
        gameType: '3v3 Tournament',
        date: 'Today, 6:00 PM',
        dateTime: today.add(const Duration(hours: 18)),
        price: 'Free',
        rating: 4.8,
        reviews: 24,
        hostName: 'Michael J.',
        thumbnailUrl:
            'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=1000&auto=format&fit=crop',
        imageUrls: [
          'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=1000&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=1000&auto=format&fit=crop',
        ],
        type: ProfileEventType.attending,
        status: ProfileEventStatus.today,
        attendeeCount: 12,
        color: Colors.blue,
        icon: Icons.sports_basketball,
        isConfirmed: true,
        description:
            'Join us for an exciting 3v3 basketball tournament at Central Park!',
      ),
      ProfileEventModel(
        id: '2',
        title: 'Pickup Game',
        location: 'Venice Beach Courts',
        gameType: 'Casual Play',
        date: 'Today, 8:00 PM',
        dateTime: today.add(const Duration(hours: 20)),
        price: '5 dollars entry',
        rating: 4.5,
        reviews: 12,
        hostName: 'You',
        thumbnailUrl:
            'https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=1000&auto=format&fit=crop',
        imageUrls: [
          'https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=1000&auto=format&fit=crop',
        ],
        type: ProfileEventType.hosting,
        status: ProfileEventStatus.today,
        attendeeCount: 8,
        color: Colors.purple,
        icon: Icons.fitness_center,
        isConfirmed: false,
        description:
            'Casual pickup game at Venice Beach. All skill levels welcome!',
      ),
      ProfileEventModel(
        id: '3',
        title: 'City League Tournament',
        location: 'City Sports Arena',
        gameType: 'Tournament',
        date: 'Jun 15, 10:00 AM',
        dateTime: today.add(const Duration(days: 2, hours: 10)),
        price: '15 dollars entry fee',
        rating: 4.9,
        reviews: 48,
        hostName: 'Coach Mike',
        thumbnailUrl:
            'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?q=80&w=1000&auto=format&fit=crop',
        imageUrls: [
          'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?q=80&w=1000&auto=format&fit=crop',
        ],
        type: ProfileEventType.attending,
        status: ProfileEventStatus.upcoming,
        attendeeCount: 24,
        color: Colors.pink,
        icon: Icons.people,
        isConfirmed: true,
        description: 'Official city league tournament with prizes for winners.',
      ),
      ProfileEventModel(
        id: '4',
        title: 'Pro Training Session',
        location: 'Elite Training Center',
        gameType: 'Training',
        date: 'Jun 16, 5:00 PM',
        dateTime: today.add(const Duration(days: 3, hours: 17)),
        price: '25 dollars',
        rating: 4.9,
        reviews: 8,
        hostName: 'Coach Mike',
        thumbnailUrl:
            'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?q=80&w=1000&auto=format&fit=crop',
        imageUrls: [
          'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?q=80&w=1000&auto=format&fit=crop',
        ],
        type: ProfileEventType.attending,
        status: ProfileEventStatus.upcoming,
        attendeeCount: 8,
        color: Colors.purple,
        icon: Icons.fitness_center,
        isConfirmed: false,
        description: 'Professional training session with former NBA players.',
      ),
      ProfileEventModel(
        id: '6',
        title: 'League Game',
        description: 'Regular season game against Rockets',
        location: 'Main Stadium',
        gameType: 'League Match',
        date: 'Jun 21, 7:00 PM',
        dateTime:
            today.add(const Duration(days: 7, hours: 19)), // In 7 days at 7 PM
        price: 'Free',
        rating: 4.7,
        reviews: 32,
        hostName: 'League Officials',
        thumbnailUrl:
            'https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=1000&auto=format&fit=crop',
        imageUrls: [
          'https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=1000&auto=format&fit=crop',
        ],
        isRegistered: true,
        type: ProfileEventType.attending,
        status: ProfileEventStatus.upcoming,
        attendeeCount: 15,
        color: Colors.amber,
        icon: Icons.sports_basketball,
        isConfirmed: true,
      ),
    ];
  }
}
