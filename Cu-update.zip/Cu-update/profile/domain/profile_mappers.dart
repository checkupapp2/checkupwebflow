import 'profile_entity.dart';
import '../../profile/domain/models/profile_model.dart' as ui;

/// Convert domain entity to your existing UI model (ProfileModel.sample structure)
ui.ProfileModel toUi(ProfileEntity e) {
  return ui.ProfileModel(
    id: e.id,
    username: e.username,
    fullName: e.fullName,
    profileImageUrl: e.profileImageUrl,
    followers: 1256, // keep sample counts until backed
    following: 423,
    checkIns: 87,
    gamesPlayed: 142,
    isOnline: true,
    isFollowing: false,
    socialLinks: e.socialLinks,
    status: e.status,
    checkedInAt: e.checkedInAt ?? e.location,
    playerRank: 'Superstar',
    hasActiveStories: true,
    playerStats: null,
    recentGames: null,
    teams: null,
    leagues: null,
    awards: null,
  );
}
