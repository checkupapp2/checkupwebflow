/// Provider for award-related data
class AwardDataProvider {
  /// Get events that led to a specific award
  List<Map<String, dynamic>> getAwardEvents(String awardId) {
    // In a real app, this would fetch data from an API or database
    // For now, we'll return mock data based on the award ID
    
    switch (awardId) {
      case '1': // MVP
        return [
          {
            'date': 'June 15, 2025',
            'location': 'NYC Amateur League Finals',
            'title': 'Championship Game',
            'stats': [
              '32 PTS', '8 AST', '6 REB', '55% FG'
            ],
          },
          {
            'date': 'June 10, 2025',
            'location': 'NYC Amateur League Semifinals',
            'title': 'Semifinal Game',
            'stats': [
              '28 PTS', '10 AST', '5 REB', '60% FG'
            ],
          },
          {
            'date': 'June 5, 2025',
            'location': 'NYC Amateur League Quarterfinals',
            'title': 'Quarterfinal Game',
            'stats': [
              '25 PTS', '7 AST', '4 REB', '52% FG'
            ],
          },
          {
            'date': 'May 25, 2025',
            'location': 'NYC Amateur League Regular Season',
            'title': 'Season Stats',
            'stats': [
              '24.5 PPG', '6.8 APG', '5.2 RPG', '53% FG', '12 Double-Doubles'
            ],
          },
        ];
      
      case '2': // Hustler
        return [
          {
            'date': 'May 12, 2025',
            'location': 'Downtown League',
            'title': 'Record-Breaking Game',
            'stats': [
              '8 STL', '3 BLK', '18 PTS', '6 AST'
            ],
          },
          {
            'date': 'May 5, 2025',
            'location': 'Downtown League',
            'title': 'Defensive Showcase',
            'stats': [
              '6 STL', '2 BLK', '15 PTS', '4 AST'
            ],
          },
          {
            'date': 'April 28, 2025',
            'location': 'Downtown League',
            'title': 'Season Stats',
            'stats': [
              '3.2 SPG', '1.5 BPG', 'Defensive Rating: 95.2'
            ],
          },
        ];
      
      case '3': // Crowd Favorite
        return [
          {
            'date': 'April 1, 2025',
            'location': 'NYC Amateur League',
            'title': 'Fan Vote Results',
            'stats': [
              '68% of Fan Votes', '1,245 Total Votes'
            ],
          },
          {
            'date': 'March 25, 2025',
            'location': 'NYC Amateur League',
            'title': 'Highlight Game',
            'stats': [
              '22 PTS', '9 AST', '360° Dunk', 'Game-Winning Shot'
            ],
          },
          {
            'date': 'March 15, 2025',
            'location': 'NYC Amateur League',
            'title': 'Community Event',
            'stats': [
              'Youth Clinic Host', 'Charity Game MVP'
            ],
          },
        ];
      
      case '4': // Sharpshooter
        return [
          {
            'date': 'March 5, 2025',
            'location': 'NYC Amateur League',
            'title': 'Three-Point Contest Winner',
            'stats': [
              '18/25 3PT Made', 'Final Round: 9 Consecutive Makes'
            ],
          },
          {
            'date': 'February 28, 2025',
            'location': 'NYC Amateur League',
            'title': 'Record-Breaking Game',
            'stats': [
              '8/10 3PT', '26 PTS', '80% 3PT'
            ],
          },
          {
            'date': 'February 15, 2025',
            'location': 'NYC Amateur League',
            'title': 'Season Stats',
            'stats': [
              '42.8% 3PT', '2.5 3PM per Game', '90.2% FT'
            ],
          },
        ];
      
      default:
        return [
          {
            'date': 'June 1, 2025',
            'location': 'NYC Amateur League',
            'title': 'Award Achievement',
            'stats': [
              'Outstanding Performance'
            ],
          },
        ];
    }
  }
}
