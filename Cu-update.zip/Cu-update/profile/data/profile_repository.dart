import 'dart:io';
import '../domain/profile_entity.dart';

abstract class ProfileRepository {
  Future<ProfileEntity> getCurrent();
  Future<ProfileEntity> update(ProfileUpdate input);
  Future<String?> uploadAvatar(File file); // returns new url
}

/// ----- Mock impl you can swap later -----
class MockProfileRepository implements ProfileRepository {
  ProfileEntity _cache = const ProfileEntity(
    id: '123',
    username: '@44michael_jordan',
    fullName: '44Michael Jordan',
    status: 'Checked-in at Rucker Park',
    checkedInAt: 'Rucker Park',
    profileImageUrl: 'https://randomuser.me/api/portraits/men/32.jpg',
    socialLinks: {
      'instagram': 'https://instagram.com/michael_jordan',
      'twitter': 'https://twitter.com/michael_jordan',
      'facebook': 'https://facebook.com/michael_jordan',
    },
  );

  @override
  Future<ProfileEntity> getCurrent() async {
    await Future.delayed(const Duration(milliseconds: 300));
    return _cache;
  }

  @override
  Future<ProfileEntity> update(ProfileUpdate input) async {
    await Future.delayed(const Duration(milliseconds: 300));
    _cache = _cache.copyWith(
      fullName: input.fullName,
      username: input.username,
      status: input.status,
      checkedInAt: input.checkedInAt,
      profileImageUrl: input.profileImageUrl ?? _cache.profileImageUrl,
      socialLinks: input.socialLinks ?? _cache.socialLinks,
      profileType: input.profileType ?? _cache.profileType,
      about: input.about ?? _cache.about,
      careerHighlights: input.careerHighlights ?? _cache.careerHighlights,
    );
    return _cache;
  }

  @override
  Future<String?> uploadAvatar(File file) async {
    await Future.delayed(const Duration(milliseconds: 500));
    // Return a pretend URL
    return 'https://img.example.com/avatars/${DateTime.now().millisecondsSinceEpoch}.jpg';
  }
}
