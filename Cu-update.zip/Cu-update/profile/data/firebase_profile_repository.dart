import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import '../domain/profile_entity.dart';
import '../data/firestore_profile_doc.dart';
import 'profile_repository.dart';

class FirebaseProfileRepository implements ProfileRepository {
  FirebaseProfileRepository({
    FirebaseAuth? auth,
    FirebaseFirestore? firestore,
    FirebaseStorage? storage,
  })  : _auth = auth ?? FirebaseAuth.instance,
        _db = firestore ?? FirebaseFirestore.instance,
        _storage = storage ?? FirebaseStorage.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;
  final FirebaseStorage _storage;

  CollectionReference<Map<String, dynamic>> get _users =>
      _db.collection(FirestoreProfileDoc.collection);

  String get _uid {
    final user = _auth.currentUser;
    if (user == null) {
      throw StateError('No signed-in user');
    }
    return user.uid;
  }

  @override
  Future<ProfileEntity> getCurrent() async {
    final snap = await _users.doc(_uid).get();
    if (!snap.exists) {
      // Optionally create a skeleton doc
      await _users.doc(_uid).set({
        'fullName': _auth.currentUser?.displayName ?? '',
        'username': _auth.currentUser?.email?.split('@').first ?? '',
        'email': _auth.currentUser?.email,
        'photoUrl': _auth.currentUser?.photoURL,
        'authMethod': _auth.currentUser?.providerData.isNotEmpty == true
            ? _auth.currentUser!.providerData.first.providerId
            : null,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'verification': {'status': 'unverified'},
      }, SetOptions(merge: true));
      final created = await _users.doc(_uid).get();
      return FirestoreProfileDoc.fromSnapshot(created);
    }
    return FirestoreProfileDoc.fromSnapshot(snap);
  }

  @override
  Future<ProfileEntity> update(ProfileUpdate input) async {
    final data = FirestoreProfileDoc.toUpdateMap(input);
    await _users.doc(_uid).set(data, SetOptions(merge: true));
    final snap = await _users.doc(_uid).get();
    return FirestoreProfileDoc.fromSnapshot(snap);
  }

  @override
  Future<String?> uploadAvatar(File file) async {
    // final ref = _storage.ref().child(
    //     'profile_images/$_uid/avatar_${DateTime.now().millisecondsSinceEpoch}.jpg');

    const folder = 'profile-images'; // ← match your rules + onboarding
    final ref = _storage.ref(
        '$folder/$_uid/avatar_${DateTime.now().millisecondsSinceEpoch}.jpg');
    final task =
        await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    final url = await task.ref.getDownloadURL();

    // persist photoUrl immediately
    await _users.doc(_uid).set({
      'photoUrl': url,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    return url;
  }
}
