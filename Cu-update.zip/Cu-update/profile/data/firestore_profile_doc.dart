import 'package:cloud_firestore/cloud_firestore.dart';
import '../domain/profile_entity.dart';

class FirestoreProfileDoc {
  static const collection = 'users';

  static ProfileEntity fromSnapshot(
      DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    final verification = (d['verification'] as Map?) ?? {};
    final social = (d['socialLinks'] as Map?)?.cast<String, String>();

    return ProfileEntity(
      id: doc.id,
      username: (d['username'] ?? '').toString(),
      fullName: (d['fullName'] ?? '').toString(),
      profileImageUrl: d['photoUrl'] as String?,
      bio: d['bio'] as String?,
      location: d['location'] as String?,
      email: d['email'] as String?,
      phone: d['phone'] as String?,
      isPaymentVerified: d['isPaymentVerified'] as bool?,
      skillLevel: d['skillLevel'] as String?,
      roles: (d['roles'] as List?)?.map((e) => e.toString()).toList(),
      favoriteContent:
          (d['favoriteContent'] as List?)?.map((e) => e.toString()).toList(),
      preferredEvents:
          (d['preferredEvents'] as List?)?.map((e) => e.toString()).toList(),
      socialLinks: social,
      status: d['status'] as String?, // present in your UI
      checkedInAt: d['checkedInAt'] as String?, // if you store it
      profileType: d['profileType'] as String?, // optional convenience
      about: d['about'] as String?,
      careerHighlights: d['careerHighlights'] as String?,
      verificationStatus: verification['status'] as String?,
      verificationReason: verification['reason'] as String?,
      personaInquiryId: verification['personaInquiryId'] as String?,
      createdAt: _toDate(d['createdAt']),
      updatedAt: _toDate(d['updatedAt']),
      authMethod: d['authMethod'] as String?,
    );
  }

  static Map<String, dynamic> toUpdateMap(ProfileUpdate u) {
    final m = <String, dynamic>{
      'fullName': u.fullName,
      'username': u.username,
      'status': u.status,
      'checkedInAt': u.checkedInAt,
      'socialLinks': u.socialLinks,
      'photoUrl': u.profileImageUrl,
      'profileType': u.profileType,
      'about': u.about,
      'careerHighlights': u.careerHighlights,
      'bio': u.bio,
      'location': u.location,
      'phone': u.phone,
      'skillLevel': u.skillLevel,
      'roles': u.roles,
      'favoriteContent': u.favoriteContent,
      'preferredEvents': u.preferredEvents,
      'updatedAt': FieldValue.serverTimestamp(),
    };

    // remove nulls
    m.removeWhere((k, v) => v == null);
    return m;
  }

  static DateTime? _toDate(dynamic v) {
    if (v is Timestamp) return v.toDate();
    if (v is DateTime) return v;
    return null;
  }
}
