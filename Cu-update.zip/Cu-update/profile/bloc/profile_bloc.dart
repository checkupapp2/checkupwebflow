import 'dart:io';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../data/firebase_profile_repository.dart';
import '../domain/profile_entity.dart';
import 'profile_event.dart';
import 'profile_state.dart';

class ProfileBloc extends Bloc<ProfileEvent, ProfileState> {
  final FirebaseProfileRepository repo;

  ProfileBloc(this.repo) : super(const ProfileState()) {
    on<ProfileLoadRequested>(_onLoad);
    on<ProfileRefreshed>(_onLoad);
    on<ProfileAvatarPicked>(_onAvatarPicked);
    on<ProfileSaveSubmitted>(_onSave);
  }

  Future<void> _onLoad(ProfileEvent event, Emitter<ProfileState> emit) async {
    try {
      emit(state.copyWith(status: ProfileStatus.loading));
      final data = await repo.getCurrent();
      emit(state.copyWith(
          status: ProfileStatus.ready, profile: data, error: null));
    } catch (e) {
      emit(state.copyWith(status: ProfileStatus.failure, error: '$e'));
    }
  }

  Future<void> _onAvatarPicked(
      ProfileAvatarPicked event, Emitter<ProfileState> emit) async {
    if (state.profile == null) return;
    try {
      emit(state.copyWith(status: ProfileStatus.uploadingAvatar));
      final String? url = await repo.uploadAvatar(event.file);
      if (url != null) {
        emit(state.copyWith(
          status: ProfileStatus.ready,
          profile: state.profile!.copyWith(profileImageUrl: url),
        ));
      } else {
        emit(state.copyWith(status: ProfileStatus.ready));
      }
    } catch (e) {
      emit(state.copyWith(status: ProfileStatus.failure, error: '$e'));
    }
  }

  Future<void> _onSave(
      ProfileSaveSubmitted event, Emitter<ProfileState> emit) async {
    try {
      emit(state.copyWith(status: ProfileStatus.saving));
      final updated = await repo.update(ProfileUpdate(
        fullName: event.fullName,
        username: event.username,
        status: event.status,
        checkedInAt: event.checkedInAt,
        socialLinks: event.socialLinks,
        profileType: event.profileType,
        about: event.about,
        careerHighlights: event.careerHighlights,
        // profileImageUrl handled by AvatarPicked; optional here
      ));
      emit(state.copyWith(
          status: ProfileStatus.success, profile: updated, error: null));
      // bounce back to ready after success so UI keeps rendering
      emit(state.copyWith(status: ProfileStatus.ready));
    } catch (e) {
      emit(state.copyWith(status: ProfileStatus.failure, error: '$e'));
    }
  }
}
