import 'dart:io';
import 'package:equatable/equatable.dart';

abstract class ProfileEvent extends Equatable {
  const ProfileEvent();
  @override
  List<Object?> get props => [];
}

class ProfileLoadRequested extends ProfileEvent {
  const ProfileLoadRequested();
}

class ProfileRefreshed extends ProfileEvent {
  const ProfileRefreshed();
}

class ProfileAvatarPicked extends ProfileEvent {
  final File file;
  const ProfileAvatarPicked(this.file);
  @override
  List<Object?> get props => [file];
}

class ProfileSaveSubmitted extends ProfileEvent {
  final String fullName;
  final String username;
  final String? status;
  final String? checkedInAt;
  final Map<String, String>? socialLinks;
  final String? profileType;
  final String? about;
  final String? careerHighlights;

  const ProfileSaveSubmitted({
    required this.fullName,
    required this.username,
    this.status,
    this.checkedInAt,
    this.socialLinks,
    this.profileType,
    this.about,
    this.careerHighlights,
  });

  @override
  List<Object?> get props => [
        fullName,
        username,
        status,
        checkedInAt,
        socialLinks,
        profileType,
        about,
        careerHighlights
      ];
}
