import 'package:flutter/material.dart';
import '../../domain/models/event_model.dart';

/// Widget for displaying an event card in the schedule tab
class ScheduleEventCard extends StatelessWidget {
  /// Event data
  final ProfileEventModel event;

  /// Callback when the card is tapped
  final VoidCallback? onTap;

  /// Callback when the confirm button is tapped
  final VoidCallback? onConfirmTap;

  /// Callback when the cancel button is tapped
  final VoidCallback? onCancelTap;

  /// Constructor
  const ScheduleEventCard({
    super.key,
    required this.event,
    this.onTap,
    this.onConfirmTap,
    this.onCancelTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2A2A2A),
              Color(0xFF1A1A1A),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 15,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        // Use a ClipRRect to ensure no content overflows the container
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Image with game type and price
              Stack(
                children: [
                  // Main image - compact size
                  ClipRRect(
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(20)),
                    child: SizedBox(
                      height: 120, // Fixed compact height
                      width: double.infinity,
                      child: Image.network(
                        event.thumbnailUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Colors.orange[800]!.withOpacity(0.3),
                                  Colors.orange[900]!.withOpacity(0.3),
                                ],
                              ),
                            ),
                            child: const Center(
                              child: Icon(Icons.sports_basketball,
                                  size: 40, color: Colors.orange),
                            ),
                          );
                        },
                      ),
                    ),
                  ),

                  // Price label
                  Positioned(
                    top: 16,
                    left: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Colors.orange[400]!,
                            Colors.deepOrange[700]!,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.4),
                            blurRadius: 10,
                            spreadRadius: 1,
                            offset: const Offset(0, 3),
                          ),
                        ],
                        border: Border.all(
                          color: Colors.white.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: Text(
                        event.price,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),

                  // Game type pill
                  Positioned(
                    bottom: 16,
                    left: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        event.gameType,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),

                  // Event type chip (hosting/attending)
                  Positioned(
                    top: 16,
                    right: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: event.type == ProfileEventType.hosting
                            ? Colors.purple.withOpacity(0.8)
                            : Colors.blue.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 5,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: Text(
                        event.type == ProfileEventType.hosting
                            ? 'Hosting'
                            : 'Attending',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              // Content - compact padding
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title - smaller font
                    Text(
                      event.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),

                    const SizedBox(height: 8),

                    // Location and Date in one row for compactness
                    Row(
                      children: [
                        // Location
                        Expanded(
                          child: Row(
                            children: [
                              const Icon(Icons.location_on,
                                  color: Colors.orange, size: 14),
                              const SizedBox(width: 6),
                              Flexible(
                                child: Text(
                                  event.location,
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 12),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(width: 12),

                        // Date
                        Row(
                          children: [
                            const Icon(Icons.calendar_today,
                                color: Colors.orange, size: 14),
                            const SizedBox(width: 6),
                            Text(
                              event.date,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),

                    const SizedBox(height: 8),

                    // Host info and reviews - more compact
                    Row(
                      children: [
                        // Host info
                        Expanded(
                          child: Row(
                            children: [
                              const Icon(Icons.person,
                                  color: Colors.grey, size: 12),
                              const SizedBox(width: 4),
                              Flexible(
                                child: Text(
                                  'Hosted by ${event.hostName}',
                                  style: TextStyle(
                                      color: Colors.grey[400], fontSize: 11),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Reviews
                        Row(
                          children: [
                            const Icon(Icons.people,
                                color: Colors.grey, size: 12),
                            const SizedBox(width: 4),
                            Text(
                              '${event.reviews} joined',
                              style: TextStyle(
                                  color: Colors.grey[400], fontSize: 11),
                            ),
                          ],
                        ),
                      ],
                    ),

                    // Action buttons for unconfirmed events
                    if (!event.isConfirmed &&
                        (onConfirmTap != null || onCancelTap != null)) ...[
                      const SizedBox(height: 12),
                      _buildActionButtons(),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Builds action buttons for unconfirmed events
  Widget _buildActionButtons() {
    return Row(
      children: [
        if (onConfirmTap != null)
          Expanded(
            child: ElevatedButton(
              onPressed: onConfirmTap,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text('Confirm'),
            ),
          ),
        if (onConfirmTap != null && onCancelTap != null)
          const SizedBox(width: 12),
        if (onCancelTap != null)
          Expanded(
            child: OutlinedButton(
              onPressed: onCancelTap,
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.grey,
                side: const BorderSide(color: Colors.grey),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              child: const Text('Cancel'),
            ),
          ),
      ],
    );
  }
}
