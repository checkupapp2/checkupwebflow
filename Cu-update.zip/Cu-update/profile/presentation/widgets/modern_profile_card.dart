import 'package:flutter/material.dart';
import 'dart:ui';
import 'dart:math' as math;
// Import for animation
// Ensure we have access to MaskFilter for the glow effect
import '../../../trophies/presentation/pages/trophies_screen.dart';

/// A modern profile card with gradient black glossy background
/// Displays user profile information, stats, and social media links
class ModernProfileCard extends StatefulWidget {
  /// User's profile image URL
  final String? profileImageUrl;

  /// User's username
  final String username;

  /// User's full name
  final String fullName;

  /// Number of followers
  final int followers;

  /// Number of check-ins
  final int checkIns;

  /// Number of games played
  final int gamesPlayed;

  /// Whether the current user is following this user
  final bool isFollowing;

  /// Callback when follow button is tapped
  final VoidCallback? onFollowTap;

  /// Social media links
  final Map<String, String>? socialLinks;

  /// User's current status (e.g., "Checked-in at Rucker Park")
  final String? status;

  /// User's player rank or level (e.g., "Superstar")
  final String? playerRank;

  /// Whether the user has active stories
  final bool hasActiveStories;

  /// Callback for when the trophies section is tapped
  final VoidCallback? onTrophiesTap;

  /// User's bio text
  final String? bio;

  /// Constructor
  const ModernProfileCard({
    Key? key,
    this.profileImageUrl,
    required this.username,
    required this.fullName,
    required this.followers,
    required this.checkIns,
    required this.gamesPlayed,
    required this.isFollowing,
    this.onFollowTap,
    this.socialLinks,
    this.status,
    this.playerRank,
    this.hasActiveStories = false,
    this.onTrophiesTap,
    this.bio,
  }) : super(key: key);

  @override
  State<ModernProfileCard> createState() => _ModernProfileCardState();
}

class _ModernProfileCardState extends State<ModernProfileCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _flipController;
  late Animation<double> _flipAnimation;
  bool _isFlipped = false;

  @override
  void initState() {
    super.initState();
    _flipController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _flipAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _flipController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _flipController.dispose();
    super.dispose();
  }

  void _toggleFlip() {
    if (_isFlipped) {
      _flipController.reverse();
    } else {
      _flipController.forward();
    }
    setState(() {
      _isFlipped = !_isFlipped;
    });
  }

  /// Navigate to trophies screen
  void _navigateToTrophiesScreen() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const TrophiesScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _flipController,
      builder: (context, child) {
        final isShowingFront = _flipController.value < 0.5;
        return Transform(
          alignment: Alignment.center,
          transform: Matrix4.identity()
            ..setEntry(3, 2, 0.001)
            ..rotateY(_flipController.value * math.pi),
          child: Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              // Gradient black glossy background
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF2A2A2A),
                  Color(0xFF121212),
                ],
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: isShowingFront ? _buildFrontCard() : _buildBackCard(),
          ),
        );
      },
    );
  }

  /// Builds the front side of the card
  Widget _buildFrontCard() {
    return Stack(
      children: [
        // Main content
        _buildMainContent(),

        // About Me button (top left) - tappable to flip card
        Positioned(
          top: 16,
          left: 16,
          child: _buildAboutMeButton(),
        ),

        // Player label (top right)
        Positioned(
          top: 16,
          right: 16,
          child: GestureDetector(
            onTap: _toggleFlip,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF2A2A2A), // Dark Grey
                    Color(0xFF121212), // Black
                  ],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Text(
                'Player',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Builds the back side of the card (About Me)
  Widget _buildBackCard() {
    return Transform(
      alignment: Alignment.center,
      transform: Matrix4.identity()..rotateY(math.pi),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.1),
                width: 1,
              ),
            ),
            child: Stack(
              children: [
                // Back button (top left) with About Me title next to it
                Positioned(
                  top: 16,
                  left: 16,
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: _toggleFlip,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.3),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Row(
                        children: [
                          const Icon(
                            Icons.person,
                            color: Colors.orange,
                            size: 20,
                          ),
                          const SizedBox(width: 6),
                          const Text(
                            'About Me',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // About Me content
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 60, 24, 24),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Expanded Bio Section with Career Highlights
                        _buildExpandedAboutMeSection(),
                        const SizedBox(height: 16),

                        // Career Highlights Section
                        _buildCareerHighlightsSection(),
                        const SizedBox(height: 16),

                        // Social Media Icons Row (always visible)
                        _buildSocialMediaIconsRow(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Builds the player rank badge
  Widget _buildPlayerRankBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFFF5722), // Deep Orange
            Color(0xFFFF9800), // Orange
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.star,
            color: Colors.white,
            size: 16,
          ),
          const SizedBox(width: 4),
          Text(
            widget.playerRank!,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  /// Builds the About Me button
  Widget _buildAboutMeButton() {
    return GestureDetector(
      onTap: _toggleFlip,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFE65100)],
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.person,
              color: Colors.white,
              size: 16,
            ),
            SizedBox(width: 4),
            Text(
              'About Me',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(width: 4),
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.white,
              size: 12,
            ),
          ],
        ),
      ),
    );
  }

  /// Builds the main content of the card
  Widget _buildMainContent() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
          ),
          child: Padding(
            padding:
                const EdgeInsets.all(24), // Increased padding for more space
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 20),

                // Profile Avatar (centered)
                _buildProfileAvatar(),

                const SizedBox(height: 20),

                // Username and Full Name (centered)
                _buildNameSection(),

                const SizedBox(height: 24),

                // Stats Row (centered, more spaced)
                _buildSimpleStatsRow(),

                const SizedBox(height: 24),

                // Follow Button (centered, full width)
                _buildSimpleFollowButton(),

                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Builds the profile avatar with Instagram stories ring animation
  Widget _buildProfileAvatar() {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Instagram stories ring animation (always shown)
        SizedBox(
          width: 132, // Increased by 20% from 110
          height: 132, // Increased by 20% from 110
          child: InstagramStoriesRing(),
        ),

        // Avatar container - centered within the ring
        Container(
          width: 120, // Increased by 20% from 100
          height: 120, // Increased by 20% from 100
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.black,
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF9800).withOpacity(0.5),
                blurRadius: 15,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: ClipOval(
            child: widget.profileImageUrl != null
                ? Image.network(
                    widget.profileImageUrl!,
                    fit: BoxFit.cover,
                    width: 120,
                    height: 120,
                    errorBuilder: (context, error, stackTrace) => Container(
                      width: 120,
                      height: 120,
                      color: Colors.black,
                      child: const Icon(
                        Icons.person,
                        color: Colors.white,
                        size: 50,
                      ),
                    ),
                  )
                : Container(
                    width: 120,
                    height: 120,
                    color: Colors.black,
                    child: const Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 50,
                    ),
                  ),
          ),
        ),

        // Verification badge - bigger with orange gradient
        Positioned(
          bottom: 0,
          right: 0,
          child: Container(
            width: 42, // Reduced by 25% (56 * 0.75 = 42)
            height: 42, // Reduced by 25% (56 * 0.75 = 42)
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF9800), // Orange
                  Color(0xFFFF5722), // Deep Orange
                ],
              ),
              border: Border.all(
                color: Colors.black,
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withOpacity(0.7),
                  blurRadius: 6,
                  spreadRadius: 1,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: const Center(
              child: Icon(
                Icons.verified,
                color: Colors.white,
                size: 28, // Reduced by 25% (38 * 0.75 ≈ 28)
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Builds the username and full name section with status
  Widget _buildNameSection() {
    return Column(
      children: [
        Text(
          widget.username,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          widget.fullName,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 16,
          ),
        ),

        // Status label (e.g., "Checked-in at Rucker Park")
        if (widget.status != null) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFFFF9800).withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xFFFF9800).withOpacity(0.5),
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.location_on,
                  color: Color(0xFFFF9800),
                  size: 16,
                ),
                const SizedBox(width: 4),
                Text(
                  widget.status!,
                  style: const TextStyle(
                    color: Color(0xFFFF9800),
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  /// Builds the stats row (followers, check-ins, events)
  Widget _buildStatsRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildStatItem('Followers', widget.followers.toString()),
          _buildDivider(),
          _buildStatItem('Check-ins', widget.checkIns.toString()),
          _buildDivider(),
          _buildStatItem('Events', widget.gamesPlayed.toString()),
        ],
      ),
    );
  }

  /// Builds a vertical divider for the stats row
  Widget _buildDivider() {
    return Container(
      height: 30,
      width: 1,
      color: Colors.grey.withOpacity(0.3),
    );
  }

  /// Builds the bio section
  Widget _buildBioSection() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[900]!,
            Colors.grey[850]!,
          ],
        ),
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.format_quote,
                color: Color(0xFFFF9800),
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Bio',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Short Instagram-style bio with three lines
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '🏀 Point Guard | NYC',
                style: TextStyle(color: Colors.white, fontSize: 14),
              ),
              SizedBox(height: 4),
              Text(
                '3x Champion | Streetball Legend',
                style: TextStyle(color: Colors.white, fontSize: 14),
              ),
              SizedBox(height: 4),
              Text(
                '"Ball is life" | DM for bookings',
                style: TextStyle(color: Colors.white, fontSize: 14),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Builds a section title
  Widget _buildSectionTitle(String title) {
    return InkWell(
      onTap: title == 'Trophies' ? widget.onTrophiesTap : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          children: [
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Spacer(),
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.white.withOpacity(0.5),
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  /// Builds an individual stat item
  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  /// Builds the badge images row in a trading card style
  Widget _buildSocialMediaRow() {
    // List of badge image paths with their achievement names
    final List<Map<String, dynamic>> badgeData = [
      {
        'path': 'assets/images/Subject 70.webp',
        'name': 'Sniper',
        'isCustom': false
      },
      {
        'path': 'assets/images/Subject 71.webp',
        'name': 'Hustler',
        'isCustom': false
      },
      {
        'path': 'assets/images/Subject 72.webp',
        'name': 'Playmaker',
        'isCustom': false
      },
      {
        'path': 'assets/images/Subject 73.webp',
        'name': 'Defender',
        'isCustom': false
      },
      {
        'path': 'assets/images/Subject 74.webp',
        'name': 'Clutch',
        'isCustom': false
      },
      {
        'path': 'assets/images/Subject 75.webp',
        'name': 'MVP',
        'isCustom': false
      },
      {'name': 'ALL TOURNAMENT', 'isCustom': true},
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: badgeData
              .map((data) => data['isCustom'] == true
                  ? _buildCustomTournamentBadge(achievementName: data['name'])
                  : _buildBadgeCard(
                      imagePath: data['path']!, achievementName: data['name']!))
              .toList(),
        ),
      ),
    );
  }

  /// Builds an individual badge card in trading card style with shimmer effect
  Widget _buildBadgeCard(
      {required String imagePath, required String achievementName}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Badge card with shimmer effect
        ShimmerBadgeCard(imagePath: imagePath),

        // Achievement name with bold text
        const SizedBox(height: 4),
        Text(
          achievementName,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  /// Builds a custom ALL TOURNAMENT badge with medal icon and number
  Widget _buildCustomTournamentBadge({required String achievementName}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Custom badge with tournament medal design
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          width: 80,
          height: 80,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Circle background
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.orange.shade700,
                      Colors.orange.shade900,
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.orange.withOpacity(0.5),
                      blurRadius: 8,
                      spreadRadius: 1,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
              ),

              // Medal icon
              const Icon(
                Icons.military_tech,
                color: Colors.white,
                size: 40,
              ),

              // Number badge
              Positioned(
                right: 5,
                bottom: 5,
                child: Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black,
                    border: Border.all(color: Colors.orange.shade300, width: 1),
                  ),
                  child: const Center(
                    child: Text(
                      '1',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ),

              // Border with gradient
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xFFFF9800).withOpacity(0.7),
                    width: 2.0,
                  ),
                ),
              ),

              // Shimmer effect
              ClipOval(
                child: _buildShimmerEffect(),
              ),
            ],
          ),
        ),

        // Achievement name
        const SizedBox(height: 4),
        Text(
          achievementName,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  /// Shimmer badge card with animation effect - now circular
  Widget ShimmerBadgeCard({required String imagePath}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8),
      width: 80, // Increased from 60 to 80
      height: 80, // Increased from 60 to 80
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF333333),
            Color(0xFF111111),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 6, // Increased from 4 to 6
            offset: const Offset(0, 3), // Increased from 2 to 3
          ),
        ],
      ),
      child: Stack(
        children: [
          // Badge image
          ClipOval(
            child: Image.asset(
              imagePath,
              fit: BoxFit.cover,
              width: 80, // Increased from 60 to 80
              height: 80, // Increased from 60 to 80
            ),
          ),

          // Shimmer overlay
          ShimmerOverlay(),

          // Border with gradient
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: const Color(0xFFFF9800).withOpacity(0.7),
                width: 2.0, // Increased from 1.5 to 2.0
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Shimmer overlay with animation
  Widget ShimmerOverlay() {
    return ClipOval(
      child: _buildShimmerEffect(),
    );
  }

  /// Build shimmer effect for trading cards
  Widget _buildShimmerEffect() {
    // Use a StatefulBuilder to manage the animation state
    return StatefulBuilder(
      builder: (BuildContext context, StateSetter setState) {
        // Create a repeating animation
        return TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: -1.0, end: 1.0),
          duration: const Duration(seconds: 2),
          onEnd: () {
            // When animation ends, rebuild with reversed values to create continuous effect
            setState(() {});
          },
          builder: (context, value, child) {
            return Container(
              width: 80, // Updated from 60 to 80
              height: 80, // Updated from 60 to 80
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  stops: const [0.0, 0.3, 0.6, 1.0],
                  colors: [
                    Colors.transparent,
                    Colors.white.withOpacity(0.05),
                    Colors.white.withOpacity(0.2),
                    Colors.transparent,
                  ],
                  transform: GradientRotation(value * 3.14),
                ),
              ),
            );
          },
        );
      },
    );
  }

  /// Handles the message button tap
  void _handleMessageTap(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Message feature coming soon!')));
  }

  /// Builds the follow button with message button
  Widget _buildFollowButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          // Follow button
          Expanded(
            child: GestureDetector(
              onTap: widget.onFollowTap,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFFF9800),
                      Color(0xFFFF5722),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF9800).withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    widget.isFollowing ? 'Following' : 'Follow',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Small gap between buttons
          const SizedBox(width: 12),

          // Message button (circular)
          Builder(
            builder: (BuildContext context) {
              return GestureDetector(
                onTap: () => _handleMessageTap(context),
                child: Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.grey[800]!,
                        Colors.grey[900]!,
                      ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.message_rounded,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // COMPACT LAYOUT METHODS

  /// Builds a compact profile avatar (smaller version)
  Widget _buildCompactProfileAvatar() {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Instagram stories ring animation (smaller)
        SizedBox(
          width: 80, // Reduced from 132
          height: 80, // Reduced from 132
          child: InstagramStoriesRing(),
        ),

        // Avatar container (smaller) - centered within the ring
        Container(
          width: 72, // Reduced from 120
          height: 72, // Reduced from 120
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.black,
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF9800).withOpacity(0.5),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: ClipOval(
            child: widget.profileImageUrl != null
                ? Image.network(
                    widget.profileImageUrl!,
                    fit: BoxFit.cover,
                    width: 72,
                    height: 72,
                    errorBuilder: (context, error, stackTrace) => Container(
                      width: 72,
                      height: 72,
                      color: Colors.black,
                      child: const Icon(
                        Icons.person,
                        color: Colors.white,
                        size: 30,
                      ),
                    ),
                  )
                : Container(
                    width: 72,
                    height: 72,
                    color: Colors.black,
                    child: const Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
          ),
        ),

        // Verification badge (smaller)
        Positioned(
          bottom: 0,
          right: 0,
          child: Container(
            width: 24, // Reduced from 42
            height: 24, // Reduced from 42
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF9800), // Orange
                  Color(0xFFFF5722), // Deep Orange
                ],
              ),
              border: Border.all(
                color: Colors.black,
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withOpacity(0.7),
                  blurRadius: 4,
                  spreadRadius: 1,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
            child: const Center(
              child: Icon(
                Icons.verified,
                color: Colors.white,
                size: 16, // Reduced from 28
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Builds compact username and full name section
  Widget _buildCompactNameSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Username
        Text(
          widget.username,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18, // Reduced from larger size
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),

        const SizedBox(height: 2),

        // Full Name
        Text(
          widget.fullName,
          style: TextStyle(
            color: Colors.grey[300],
            fontSize: 14, // Reduced from larger size
            fontWeight: FontWeight.w500,
          ),
        ),

        // Status (if available)
        if (widget.status != null) ...[
          const SizedBox(height: 2),
          Text(
            widget.status!,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 12, // Reduced from larger size
              fontStyle: FontStyle.italic,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ],
    );
  }

  /// Builds compact stats row (horizontal layout)
  Widget _buildCompactStatsRow() {
    return Row(
      children: [
        _buildCompactStatItem('Followers', widget.followers.toString()),
        const SizedBox(width: 16),
        _buildCompactStatItem('Check-ins', widget.checkIns.toString()),
        const SizedBox(width: 16),
        _buildCompactStatItem('Events', widget.gamesPlayed.toString()),
      ],
    );
  }

  /// Builds a compact individual stat item
  Widget _buildCompactStatItem(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16, // Reduced from larger size
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 11, // Reduced from larger size
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  /// Builds compact bio section
  Widget _buildCompactBioSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Text(
        'Basketball enthusiast and community player. Love connecting with fellow ballers and sharing the game! 🏀',
        style: TextStyle(
          color: Colors.grey[300],
          fontSize: 13, // Reduced from larger size
          height: 1.3,
        ),
        textAlign: TextAlign.center,
        maxLines: 2, // Limit to 2 lines for compactness
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  /// Builds compact follow button
  Widget _buildCompactFollowButton() {
    return GestureDetector(
      onTap: widget.onFollowTap,
      child: Container(
        height: 36, // Reduced from 50
        decoration: BoxDecoration(
          gradient: widget.isFollowing
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.grey[700]!,
                    Colors.grey[800]!,
                  ],
                )
              : const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFFFF6600),
                    Color(0xFFE55A00),
                  ],
                ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: (widget.isFollowing
                      ? Colors.grey[800]!
                      : const Color(0xFFFF6600))
                  .withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Center(
          child: Text(
            widget.isFollowing ? 'Following' : 'Follow',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14, // Reduced from 16
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ),
    );
  }

  /// Builds compact section title
  Widget _buildCompactSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 14, // Reduced from larger size
        fontWeight: FontWeight.bold,
        letterSpacing: 0.5,
      ),
    );
  }

  /// Builds compact social media/badges row
  Widget _buildCompactSocialMediaRow() {
    return SizedBox(
      height: 40, // Reduced height
      child: Row(
        children: [
          _buildCompactBadgeCard(
            imagePath: 'assets/images/badges/champion_badge.png',
            achievementName: 'Champion',
          ),
          const SizedBox(width: 6),
          _buildCompactBadgeCard(
            imagePath: 'assets/images/badges/mvp_badge.png',
            achievementName: 'MVP',
          ),
          const SizedBox(width: 6),
          _buildCompactCustomTournamentBadge(
            achievementName: 'Tournament Winner',
          ),
        ],
      ),
    );
  }

  /// Builds compact badge card
  Widget _buildCompactBadgeCard(
      {required String imagePath, required String achievementName}) {
    return Container(
      width: 32, // Reduced from larger size
      height: 32, // Reduced from larger size
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFFF9800),
            Color(0xFFFF5722),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF9800).withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: const Center(
        child: Icon(
          Icons.emoji_events,
          color: Colors.white,
          size: 18, // Reduced icon size
        ),
      ),
    );
  }

  /// Builds compact custom tournament badge
  Widget _buildCompactCustomTournamentBadge({required String achievementName}) {
    return Container(
      width: 32, // Reduced from larger size
      height: 32, // Reduced from larger size
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFFF9800),
            Color(0xFFFF5722),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF9800).withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: const Center(
        child: Icon(
          Icons.military_tech,
          color: Colors.white,
          size: 18, // Reduced icon size
        ),
      ),
    );
  }

  // SIMPLE LAYOUT METHODS

  /// Builds simple stats row with better spacing
  Widget _buildSimpleStatsRow() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildSimpleStatItem('Followers', widget.followers.toString()),
          Container(
            width: 1,
            height: 40,
            color: Colors.grey.withOpacity(0.3),
          ),
          _buildSimpleStatItem('Check-ins', widget.checkIns.toString()),
          Container(
            width: 1,
            height: 40,
            color: Colors.grey.withOpacity(0.3),
          ),
          _buildSimpleStatItem('Events', widget.gamesPlayed.toString()),
        ],
      ),
    );
  }

  /// Builds a simple individual stat item with better spacing
  Widget _buildSimpleStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 24, // Larger for better visibility
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  /// Builds simple follow button (full width, centered)
  Widget _buildSimpleFollowButton() {
    return Container(
      width: double.infinity,
      child: Row(
        children: [
          // Follow Button
          Expanded(
            flex: 4,
            child: GestureDetector(
              onTap: widget.onFollowTap,
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  gradient: widget.isFollowing
                      ? LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Colors.grey[700]!,
                            Colors.grey[800]!,
                          ],
                        )
                      : const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Color(0xFFFF6600),
                            Color(0xFFE55A00),
                          ],
                        ),
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [
                    BoxShadow(
                      color: (widget.isFollowing
                              ? Colors.grey[800]!
                              : const Color(0xFFFF6600))
                          .withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    widget.isFollowing ? 'Following' : 'Follow',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ),
          ),

          const SizedBox(width: 16),

          // Message Button
          GestureDetector(
            onTap: () {
              // Handle message tap - could navigate to message screen
              // For now, just a placeholder
            },
            child: Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.grey[800]!,
                    Colors.grey[900]!,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Center(
                child: Icon(
                  Icons.message_rounded,
                  color: Colors.white,
                  size: 24,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Builds an expanded About Me section with bio-focused content
  Widget _buildExpandedAboutMeSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[900]!.withOpacity(0.9),
            Colors.grey[800]!.withOpacity(0.7),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.orange.withOpacity(0.3),
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFE65100)],
                  ),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Icon(
                  Icons.format_quote,
                  color: Colors.white,
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'About Me',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Bio description content
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.sports_basketball,
                      color: Colors.orange, size: 14),
                  const SizedBox(width: 6),
                  const Flexible(
                    child: Text(
                      'Point Guard | NYC | 3x Champion',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  const Icon(Icons.favorite, color: Colors.red, size: 14),
                  const SizedBox(width: 6),
                  const Flexible(
                    child: Text(
                      'Known for clutch shots and court vision',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        height: 1.3,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  const Icon(Icons.location_on, color: Colors.orange, size: 14),
                  const SizedBox(width: 6),
                  const Flexible(
                    child: Text(
                      'Home court: Rucker Park, Harlem',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        height: 1.3,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  const Icon(Icons.message, color: Colors.blue, size: 14),
                  const SizedBox(width: 6),
                  const Flexible(
                    child: Text(
                      'DM for bookings and collaborations',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        height: 1.3,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Builds the career highlights section - compact version
  Widget _buildCareerHighlightsSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[900]!.withOpacity(0.9),
            Colors.grey[800]!.withOpacity(0.7),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.orange.withOpacity(0.3),
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFE65100)],
                  ),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Icon(
                  Icons.sports_basketball,
                  color: Colors.white,
                  size: 16,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'Career Highlights',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Compact career highlights grid
          Row(
            children: [
              Expanded(
                child: _buildHighlightItem(
                  icon: Icons.emoji_events,
                  title: '47 Points',
                  color: Colors.orange,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildHighlightItem(
                  icon: Icons.military_tech,
                  title: '3 Titles',
                  color: Colors.amber,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _buildHighlightItem(
                  icon: Icons.flash_on,
                  title: 'Clutch',
                  color: Colors.yellow,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildHighlightItem(
                  icon: Icons.location_on,
                  title: 'Rucker Park',
                  color: Colors.red,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Builds an individual highlight item - compact version
  Widget _buildHighlightItem({
    required IconData icon,
    required String title,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: color,
            size: 18,
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  /// Builds a social media icons row that always shows
  Widget _buildSocialMediaIconsRow() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.grey[900]!.withOpacity(0.8),
            Colors.grey[850]!.withOpacity(0.6),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.orange.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.share,
                color: Colors.orange,
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(
                'Social Media',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildSocialMediaIcon(
                  Icons.camera_alt, Colors.purple, 'Instagram'),
              _buildSocialMediaIcon(
                  Icons.alternate_email, Colors.blue, 'Twitter'),
              _buildSocialMediaIcon(
                  Icons.facebook, Colors.blue[800]!, 'Facebook'),
              _buildSocialMediaIcon(
                  Icons.play_circle_filled, Colors.red, 'YouTube'),
              _buildSocialMediaIcon(
                  Icons.videogame_asset, Colors.purple[700]!, 'Twitch'),
            ],
          ),
        ],
      ),
    );
  }

  /// Builds an individual social media icon
  Widget _buildSocialMediaIcon(IconData icon, Color color, String platform) {
    return GestureDetector(
      onTap: () {
        // Handle social media tap
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Opening $platform...')),
        );
      },
      child: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color.withOpacity(0.3),
            width: 1.5,
          ),
        ),
        child: Icon(
          icon,
          color: color,
          size: 24,
        ),
      ),
    );
  }

  /// Builds the trophies and game awards section in a single row
  Widget _buildTrophiesSection() {
    return GestureDetector(
      onTap: _navigateToTrophiesScreen,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.grey[900]!.withOpacity(0.8),
              Colors.grey[850]!.withOpacity(0.6),
            ],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.orange.withOpacity(0.2),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.emoji_events,
                  color: Colors.orange,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Text(
                  'Trophies & Game Awards',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            // Single row of trophies/badges
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildAboutMeBadgeCard(
                      'assets/images/Subject 70.webp', 'Sniper'),
                  const SizedBox(width: 8),
                  _buildAboutMeBadgeCard(
                      'assets/images/Subject 71.webp', 'Hustler'),
                  const SizedBox(width: 8),
                  _buildAboutMeBadgeCard(
                      'assets/images/Subject 72.webp', 'Playmaker'),
                  const SizedBox(width: 8),
                  _buildAboutMeBadgeCard(
                      'assets/images/Subject 73.webp', 'Defender'),
                  const SizedBox(width: 8),
                  _buildAboutMeBadgeCard(
                      'assets/images/Subject 74.webp', 'Clutch'),
                  const SizedBox(width: 8),
                  _buildAboutMeBadgeCard(
                      'assets/images/Subject 75.webp', 'MVP'),
                  const SizedBox(width: 8),
                  _buildAboutMeTournamentBadge(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Builds a compact badge card for the About Me section
  Widget _buildAboutMeBadgeCard(String imagePath, String name) {
    return GestureDetector(
      onTap: _navigateToTrophiesScreen,
      child: Column(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.orange.withOpacity(0.3),
                  Colors.orange.withOpacity(0.1),
                ],
              ),
              border: Border.all(
                color: Colors.orange.withOpacity(0.4),
                width: 2,
              ),
            ),
            child: ClipOval(
              child: imagePath.isNotEmpty
                  ? Image.asset(
                      imagePath,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.orange, Colors.deepOrange],
                            ),
                          ),
                          child: const Icon(
                            Icons.emoji_events,
                            color: Colors.white,
                            size: 20,
                          ),
                        );
                      },
                    )
                  : Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.orange, Colors.deepOrange],
                        ),
                      ),
                      child: const Icon(
                        Icons.emoji_events,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            name,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  /// Builds a compact tournament badge for the About Me section
  Widget _buildAboutMeTournamentBadge() {
    return GestureDetector(
      onTap: _navigateToTrophiesScreen,
      child: Column(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFFD700),
                  Color(0xFFFFA500),
                ],
              ),
              border: Border.all(
                color: Colors.orange,
                width: 2,
              ),
            ),
            child: const Stack(
              children: [
                Center(
                  child: Icon(
                    Icons.military_tech,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
                Positioned(
                  top: 2,
                  right: 2,
                  child: Text(
                    '5',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Tournament',
            style: TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

/// Instagram Stories Ring Animation
class InstagramStoriesRing extends StatefulWidget {
  /// Constructor
  const InstagramStoriesRing({Key? key}) : super(key: key);

  @override
  InstagramStoriesRingState createState() => InstagramStoriesRingState();
}

class InstagramStoriesRingState extends State<InstagramStoriesRing>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration:
          const Duration(seconds: 5), // 5 seconds - not too fast, not too slow
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          painter: StoriesRingPainter(_controller.value),
          child: Container(),
        );
      },
    );
  }
}

class StoriesRingPainter extends CustomPainter {
  final double animationValue;

  StoriesRingPainter(this.animationValue);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2;

    // Create gradient for the ring with more contrasting colors
    final rect = Rect.fromCircle(center: center, radius: radius);

    // Create a more noticeable gradient with higher contrast
    final gradient = SweepGradient(
      startAngle: 0,
      endAngle: math.pi * 2,
      colors: const [
        Color(0xFFFF9800), // Orange
        Color(0xFFFF5722), // Deep Orange
        Color(0xFFFFFFFF), // White (for high contrast)
        Color(0xFFFF9800), // Orange (to complete the circle)
      ],
      stops: const [0.0, 0.3, 0.6, 1.0], // Control color distribution
      transform: GradientRotation(math.pi * 2 * animationValue),
    );

    // Glow effect (outer ring)
    final glowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.0
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0)
      ..shader = gradient.createShader(rect);

    // Main ring
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8.0 // Increased width for more visibility
      ..shader = gradient.createShader(rect);

    // Draw both rings
    canvas.drawCircle(center, radius - glowPaint.strokeWidth / 2, glowPaint);
    canvas.drawCircle(center, radius - paint.strokeWidth / 2, paint);

    // Add small dots along the ring for more visual movement
    final dotRadius = 3.0;
    final dotPaint = Paint()..color = Colors.white;

    // Draw 3 dots at different positions based on animation value
    for (int i = 0; i < 3; i++) {
      final angle = math.pi * 2 * ((animationValue + (i / 3)) % 1.0);
      final dotX = center.dx + (radius - 4) * math.cos(angle);
      final dotY = center.dy + (radius - 4) * math.sin(angle);
      canvas.drawCircle(Offset(dotX, dotY), dotRadius, dotPaint);
    }
  }

  @override
  bool shouldRepaint(StoriesRingPainter oldDelegate) {
    return animationValue != oldDelegate.animationValue;
  }
}
