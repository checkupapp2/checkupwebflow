import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../domain/models/player_stats_model.dart';

/// Widget for displaying a game matchup card with team vs team and player stats
class GameMatchupCard extends StatelessWidget {
  /// The recent game data
  final RecentGameModel game;
  
  /// Callback when the card is tapped
  final VoidCallback? onTap;

  /// Constructor
  const GameMatchupCard({
    super.key,
    required this.game,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('MMM d');
    final isWin = game.result == 'W';
    
    // Extract team names from the score (assuming format like "TeamA 21 - TeamB 15")
    final String homeTeam = "Home";
    final String awayTeam = "Away";
    
    // Parse score (e.g., "21-15")
    final scoreParts = game.score.split('-');
    final homeScore = scoreParts[0].trim();
    final awayScore = scoreParts[1].trim();
    
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 10),
        width: 220,
        height: 120,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color(0xFF1A1A1A),
              const Color(0xFF242424),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Date and Location
              Row(
                children: [
                  Icon(
                    Icons.location_on,
                    color: Colors.orange,
                    size: 12,
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      '${dateFormat.format(game.date)} · ${game.location}',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 10,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 8),
              
              // Team vs Team with Score
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Home Team
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          homeTeam,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                        ),
                        ShaderMask(
                          shaderCallback: (Rect bounds) {
                            return LinearGradient(
                              colors: [
                                Colors.orange.shade300,
                                Colors.orange.shade600,
                              ],
                            ).createShader(bounds);
                          },
                          child: Text(
                            homeScore,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // VS
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: isWin ? Colors.green.shade800 : Colors.red.shade800,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      game.result,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  
                  // Away Team
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          awayTeam,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          awayScore,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.8),
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 8),
              
              // Player Stats
              Container(
                padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withOpacity(0.4),
                      Colors.black.withOpacity(0.2),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildStatItem('PTS', game.playerPoints.toString()),
                    _buildStatItem('AST', game.playerAssists.toString()),
                    _buildStatItem('REB', game.playerRebounds.toString()),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildStatItem(String label, String value) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ShaderMask(
          shaderCallback: (Rect bounds) {
            return LinearGradient(
              colors: [
                Colors.orange.shade300,
                Colors.orange.shade600,
              ],
            ).createShader(bounds);
          },
          child: Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 9,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
