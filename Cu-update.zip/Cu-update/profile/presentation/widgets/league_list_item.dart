import 'package:flutter/material.dart';
import '../../domain/models/player_stats_model.dart';

/// Widget for displaying a league list item
class LeagueListItem extends StatelessWidget {
  /// The league data
  final LeagueModel league;
  
  /// Callback when the item is tapped
  final VoidCallback? onTap;

  /// Constructor
  const LeagueListItem({
    super.key,
    required this.league,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            // League logo
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.grey[800],
                shape: BoxShape.circle,
              ),
              child: league.logoUrl != null
                  ? ClipOval(
                      child: Image.network(
                        league.logoUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) => const Icon(
                          Icons.emoji_events,
                          color: Colors.grey,
                          size: 24,
                        ),
                      ),
                    )
                  : const Icon(
                      Icons.emoji_events,
                      color: Colors.grey,
                      size: 24,
                    ),
            ),
            const SizedBox(width: 12),
            
            // League details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    league.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${league.season} • ${league.location}',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            
            // Arrow icon
            const Icon(
              Icons.chevron_right,
              color: Colors.orange,
            ),
          ],
        ),
      ),
    );
  }
}
