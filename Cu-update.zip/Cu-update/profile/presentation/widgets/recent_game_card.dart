import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../domain/models/player_stats_model.dart';

/// Widget for displaying a recent game card
class RecentGameCard extends StatelessWidget {
  /// The recent game data
  final RecentGameModel game;
  
  /// Callback when the card is tapped
  final VoidCallback? onTap;

  /// Constructor
  const RecentGameCard({
    super.key,
    required this.game,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('MMM d');
    final isWin = game.result == 'W';
    
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 10),
        width: 220,
        height: 85, // Fixed height to prevent extra space
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1A),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 4,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header row with date, location and result
              Row(
                children: [
                  // Date and location
                  Expanded(
                    child: Row(
                      children: [
                        Icon(
                          Icons.location_on,
                          color: Colors.orange,
                          size: 12,
                        ),
                        const SizedBox(width: 2),
                        Expanded(
                          child: Text(
                            '${dateFormat.format(game.date)} \u00b7 ${game.location}',
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 10,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // Result
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                    decoration: BoxDecoration(
                      color: isWin ? Colors.green.shade800 : Colors.red.shade800,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      '${game.result} ${game.score}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
              
              const Spacer(), // Use spacer to push stats to bottom
              
              // Player stats row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildStatItem('PTS', game.playerPoints.toString()),
                  _buildStatItem('AST', game.playerAssists.toString()),
                  _buildStatItem('REB', game.playerRebounds.toString()),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildStatItem(String label, String value) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.orange,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[400],
            fontSize: 9,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
