import 'package:flutter/material.dart';
import '../../domain/models/player_stats_model.dart';

/// Widget for displaying an award badge
class AwardBadge extends StatelessWidget {
  /// The award data
  final PlayerAwardModel award;
  
  /// Callback when the badge is tapped
  final VoidCallback? onTap;

  /// Constructor
  const AwardBadge({
    super.key,
    required this.award,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // Parse the color from hex string
    final Color awardColor = _parseColor(award.color);
    
    // Special handling for ALL TOURNAMENT award
    final bool isAllTournament = award.name == 'ALL TOURNAMENT';
    
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 16),
        child: Column(
          children: [
            // Badge icon/image
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: isAllTournament ? Colors.transparent : awardColor.withOpacity(0.2),
                shape: BoxShape.circle,
                border: isAllTournament ? null : Border.all(
                  color: awardColor,
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: awardColor.withOpacity(0.3),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: isAllTournament
                ? Stack(
                    alignment: Alignment.center,
                    children: [
                      // Circle background
                      Container(
                        width: 70,
                        height: 70,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.orange.shade800,
                          border: Border.all(color: Colors.orange.shade300, width: 2),
                        ),
                      ),
                      // Number badge
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.black,
                            border: Border.all(color: Colors.orange.shade300, width: 1),
                          ),
                          child: const Center(
                            child: Text(
                              '1',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                      ),
                      // Medal icon
                      Icon(
                        Icons.military_tech,
                        color: Colors.white,
                        size: 36,
                      ),
                    ],
                  )
                : Icon(
                    _getIconData(award.icon),
                    color: awardColor,
                    size: 36,
                  ),
            ),
            const SizedBox(height: 8),
            
            // Award name
            Text(
              award.name,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
  
  // Helper method to parse color from hex string
  Color _parseColor(String hexColor) {
    try {
      hexColor = hexColor.replaceAll('#', '');
      if (hexColor.length == 6) {
        return Color(int.parse('0xFF$hexColor'));
      }
      return Colors.orange;
    } catch (e) {
      return Colors.orange;
    }
  }
  
  // Helper method to get icon data based on icon name
  IconData _getIconData(String iconName) {
    switch (iconName.toLowerCase()) {
      case 'trophy':
        return Icons.emoji_events;
      case 'star':
        return Icons.star;
      case 'bolt':
        return Icons.bolt;
      case 'target':
        return Icons.gps_fixed;
      case 'medal':
        return Icons.military_tech;
      case 'fire':
        return Icons.local_fire_department;
      case 'crown':
        return Icons.workspace_premium;
      default:
        return Icons.emoji_events;
    }
  }
}
