import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../domain/models/event_model.dart';

/// A widget that displays an event card
class EventCard extends StatelessWidget {
  /// The event to display
  final ProfileEventModel event;

  /// Callback when the card is tapped
  final VoidCallback? onTap;

  /// Callback when the confirm button is tapped
  final VoidCallback? onConfirmTap;

  /// Callback when the cancel button is tapped
  final VoidCallback? onCancelTap;

  /// Constructor
  const EventCard({
    super.key,
    required this.event,
    this.onTap,
    this.onConfirmTap,
    this.onCancelTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF1F1F1F),
              const Color(0xFF121212),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: event.color.withOpacity(0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Event image if available
            if (event.thumbnailUrl.isNotEmpty) ...[
              ClipRRect(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
                child: Image.network(
                  event.thumbnailUrl,
                  height: 120,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    height: 120,
                    color: event.color.withOpacity(0.2),
                    child: Center(
                      child: Icon(
                        event.icon,
                        color: event.color,
                        size: 40,
                      ),
                    ),
                  ),
                ),
              ),
            ],

            // Event details
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Event time and status indicator
                  Row(
                    children: [
                      _buildTimeIndicator(),
                      const Spacer(),
                      _buildEventTypeChip(),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Event title
                  Text(
                    event.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 8),

                  // Event location
                  Row(
                    children: [
                      const Icon(
                        Icons.location_on,
                        color: Colors.grey,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          event.location,
                          style: TextStyle(
                            color: Colors.grey[300],
                            fontSize: 14,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 4),

                  // Attendee count
                  Row(
                    children: [
                      const Icon(
                        Icons.people,
                        color: Colors.grey,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${event.attendeeCount} attending',
                        style: TextStyle(
                          color: Colors.grey[300],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Action buttons for unconfirmed events
                  if (!event.isConfirmed) _buildActionButtons(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Builds the time indicator with icon
  Widget _buildTimeIndicator() {
    final timeFormat = DateFormat('h:mm a');
    final dateFormat = DateFormat('MMM d');

    final timeString = timeFormat.format(event.dateTime);
    final dateString = dateFormat.format(event.dateTime);

    Color timeColor;
    String timeLabel;

    switch (event.status) {
      case ProfileEventStatus.today:
        timeColor = Colors.green;
        timeLabel = 'Today, $timeString';
        break;
      case ProfileEventStatus.upcoming:
        timeColor = Colors.orange;
        timeLabel = '$dateString, $timeString';
        break;
      case ProfileEventStatus.past:
        timeColor = Colors.grey;
        timeLabel = '$dateString, $timeString';
        break;
    }

    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: timeColor.withOpacity(0.2),
            shape: BoxShape.circle,
          ),
          child: Icon(
            Icons.access_time,
            color: timeColor,
            size: 16,
          ),
        ),
        const SizedBox(width: 8),
        Text(
          timeLabel,
          style: TextStyle(
            color: timeColor,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  /// Builds a chip indicating the event type (hosting or attending)
  Widget _buildEventTypeChip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: event.type == ProfileEventType.hosting
            ? Colors.purple.withOpacity(0.2)
            : Colors.blue.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: event.type == ProfileEventType.hosting
              ? Colors.purple
              : Colors.blue,
          width: 1,
        ),
      ),
      child: Text(
        event.type == ProfileEventType.hosting ? 'Hosting' : 'Attending',
        style: TextStyle(
          color: event.type == ProfileEventType.hosting
              ? Colors.purple
              : Colors.blue,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  /// Builds action buttons for unconfirmed events
  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton(
            onPressed: onConfirmTap,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            child: const Text('Confirm'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: OutlinedButton(
            onPressed: onCancelTap,
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.grey,
              side: const BorderSide(color: Colors.grey),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            child: const Text('Cancel'),
          ),
        ),
      ],
    );
  }
}
