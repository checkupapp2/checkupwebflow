import 'package:flutter/material.dart';
import '../../data/firebase_profile_repository.dart';
import '../widgets/owner_profile_card.dart';
import 'edit_profile_page.dart';
import '../widgets/game_matchup_card.dart';
import '../../domain/models/profile_model.dart';
import '../../domain/models/player_stats_model.dart';
import '../../../feed/data/feed_data_provider.dart';
import '../../../feed/domain/models/feed_post_model.dart';
import '../../../feed/presentation/widgets/feed_post.dart';
import '../../../feed/presentation/post_detail_screen.dart';
import '../../domain/models/event_model.dart';
import '../../../events/presentation/pages/event_detail_page.dart';
import '../widgets/date_header.dart';
import '../widgets/section_header.dart';
import '../widgets/player_stats_card.dart';
import '../widgets/team_list_item.dart';
import '../widgets/league_list_item.dart';
import '../pages/award_detail_page.dart';
import '../pages/trophies_page.dart';
import '../../data/award_data_provider.dart';
import '../../../trophies/presentation/pages/trophies_screen.dart';

import 'package:flutter_bloc/flutter_bloc.dart';
import '../../bloc/profile_bloc.dart';
import '../../bloc/profile_event.dart';
import '../../bloc/profile_state.dart';
// import '../../data/profile_repository.dart';
import '../../domain/profile_mappers.dart';

/// Owner's profile page with Edit Profile functionality
class OwnerProfilePage extends StatefulWidget {
  /// Constructor
  const OwnerProfilePage({Key? key}) : super(key: key);

  @override
  State<OwnerProfilePage> createState() => _OwnerProfilePageState();
}

class _OwnerProfilePageState extends State<OwnerProfilePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedTabIndex = 0;

  // Feed data
  late List<FeedPostModel> _feedPosts;

  // Schedule data
  late List<ProfileEventModel> _events;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        setState(() {
          _selectedTabIndex = _tabController.index;
        });
      }
    });

    // Load feed data
    _loadFeedData();

    // Load events data
    _loadEventsData();
  }

  void _loadFeedData() {
    final feedDataProvider = FeedDataProvider();
    _feedPosts = feedDataProvider.getFeedPosts();
  }

  void _loadEventsData() {
    _events = ProfileEventModel.getSampleEvents();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final profile = ProfileModel.sample();
    return BlocProvider(
        create: (_) => ProfileBloc(FirebaseProfileRepository())
          ..add(const ProfileLoadRequested()),
        child: BlocBuilder<ProfileBloc, ProfileState>(
          builder: (context, state) {
            if (state.status == ProfileStatus.loading ||
                state.status == ProfileStatus.initial) {
              return const Scaffold(
                backgroundColor: Color(0xFF121212),
                body: Center(child: CircularProgressIndicator()),
              );
            }
            if (state.status == ProfileStatus.failure) {
              return Scaffold(
                backgroundColor: const Color(0xFF121212),
                body: Center(
                    child: Text('Failed to load profile',
                        style: const TextStyle(color: Colors.white))),
              );
            }

            final uiProfile = toUi(state.profile!);

            // …use uiProfile everywhere you were using ProfileModel.sample()
            // For OwnerProfileCard / ModernProfileCard pass uiProfile fields.
            // The rest of the page code stays the same.
            // Example:
            return Scaffold(
              backgroundColor: const Color(0xFF121212),
              appBar: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0,
                automaticallyImplyLeading: false,
                title: Row(
                  children: [
                    // Back button
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const SizedBox(width: 8),
                    // CHECK-UP logo moved to left
                    Image.asset(
                      'assets/images/checkup_main-1.png',
                      height: 30,
                      fit: BoxFit.contain,
                    ),
                  ],
                ),
                actions: [
                  // Trophy/Experience badge - tappable to navigate to trophies page
                  GestureDetector(
                    onTap: () {
                      // Navigate to the trophies screen when tapped
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => const TrophiesScreen(),
                        ),
                      );
                    },
                    child: Container(
                      margin: const EdgeInsets.only(right: 16),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.orange.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.star,
                            color: Colors.white,
                            size: 16,
                          ),
                          SizedBox(width: 6),
                          Text(
                            'Superstar',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Montserrat',
                            ),
                          ),
                          SizedBox(width: 4),
                          Text(
                            '|',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 12,
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                          SizedBox(width: 4),
                          Text(
                            '87XP',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Montserrat',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    // Owner Profile Card with Edit Profile button
                    OwnerProfileCard(
                      profileImageUrl: uiProfile.profileImageUrl,
                      username: uiProfile.username,
                      fullName: uiProfile.fullName,
                      followers: uiProfile.followers,
                      checkIns: uiProfile.checkIns,
                      gamesPlayed: uiProfile.gamesPlayed,
                      status: uiProfile.status,
                      playerRank: uiProfile.playerRank,
                      hasActiveStories: uiProfile.hasActiveStories,
                      onEditProfileTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => BlocProvider.value(
                            value: context.read<ProfileBloc>(),
                            child: EditProfilePage(initialProfile: uiProfile),
                          ),
                        ));
                      },
                      onTrophiesTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => const TrophiesScreen(),
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 8),

                    // Tab Row
                    _buildTabRow(),

                    const SizedBox(height: 20),

                    // Content based on selected tab
                    _buildTabContent(),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            );
          },
        ));
  }

  /// Builds the tab row
  Widget _buildTabRow() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 50,
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(30),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: const LinearGradient(
            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey,
        labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        unselectedLabelStyle:
            const TextStyle(fontWeight: FontWeight.normal, fontSize: 16),
        indicatorWeight: 0,
        indicatorSize: TabBarIndicatorSize.tab,
        indicatorPadding: EdgeInsets.zero,
        padding: const EdgeInsets.all(4),
        dividerColor: Colors.transparent,
        dividerHeight: 0,
        tabs: const [
          Tab(text: 'Feed'),
          Tab(text: 'Schedule'),
          Tab(text: 'Stats'),
        ],
      ),
    );
  }

  /// Builds content based on selected tab
  Widget _buildTabContent() {
    switch (_selectedTabIndex) {
      case 0:
        return _buildFeedContent();
      case 1:
        return _buildScheduleContent();
      case 2:
        return _buildStatsContent();
      default:
        return _buildFeedContent();
    }
  }

  /// Builds feed content
  Widget _buildFeedContent() {
    return Column(
      children: _feedPosts.asMap().entries.map((entry) {
        final post = entry.value;
        return Column(
          children: [
            GestureDetector(
              onTap: () => _navigateToPostDetail(post),
              child: FeedPost(
                post: post,
                onLikeTap: () => _handlePostInteraction('like', post.id),
                onCommentTap: () => _handlePostInteraction('comment', post.id),
                onRepostTap: () => _handlePostInteraction('repost', post.id),
                onShareTap: () => _handlePostInteraction('share', post.id),
                onPollOptionSelected: (optionIndex) =>
                    _handlePollOptionSelected(post.id, optionIndex),
                onImageTap: (imageIndex) =>
                    _handleImageTap(post.id, imageIndex),
                onVideoTap: () => _handlePostVideoTap(post.id),
                onYouTubeVideoTap: () => _handleYouTubeVideoTap(post.id),
                onEventGoingTap: () => _handleEventGoingTap(post.id),
                onEventInterestedTap: () => _handleEventInterestedTap(post.id),
                onEventTap: () => _handleEventTap(post.id),
                onGameTap: () => _handleGameTap(post.id),
              ),
            ),
            if (entry.key < _feedPosts.length - 1) const SizedBox(height: 16),
          ],
        );
      }).toList(),
    );
  }

  /// Builds schedule content
  Widget _buildScheduleContent() {
    final todayEvents = _events
        .where((event) => event.status == ProfileEventStatus.today)
        .toList();
    final upcomingEvents = _events
        .where((event) => event.status == ProfileEventStatus.upcoming)
        .toList();

    return Column(children: [
      if (todayEvents.isEmpty && upcomingEvents.isEmpty)
        _buildEmptyScheduleState()
      else
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (todayEvents.isNotEmpty) ...[
              const DateHeader(
                title: 'TODAY',
                color: Colors.green,
                icon: Icons.today,
              ),
              ...todayEvents
                  .map((event) => _buildDiscoverStyleEventCard(event))
                  .toList(),
            ],
            if (upcomingEvents.isNotEmpty) ...[
              const DateHeader(
                title: 'UPCOMING',
                color: Colors.orange,
                icon: Icons.calendar_month,
              ),
              ...upcomingEvents
                  .map((event) => _buildDiscoverStyleEventCard(event))
                  .toList(),
            ],
          ]),
        ),
    ]);
  }

  /// Builds stats content
  Widget _buildStatsContent() {
    final profile = ProfileModel.sample();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),

          // Awards section
          if (profile.awards != null && profile.awards!.isNotEmpty) ...[
            SectionHeader(
              title: 'Trophies',
              actionLabel: 'See All',
              onActionTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const TrophiesScreen(),
                  ),
                );
              },
            ),
            SizedBox(
              height: 120,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                children: [
                  _buildAwardItem('MVP', Icons.sports_score, Colors.amber),
                  _buildAwardItem(
                      'ALL TOURNAMENT', Icons.military_tech, Colors.orange),
                  _buildTrophyImageItem(
                      'TEAM PLAYER', 'assets/images/Subject 73.webp'),
                  _buildAwardItem('HUSTLER', Icons.speed, Colors.deepOrange),
                  _buildAwardItem(
                      'CROWD FAVORITE', Icons.favorite, Colors.redAccent),
                  _buildTrophyImageItem(
                      'ROOKIE', 'assets/images/Subject 74.webp'),
                  _buildTrophyImageItem(
                      'SHARPSHOOTER', 'assets/images/Subject 75.webp'),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],

          // Recent games section
          if (profile.recentGames != null &&
              profile.recentGames!.isNotEmpty) ...[
            const SectionHeader(
              title: 'Recent Games',
              actionLabel: 'See All',
            ),
            SizedBox(
              height: 140,
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: profile.recentGames!.length > 5
                    ? 5
                    : profile.recentGames!.length,
                itemBuilder: (context, index) {
                  final game = profile.recentGames![index];
                  return GameMatchupCard(
                    game: game,
                    onTap: () => _handleGameTap(game.id),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
          ],

          // Teams section
          if (profile.teams != null && profile.teams!.isNotEmpty) ...[
            const SectionHeader(
              title: 'Teams',
              actionLabel: 'See All',
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  for (final team in profile.teams!)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: TeamListItem(
                        team: team,
                        onTap: () => _handleTeamTap(team.id),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],

          // Leagues section
          if (profile.leagues != null && profile.leagues!.isNotEmpty) ...[
            const SectionHeader(
              title: 'Leagues',
              actionLabel: 'See All',
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  for (final league in profile.leagues!)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: LeagueListItem(
                        league: league,
                        onTap: () => _handleLeagueTap(league.id),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],

          // All-time stats section
          if (profile.playerStats != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: PlayerStatsCard(stats: profile.playerStats!),
            ),

          const SizedBox(height: 30),
        ],
      ),
    );
  }

  // Event handlers and helper methods (same as original profile page)
  void _handlePostInteraction(String action, String postId) {
    debugPrint('Post $action tapped for post $postId');

    if (action == 'comment') {
      final post = _findPostById(postId);
      if (post != null) {
        _navigateToPostDetail(post, focusComment: true);
        return;
      }
    }
  }

  FeedPostModel? _findPostById(String postId) {
    for (final post in _feedPosts) {
      if (post.id == postId) {
        return post;
      }
    }
    return null;
  }

  void _navigateToPostDetail(FeedPostModel post, {bool focusComment = false}) {
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) =>
            PostDetailScreen(
          post: post,
          focusComment: focusComment,
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(0.0, 0.05);
          const end = Offset.zero;
          const curve = Curves.easeOutCubic;

          var tween =
              Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
          var offsetAnimation = animation.drive(tween);

          return SlideTransition(
            position: offsetAnimation,
            child: FadeTransition(
              opacity: animation,
              child: child,
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  /// Builds a discover-style event card matching the ticket design
  Widget _buildDiscoverStyleEventCard(ProfileEventModel event) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      height: 130,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _handleScheduleEventTap(event.id),
          borderRadius: BorderRadius.circular(16),
          splashColor: Colors.orange.withOpacity(0.1),
          highlightColor: Colors.orange.withOpacity(0.05),
          child: Stack(
            children: [
              // Main ticket container
              Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF2A2A2A), // Dark gray
                      Color(0xFF1A1A1A), // Black
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.4),
                      blurRadius: 15,
                      spreadRadius: 2,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    children: [
                      // Ticket perforations pattern
                      Positioned(
                        right: -8,
                        top: 0,
                        bottom: 0,
                        child: Container(
                          width: 16,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: List.generate(
                              7,
                              (index) => Container(
                                width: 6,
                                height: 6,
                                decoration: const BoxDecoration(
                                  color: Colors.black,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      // Ticket stub separator line
                      Positioned(
                        right: 12,
                        top: 0,
                        bottom: 0,
                        child: Container(
                          width: 1,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                          ),
                        ),
                      ),
                      // Main content
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 16, 30, 16),
                        child: Row(
                          children: [
                            // Event image/icon (larger)
                            Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(14),
                                color: Colors.white.withOpacity(0.1),
                                border: Border.all(
                                  color:
                                      const Color(0xFFFF9800).withOpacity(0.4),
                                  width: 2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFFFF9800)
                                        .withOpacity(0.2),
                                    blurRadius: 8,
                                    spreadRadius: 1,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: event.thumbnailUrl.isNotEmpty
                                  ? ClipRRect(
                                      borderRadius: BorderRadius.circular(12),
                                      child: Image.network(
                                        event.thumbnailUrl,
                                        fit: BoxFit.cover,
                                        errorBuilder:
                                            (context, error, stackTrace) {
                                          return _buildEventIcon(event);
                                        },
                                      ),
                                    )
                                  : _buildEventIcon(event),
                            ),
                            const SizedBox(width: 16),
                            // Event details
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  // Event title
                                  Text(
                                    event.title,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 17,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.3,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 8),
                                  // Date and time
                                  Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(4),
                                        decoration: BoxDecoration(
                                          color: Colors.white.withOpacity(0.15),
                                          borderRadius:
                                              BorderRadius.circular(6),
                                        ),
                                        child: Icon(
                                          Icons.access_time_rounded,
                                          size: 14,
                                          color: Colors.grey[300],
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        event.date,
                                        style: TextStyle(
                                          color: Colors.grey[300],
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  // Location
                                  Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(4),
                                        decoration: BoxDecoration(
                                          color: Colors.white.withOpacity(0.15),
                                          borderRadius:
                                              BorderRadius.circular(6),
                                        ),
                                        child: Icon(
                                          Icons.location_on_rounded,
                                          size: 14,
                                          color: Colors.grey[300],
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Expanded(
                                        child: Text(
                                          event.location,
                                          style: TextStyle(
                                            color: Colors.grey[300],
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Event type badge (positioned over image bottom-left)
                      Positioned(
                        left: 20,
                        bottom: 20,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFFFF9800),
                                Color(0xFFFF5722),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.4),
                                blurRadius: 6,
                                spreadRadius: 1,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Text(
                            _getEventType(event.gameType),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Builds event icon for discover-style cards
  Widget _buildEventIcon(ProfileEventModel event) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.orange[800]!.withOpacity(0.3),
            Colors.orange[900]!.withOpacity(0.3),
          ],
        ),
      ),
      child: const Center(
        child: Icon(Icons.sports_basketball, size: 32, color: Colors.orange),
      ),
    );
  }

  /// Maps game type to proper event type badge
  String _getEventType(String gameType) {
    // Map to only valid event types: runs, 1v1, tournament, training, camp, fundraiser, special events
    final lowerType = gameType.toLowerCase();

    // Handle common patterns from search repository
    if (lowerType.contains('open play') ||
        lowerType.contains('pickup') ||
        lowerType.contains('basketball') ||
        lowerType.contains('3v3') ||
        lowerType.contains('5v5') ||
        lowerType.contains('opengym') ||
        lowerType.contains('open gym') ||
        lowerType.contains('casual')) {
      return 'Runs';
    }

    if (lowerType.contains('1v1') || lowerType.contains('onevsone')) {
      return '1v1';
    }

    if (lowerType.contains('tournament') ||
        lowerType.contains('elimination') ||
        lowerType.contains('bracket')) {
      return 'Tournament';
    }

    if (lowerType.contains('training') || lowerType.contains('skill')) {
      return 'Training';
    }

    if (lowerType.contains('camp')) {
      return 'Camp';
    }

    if (lowerType.contains('donation') ||
        lowerType.contains('charity') ||
        lowerType.contains('fundraiser')) {
      return 'Fundraiser';
    }

    if (lowerType.contains('special') ||
        lowerType.contains('showcase') ||
        lowerType.contains('oneoff') ||
        lowerType.contains('one-off')) {
      return 'Special Events';
    }

    // Default to 'Runs' for any unrecognized type
    return 'Runs';
  }

  Widget _buildEmptyScheduleState() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.event_busy,
            size: 64,
            color: Colors.grey[600],
          ),
          const SizedBox(height: 16),
          const Text(
            'No events found',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'You have no upcoming events in your schedule',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.grey[400],
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              debugPrint('Create event button tapped');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: const Text('Create Event'),
          ),
        ],
      ),
    );
  }

  Widget _buildAwardItem(String name, IconData icon, Color color) {
    return Container(
      width: 100,
      margin: const EdgeInsets.only(right: 12),
      child: GestureDetector(
        onTap: () => _handleAwardTap(name),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    color.withOpacity(0.3),
                    color.withOpacity(0.1),
                  ],
                ),
                border: Border.all(
                  color: color,
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.3),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Icon(
                icon,
                color: color,
                size: 32,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              name,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 11,
                letterSpacing: 0.5,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTrophyImageItem(String name, String imagePath) {
    return Container(
      width: 100,
      margin: const EdgeInsets.only(right: 12),
      child: GestureDetector(
        onTap: () => _handleAwardTap(name),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    Colors.orange.withOpacity(0.3),
                    Colors.orange.withOpacity(0.1),
                  ],
                ),
                border: Border.all(
                  color: Colors.orange,
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.orange.withOpacity(0.3),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: ClipOval(
                child: Image.asset(
                  imagePath,
                  width: 66,
                  height: 66,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Icon(
                    Icons.emoji_events,
                    color: Colors.orange,
                    size: 32,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              name,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 11,
                letterSpacing: 0.5,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  // Event handlers
  void _handleScheduleEventTap(String eventId) {
    debugPrint('Event tapped: $eventId');

    final events = ProfileEventModel.getSampleEvents();

    ProfileEventModel? event;
    try {
      event = events.firstWhere((e) => e.id == eventId);
    } catch (e) {
      event = null;
    }

    if (event != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => EventDetailPage(
            eventId: eventId,
            title: event!.title,
            // eventType: event.gameType,
          ),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => EventDetailPage(
            eventId: eventId,
            title: '',
          ),
        ),
      );
    }
  }

  void _handleAwardTap(String awardId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const TrophiesScreen(),
      ),
    );
  }

  void _handleGameTap(String gameId) {
    debugPrint('Game tapped: $gameId');
  }

  void _handleTeamTap(String teamId) {
    debugPrint('Team tapped: $teamId');
  }

  void _handleLeagueTap(String leagueId) {
    debugPrint('League tapped: $leagueId');
  }

  void _handlePollOptionSelected(String postId, int optionIndex) {
    debugPrint('Poll option $optionIndex selected for post $postId');
  }

  void _handleImageTap(String postId, int imageIndex) {
    debugPrint('Image $imageIndex tapped in post $postId');
  }

  void _handlePostVideoTap(String postId) {
    debugPrint('Video tapped in post $postId');
  }

  void _handleYouTubeVideoTap(String postId) {
    debugPrint('YouTube video tapped in post $postId');
  }

  void _handleEventGoingTap(String postId) {
    debugPrint('Going button tapped for event in post $postId');
  }

  void _handleEventInterestedTap(String postId) {
    debugPrint('Interested button tapped for event in post $postId');
  }

  void _handleEventTap(String postId) {
    debugPrint('Event tapped in post $postId');
  }
}
