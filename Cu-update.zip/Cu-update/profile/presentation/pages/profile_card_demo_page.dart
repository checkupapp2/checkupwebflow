import 'package:flutter/material.dart';
import '../widgets/modern_profile_card.dart';
import '../../domain/models/profile_model.dart';

/// A demo page to showcase the modern profile card
class ProfileCardDemoPage extends StatefulWidget {
  /// Constructor
  const ProfileCardDemoPage({Key? key}) : super(key: key);

  @override
  State<ProfileCardDemoPage> createState() => _ProfileCardDemoPageState();
}

class _ProfileCardDemoPageState extends State<ProfileCardDemoPage> {
  // Sample profile data
  late ProfileModel _profile;
  bool _isFollowing = false;

  @override
  void initState() {
    super.initState();
    _profile = ProfileModel.sample();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'Profile Card Demo',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 20),
            
            // Modern Profile Card
            ModernProfileCard(
              profileImageUrl: _profile.profileImageUrl,
              username: _profile.username,
              fullName: _profile.fullName,
              followers: _profile.followers,
              checkIns: _profile.checkIns,
              gamesPlayed: _profile.gamesPlayed,
              isFollowing: _isFollowing,
              onFollowTap: () {
                setState(() {
                  _isFollowing = !_isFollowing;
                });
                
                // Show feedback
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(_isFollowing ? 'Following user!' : 'Unfollowed user'),
                    backgroundColor: _isFollowing ? Colors.green : Colors.grey[700],
                  ),
                );
              },
            ),
            
            const SizedBox(height: 30),
            
            // Customization controls
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A1A),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Card Controls',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Toggle follow state button
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _isFollowing = !_isFollowing;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                    ),
                    child: Text(_isFollowing ? 'Unfollow User' : 'Follow User'),
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Explanation text
                  const Text(
                    'This is a demo of the modern profile card component. The card features a glossy black gradient background, profile avatar, username, full name, stats (followers, check-ins, games), social media icons, and a gradient orange follow button.',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
