import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import '../../domain/models/profile_model.dart';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart'; // ← add
import '../../bloc/profile_bloc.dart';
import '../../bloc/profile_event.dart';
import '../../bloc/profile_state.dart';

class EditProfilePage extends StatefulWidget {
  final ProfileModel? initialProfile;

  const EditProfilePage({Key? key, this.initialProfile}) : super(key: key);

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late TextEditingController _fullNameController;
  late TextEditingController _usernameController;
  late TextEditingController _statusController; // bio/about
  late TextEditingController _locationController; // checkedInAt
  late TextEditingController _instagramController;
  late TextEditingController _twitterController;
  late TextEditingController _facebookController;
  late TextEditingController _aboutController; // About Me
  late TextEditingController _careerHighlightsController; // Career Highlights

  String _selectedProfileType = 'Player';
  final List<String> _profileTypeOptions = const ['Player', 'Host', 'Coach'];

  @override
  void initState() {
    super.initState();
    final p = widget.initialProfile ?? ProfileModel.sample();
    _fullNameController = TextEditingController(text: p.fullName);
    _usernameController = TextEditingController(text: p.username);
    _statusController = TextEditingController(text: p.status ?? '');
    _locationController = TextEditingController(text: p.checkedInAt ?? '');
    _instagramController =
        TextEditingController(text: p.socialLinks?['instagram'] ?? '');
    _twitterController =
        TextEditingController(text: p.socialLinks?['twitter'] ?? '');
    _facebookController =
        TextEditingController(text: p.socialLinks?['facebook'] ?? '');
    _aboutController = TextEditingController(text: '');
    _careerHighlightsController = TextEditingController(text: '');
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _usernameController.dispose();
    _statusController.dispose();
    _locationController.dispose();
    _instagramController.dispose();
    _twitterController.dispose();
    _facebookController.dispose();
    _aboutController.dispose();
    _careerHighlightsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<ProfileBloc, ProfileState>(
      listenWhen: (prev, curr) => prev.status != curr.status,
      listener: (context, state) {
        if (state.status == ProfileStatus.uploadingAvatar) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Uploading photo...')),
          );
        } else if (state.status == ProfileStatus.ready &&
            prevStatusWasUploading(prev: state)) {
          ScaffoldMessenger.of(context).hideCurrentSnackBar();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Photo updated'),
              backgroundColor: Colors.green,
            ),
          );
        } else if (state.status == ProfileStatus.failure) {
          ScaffoldMessenger.of(context).hideCurrentSnackBar();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.error ?? 'Something went wrong'),
              backgroundColor: Colors.red,
            ),
          );
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          title:
              const Text('Edit Profile', style: TextStyle(color: Colors.white)),
          actions: [
            TextButton(
              onPressed: _onSave,
              child: const Text('Save',
                  style: TextStyle(
                      color: Colors.orange, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
        body: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildAvatarSection(),
              const SizedBox(height: 16),
              _buildLabeledField('Full Name', _fullNameController, Icons.badge),
              _buildLabeledField(
                  'Username', _usernameController, Icons.alternate_email),
              _buildLabeledField('Status', _statusController, Icons.notes,
                  hint: 'What are you up to?'),
              _buildMultilineField('About Me', _aboutController, Icons.person,
                  hint: 'Tell the community about yourself'),
              _buildMultilineField('Career Highlights',
                  _careerHighlightsController, Icons.emoji_events,
                  hint: 'List your awards and milestones'),
              _buildProfileTypeDropdown(),
              const SizedBox(height: 8),
              _buildLabeledField(
                  'Location', _locationController, Icons.location_on,
                  hint: 'Where you hoop?'),
              const SizedBox(height: 8),
              const _SectionHeader(title: 'Social Links'),
              _buildLabeledField(
                  'Instagram', _instagramController, Icons.photo_camera),
              _buildLabeledField(
                  'Twitter', _twitterController, Icons.alternate_email),
              _buildLabeledField(
                  'Facebook', _facebookController, Icons.facebook),
              const SizedBox(height: 24),
              _buildSaveButton(),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  // helper to detect transition from uploadingAvatar -> ready
  bool prevStatusWasUploading({required ProfileState prev}) {
    // when listener runs we only have current state; quick heuristic:
    // rely on the snackbar flow + ready trigger; optional to keep simple.
    return true;
  }

  Widget _buildProfileTypeDropdown() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1C1C1C), Color(0xFF121212)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white24.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 12,
              offset: const Offset(0, 6)),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)]),
            ),
            child: const Icon(Icons.badge, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text('Profile Type',
                style: TextStyle(color: Colors.white70, fontSize: 12)),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
            ),
            child: DropdownButton<String>(
              value: _profileTypeOptions.contains(_selectedProfileType)
                  ? _selectedProfileType
                  : _profileTypeOptions.first,
              onChanged: (val) {
                if (val != null) setState(() => _selectedProfileType = val);
              },
              dropdownColor: const Color(0xFF1C1C1C),
              underline: const SizedBox.shrink(),
              style: const TextStyle(color: Colors.white),
              items: _profileTypeOptions
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAvatarSection() {
    final liveUrl = context.watch<ProfileBloc>().state.profile?.profileImageUrl;

    return Row(
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFF9800).withOpacity(0.35),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Container(
                margin: const EdgeInsets.all(3),
                decoration: const BoxDecoration(
                  color: Color(0xFF121212),
                  shape: BoxShape.circle,
                ),
                child: ClipOval(
                  child: (liveUrl != null && liveUrl.isNotEmpty)
                      ? Image.network(
                          liveUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Icon(Icons.person,
                              color: Colors.white, size: 48),
                        )
                      : const Icon(Icons.person, color: Colors.white, size: 48),
                ),
              ),
            ),
            Positioned(
              right: -4,
              bottom: -4,
              child: GestureDetector(
                onTap: _onChangePhoto,
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    ),
                    border: Border.all(color: Colors.black, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: const Icon(Icons.camera_alt,
                      color: Colors.white, size: 18),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFF2A2A2A), Color(0xFF1A1A1A)]),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.25),
                    blurRadius: 12,
                    offset: const Offset(0, 6)),
              ],
            ),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: _onChangePhoto,
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.camera_alt, color: Colors.white, size: 18),
                    SizedBox(width: 8),
                    Text('Change Photo',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMultilineField(
      String label, TextEditingController controller, IconData icon,
      {String? hint}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1C1C1C), Color(0xFF121212)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white24.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 12,
              offset: const Offset(0, 6)),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)]),
            ),
            child: Icon(icon, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style:
                        const TextStyle(color: Colors.white70, fontSize: 12)),
                TextField(
                  controller: controller,
                  style: const TextStyle(color: Colors.white),
                  maxLines: 4,
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.4)),
                    border: InputBorder.none,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLabeledField(
      String label, TextEditingController controller, IconData icon,
      {String? hint}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1C1C1C), Color(0xFF121212)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white24.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 12,
              offset: const Offset(0, 6)),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)]),
            ),
            child: Icon(icon, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style:
                        const TextStyle(color: Colors.white70, fontSize: 12)),
                TextField(
                  controller: controller,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.4)),
                    border: InputBorder.none,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSaveButton() {
    return SizedBox(
      width: double.infinity,
      child: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [Color(0xFFFF9800), Color(0xFFFF5722)]),
          borderRadius: BorderRadius.circular(28),
          boxShadow: [
            BoxShadow(
                color: const Color(0xFFFF9800).withOpacity(0.35),
                blurRadius: 16,
                offset: const Offset(0, 6)),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(28),
            onTap: _onSave,
            child: const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Center(
                child: Text(
                  'Save Changes',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _onChangePhoto() async {
    final picker = ImagePicker();

    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: Colors.black87,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library, color: Colors.white),
              title: const Text('Choose from Gallery',
                  style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.photo_camera, color: Colors.white),
              title: const Text('Take a Photo',
                  style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
          ],
        ),
      ),
    );

    if (source == null) return;

    final picked = await picker.pickImage(
      source: source,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 82,
    );
    if (picked == null) return;

    context.read<ProfileBloc>().add(ProfileAvatarPicked(File(picked.path)));
  }

  void _onSave() {
    final bloc = context.read<ProfileBloc>();

    bloc.add(ProfileSaveSubmitted(
      fullName: _fullNameController.text.trim(),
      username: _usernameController.text.trim(),
      status: _statusController.text.trim().isEmpty
          ? null
          : _statusController.text.trim(),
      checkedInAt: _locationController.text.trim().isEmpty
          ? null
          : _locationController.text.trim(),
      socialLinks: {
        if (_instagramController.text.trim().isNotEmpty)
          'instagram': _instagramController.text.trim(),
        if (_twitterController.text.trim().isNotEmpty)
          'twitter': _twitterController.text.trim(),
        if (_facebookController.text.trim().isNotEmpty)
          'facebook': _facebookController.text.trim(),
      },
      profileType: _selectedProfileType,
      about: _aboutController.text.trim().isEmpty
          ? null
          : _aboutController.text.trim(),
      careerHighlights: _careerHighlightsController.text.trim().isEmpty
          ? null
          : _careerHighlightsController.text.trim(),
    ));

    StreamSubscription<ProfileState>? sub;
    sub = bloc.stream.listen((s) {
      if (s.status == ProfileStatus.success) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Profile updated'), backgroundColor: Colors.green),
        );
        sub?.cancel();
        Navigator.pop(context);
      } else if (s.status == ProfileStatus.failure) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text(s.error ?? 'Update failed'),
              backgroundColor: Colors.red),
        );
        sub?.cancel();
      }
    });
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 18,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFFFF9800), Color(0xFFFF5722)]),
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 10),
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                  fontSize: 14)),
        ],
      ),
    );
  }
}
