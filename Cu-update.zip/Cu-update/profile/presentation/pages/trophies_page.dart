import 'package:flutter/material.dart';
import '../../domain/models/player_stats_model.dart';
import '../../data/award_data_provider.dart';
import 'award_detail_page.dart';

/// A page to display all trophies and awards
class TrophiesPage extends StatelessWidget {
  /// Constructor
  const TrophiesPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Get sample awards
    final awards = PlayerAwardModel.getSampleAwards();
    
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'Trophies & Awards',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                children: [
                  const Icon(
                    Icons.emoji_events,
                    color: Colors.amber,
                    size: 28,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Your Achievements',
                    style: TextStyle(
                      color: Colors.grey[200],
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Tap on any award to see details',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 24),
              
              // Awards grid
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.85,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: awards.length,
                itemBuilder: (context, index) {
                  final award = awards[index];
                  return _buildAwardCard(context, award);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  // Build an award card
  Widget _buildAwardCard(BuildContext context, PlayerAwardModel award) {
    // Parse the color from hex string
    final Color awardColor = _parseColor(award.color);
    
    // Get the icon based on the award icon name
    final IconData awardIcon = _getIconData(award.icon);
    
    return GestureDetector(
      onTap: () => _navigateToAwardDetail(context, award),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: awardColor.withOpacity(0.5),
            width: 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Badge icon
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: awardColor.withOpacity(0.2),
                shape: BoxShape.circle,
                border: Border.all(
                  color: awardColor,
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: awardColor.withOpacity(0.3),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Icon(
                awardIcon,
                color: awardColor,
                size: 40,
              ),
            ),
            const SizedBox(height: 12),
            
            // Award name
            Text(
              award.name,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            
            // Award date
            Text(
              _formatDate(award.dateAwarded),
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 12,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
  
  // Navigate to award detail page
  void _navigateToAwardDetail(BuildContext context, PlayerAwardModel award) {
    // Get award events from data provider
    final awardDataProvider = AwardDataProvider();
    final awardEvents = awardDataProvider.getAwardEvents(award.id);
    
    // Navigate to award detail page
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AwardDetailPage(
          award: award,
          awardEvents: awardEvents,
        ),
      ),
    );
  }
  
  // Helper method to parse color from hex string
  Color _parseColor(String hexColor) {
    try {
      hexColor = hexColor.replaceAll('#', '');
      if (hexColor.length == 6) {
        return Color(int.parse('0xFF$hexColor'));
      }
      return Colors.orange;
    } catch (e) {
      return Colors.orange;
    }
  }
  
  // Helper method to get icon data based on icon name
  IconData _getIconData(String iconName) {
    switch (iconName.toLowerCase()) {
      case 'trophy':
        return Icons.emoji_events;
      case 'star':
        return Icons.star;
      case 'bolt':
        return Icons.bolt;
      case 'target':
        return Icons.gps_fixed;
      case 'medal':
        return Icons.military_tech;
      case 'fire':
        return Icons.local_fire_department;
      case 'crown':
        return Icons.workspace_premium;
      default:
        return Icons.emoji_events;
    }
  }
  
  // Helper method to format date
  String _formatDate(DateTime date) {
    final months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${months[date.month - 1]} ${date.day}, ${date.year}';
  }
}
