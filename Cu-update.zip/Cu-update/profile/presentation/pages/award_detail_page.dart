import 'package:flutter/material.dart';
import '../../domain/models/player_stats_model.dart';

/// A page to display detailed information about an award
class AwardDetailPage extends StatelessWidget {
  /// The award to display
  final PlayerAwardModel award;

  /// The events that led to this award
  final List<Map<String, dynamic>> awardEvents;

  /// Constructor
  const AwardDetailPage({
    super.key,
    required this.award,
    required this.awardEvents,
  });

  @override
  Widget build(BuildContext context) {
    // Parse the color from hex string
    final Color awardColor = _parseColor(award.color);
    
    // Get the icon based on the award icon name
    final IconData awardIcon = _getIconData(award.icon);
    
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text('Award Details'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Award badge
              Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: awardColor.withOpacity(0.2),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: awardColor,
                    width: 3,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: awardColor.withOpacity(0.3),
                      blurRadius: 12,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Icon(
                  awardIcon,
                  color: awardColor,
                  size: 60,
                ),
              ),
              const SizedBox(height: 24),
              
              // Award name
              Text(
                award.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              
              // Award date
              Text(
                'Awarded on ${_formatDate(award.dateAwarded)}',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              
              // Award description
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1E1E),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: awardColor.withOpacity(0.5),
                    width: 1,
                  ),
                ),
                child: Text(
                  award.description,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 32),
              
              // Events section header
              const Row(
                children: [
                  Icon(
                    Icons.event_note,
                    color: Colors.white,
                    size: 20,
                  ),
                  SizedBox(width: 8),
                  Text(
                    'Events & Stats',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              
              // Events list
              ...awardEvents.map((event) => _buildEventItem(event, awardColor)).toList(),
            ],
          ),
        ),
      ),
    );
  }
  
  // Helper method to build an event item
  Widget _buildEventItem(Map<String, dynamic> event, Color awardColor) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Event date and location
          Row(
            children: [
              Icon(
                Icons.calendar_today,
                color: Colors.grey[400],
                size: 14,
              ),
              const SizedBox(width: 6),
              Text(
                event['date'] ?? '',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 14,
                ),
              ),
              const SizedBox(width: 16),
              Icon(
                Icons.location_on,
                color: Colors.grey[400],
                size: 14,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  event['location'] ?? '',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 14,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          
          // Event title
          Text(
            event['title'] ?? '',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 12),
          
          // Event stats
          if (event['stats'] != null && (event['stats'] as List).isNotEmpty)
            Wrap(
              spacing: 8.0,
              runSpacing: 8.0,
              children: [
                for (final stat in event['stats'] as List)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: awardColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: awardColor.withOpacity(0.5), width: 1),
                    ),
                    child: Text(
                      stat,
                      style: TextStyle(
                        color: awardColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
              ],
            ),
        ],
      ),
    );
  }
  
  // Helper method to parse color from hex string
  Color _parseColor(String hexColor) {
    try {
      hexColor = hexColor.replaceAll('#', '');
      if (hexColor.length == 6) {
        return Color(int.parse('0xFF$hexColor'));
      }
      return Colors.orange;
    } catch (e) {
      return Colors.orange;
    }
  }
  
  // Helper method to get icon data based on icon name
  IconData _getIconData(String iconName) {
    switch (iconName.toLowerCase()) {
      case 'trophy':
        return Icons.emoji_events;
      case 'star':
        return Icons.star;
      case 'bolt':
        return Icons.bolt;
      case 'target':
        return Icons.gps_fixed;
      case 'medal':
        return Icons.military_tech;
      case 'fire':
        return Icons.local_fire_department;
      case 'crown':
        return Icons.workspace_premium;
      default:
        return Icons.emoji_events;
    }
  }
  
  // Helper method to format date
  String _formatDate(DateTime date) {
    final months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return '${months[date.month - 1]} ${date.day}, ${date.year}';
  }
}
