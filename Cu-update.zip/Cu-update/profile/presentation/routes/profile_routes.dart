import 'package:flutter/material.dart';
import '../pages/profile_page.dart';

/// Routes for the profile feature
class ProfileRoutes {
  /// Route name for the profile page
  static const String profilePage = '/profile';
  
  /// Register profile routes
  static Map<String, WidgetBuilder> getRoutes() {
    return {
      profilePage: (context) => const ProfilePage(),
    };
  }
  
  /// Navigate to profile page
  static void navigateToProfilePage(BuildContext context) {
    Navigator.pushNamed(context, profilePage);
  }
}
