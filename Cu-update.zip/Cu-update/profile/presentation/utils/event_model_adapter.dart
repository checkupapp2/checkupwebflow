import 'package:check_up_app/features/profile/domain/models/event_model.dart'
    as profile;
import 'package:check_up_app/features/events/domain/models/event_model.dart'
    as events;
import 'package:check_up_app/features/events/domain/models/event_type.dart';

/// Adapter class to convert between different ProfileEventModel implementations
class EventModelAdapter {
  /// Convert a profile ProfileEventModel to an events ProfileEventModel (PickupRunEvent)
  /// This allows us to use the standard EventCard with profile events
  static events.PickupRunEvent convertToEventsModel(
      profile.ProfileEventModel profileEvent) {
    // Map the registration status
    events.RegistrationStatus registrationStatus;
    switch (profileEvent.type) {
      case profile.ProfileEventType.attending:
        registrationStatus = events.RegistrationStatus.approved;
        break;
      case profile.ProfileEventType.hosting:
      default:
        registrationStatus = events.RegistrationStatus.approved;
        break;
    }

    // Extract price as double (default to 0.0 if not parseable)
    double? priceValue;
    bool isFree = profileEvent.price.toLowerCase().contains('free');

    if (!isFree) {
      // Try to extract numeric value from price string
      final priceString = profileEvent.price.replaceAll(RegExp(r'[^\d.]'), '');
      if (priceString.isNotEmpty) {
        priceValue = double.tryParse(priceString) ?? 0.0;
      }
    }

    // Create a PickupRunEvent from the profile ProfileEventModel
    return events.PickupRunEvent(
      id: profileEvent.id,
      title: profileEvent.title,
      description: profileEvent.description ?? 'No description available',
      dateTime: profileEvent.dateTime,
      location: profileEvent.location,
      bannerImageUrl: profileEvent.thumbnailUrl,
      category: profileEvent.gameType,
      isFree: isFree,
      price: priceValue,
      maxPlayers:
          profileEvent.attendeeCount > 0 ? profileEvent.attendeeCount : 10,
      currentPlayers: profileEvent.reviews,
      skillLevel: 'All Levels',
      registrationStatus: registrationStatus,
      locationHidden: false, // Default value for locationHidden
    );
  }
}
