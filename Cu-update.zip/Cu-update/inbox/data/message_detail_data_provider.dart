import '../domain/models/message_detail_model.dart';
import '../domain/models/message_model.dart';

/// Provider for message detail data
class MessageDetailDataProvider {
  /// Get a list of messages for a specific conversation
  List<MessageDetailModel> getMessageDetails(MessageModel conversation) {
    // In a real app, this would fetch messages from a database or API
    // based on the conversation ID

    // Generate different messages based on conversation type
    if (conversation.type == 'direct') {
      return _getDirectMessageDetails(conversation);
    } else {
      return _getGroupMessageDetails(conversation);
    }
  }

  /// Get messages for a direct conversation
  List<MessageDetailModel> _getDirectMessageDetails(MessageModel conversation) {
    final now = DateTime.now();

    return [
      MessageDetailModel(
        id: '1',
        senderId: conversation.id,
        senderName: conversation.senderName,
        senderImageUrl: conversation.senderImageUrl,
        content: 'Hey, how\'s it going?',
        time: now.subtract(const Duration(days: 0, hours: 2, minutes: 35)),
        isRead: true,
        isFromCurrentUser: false,
      ),
      MessageDetailModel(
        id: '2',
        senderId: 'current_user',
        senderName: 'You',
        senderImageUrl: 'https://i.pravatar.cc/150?u=current_user',
        content: 'Not bad! Just finished practice. You?',
        time: now.subtract(const Duration(days: 0, hours: 2, minutes: 30)),
        isRead: true,
        isFromCurrentUser: true,
      ),
      MessageDetailModel(
        id: '3',
        senderId: conversation.id,
        senderName: conversation.senderName,
        senderImageUrl: conversation.senderImageUrl,
        content: 'Same here. Did you see the game last night?',
        time: now.subtract(const Duration(days: 0, hours: 2, minutes: 25)),
        isRead: true,
        isFromCurrentUser: false,
      ),
      MessageDetailModel(
        id: '4',
        senderId: 'current_user',
        senderName: 'You',
        senderImageUrl: 'https://i.pravatar.cc/150?u=current_user',
        content: 'Yeah, it was incredible! That last-minute shot was amazing.',
        time: now.subtract(const Duration(days: 0, hours: 2, minutes: 20)),
        isRead: true,
        isFromCurrentUser: true,
      ),
      MessageDetailModel(
        id: '5',
        senderId: conversation.id,
        senderName: conversation.senderName,
        senderImageUrl: conversation.senderImageUrl,
        content: 'Check out this highlight reel',
        time: now.subtract(const Duration(days: 0, hours: 2, minutes: 15)),
        isRead: true,
        isFromCurrentUser: false,
      ),
      MessageDetailModel(
        id: '6',
        senderId: conversation.id,
        senderName: conversation.senderName,
        senderImageUrl: conversation.senderImageUrl,
        content: 'https://example.com/video',
        time: now.subtract(const Duration(days: 0, hours: 2, minutes: 15)),
        isRead: true,
        isFromCurrentUser: false,
        messageType: 'video',
        mediaUrl: 'https://i.pravatar.cc/300?u=basketball_video',
      ),
      MessageDetailModel(
        id: '7',
        senderId: 'current_user',
        senderName: 'You',
        senderImageUrl: 'https://i.pravatar.cc/150?u=current_user',
        content: 'That\'s awesome! We should try that move in practice.',
        time: now.subtract(const Duration(days: 0, hours: 2, minutes: 10)),
        isRead: true,
        isFromCurrentUser: true,
      ),
      MessageDetailModel(
        id: '8',
        senderId: conversation.id,
        senderName: conversation.senderName,
        senderImageUrl: conversation.senderImageUrl,
        content: 'Check out this upcoming tournament!',
        time: now.subtract(const Duration(days: 0, hours: 0, minutes: 20)),
        isRead: false,
        isFromCurrentUser: false,
        messageType: 'event',
        eventData: {
          'title': 'Summer Basketball Tournament',
          'description':
              'Annual 3v3 basketball tournament with prizes for winners.',
          'location': 'Central Park Courts, New York',
          'dateTime': DateTime(2025, 7, 15, 10, 0).toIso8601String(),
          'imageUrl': 'https://picsum.photos/400/300?random=7',
          'goingCount': 156,
          'interestedCount': 342,
          'isGoing': false,
          'isInterested': false,
        },
      ),
      MessageDetailModel(
        id: '9',
        senderId: 'current_user',
        senderName: 'You',
        senderImageUrl: 'https://i.pravatar.cc/150?u=current_user',
        content: 'Here\'s the court we talked about',
        time: now.subtract(const Duration(days: 0, hours: 0, minutes: 18)),
        isRead: true,
        isFromCurrentUser: true,
        messageType: 'court',
        courtData: {
          'id': 'venice_beach_court',
          'name': 'Venice Beach Basketball Courts',
          'address': '1800 Ocean Front Walk, Venice, CA 90291',
          'imageUrl': 'https://picsum.photos/400/300?random=court',
          'latitude': 33.9850,
          'longitude': -118.4695,
        },
      ),
      MessageDetailModel(
        id: '10',
        senderId: conversation.id,
        senderName: conversation.senderName,
        senderImageUrl: conversation.senderImageUrl,
        content: 'Did you see last night\'s game score?',
        time: now.subtract(const Duration(days: 0, hours: 0, minutes: 16)),
        isRead: false,
        isFromCurrentUser: false,
        messageType: 'gameScore',
        gameScoreData: {
          'homeTeam': 'Lakers',
          'awayTeam': 'Warriors',
          'homeScore': 108,
          'awayScore': 112,
          'homeTeamLogoUrl': 'https://picsum.photos/100/100?random=lakers',
          'awayTeamLogoUrl': 'https://picsum.photos/100/100?random=warriors',
          'gameStatus': 'Final',
          'gameDate': DateTime.now()
              .subtract(const Duration(days: 1))
              .toIso8601String(),
          'gameLocation': 'Crypto.com Arena',
        },
      ),
      MessageDetailModel(
        id: '11',
        senderId: conversation.id,
        senderName: conversation.senderName,
        senderImageUrl: conversation.senderImageUrl,
        content: 'Check out the tournament bracket!',
        time: now.subtract(const Duration(days: 0, hours: 0, minutes: 14)),
        isRead: false,
        isFromCurrentUser: false,
        messageType: 'bracket',
        bracketData: {
          'title': 'Tournament Bracket',
          'teamCount': 8,
          'format': 'Single Elimination',
          'stage': 'Quarterfinals',
          'matches': [
            {
              'team1': 'Lakers',
              'team2': 'Warriors',
              'score1': 92,
              'score2': 85,
              'isComplete': true,
              'winner': 'Lakers'
            },
            {
              'team1': 'Celtics',
              'team2': 'Heat',
              'score1': 78,
              'score2': 82,
              'isComplete': true,
              'winner': 'Heat'
            },
            {
              'team1': 'Nets',
              'team2': 'Knicks',
              'score1': null,
              'score2': null,
              'isComplete': false,
              'winner': null
            },
            {
              'team1': 'Bulls',
              'team2': 'Bucks',
              'score1': null,
              'score2': null,
              'isComplete': false,
              'winner': null
            },
          ],
        },
      ),
      MessageDetailModel(
        id: '12',
        senderId: conversation.id,
        senderName: conversation.senderName,
        senderImageUrl: conversation.senderImageUrl,
        content: conversation.content,
        time: now.subtract(const Duration(days: 0, hours: 0, minutes: 15)),
        isRead: false,
        isFromCurrentUser: false,
      ),
    ];
  }

  /// Get messages for a group conversation
  List<MessageDetailModel> _getGroupMessageDetails(MessageModel conversation) {
    final now = DateTime.now();

    // Create some mock participants for the group
    final participants = [
      {
        'id': 'user1',
        'name': 'Stephen Curry',
        'imageUrl': 'https://i.pravatar.cc/150?u=stephen',
      },
      {
        'id': 'user2',
        'name': 'Kevin Durant',
        'imageUrl': 'https://i.pravatar.cc/150?u=kevin',
      },
      {
        'id': 'user3',
        'name': 'Giannis Antetokounmpo',
        'imageUrl': 'https://i.pravatar.cc/150?u=giannis',
      },
      {
        'id': 'current_user',
        'name': 'You',
        'imageUrl': 'https://i.pravatar.cc/150?u=current_user',
      },
    ];

    return [
      MessageDetailModel(
        id: '1',
        senderId: 'user1',
        senderName: participants[0]['name']!,
        senderImageUrl: participants[0]['imageUrl']!,
        content: 'Hey everyone, are we still on for practice tomorrow?',
        time: now.subtract(const Duration(days: 0, hours: 5, minutes: 45)),
        isRead: true,
        isFromCurrentUser: false,
      ),
      MessageDetailModel(
        id: '2',
        senderId: 'user2',
        senderName: participants[1]['name']!,
        senderImageUrl: participants[1]['imageUrl']!,
        content: 'I\'ll be there!',
        time: now.subtract(const Duration(days: 0, hours: 5, minutes: 40)),
        isRead: true,
        isFromCurrentUser: false,
      ),
      MessageDetailModel(
        id: '3',
        senderId: 'current_user',
        senderName: participants[3]['name']!,
        senderImageUrl: participants[3]['imageUrl']!,
        content: 'Count me in. What time?',
        time: now.subtract(const Duration(days: 0, hours: 5, minutes: 35)),
        isRead: true,
        isFromCurrentUser: true,
      ),
      MessageDetailModel(
        id: '4',
        senderId: 'user1',
        senderName: participants[0]['name']!,
        senderImageUrl: participants[0]['imageUrl']!,
        content: '7 PM at the downtown court',
        time: now.subtract(const Duration(days: 0, hours: 5, minutes: 30)),
        isRead: true,
        isFromCurrentUser: false,
      ),
      MessageDetailModel(
        id: '5',
        senderId: 'user3',
        senderName: participants[2]['name']!,
        senderImageUrl: participants[2]['imageUrl']!,
        content: 'Perfect! I\'ll bring some extra water bottles.',
        time: now.subtract(const Duration(days: 0, hours: 5, minutes: 25)),
        isRead: true,
        isFromCurrentUser: false,
      ),
      MessageDetailModel(
        id: '6',
        senderId: 'user2',
        senderName: participants[1]['name']!,
        senderImageUrl: participants[1]['imageUrl']!,
        content: 'Check out this court we might want to try next week',
        time: now.subtract(const Duration(days: 0, hours: 5, minutes: 20)),
        isRead: true,
        isFromCurrentUser: false,
      ),
      MessageDetailModel(
        id: '7',
        senderId: 'user2',
        senderName: participants[1]['name']!,
        senderImageUrl: participants[1]['imageUrl']!,
        content: 'https://example.com/image',
        time: now.subtract(const Duration(days: 0, hours: 5, minutes: 20)),
        isRead: true,
        isFromCurrentUser: false,
        messageType: 'image',
        mediaUrl: 'https://i.pravatar.cc/300?u=basketball_court',
      ),
      MessageDetailModel(
        id: '8',
        senderId: 'current_user',
        senderName: participants[3]['name']!,
        senderImageUrl: participants[3]['imageUrl']!,
        content: 'Looks nice! I\'m in for trying it out.',
        time: now.subtract(const Duration(days: 0, hours: 5, minutes: 15)),
        isRead: true,
        isFromCurrentUser: true,
      ),
      MessageDetailModel(
        id: '9',
        senderId: 'user1',
        senderName: participants[0]['name']!,
        senderImageUrl: participants[0]['imageUrl']!,
        content: conversation.content,
        time: now.subtract(const Duration(days: 0, hours: 0, minutes: 5)),
        isRead: false,
        isFromCurrentUser: false,
      ),
    ];
  }

  /// Get participants for a group conversation
  List<Map<String, String>> getGroupParticipants(MessageModel conversation) {
    // In a real app, this would fetch participants from a database or API
    return [
      {
        'id': 'user1',
        'name': 'Stephen Curry',
        'imageUrl': 'https://i.pravatar.cc/150?u=stephen',
      },
      {
        'id': 'user2',
        'name': 'Kevin Durant',
        'imageUrl': 'https://i.pravatar.cc/150?u=kevin',
      },
      {
        'id': 'user3',
        'name': 'Giannis Antetokounmpo',
        'imageUrl': 'https://i.pravatar.cc/150?u=giannis',
      },
      {
        'id': 'current_user',
        'name': 'You',
        'imageUrl': 'https://i.pravatar.cc/150?u=current_user',
      },
    ];
  }
}
