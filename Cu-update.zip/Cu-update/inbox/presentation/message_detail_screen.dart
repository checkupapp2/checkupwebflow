import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../data/message_detail_data_provider.dart';
import '../domain/models/message_detail_model.dart';
import '../domain/models/message_model.dart';
import 'widgets/message_bubble.dart';
import '../../events/presentation/pages/event_detail_page.dart';
import '../../courts/presentation/pages/unverified_court_detail_page.dart';
import '../../search/presentation/pages/score_detail_screen.dart';
import '../../search/domain/models/score_model.dart';
import '../../brackets/presentation/pages/bracket_detail_page.dart';
import '../../brackets/domain/models/bracket_model.dart';

/// Screen for displaying a message conversation
class MessageDetailScreen extends StatefulWidget {
  /// The message conversation to display
  final MessageModel conversation;

  /// Constructor
  const MessageDetailScreen({
    super.key,
    required this.conversation,
  });

  @override
  State<MessageDetailScreen> createState() => _MessageDetailScreenState();
}

class _MessageDetailScreenState extends State<MessageDetailScreen> {
  late List<MessageDetailModel> _messages;
  late final TextEditingController _messageController;
  late final ScrollController _scrollController;
  late final MessageDetailDataProvider _dataProvider;
  late final FocusNode _messageFocusNode;
  bool _isAttachmentMenuOpen = false;
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    _dataProvider = MessageDetailDataProvider();
    _messages = _dataProvider.getMessageDetails(widget.conversation);
    _messageController = TextEditingController();
    _scrollController = ScrollController();
    _messageFocusNode = FocusNode();

    // Listen for text changes to show typing indicator
    _messageController.addListener(() {
      setState(() {
        _isTyping = _messageController.text.isNotEmpty;
      });
    });

    // Scroll to bottom after frame is rendered
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _messageFocusNode.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _sendMessage() {
    if (_messageController.text.trim().isEmpty) return;

    final newMessage = MessageDetailModel.fromCurrentUser(
      content: _messageController.text.trim(),
    );

    setState(() {
      _messages.add(newMessage);
      _messageController.clear();
      _isTyping = false;
    });

    // Provide haptic feedback
    HapticFeedback.lightImpact();

    // Scroll to the new message
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  void _toggleAttachmentMenu() {
    setState(() {
      _isAttachmentMenuOpen = !_isAttachmentMenuOpen;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          Expanded(
            child: _buildMessageList(),
          ),
          _buildAttachmentMenu(),
          _buildMessageInput(),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    final bool isGroup = widget.conversation.type != 'direct';

    return AppBar(
      backgroundColor: Colors.black,
      elevation: 0,
      leadingWidth: 40,
      titleSpacing: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios, size: 20),
        onPressed: () => Navigator.of(context).pop(),
      ),
      title: Row(
        children: [
          _buildConversationAvatar(),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isGroup
                      ? widget.conversation.groupName ??
                          widget.conversation.senderName
                      : widget.conversation.senderName,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (isGroup)
                  Text(
                    '${_dataProvider.getGroupParticipants(widget.conversation).length} participants',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[400],
                    ),
                  )
                else
                  Text(
                    'Online',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.green[400],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.more_vert),
          onPressed: () {
            // Show more options
          },
        ),
      ],
    );
  }

  Widget _buildConversationAvatar() {
    if (widget.conversation.type == 'direct') {
      return CircleAvatar(
        radius: 20,
        backgroundImage: NetworkImage(widget.conversation.senderImageUrl),
        onBackgroundImageError: (_, __) => const Icon(Icons.person),
      );
    } else {
      return Stack(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundImage: NetworkImage(widget.conversation.groupImageUrl ??
                widget.conversation.senderImageUrl),
            onBackgroundImageError: (_, __) => const Icon(Icons.group),
          ),
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: widget.conversation.type == 'group'
                    ? Colors.blue
                    : Colors.orange,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 2),
              ),
              child: Icon(
                widget.conversation.typeIcon,
                size: 10,
                color: Colors.white,
              ),
            ),
          ),
        ],
      );
    }
  }

  Widget _buildMessageList() {
    // Group messages by date
    final Map<String, List<MessageDetailModel>> groupedMessages = {};

    for (final message in _messages) {
      final date = _getDateString(message.time);
      if (!groupedMessages.containsKey(date)) {
        groupedMessages[date] = [];
      }
      groupedMessages[date]!.add(message);
    }

    // Sort dates
    final sortedDates = groupedMessages.keys.toList()
      ..sort((a, b) => a.compareTo(b));

    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.only(top: 16, bottom: 8),
      itemCount: sortedDates.length,
      itemBuilder: (context, dateIndex) {
        final date = sortedDates[dateIndex];
        final messagesForDate = groupedMessages[date]!;

        return Column(
          children: [
            _buildDateDivider(date),
            ...List.generate(messagesForDate.length, (index) {
              final message = messagesForDate[index];
              final showAvatar = _shouldShowAvatar(messagesForDate, index);
              final showSenderName =
                  _shouldShowSenderName(messagesForDate, index);

              return MessageBubble(
                message: message,
                showAvatar: showAvatar,
                showSenderName:
                    showSenderName && widget.conversation.type != 'direct',
                onGameScoreTap: () => _navigateToGameScore(message),
                onEventTap: () => _navigateToEvent(message),
                onCourtTap: () => _navigateToCourt(message),
                onBracketTap: () => _navigateToBracket(message),
              );
            }),
          ],
        );
      },
    );
  }

  Widget _buildDateDivider(String date) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 16),
      child: Row(
        children: [
          Expanded(
            child: Divider(
              color: Colors.grey[800],
              thickness: 1,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              date,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[500],
              ),
            ),
          ),
          Expanded(
            child: Divider(
              color: Colors.grey[800],
              thickness: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAttachmentMenu() {
    if (!_isAttachmentMenuOpen) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        border: Border(
          top: BorderSide(
            color: Colors.grey[900]!,
            width: 1,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildAttachmentButton(Icons.photo, Colors.green, 'Photo'),
          _buildAttachmentButton(Icons.videocam, Colors.red, 'Video'),
          _buildAttachmentButton(Icons.mic, Colors.blue, 'Audio'),
          _buildAttachmentButton(Icons.location_on, Colors.orange, 'Location'),
          _buildAttachmentButton(
              Icons.insert_drive_file, Colors.purple, 'File'),
          _buildAttachmentButton(Icons.person, Colors.teal, 'Contact'),
        ],
      ),
    );
  }

  Widget _buildAttachmentButton(IconData icon, Color color, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: color.withOpacity(0.2),
            shape: BoxShape.circle,
          ),
          child: IconButton(
            icon: Icon(icon, color: color),
            onPressed: () {
              // Handle attachment
              setState(() {
                _isAttachmentMenuOpen = false;
              });
            },
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[400],
          ),
        ),
      ],
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        border: Border(
          top: BorderSide(
            color: Colors.grey[900]!,
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          IconButton(
            icon: Icon(
              _isAttachmentMenuOpen ? Icons.close : Icons.add,
              color: Colors.grey[400],
            ),
            onPressed: _toggleAttachmentMenu,
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(24),
              ),
              child: TextField(
                controller: _messageController,
                focusNode: _messageFocusNode,
                style: const TextStyle(color: Colors.white),
                maxLines: 5,
                minLines: 1,
                textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(
                  hintText: 'Message',
                  hintStyle: TextStyle(color: Colors.grey[500]),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 10),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          _isTyping
              ? Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 20),
                    onPressed: _sendMessage,
                  ),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.mic, color: Colors.grey[400]),
                      onPressed: () {
                        // Handle voice recording
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.camera_alt, color: Colors.grey[400]),
                      onPressed: () {
                        // Handle camera
                      },
                    ),
                  ],
                ),
        ],
      ),
    );
  }

  String _getDateString(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final messageDate = DateTime(date.year, date.month, date.day);

    if (messageDate == today) {
      return 'Today';
    } else if (messageDate == yesterday) {
      return 'Yesterday';
    } else {
      return '${date.month}/${date.day}/${date.year}';
    }
  }

  bool _shouldShowAvatar(List<MessageDetailModel> messages, int index) {
    if (index == messages.length - 1) return true;

    final currentMessage = messages[index];
    final nextMessage = messages[index + 1];

    return currentMessage.senderId != nextMessage.senderId ||
        nextMessage.time.difference(currentMessage.time).inMinutes > 2;
  }

  void _navigateToGameScore(MessageDetailModel message) {
    if (message.gameScoreData != null) {
      // Create ScoreModel from game score data
      final scoreModel = ScoreModel(
        id: 'score_${message.id}',
        homeTeamName: message.gameScoreData!['homeTeam'] ?? 'Home Team',
        awayTeamName: message.gameScoreData!['awayTeam'] ?? 'Away Team',
        homeScore: message.gameScoreData!['homeScore'] ?? 0,
        awayScore: message.gameScoreData!['awayScore'] ?? 0,
        gameStatus: message.gameScoreData!['gameStatus'] ?? 'Final',
        gameDateTime: DateTime.now(),
        courtName: message.gameScoreData!['gameLocation'] ?? 'Basketball Court',
        courtLocation: message.gameScoreData!['gameLocation'] ?? 'Local Court',
        gameType: '5v5',
        leagueName: 'Local League',
        hostName: 'Game Host',
        homeTeamLogoUrl: message.gameScoreData!['homeTeamLogoUrl'],
        awayTeamLogoUrl: message.gameScoreData!['awayTeamLogoUrl'],
      );

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ScoreDetailScreen(score: scoreModel),
        ),
      );
    }
  }

  void _navigateToEvent(MessageDetailModel message) {
    if (message.eventData != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => EventDetailPage(
            eventId: message.eventData!['id'] ?? 'event_${message.id}',
          ),
        ),
      );
    }
  }

  void _navigateToCourt(MessageDetailModel message) {
    if (message.courtData != null) {
      print('Court navigation called with data: ${message.courtData}');
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => UnverifiedCourtDetailPage(
            courtId: message.courtData!['id'] ?? 'court_${message.id}',
          ),
        ),
      );
    } else {
      print('Court navigation called but courtData is null');
    }
  }

  void _navigateToBracket(MessageDetailModel message) {
    if (message.bracketData != null) {
      // Create BracketModel from bracket data with correct parameters
      final bracketModel = BracketModel(
        id: message.bracketData!['id'] ?? 'bracket_${message.id}',
        name: message.bracketData!['name'] ?? 'Tournament Bracket',
        description:
            message.bracketData!['description'] ?? 'Tournament bracket details',
        startDate: DateTime.now(),
        endDate: DateTime.now().add(const Duration(days: 7)),
        participantCount: message.bracketData!['participantCount'] ?? 8,
        status: BracketStatus.inProgress,
        createdBy: message.bracketData!['createdBy'] ?? 'Tournament Host',
        createdAt: DateTime.now(),
        rounds: null,
        location: message.bracketData!['location'] ?? 'Local Court',
        sport: message.bracketData!['sport'] ?? 'Basketball',
      );

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => BracketDetailPage(bracket: bracketModel),
        ),
      );
    }
  }

  bool _shouldShowSenderName(List<MessageDetailModel> messages, int index) {
    if (index == 0) return true;

    final currentMessage = messages[index];
    final previousMessage = messages[index - 1];

    return currentMessage.senderId != previousMessage.senderId ||
        currentMessage.time.difference(previousMessage.time).inMinutes > 2;
  }
}
