import 'package:flutter/material.dart';
import '../data/inbox_data_provider.dart';
import '../domain/models/alert_model.dart';
import '../domain/models/message_model.dart';
import 'package:check_up_app/core/mixins/resettable_screen_mixin.dart';
import 'message_detail_screen.dart';
import 'create_message_screen.dart';
import 'widgets/widgets.dart';
import '../../feed/presentation/post_detail_screen.dart';
import '../../feed/domain/models/feed_post_model.dart';
import '../../map/presentation/map_screen.dart';
import '../../events/presentation/pages/event_detail_page.dart';
import '../../bookings/presentation/pages/my_bookings_page.dart';
import '../../bookings/presentation/pages/user_booking_details_page.dart';
import '../../bookings/domain/models/booking_model.dart';
import '../../banks/presentation/pages/transaction_detail_page.dart';
import '../../scoreboard/presentation/scoreboard_screen.dart';
import '../../leaderboard/presentation/pages/leaderboard_screen.dart';
import '../../search/presentation/pages/team_detail_page.dart';
import '../../search/domain/models/team_model.dart';
import '../../profile/presentation/pages/profile_page.dart';

/// Inbox screen implementation with tabbed interface for alerts and messages
class InboxScreen extends StatefulWidget {
  /// Constructor
  const InboxScreen({super.key});

  @override
  State<InboxScreen> createState() => _InboxScreenState();
}

class _InboxScreenState extends State<InboxScreen>
    with TickerProviderStateMixin, ResettableScreenMixin<InboxScreen>
    implements ResettableScreen {
  late TabController _tabController;
  late PageController _pageController;
  late List<AlertModel> _alerts;
  late List<MessageModel> _messages;
  int _selectedTabIndex = 0;

  // Animation controller for FAB shimmer effect
  late AnimationController _fabAnimationController;
  late Animation<double> _fabShimmerAnimation;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _pageController = PageController(initialPage: 0);
    _tabController.addListener(_handleTabChange);

    // Initialize FAB shimmer animation
    _fabAnimationController = AnimationController(
      duration: const Duration(milliseconds: 2500),
      vsync: this,
    );
    _fabShimmerAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fabAnimationController,
      curve: Curves.easeInOut,
    ));
    _fabAnimationController.repeat();

    _loadData();
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabChange);
    _tabController.dispose();
    _pageController.dispose();
    _fabAnimationController.dispose();
    super.dispose();
  }

  void _handleTabChange() {
    if (_tabController.indexIsChanging) {
      setState(() {
        _selectedTabIndex = _tabController.index;
      });
      // Sync page controller with tab controller
      _pageController.animateToPage(
        _tabController.index,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  String get screenKey => 'inbox_screen';

  @override
  void resetToDefaultView() {
    if (mounted) {
      // Reset to the first tab (Alerts)
      _tabController.animateTo(0);
      _pageController.animateToPage(
        0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      setState(() {
        _selectedTabIndex = 0;
      });
    }
  }

  void _loadData() {
    // In a real app, this would be an async call to a repository
    final inboxDataProvider = InboxDataProvider();
    _alerts = inboxDataProvider.getAlerts();
    _messages = inboxDataProvider.getMessages();
  }

  /// Calculate unread count for alerts
  int get _unreadAlertsCount {
    return _alerts.where((alert) => !alert.isRead).length;
  }

  /// Calculate unread count for messages
  int get _unreadMessagesCount {
    return _messages.where((message) => !message.isRead).length;
  }

  void _handleTabSelected(int index) {
    setState(() {
      _selectedTabIndex = index;
      _tabController.animateTo(index);
      // Sync page controller with tab selection
      _pageController.animateToPage(
        index,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    });
  }

  void _handleAlertTap(AlertModel alert) {
    // Mark the alert as read (in a real app, this would update the database)
    setState(() {
      final index = _alerts.indexWhere((a) => a.id == alert.id);
      if (index != -1) {
        // Create a new alert with isRead set to true
        _alerts[index] = AlertModel(
          id: alert.id,
          title: alert.title,
          message: alert.message,
          time: alert.time,
          type: alert.type,
          senderImageUrl: alert.senderImageUrl,
          isRead: true,
          targetScreen: alert.targetScreen,
          navigationData: alert.navigationData,
        );
      }
    });

    // Navigate to the appropriate screen based on the alert type
    _navigateToTargetScreen(alert.targetScreen, alert.navigationData);
  }

  void _navigateToTargetScreen(
      String targetScreen, Map<String, dynamic>? navigationData) {
    switch (targetScreen) {
      case 'post_detail':
        final postId = navigationData?['postId'] as String?;
        if (postId != null) {
          // In a real app, you would fetch the post data first
          // For now, we'll just navigate with a mock post
          final post = FeedPostModel(
            id: postId,
            authorId: navigationData?['userId'] as String? ?? 'unknown',
            username: navigationData?['userId'] as String? ?? 'unknown',
            isVerified: false,
            timeAgo: '1h ago',
            content: 'This is a placeholder post content',
            likes: 0,
            comments: 0,
            reposts: 0,
            postType: PostType.standard,
            target: const FeedTarget.global(),
          );

          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => PostDetailScreen(post: post),
            ),
          );
        }
        break;

      case 'profile':
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => const ProfilePage(),
          ),
        );
        break;

      case 'scoreboard':
        // Navigate to search page with scores tab as alternative
        debugPrint(
            'Navigate to scoreboard - using search page scores tab as fallback');
        // In a real app, you would navigate to the appropriate scores/scoreboard screen
        // For now, we'll just show a debug message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Scoreboard feature coming soon'),
            backgroundColor: Color(0xFF1A1A1A),
          ),
        );
        break;

      case 'map':
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => const MapScreen(),
          ),
        );
        break;

      case 'event_detail':
        final eventId = navigationData?['eventId'] as String?;
        final eventTitle = navigationData?['eventTitle'] as String?;

        if (eventId != null) {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => EventDetailPage(
                eventId: eventId,
                title: eventTitle!,
              ),
            ),
          );
        }
        break;

      case 'booking_detail':
        // Create a sample booking for the notification
        final bookingId =
            navigationData?['bookingId'] as String? ?? 'booking123';
        final sampleBooking = CourtBookingModel(
          id: bookingId,
          title: 'Court A - Downtown Recreation Center',
          description: 'Full court reservation confirmed',
          dateTime: DateTime.now().add(const Duration(hours: 24)),
          location: 'Downtown Recreation Center',
          status: BookingStatus.confirmed,
          durationMinutes: 60,
          numberOfPlayers: 8,
          bookingPrice: 25.0,
          hostName: 'Recreation Center',
          hostContact: 'info@downtownrec.com',
          ticketType: 'Full Court Access',
        );

        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) =>
                UserBookingDetailsPage(booking: sampleBooking),
          ),
        );
        break;

      case 'my_bookings':
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => const MyBookingsPage(),
          ),
        );
        break;

      case 'team_detail':
        // Teams feature disabled - show upcoming dialog
        _showUpcomingFeatureDialog('Teams');
        break;

      case 'payment_detail':
        final paymentId = navigationData?['paymentId'] as String?;
        final amount = navigationData?['amount'] as int? ?? 0;
        if (paymentId != null) {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => TransactionDetailPage(
                transactionId: paymentId,
                title: 'Payment Transaction',
                subtitle: 'Court booking payment',
                amount: '\$${amount.toString()}',
                isDebit: false,
              ),
            ),
          );
        }
        break;

      case 'team_detail_page':
        // Create a sample team for the notification
        final teamId = navigationData?['teamId'] as String? ?? 'team789';
        final sampleTeam = TeamModel(
          id: teamId,
          name: 'Lakers Squad',
          handle: '@lakersquad',
          description:
              'Competitive basketball team looking for skilled players',
          logoUrl: 'https://i.pravatar.cc/150?u=lakersquad',
          membersCount: 15,
          followers: 250,
          sport: 'Basketball',
          location: 'Los Angeles, CA',
          isFollowing: false,
        );

        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => TeamDetailPage(team: sampleTeam),
          ),
        );
        break;

      case 'scoreboard_screen':
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => const ScoreboardScreen(),
          ),
        );
        break;

      case 'leaderboard_screen':
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => const LeaderboardScreen(),
          ),
        );
        break;

      default:
        debugPrint('No navigation handler for screen: $targetScreen');
        break;
    }
  }

  void _handleMessageTap(MessageModel message) {
    // Navigate to the message detail screen
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) =>
            MessageDetailScreen(conversation: message),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(1.0, 0.0);
          const end = Offset.zero;
          const curve = Curves.easeInOut;
          var tween =
              Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
          var offsetAnimation = animation.drive(tween);
          return SlideTransition(position: offsetAnimation, child: child);
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  void _handleFloatingActionButton() {
    // Navigate directly to the create message screen
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const CreateMessageScreen(),
      ),
    );
  }

  /// Show upcoming feature dialog for disabled features
  void _showUpcomingFeatureDialog(String featureName) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF1A1A1A),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.upcoming,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                '$featureName Coming Soon',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          content: Text(
            'We\'re working hard to bring you $featureName functionality. Stay tuned for updates!',
            style: TextStyle(
              color: Colors.grey[300],
              fontSize: 14,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              style: TextButton.styleFrom(
                backgroundColor: const Color(0xFFFF9800),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Got it'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          CustomTabBar(
            tabs: const ['Alerts', 'Messages'],
            selectedIndex: _selectedTabIndex,
            onTabSelected: _handleTabSelected,
            unreadCounts: [_unreadAlertsCount, _unreadMessagesCount],
          ),
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: (index) {
                // Sync tab controller with page swipes
                setState(() {
                  _selectedTabIndex = index;
                  _tabController.animateTo(index);
                });
              },
              children: [
                AlertsTab(
                  alerts: _alerts,
                  onAlertTap: _handleAlertTap,
                ),
                MessagesTab(
                  messages: _messages,
                  onMessageTap: _handleMessageTap,
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.black,
      elevation: 0,
      titleSpacing: 0,
      leadingWidth: 0,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.black,
              Colors.black.withValues(alpha: 0.85),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
      ),
      title: LayoutBuilder(
        builder: (context, constraints) {
          return Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Logo with error handling
              Container(
                height: 36,
                width: 36,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF9800).withValues(alpha: 0.3),
                      blurRadius: 8,
                      spreadRadius: 0,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(
                    'assets/images/main_btn.png',
                    height: 48, // Increased from 36 to 48
                    width: 48, // Increased from 36 to 48
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      // Fallback if image fails to load
                      return Container(
                        height: 48, // Increased from 36 to 48
                        width: 48, // Increased from 36 to 48
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.sports_basketball,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                'Inbox',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  letterSpacing: 0.3,
                ),
              ),
              const SizedBox(width: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: const Text(
                  'New',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          );
        },
      ),
      actions: [
        // Search and filter icons removed as requested
      ],
    );
  }

  Widget _buildFloatingActionButton() {
    return AnimatedBuilder(
      animation: _fabShimmerAnimation,
      builder: (context, child) {
        return SizedBox(
          height: 56,
          width: 120,
          child: Stack(
            children: [
              Container(
                height: 56,
                width: 120,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFFFF6B00),
                      Color(0xFFFF9500),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF7D00).withValues(alpha: 0.5),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                    BoxShadow(
                      color: const Color(0xFFFF7D00).withValues(alpha: 0.3),
                      blurRadius: 10,
                      spreadRadius: 2,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
              ),
              FloatingActionButton.extended(
                backgroundColor: Colors.transparent,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(28),
                ),
                onPressed: _handleFloatingActionButton,
                icon: const Icon(
                  Icons.edit,
                  color: Colors.white,
                  size: 20,
                ),
                label: const Text(
                  'Create',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              // Shimmer overlay
              Positioned.fill(
                child: IgnorePointer(
                  child: ClipOval(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment(
                              -1.0 + 2.0 * _fabShimmerAnimation.value, 0.0),
                          end: Alignment(
                              1.0 + 2.0 * _fabShimmerAnimation.value, 0.0),
                          colors: [
                            Colors.transparent,
                            Colors.white.withValues(alpha: 0.15),
                            Colors.transparent,
                          ],
                          stops: const [0.0, 0.5, 1.0],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
