import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../domain/models/message_detail_model.dart';
import '../../../feed/presentation/widgets/court_post_widget.dart';
import '../../../feed/domain/models/feed_post_model.dart';

/// Widget to display a single message bubble in a conversation
class MessageBubble extends StatelessWidget {
  /// The message to display
  final MessageDetailModel message;

  /// Whether to show the sender's avatar
  final bool showAvatar;

  /// Whether to show the sender's name
  final bool showSenderName;

  /// Callback for when a game score message is tapped
  final VoidCallback? onGameScoreTap;

  /// Callback for when an event message is tapped
  final VoidCallback? onEventTap;

  /// Callback for when a court message is tapped
  final VoidCallback? onCourtTap;

  /// Callback for when a bracket message is tapped
  final VoidCallback? onBracketTap;

  /// Constructor
  const MessageBubble({
    super.key,
    required this.message,
    this.showAvatar = true,
    this.showSenderName = true,
    this.onGameScoreTap,
    this.onEventTap,
    this.onCourtTap,
    this.onBracketTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 16),
      child: Row(
        mainAxisAlignment: message.isFromCurrentUser
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!message.isFromCurrentUser && showAvatar)
            _buildAvatar()
          else if (!message.isFromCurrentUser)
            const SizedBox(width: 36),
          if (!message.isFromCurrentUser) const SizedBox(width: 8),
          Flexible(
            child: Column(
              crossAxisAlignment: message.isFromCurrentUser
                  ? CrossAxisAlignment.end
                  : CrossAxisAlignment.start,
              children: [
                if (!message.isFromCurrentUser && showSenderName)
                  Padding(
                    padding: const EdgeInsets.only(left: 12, bottom: 4),
                    child: Text(
                      message.senderName,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[400],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                _buildMessageContent(),
                Padding(
                  padding: EdgeInsets.only(
                    top: 4,
                    right: message.isFromCurrentUser ? 12 : 0,
                    left: message.isFromCurrentUser ? 0 : 12,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        timeago.format(message.time, locale: 'en_short'),
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.grey[500],
                        ),
                      ),
                      if (message.isFromCurrentUser) ...[
                        const SizedBox(width: 4),
                        Icon(
                          message.isSeen ? Icons.done_all : Icons.done,
                          size: 14,
                          color: message.isSeen
                              ? const Color(0xFF4FC3F7)
                              : Colors.grey[500],
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (message.isFromCurrentUser && showAvatar)
            _buildAvatar()
          else if (message.isFromCurrentUser)
            const SizedBox(width: 36),
        ],
      ),
    );
  }

  Widget _buildAvatar() {
    return CircleAvatar(
      radius: 18,
      backgroundImage: NetworkImage(message.senderImageUrl),
      onBackgroundImageError: (_, __) => const Icon(Icons.person),
    );
  }

  Widget _buildMessageContent() {
    switch (message.messageType) {
      case 'image':
        return _buildImageMessage();
      case 'video':
        return _buildVideoMessage();
      case 'event':
        return _buildEventMessage();
      case 'court':
        return _buildCourtMessage();
      case 'gameScore':
        return _buildGameScoreMessage();
      case 'bracket':
        return _buildBracketMessage();
      default:
        return _buildTextMessage();
    }
  }

  Widget _buildTextMessage() {
    return Container(
      constraints: const BoxConstraints(maxWidth: 270),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        gradient: message.isFromCurrentUser
            ? const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : const LinearGradient(
                colors: [Color(0xFF000000), Color(0xFF424242)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: BorderRadius.circular(18).copyWith(
          bottomRight:
              message.isFromCurrentUser ? const Radius.circular(4) : null,
          bottomLeft:
              !message.isFromCurrentUser ? const Radius.circular(4) : null,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 3,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Text(
        message.content,
        style: TextStyle(
          color: message.isFromCurrentUser ? Colors.white : Colors.white,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget _buildImageMessage() {
    return Container(
      constraints: const BoxConstraints(maxWidth: 270, maxHeight: 200),
      decoration: BoxDecoration(
        gradient: message.isFromCurrentUser
            ? const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : const LinearGradient(
                colors: [Color(0xFF000000), Color(0xFF424242)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: BorderRadius.circular(18).copyWith(
          bottomRight:
              message.isFromCurrentUser ? const Radius.circular(4) : null,
          bottomLeft:
              !message.isFromCurrentUser ? const Radius.circular(4) : null,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 3,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18).copyWith(
          bottomRight:
              message.isFromCurrentUser ? const Radius.circular(4) : null,
          bottomLeft:
              !message.isFromCurrentUser ? const Radius.circular(4) : null,
        ),
        child: Image.network(
          message.mediaUrl ?? '',
          fit: BoxFit.cover,
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) return child;
            return Container(
              width: 270,
              height: 150,
              color: Colors.grey[800],
              child: const Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFF9800)),
                ),
              ),
            );
          },
          errorBuilder: (context, error, stackTrace) {
            return Container(
              width: 270,
              height: 150,
              color: Colors.grey[800],
              child: const Center(
                child: Icon(
                  Icons.broken_image,
                  color: Colors.white,
                  size: 40,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildVideoMessage() {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          constraints: const BoxConstraints(maxWidth: 270, maxHeight: 200),
          decoration: BoxDecoration(
            gradient: message.isFromCurrentUser
                ? const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : const LinearGradient(
                    colors: [Color(0xFF000000), Color(0xFF424242)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(18).copyWith(
              bottomRight:
                  message.isFromCurrentUser ? const Radius.circular(4) : null,
              bottomLeft:
                  !message.isFromCurrentUser ? const Radius.circular(4) : null,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.1),
                blurRadius: 3,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18).copyWith(
              bottomRight:
                  message.isFromCurrentUser ? const Radius.circular(4) : null,
              bottomLeft:
                  !message.isFromCurrentUser ? const Radius.circular(4) : null,
            ),
            child: Image.network(
              message.mediaUrl ?? '',
              fit: BoxFit.cover,
              loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) return child;
                return Container(
                  width: 270,
                  height: 150,
                  color: Colors.grey[800],
                  child: const Center(
                    child: CircularProgressIndicator(
                      valueColor:
                          AlwaysStoppedAnimation<Color>(Color(0xFFFF9800)),
                    ),
                  ),
                );
              },
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  width: 270,
                  height: 150,
                  color: Colors.grey[800],
                  child: const Center(
                    child: Icon(
                      Icons.broken_image,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.5),
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.play_arrow,
            color: Colors.white,
            size: 30,
          ),
        ),
      ],
    );
  }

  Widget _buildEventMessage() {
    if (message.eventData == null) return _buildTextMessage();

    return GestureDetector(
        onTap: onEventTap,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 280),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: message.isFromCurrentUser
                ? const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : const LinearGradient(
                    colors: [Color(0xFF000000), Color(0xFF424242)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(18).copyWith(
              bottomRight:
                  message.isFromCurrentUser ? const Radius.circular(4) : null,
              bottomLeft:
                  !message.isFromCurrentUser ? const Radius.circular(4) : null,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Event header
              Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.grey[800],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: message.eventData!['imageUrl'] != null
                          ? Image.network(
                              message.eventData!['imageUrl'],
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  const Icon(
                                Icons.event,
                                color: Colors.grey,
                                size: 30,
                              ),
                            )
                          : const Icon(
                              Icons.event,
                              color: Colors.grey,
                              size: 30,
                            ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          message.eventData!['title'] ?? 'Event',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(
                              Icons.access_time,
                              color: Colors.grey,
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Jul 15',
                              style: TextStyle(
                                color: Colors.grey[400],
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Row(
                          children: [
                            const Icon(
                              Icons.location_on,
                              color: Colors.grey,
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                message.eventData!['location'] ?? 'Location',
                                style: TextStyle(
                                  color: Colors.grey[400],
                                  fontSize: 12,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // Event type badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFFF9800),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  '5v5',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ));
  }

  Widget _buildCourtMessage() {
    if (message.courtData == null) return _buildTextMessage();

    final courtData = CourtData(
      name: message.courtData!['name'] ?? 'Basketball Court',
      address: message.courtData!['address'] ?? 'Location',
      imageUrl: message.courtData!['imageUrl'],
      latitude: message.courtData!['latitude']?.toDouble() ?? 0.0,
      longitude: message.courtData!['longitude']?.toDouble() ?? 0.0,
    );

    return GestureDetector(
        onTap: onCourtTap,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 300),
          decoration: BoxDecoration(
            gradient: message.isFromCurrentUser
                ? const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : const LinearGradient(
                    colors: [Color(0xFF000000), Color(0xFF424242)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(18).copyWith(
              bottomRight:
                  message.isFromCurrentUser ? const Radius.circular(4) : null,
              bottomLeft:
                  !message.isFromCurrentUser ? const Radius.circular(4) : null,
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18).copyWith(
              bottomRight:
                  message.isFromCurrentUser ? const Radius.circular(4) : null,
              bottomLeft:
                  !message.isFromCurrentUser ? const Radius.circular(4) : null,
            ),
            child: CourtPostWidget(
              courtData: courtData,
            ),
          ),
        ));
  }

  Widget _buildGameScoreMessage() {
    if (message.gameScoreData == null) return _buildTextMessage();

    return GestureDetector(
        onTap: onGameScoreTap,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 280),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: message.isFromCurrentUser
                ? const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : const LinearGradient(
                    colors: [Color(0xFF000000), Color(0xFF424242)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(18).copyWith(
              bottomRight:
                  message.isFromCurrentUser ? const Radius.circular(4) : null,
              bottomLeft:
                  !message.isFromCurrentUser ? const Radius.circular(4) : null,
            ),
          ),
          child: Column(
            children: [
              // Game header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: message.gameScoreData!['gameStatus']
                                      ?.toLowerCase() ==
                                  'live'
                              ? const LinearGradient(
                                  colors: [Colors.red, Colors.redAccent],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                )
                              : LinearGradient(
                                  colors: [
                                    Colors.grey[800]!,
                                    Colors.grey[700]!
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: (message.gameScoreData!['gameStatus']
                                              ?.toLowerCase() ==
                                          'live'
                                      ? Colors.red
                                      : Colors.grey[800]!)
                                  .withValues(alpha: 0.3),
                              blurRadius: 4,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (message.gameScoreData!['gameStatus']
                                    ?.toLowerCase() ==
                                'live')
                              Container(
                                width: 6,
                                height: 6,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  shape: BoxShape.circle,
                                ),
                                margin: const EdgeInsets.only(right: 6),
                              ),
                            Text(
                              message.gameScoreData!['gameStatus'] ?? 'Final',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF9800).withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: const Color(0xFFFF9800),
                            width: 1,
                          ),
                        ),
                        child: const Text(
                          '5v5',
                          style: TextStyle(
                            color: Color(0xFFFF9800),
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Text(
                    'Jun 10 • 7:30 PM',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Teams and scores
              Row(
                children: [
                  // Home team
                  Expanded(
                    child: Column(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.grey[800]!, Colors.grey[700]!],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.3),
                                blurRadius: 4,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: message.gameScoreData!['homeTeamLogoUrl'] !=
                                  null
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: Image.network(
                                    message.gameScoreData!['homeTeamLogoUrl'],
                                    fit: BoxFit.cover,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                            const Icon(
                                      Icons.sports_basketball,
                                      color: Colors.grey,
                                      size: 24,
                                    ),
                                  ),
                                )
                              : const Icon(
                                  Icons.sports_basketball,
                                  color: Colors.grey,
                                  size: 24,
                                ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          message.gameScoreData!['homeTeam'] ?? 'Team A',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  // Score
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              '${message.gameScoreData!['homeScore'] ?? 0}',
                              style: TextStyle(
                                color: (message.gameScoreData!['homeScore'] ??
                                            0) >
                                        (message.gameScoreData!['awayScore'] ??
                                            0)
                                    ? const Color(0xFFFF9800)
                                    : Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 24,
                              ),
                            ),
                            const Text(
                              ' - ',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 24,
                              ),
                            ),
                            Text(
                              '${message.gameScoreData!['awayScore'] ?? 0}',
                              style: TextStyle(
                                color: (message.gameScoreData!['awayScore'] ??
                                            0) >
                                        (message.gameScoreData!['homeScore'] ??
                                            0)
                                    ? const Color(0xFFFF9800)
                                    : Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 24,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.3),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            message.gameScoreData!['gameStatus'] ?? 'Final',
                            style: TextStyle(
                              color: Colors.grey[300],
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Away team
                  Expanded(
                    child: Column(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.grey[800]!, Colors.grey[700]!],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.3),
                                blurRadius: 4,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: message.gameScoreData!['awayTeamLogoUrl'] !=
                                  null
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: Image.network(
                                    message.gameScoreData!['awayTeamLogoUrl'],
                                    fit: BoxFit.cover,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                            const Icon(
                                      Icons.sports_basketball,
                                      color: Colors.grey,
                                      size: 24,
                                    ),
                                  ),
                                )
                              : const Icon(
                                  Icons.sports_basketball,
                                  color: Colors.grey,
                                  size: 24,
                                ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          message.gameScoreData!['awayTeam'] ?? 'Team B',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Bottom info
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.sports_basketball,
                        color: Colors.grey,
                        size: 12,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Local League',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Icon(
                        Icons.person,
                        color: Colors.grey,
                        size: 12,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Game Host',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Action buttons
              Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.grey[800],
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Text(
                        'View Full Score',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF9800),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.share,
                          color: Colors.white,
                          size: 12,
                        ),
                        SizedBox(width: 4),
                        Text(
                          'Share',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ));
  }

  Widget _buildBracketMessage() {
    if (message.bracketData == null) return _buildTextMessage();

    return GestureDetector(
        onTap: onBracketTap,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 320),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: message.isFromCurrentUser
                ? const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : const LinearGradient(
                    colors: [Color(0xFF000000), Color(0xFF424242)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            borderRadius: BorderRadius.circular(18).copyWith(
              bottomRight:
                  message.isFromCurrentUser ? const Radius.circular(4) : null,
              bottomLeft:
                  !message.isFromCurrentUser ? const Radius.circular(4) : null,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.orange.shade400,
                          Colors.deepOrange.shade600,
                        ],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.orange.withValues(alpha: 0.3),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.account_tree,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          message.bracketData!['title'] ?? 'Tournament Bracket',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${message.bracketData!['teamCount'] ?? 8} teams • ${message.bracketData!['format'] ?? 'Single Elimination'}',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFF9800),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      message.bracketData!['stage'] ?? 'Quarterfinals',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Bracket matches preview
              Row(
                children: [
                  // Left column
                  Expanded(
                    child: Column(
                      children: [
                        _buildBracketMatch(
                          message.bracketData!['matches']?[0] ??
                              {
                                'team1': 'Lakers',
                                'team2': 'Warriors',
                                'score1': 92,
                                'score2': 85,
                                'isComplete': true,
                                'winner': 'Lakers'
                              },
                        ),
                        const SizedBox(height: 8),
                        _buildBracketMatch(
                          message.bracketData!['matches']?[1] ??
                              {
                                'team1': 'Celtics',
                                'team2': 'Heat',
                                'score1': 78,
                                'score2': 82,
                                'isComplete': true,
                                'winner': 'Heat'
                              },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  // Right column
                  Expanded(
                    child: Column(
                      children: [
                        _buildBracketMatch(
                          message.bracketData!['matches']?[2] ??
                              {
                                'team1': 'Nets',
                                'team2': 'Knicks',
                                'score1': null,
                                'score2': null,
                                'isComplete': false,
                                'winner': null
                              },
                        ),
                        const SizedBox(height: 8),
                        _buildBracketMatch(
                          message.bracketData!['matches']?[3] ??
                              {
                                'team1': 'Bulls',
                                'team2': 'Bucks',
                                'score1': null,
                                'score2': null,
                                'isComplete': false,
                                'winner': null
                              },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ));
  }

  Widget _buildBracketMatch(Map<String, dynamic> match) {
    final isComplete = match['isComplete'] ?? false;
    final winner = match['winner'];

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF2A2A2A),
            Color(0xFF1A1A1A),
          ],
        ),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isComplete
              ? Colors.orange.shade400.withValues(alpha: 0.3)
              : Colors.white.withValues(alpha: 0.08),
          width: 0.5,
        ),
      ),
      child: Column(
        children: [
          _buildBracketTeamRow(
            match['team1'] ?? 'Team 1',
            match['score1'],
            winner == match['team1'],
          ),
          const SizedBox(height: 6),
          Container(
            height: 1,
            color: Colors.white.withValues(alpha: 0.1),
          ),
          const SizedBox(height: 6),
          _buildBracketTeamRow(
            match['team2'] ?? 'Team 2',
            match['score2'],
            winner == match['team2'],
          ),
        ],
      ),
    );
  }

  Widget _buildBracketTeamRow(String teamName, int? score, bool isWinner) {
    return Row(
      children: [
        Container(
          width: 20,
          height: 20,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isWinner
                  ? [Colors.orange.shade400, Colors.deepOrange.shade600]
                  : [const Color(0xFF3A3A3A), const Color(0xFF2A2A2A)],
            ),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Icon(
            Icons.group,
            color: Colors.white,
            size: 12,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            teamName,
            style: TextStyle(
              color: isWinner ? Colors.orange.shade200 : Colors.white,
              fontSize: 11,
              fontWeight: isWinner ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
        if (score != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: isWinner
                  ? Colors.orange.shade400.withValues(alpha: 0.2)
                  : Colors.white.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              score.toString(),
              style: TextStyle(
                color: isWinner ? Colors.orange.shade200 : Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
      ],
    );
  }
}
