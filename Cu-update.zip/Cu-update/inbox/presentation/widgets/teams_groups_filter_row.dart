import 'package:flutter/material.dart';

/// Widget to display a row of circle avatars for teams and groups
class TeamsGroupsFilterRow extends StatelessWidget {
  /// Callback when a team or group is tapped
  final Function(Map<String, dynamic>) onItemTap;

  /// Constructor
  const TeamsGroupsFilterRow({
    super.key,
    required this.onItemTap,
  });

  // Sample data for teams and groups
  static final List<Map<String, dynamic>> _items = [
    {
      'id': 'team1',
      'name': 'Bulls',
      'imageUrl': 'https://i.pravatar.cc/150?u=bulls',
      'type': 'team',
      'groupName': 'Chicago Bulls',
      'lastMessage': 'Coach: Team meeting tomorrow at 9 AM',
    },
    {
      'id': 'team2',
      'name': 'Lakers',
      'imageUrl': 'https://i.pravatar.cc/150?u=lakers',
      'type': 'team',
      'groupName': 'Lakers Fan Club',
      'lastMessage': 'Kevin: Did you all see that amazing dunk?',
    },
    {
      'id': 'group1',
      'name': 'Downtown',
      'imageUrl': 'https://i.pravatar.cc/150?u=ballers',
      'type': 'group',
      'groupName': 'Downtown Ballers',
      'lastMessage': 'Stephen: When are we meeting for practice?',
    },
    {
      'id': 'group2',
      'name': 'Streetball',
      'imageUrl': 'https://i.pravatar.cc/150?u=streetball',
      'type': 'group',
      'groupName': 'Streetball Champions',
      'lastMessage': 'Giannis: Who\'s bringing the water tomorrow?',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120, // Increased height
      padding: const EdgeInsets.symmetric(vertical: 12), // Increased padding
      decoration: BoxDecoration(
        color: Colors.black,
        border: Border(
          bottom: BorderSide(
            color: Colors.grey.withOpacity(0.3), // Slightly more visible border
            width: 1.0, // Increased border width
          ),
        ),
      ),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _items.length,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemBuilder: (context, index) {
          final item = _items[index];
          
          return GestureDetector(
            onTap: () {
              // Navigate directly to the message thread for this team/group
              onItemTap(item);
            },
            child: Container(
              margin: const EdgeInsets.only(right: 24), // Increased spacing between items
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: item['type'] == 'team' ? Colors.orange.withOpacity(0.5) : Colors.blue.withOpacity(0.5),
                            width: 3, // Thicker border
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: (item['type'] == 'team' ? Colors.orange : Colors.blue).withOpacity(0.3),
                              blurRadius: 8,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        padding: const EdgeInsets.all(3), // Increased padding
                        child: _buildAvatar(item),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          padding: const EdgeInsets.all(5), // Increased padding
                          decoration: BoxDecoration(
                            color: item['type'] == 'team' ? Colors.orange : Colors.blue,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.black, width: 2),
                          ),
                          child: Icon(
                            item['type'] == 'team' ? Icons.sports_basketball : Icons.group,
                            size: 10,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    item['name'],
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.normal,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildAvatar(Map<String, dynamic> item) {
    return CircleAvatar(
      radius: 30, // Increased radius
      backgroundImage: NetworkImage(item['imageUrl']),
      backgroundColor: Colors.grey.withOpacity(0.2),
      onBackgroundImageError: (_, __) => const Icon(
        Icons.error,
        color: Colors.white,
        size: 30, // Increased icon size
      ),
    );
  }
}
