import 'package:flutter/material.dart';

/// Custom tab bar for the inbox screen
class CustomTabBar extends StatelessWidget {
  /// List of tab titles
  final List<String> tabs;

  /// Currently selected tab index
  final int selectedIndex;

  /// Callback when a tab is tapped
  final Function(int) onTabSelected;

  /// Unread counts for each tab (optional)
  final List<int>? unreadCounts;

  /// Constructor
  const CustomTabBar({
    super.key,
    required this.tabs,
    required this.selectedIndex,
    required this.onTabSelected,
    this.unreadCounts,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60, // Increased height
      margin: const EdgeInsets.symmetric(
          horizontal: 16, vertical: 12), // Increased vertical margin
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(30), // Increased border radius
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 8,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: List.generate(
          tabs.length,
          (index) => Expanded(
            child: GestureDetector(
              onTap: () => onTabSelected(index),
              child: Container(
                decoration: BoxDecoration(
                  gradient: selectedIndex == index
                      ? const LinearGradient(
                          colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : null,
                  borderRadius:
                      BorderRadius.circular(30), // Increased border radius
                  boxShadow: selectedIndex == index
                      ? [
                          BoxShadow(
                            color: const Color(0xFFFF9800).withOpacity(0.3),
                            blurRadius: 8,
                            spreadRadius: 1,
                          ),
                        ]
                      : null,
                ),
                child: Center(
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Text(
                        tabs[index],
                        style: TextStyle(
                          color: selectedIndex == index
                              ? Colors.white
                              : Colors.grey,
                          fontWeight: selectedIndex == index
                              ? FontWeight.bold
                              : FontWeight.normal,
                          fontSize: 18, // Increased font size
                          letterSpacing: 0.5, // Added letter spacing
                        ),
                      ),
                      // Badge for unread count
                      if (unreadCounts != null &&
                          index < unreadCounts!.length &&
                          unreadCounts![index] > 0)
                        Positioned(
                          right: -12,
                          top: -8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFF4444),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                  color:
                                      const Color(0xFFFF4444).withOpacity(0.3),
                                  blurRadius: 4,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                            constraints: const BoxConstraints(
                              minWidth: 20,
                              minHeight: 20,
                            ),
                            child: Text(
                              unreadCounts![index] > 99
                                  ? '99+'
                                  : unreadCounts![index].toString(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
