import 'package:flutter/material.dart';
import '../../domain/models/message_model.dart';
import 'package:timeago/timeago.dart' as timeago;

/// Widget to display a single message item
class MessageListItem extends StatelessWidget {
  /// The message model to display
  final MessageModel message;
  
  /// Callback when the message is tapped
  final VoidCallback onTap;
  
  /// Constructor
  const MessageListItem({
    super.key,
    required this.message,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16), // Increased vertical padding
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), // Added margin
        decoration: BoxDecoration(
          color: message.isRead ? Colors.black : const Color(0xFF121212),
          border: Border(
            bottom: BorderSide(
              color: Colors.grey.withOpacity(0.3), // More visible border
              width: 1.0, // Increased border width
            ),
          ),
          // Add subtle highlight for unread messages
          gradient: !message.isRead ? LinearGradient(
            colors: [
              const Color(0xFF1A1A1A),
              Colors.black,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ) : null,
        ),
        child: Row(
          children: [
            _buildAvatar(),
            const SizedBox(width: 16), // Increased spacing
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          message.type == 'direct' 
                              ? message.senderName 
                              : message.groupName ?? '',
                          style: TextStyle(
                            fontWeight: message.isRead ? FontWeight.w500 : FontWeight.bold, // Increased weight
                            fontSize: 16, // Increased font size
                            color: Colors.white,
                            letterSpacing: 0.2, // Added letter spacing
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(
                        timeago.format(message.time),
                        style: TextStyle(
                          fontSize: 13, // Increased font size
                          color: Colors.grey[500], // Brighter color
                          fontWeight: FontWeight.w500, // Added weight
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6), // Increased spacing
                  Text(
                    message.content,
                    style: TextStyle(
                      fontSize: 15, // Increased font size
                      color: message.isRead ? Colors.grey[400] : Colors.white,
                      fontWeight: message.isRead ? FontWeight.normal : FontWeight.w500,
                      height: 1.2, // Added line height
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12), // Increased spacing
            if (message.unreadCount > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), // Increased padding
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: const BorderRadius.all(Radius.circular(14)), // Increased radius
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF9800).withOpacity(0.3),
                      blurRadius: 6,
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: Text(
                  message.unreadCount.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14, // Increased font size
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildAvatar() {
    if (message.type == 'direct') {
      return CircleAvatar(
        radius: 30, // Increased radius
        backgroundImage: NetworkImage(message.senderImageUrl),
        backgroundColor: Colors.grey.withOpacity(0.2),
        onBackgroundImageError: (_, __) => const Icon(
          Icons.person,
          size: 30, // Increased icon size
          color: Colors.white70,
        ),
      );
    } else {
      return Stack(
        children: [
          CircleAvatar(
            radius: 30, // Increased radius
            backgroundImage: NetworkImage(message.groupImageUrl ?? message.senderImageUrl),
            backgroundColor: Colors.grey.withOpacity(0.2),
            onBackgroundImageError: (_, __) => const Icon(
              Icons.group,
              size: 30, // Increased icon size
              color: Colors.white70,
            ),
          ),
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(5), // Increased padding
              decoration: BoxDecoration(
                color: message.type == 'group' ? Colors.blue : Colors.orange,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 2.5), // Increased border width
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 4,
                    spreadRadius: 0,
                  ),
                ],
              ),
              child: Icon(
                message.typeIcon,
                size: 14, // Increased icon size
                color: Colors.white,
              ),
            ),
          ),
        ],
      );
    }
  }
}
