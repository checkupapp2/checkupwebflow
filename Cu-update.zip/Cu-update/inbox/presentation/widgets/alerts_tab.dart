import 'package:flutter/material.dart';
import '../../domain/models/alert_model.dart';
import 'alert_list_item.dart';

/// Widget to display the alerts tab content
class AlertsTab extends StatefulWidget {
  /// List of alerts to display
  final List<AlertModel> alerts;

  /// Callback when an alert is tapped
  final Function(AlertModel) onAlertTap;

  /// Constructor
  const AlertsTab({
    super.key,
    required this.alerts,
    required this.onAlertTap,
  });

  @override
  State<AlertsTab> createState() => _AlertsTabState();
}

class _AlertsTabState extends State<AlertsTab> {
  String _selectedFilter = 'All';

  List<AlertModel> get _filteredAlerts {
    List<AlertModel> filtered = widget.alerts;

    // Filter by type
    if (_selectedFilter != 'All') {
      filtered = filtered.where((alert) {
        switch (_selectedFilter) {
          case 'Social':
            return [
              'like',
              'comment',
              'mention',
              'follow',
              'post_shared',
              'video_featured',
              'achievement_unlocked',
              'profile_viewed',
              'content_trending'
            ].contains(alert.type);
          case 'Events':
            return ['event', 'event_reminder'].contains(alert.type);
          case 'Bookings':
            return [
              'booking_confirmed',
              'booking_cancelled',
              'booking_reminder'
            ].contains(alert.type);
          case 'Payments':
            return ['payment_received', 'payment_failed', 'payment_due']
                .contains(alert.type);
          case 'Teams':
            return ['team_invite'].contains(alert.type);
          case 'Scores':
            return [
              'game',
              'game_score_updated',
              'game_finished',
              'personal_stats_updated',
              'leaderboard_position',
              'season_stats_summary',
              'bracket_advancement'
            ].contains(alert.type);
          case 'System':
            return [
              'system_announcement',
              'maintenance_notice',
              'app_update_available',
              'terms_updated',
              'privacy_policy_updated',
              'server_maintenance',
              'new_feature_available',
              'feature_improvement',
              'beta_feature_invite',
              'tutorial_available',
              'tips_and_tricks',
              'community_guidelines'
            ].contains(alert.type);
          default:
            return true;
        }
      }).toList();
    }

    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    final filteredAlerts = _filteredAlerts;

    return Column(
      children: [
        _buildFilterRow(),
        Expanded(
          child: filteredAlerts.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  itemCount: filteredAlerts.length,
                  itemBuilder: (context, index) {
                    final alert = filteredAlerts[index];
                    return AlertListItem(
                      alert: alert,
                      onTap: () => widget.onAlertTap(alert),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildFilterRow() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Color(0xFF1E1E1E),
        border: Border(
          bottom: BorderSide(
            color: Color(0xFF2A2A2A),
            width: 1,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.filter_list,
                color: Colors.white70,
                size: 20,
              ),
              const SizedBox(width: 8),
              const Text(
                'Filters',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const Spacer(),
              if (_selectedFilter != 'All')
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedFilter = 'All';
                    });
                  },
                  child: const Text(
                    'Clear All',
                    style: TextStyle(
                      color: Color(0xFFFF6B35),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildFilterChip('All', _selectedFilter, (value) {
                  setState(() {
                    _selectedFilter = value;
                  });
                }),
                const SizedBox(width: 8),
                _buildFilterChip('Social', _selectedFilter, (value) {
                  setState(() {
                    _selectedFilter = value;
                  });
                }),
                const SizedBox(width: 8),
                _buildFilterChip('Events', _selectedFilter, (value) {
                  setState(() {
                    _selectedFilter = value;
                  });
                }),
                const SizedBox(width: 8),
                _buildFilterChip('Bookings', _selectedFilter, (value) {
                  setState(() {
                    _selectedFilter = value;
                  });
                }),
                const SizedBox(width: 8),
                _buildFilterChip('Payments', _selectedFilter, (value) {
                  setState(() {
                    _selectedFilter = value;
                  });
                }),
                const SizedBox(width: 8),
                _buildFilterChip('Teams', _selectedFilter, (value) {
                  setState(() {
                    _selectedFilter = value;
                  });
                }),
                const SizedBox(width: 8),
                _buildFilterChip('Scores', _selectedFilter, (value) {
                  setState(() {
                    _selectedFilter = value;
                  });
                }),
                const SizedBox(width: 8),
                _buildFilterChip('System', _selectedFilter, (value) {
                  setState(() {
                    _selectedFilter = value;
                  });
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(
      String label, String selectedValue, Function(String) onTap) {
    final isSelected = selectedValue == label;
    return GestureDetector(
      onTap: () => onTap(label),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFFF6B35) : const Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color:
                isSelected ? const Color(0xFFFF6B35) : const Color(0xFF3A3A3A),
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white70,
            fontSize: 12,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF9800).withOpacity(0.3),
                  blurRadius: 15,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: const Icon(
              Icons.notifications_off,
              size: 48,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'No Alerts Yet',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 12),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              'When you get notifications about likes, comments, mentions, and more, you\'ll see them here.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
