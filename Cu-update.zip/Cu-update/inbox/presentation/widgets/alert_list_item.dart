import 'package:flutter/material.dart';
import '../../domain/models/alert_model.dart';
import 'package:timeago/timeago.dart' as timeago;

/// Widget to display a single alert item
class AlertListItem extends StatelessWidget {
  /// The alert model to display
  final AlertModel alert;

  /// Callback when the alert is tapped
  final VoidCallback onTap;

  /// Constructor
  const AlertListItem({
    super.key,
    required this.alert,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: alert.isRead ? Colors.black : const Color(0xFF1A1A1A),
          border: Border(
            bottom: BorderSide(
              color: Colors.grey.withOpacity(0.3),
              width: 0.5,
            ),
          ),
          gradient: !alert.isRead
              ? LinearGradient(
                  colors: [
                    const Color(0xFF1A1A1A),
                    Color(alert.typeColor.value & 0xFFFFFF | 0x0A000000),
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  stops: const [0.85, 1.0],
                )
              : null,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: alert.typeColor.withOpacity(0.3),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: CircleAvatar(
                    radius: 24,
                    backgroundImage: NetworkImage(alert.senderImageUrl),
                    onBackgroundImageError: (_, __) => const Icon(Icons.person),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          alert.typeColor,
                          Color(alert.typeColor.value | 0x30000000),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: alert.typeColor.withOpacity(0.5),
                          blurRadius: 4,
                          spreadRadius: 0,
                        ),
                      ],
                      border: Border.all(color: Colors.black, width: 2),
                    ),
                    child: Icon(
                      alert.typeIcon,
                      size: 14,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    alert.title,
                    style: TextStyle(
                      fontWeight:
                          alert.isRead ? FontWeight.w500 : FontWeight.w800,
                      fontSize: 16,
                      color: Colors.white,
                      letterSpacing: 0.2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    alert.message,
                    style: TextStyle(
                      fontSize: 14,
                      color: alert.isRead ? Colors.grey[400] : Colors.grey[300],
                      height: 1.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    timeago.format(alert.time),
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            if (!alert.isRead)
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF9800), Color(0xFFFF5722)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF9800).withOpacity(0.5),
                      blurRadius: 4,
                      spreadRadius: 0,
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
