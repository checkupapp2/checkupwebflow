import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../search/domain/models/user_model.dart';
import '../domain/models/message_model.dart';
import 'message_detail_screen.dart';

/// Screen for creating a new message
class CreateMessageScreen extends StatefulWidget {
  /// Constructor
  const CreateMessageScreen({super.key});

  @override
  State<CreateMessageScreen> createState() => _CreateMessageScreenState();
}

class _CreateMessageScreenState extends State<CreateMessageScreen> {
  final TextEditingController _searchController = TextEditingController();
  final List<UserModel> _selectedUsers = [];
  List<UserModel> _searchResults = [];
  bool _isSearching = false;
  bool _showRecentContacts = true;

  // Mock data for all app users (expanded to include everyone on the platform)
  final List<UserModel> _allUsers = [
    // Recent contacts / Friends
    UserModel(
      id: '1',
      name: 'John Smith',
      username: 'johnsmith',
      profileImageUrl: 'https://i.pravatar.cc/150?u=1',
      isActive: true,
      bio: 'Basketball enthusiast and coach',
      profileType: 'Coach',
      city: 'Los Angeles',
      state: 'CA',
    ),
    UserModel(
      id: '2',
      name: 'Sarah Johnson',
      username: 'sarahj',
      profileImageUrl: 'https://i.pravatar.cc/150?u=2',
      isActive: false,
      bio: 'Professional player, Lakers fan',
      profileType: 'Player',
      city: 'Miami',
      state: 'FL',
    ),
    UserModel(
      id: '3',
      name: 'Michael Brown',
      username: 'mikebrown',
      profileImageUrl: 'https://i.pravatar.cc/150?u=3',
      isActive: true,
      bio: 'Weekend warrior, pickup games',
      profileType: 'Player',
      city: 'Chicago',
      state: 'IL',
    ),
    UserModel(
      id: '4',
      name: 'Emily Davis',
      username: 'emilyd',
      profileImageUrl: 'https://i.pravatar.cc/150?u=4',
      isActive: false,
      bio: 'Court owner and event host',
      profileType: 'Host',
      city: 'New York',
      state: 'NY',
    ),

    // Extended user base - other app users
    UserModel(
      id: '5',
      name: 'David Wilson',
      username: 'davidw',
      profileImageUrl: 'https://i.pravatar.cc/150?u=5',
      isActive: true,
      bio: 'Personal trainer specializing in basketball',
      profileType: 'Trainer',
      city: 'Phoenix',
      state: 'AZ',
    ),
    UserModel(
      id: '6',
      name: 'Alex Rivera',
      username: 'alexr',
      profileImageUrl: 'https://i.pravatar.cc/150?u=6',
      isActive: true,
      bio: 'College player, looking for pickup games',
      profileType: 'Player',
      city: 'Austin',
      state: 'TX',
    ),
    UserModel(
      id: '7',
      name: 'Jessica Chen',
      username: 'jessicac',
      profileImageUrl: 'https://i.pravatar.cc/150?u=7',
      isActive: false,
      bio: 'Youth basketball coach',
      profileType: 'Coach',
      city: 'Seattle',
      state: 'WA',
    ),
    UserModel(
      id: '8',
      name: 'Marcus Johnson',
      username: 'marcusj',
      profileImageUrl: 'https://i.pravatar.cc/150?u=8',
      isActive: true,
      bio: 'Tournament organizer and referee',
      profileType: 'Host',
      city: 'Atlanta',
      state: 'GA',
    ),
    UserModel(
      id: '9',
      name: 'Lisa Thompson',
      username: 'lisathompson',
      profileImageUrl: 'https://i.pravatar.cc/150?u=9',
      isActive: true,
      bio: 'Sports photographer and blogger',
      profileType: 'Fan',
      city: 'Denver',
      state: 'CO',
    ),
    UserModel(
      id: '10',
      name: 'Carlos Rodriguez',
      username: 'carlosr',
      profileImageUrl: 'https://i.pravatar.cc/150?u=10',
      isActive: false,
      bio: 'Former pro player, now coaching',
      profileType: 'Coach',
      city: 'San Antonio',
      state: 'TX',
    ),
    UserModel(
      id: '11',
      name: 'Amanda Foster',
      username: 'amandaf',
      profileImageUrl: 'https://i.pravatar.cc/150?u=11',
      isActive: true,
      bio: 'High school basketball star',
      profileType: 'Player',
      city: 'Portland',
      state: 'OR',
    ),
    UserModel(
      id: '12',
      name: 'Kevin Park',
      username: 'kevinpark',
      profileImageUrl: 'https://i.pravatar.cc/150?u=12',
      isActive: true,
      bio: 'Basketball equipment specialist',
      profileType: 'Trainer',
      city: 'Las Vegas',
      state: 'NV',
    ),
    UserModel(
      id: '13',
      name: 'Rachel Green',
      username: 'rachelg',
      profileImageUrl: 'https://i.pravatar.cc/150?u=13',
      isActive: false,
      bio: 'Sports medicine doctor',
      profileType: 'Trainer',
      city: 'Boston',
      state: 'MA',
    ),
    UserModel(
      id: '14',
      name: 'Tyler Brooks',
      username: 'tylerb',
      profileImageUrl: 'https://i.pravatar.cc/150?u=14',
      isActive: true,
      bio: 'Street ball legend',
      profileType: 'Player',
      city: 'Detroit',
      state: 'MI',
    ),
    UserModel(
      id: '15',
      name: 'Maya Patel',
      username: 'mayapatel',
      profileImageUrl: 'https://i.pravatar.cc/150?u=15',
      isActive: true,
      bio: 'Basketball analytics expert',
      profileType: 'Fan',
      city: 'San Francisco',
      state: 'CA',
    ),
  ];

  // Recent contacts (most frequently messaged)
  List<UserModel> get _recentContacts => _allUsers.take(4).toList();

  // Suggested contacts (active users)
  List<UserModel> get _suggestedContacts =>
      _allUsers.where((user) => user.isActive).take(6).toList();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _handleSearch(String query) {
    if (query.isEmpty) {
      setState(() {
        _searchResults = [];
        _isSearching = false;
        _showRecentContacts = true;
      });
      return;
    }

    setState(() {
      _isSearching = true;
      _showRecentContacts = false;

      // Enhanced search - search by name, username, bio, city, and profile type
      _searchResults = _allUsers.where((user) {
        final searchLower = query.toLowerCase();
        return user.name.toLowerCase().contains(searchLower) ||
            user.username.toLowerCase().contains(searchLower) ||
            (user.bio?.toLowerCase().contains(searchLower) ?? false) ||
            (user.city?.toLowerCase().contains(searchLower) ?? false) ||
            (user.state?.toLowerCase().contains(searchLower) ?? false) ||
            (user.profileType?.toLowerCase().contains(searchLower) ?? false);
      }).toList();

      // Sort results: exact matches first, then active users, then by name
      _searchResults.sort((a, b) {
        final searchLower = query.toLowerCase();

        // Exact name matches first
        final aExactName = a.name.toLowerCase() == searchLower;
        final bExactName = b.name.toLowerCase() == searchLower;
        if (aExactName && !bExactName) return -1;
        if (!aExactName && bExactName) return 1;

        // Exact username matches second
        final aExactUsername = a.username.toLowerCase() == searchLower;
        final bExactUsername = b.username.toLowerCase() == searchLower;
        if (aExactUsername && !bExactUsername) return -1;
        if (!aExactUsername && bExactUsername) return 1;

        // Active users next
        if (a.isActive && !b.isActive) return -1;
        if (!a.isActive && b.isActive) return 1;

        // Then alphabetical by name
        return a.name.compareTo(b.name);
      });
    });
  }

  void _selectUser(UserModel user) {
    HapticFeedback.lightImpact();

    // Check if user is already selected
    if (_selectedUsers.any((selected) => selected.id == user.id)) {
      return; // User already selected
    }

    setState(() {
      _selectedUsers.add(user);
    });
  }

  void _removeSelectedUser(UserModel user) {
    setState(() {
      _selectedUsers.removeWhere((selected) => selected.id == user.id);
    });
  }

  void _startConversation() {
    if (_selectedUsers.isEmpty) return;

    HapticFeedback.mediumImpact();

    if (_selectedUsers.length == 1) {
      // Single user - direct message
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MessageDetailScreen(
            conversation: _createConversationFromUser(_selectedUsers.first),
          ),
        ),
      );
    } else {
      // Multiple users - group message
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MessageDetailScreen(
            conversation: _createGroupConversation(_selectedUsers),
          ),
        ),
      );
    }
  }

  // Helper method to create a conversation model from a user
  MessageModel _createConversationFromUser(UserModel user) {
    // This creates a new conversation with the selected user
    // In a real app, this would check if a conversation already exists
    return MessageModel(
      id: 'new_${user.id}',
      senderName: user.name,
      senderImageUrl:
          user.profileImageUrl ?? 'https://i.pravatar.cc/150?u=${user.id}',
      content:
          'Start a new conversation...', // Placeholder for new conversation
      time: DateTime.now(),
      isRead: true, // New conversation starts as read
      type: 'direct',
      unreadCount: 0,
    );
  }

  // Helper method to create a group conversation model
  MessageModel _createGroupConversation(List<UserModel> users) {
    final groupName = users.length <= 3
        ? users.map((u) => u.name.split(' ').first).join(', ')
        : '${users.take(2).map((u) => u.name.split(' ').first).join(', ')} +${users.length - 2} others';

    return MessageModel(
      id: 'group_${DateTime.now().millisecondsSinceEpoch}',
      senderName: groupName,
      senderImageUrl: 'https://i.pravatar.cc/150?u=group',
      content: 'Start a group conversation...', // Placeholder for new group
      time: DateTime.now(),
      isRead: true, // New conversation starts as read
      type: 'group',
      groupName: groupName,
      unreadCount: 0,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          'New Message',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          if (_selectedUsers.isNotEmpty)
            Container(
              margin: const EdgeInsets.only(right: 8),
              child: TextButton(
                onPressed: _startConversation,
                style: TextButton.styleFrom(
                  backgroundColor: const Color(0xFFFF7D00),
                  foregroundColor: Colors.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: Text(
                  _selectedUsers.length == 1
                      ? 'Message'
                      : 'Group (${_selectedUsers.length})',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Modern search bar
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _searchController.text.isNotEmpty
                    ? const Color(0xFFFF7D00)
                    : Colors.grey[700]!,
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: TextField(
              controller: _searchController,
              onChanged: _handleSearch,
              style: const TextStyle(color: Colors.white, fontSize: 16),
              decoration: InputDecoration(
                hintText: 'Search for people to message...',
                hintStyle: TextStyle(color: Colors.grey[400], fontSize: 16),
                prefixIcon: Icon(
                  Icons.search,
                  color: _searchController.text.isNotEmpty
                      ? const Color(0xFFFF7D00)
                      : Colors.grey[400],
                  size: 24,
                ),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, color: Colors.grey),
                        onPressed: () {
                          _searchController.clear();
                          _handleSearch('');
                        },
                      )
                    : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 16,
                ),
              ),
            ),
          ),

          // Selected users chips
          if (_selectedUsers.isNotEmpty)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A1A),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey[800]!),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'To: ${_selectedUsers.length} recipient${_selectedUsers.length > 1 ? 's' : ''}',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _selectedUsers
                        .map((user) => _buildUserChip(user))
                        .toList(),
                  ),
                ],
              ),
            ),

          // Content area
          Expanded(
            child: _isSearching && _searchResults.isNotEmpty
                ? _buildSearchResults()
                : _showRecentContacts
                    ? _buildRecentContactsView()
                    : _buildEmptySearchState(),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchResults() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: _searchResults.length,
      itemBuilder: (context, index) {
        final user = _searchResults[index];
        return _buildUserListItem(user);
      },
    );
  }

  Widget _buildRecentContactsView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          _buildSectionHeader('Recent', Icons.history),
          const SizedBox(height: 12),
          ..._recentContacts.map((user) => _buildUserListItem(user)),
          const SizedBox(height: 24),
          _buildSectionHeader('Suggested', Icons.people_outline),
          const SizedBox(height: 12),
          ..._suggestedContacts.map((user) => _buildUserListItem(user)),
          const SizedBox(height: 100), // Bottom padding
        ],
      ),
    );
  }

  Widget _buildEmptySearchState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFFF6B00), Color(0xFFFF9500)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF7D00).withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: const Icon(
              Icons.search,
              size: 48,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Start a new conversation',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'Search for someone to message or select from your recent contacts',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[400],
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[800]!),
          ),
          child: Icon(
            icon,
            color: const Color(0xFFFF7D00),
            size: 16,
          ),
        ),
        const SizedBox(width: 12),
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildUserListItem(UserModel user) {
    final isSelected = _selectedUsers.any((selected) => selected.id == user.id);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFF2A2A2A) : const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSelected ? const Color(0xFFFF7D00) : Colors.grey[800]!,
          width: isSelected ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _selectUser(user),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Stack(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: user.isActive
                              ? [
                                  const Color(0xFF4CAF50),
                                  const Color(0xFF2E7D32)
                                ]
                              : [
                                  const Color(0xFFFF9800),
                                  const Color(0xFFFF5722)
                                ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: (user.isActive
                                    ? const Color(0xFF4CAF50)
                                    : const Color(0xFFFF9800))
                                .withOpacity(0.3),
                            blurRadius: 8,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.all(2),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(25),
                        child: user.profileImageUrl != null
                            ? Image.network(
                                user.profileImageUrl!,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    _buildProfilePlaceholder(user),
                              )
                            : _buildProfilePlaceholder(user),
                      ),
                    ),
                    if (user.isActive)
                      Positioned(
                        right: 2,
                        bottom: 2,
                        child: Container(
                          width: 14,
                          height: 14,
                          decoration: BoxDecoration(
                            color: const Color(0xFF4CAF50),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.black, width: 2),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              user.name,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          if (user.profileType != null)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFF7D00).withOpacity(0.2),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color:
                                      const Color(0xFFFF7D00).withOpacity(0.3),
                                ),
                              ),
                              child: Text(
                                user.profileType!,
                                style: const TextStyle(
                                  color: Color(0xFFFF7D00),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '@${user.username}',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 14,
                        ),
                      ),
                      if (user.city != null && user.state != null) ...[
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(
                              Icons.location_on,
                              color: Colors.grey[500],
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '${user.city}, ${user.state}',
                              style: TextStyle(
                                color: Colors.grey[500],
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ],
                      if (user.bio != null && user.bio!.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(
                          user.bio!,
                          style: TextStyle(
                            color: Colors.grey[400],
                            fontSize: 12,
                            fontStyle: FontStyle.italic,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                      if (user.isActive)
                        Container(
                          margin: const EdgeInsets.only(top: 6),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFF4CAF50).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: const Color(0xFF4CAF50).withOpacity(0.3),
                            ),
                          ),
                          child: const Text(
                            'Active now',
                            style: TextStyle(
                              color: Color(0xFF4CAF50),
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                if (isSelected)
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: const BoxDecoration(
                      color: Color(0xFFFF7D00),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.check,
                      color: Colors.white,
                      size: 16,
                    ),
                  )
                else
                  Icon(
                    Icons.add_circle_outline,
                    color: Colors.grey[400],
                    size: 20,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfilePlaceholder(UserModel user) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[800],
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildUserChip(UserModel user) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFF6B00), Color(0xFFFF9500)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFFF7D00).withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 12,
            backgroundImage: user.profileImageUrl != null
                ? NetworkImage(user.profileImageUrl!)
                : null,
            backgroundColor: Colors.white24,
            child: user.profileImageUrl == null
                ? Text(
                    user.name[0],
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  )
                : null,
          ),
          const SizedBox(width: 8),
          Text(
            user.name.split(' ').first, // Show first name only
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: () => _removeSelectedUser(user),
            child: Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.close,
                color: Colors.white,
                size: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
