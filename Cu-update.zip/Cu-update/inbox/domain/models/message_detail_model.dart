/// Model representing a single message in a conversation
class MessageDetailModel {
  /// Unique identifier for the message
  final String id;

  /// Sender's ID
  final String senderId;

  /// Sender's name
  final String senderName;

  /// Sender's profile image URL
  final String senderImageUrl;

  /// Message content
  final String content;

  /// Time when the message was sent
  final DateTime time;

  /// Whether the message has been read
  final bool isRead;

  /// Whether the message is from the current user
  final bool isFromCurrentUser;

  /// Message type: 'text', 'image', 'video', 'event', 'court', 'gameScore', etc.
  final String messageType;

  /// URL for media content (if applicable)
  final String? mediaUrl;

  /// Event data for event type messages
  final Map<String, dynamic>? eventData;

  /// Court data for court type messages
  final Map<String, dynamic>? courtData;

  /// Game score data for game score type messages
  final Map<String, dynamic>? gameScoreData;

  /// Bracket data for tournament bracket type messages
  final Map<String, dynamic>? bracketData;

  /// Whether the message has been delivered
  final bool isDelivered;

  /// Whether the message has been seen by the recipient
  final bool isSeen;

  /// Constructor
  const MessageDetailModel({
    required this.id,
    required this.senderId,
    required this.senderName,
    required this.senderImageUrl,
    required this.content,
    required this.time,
    this.isRead = false,
    this.isFromCurrentUser = false,
    this.messageType = 'text',
    this.mediaUrl,
    this.eventData,
    this.courtData,
    this.gameScoreData,
    this.bracketData,
    this.isDelivered = true,
    this.isSeen = false,
  });

  /// Create a new message from the current user
  static MessageDetailModel fromCurrentUser({
    required String content,
    String messageType = 'text',
    String? mediaUrl,
    Map<String, dynamic>? eventData,
    Map<String, dynamic>? courtData,
    Map<String, dynamic>? gameScoreData,
    Map<String, dynamic>? bracketData,
  }) {
    return MessageDetailModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      senderId: 'current_user',
      senderName: 'You',
      senderImageUrl: 'https://i.pravatar.cc/150?u=current_user',
      content: content,
      time: DateTime.now(),
      isFromCurrentUser: true,
      messageType: messageType,
      mediaUrl: mediaUrl,
      eventData: eventData,
      courtData: courtData,
      gameScoreData: gameScoreData,
      bracketData: bracketData,
      isDelivered: true,
      isSeen: false,
    );
  }
}
