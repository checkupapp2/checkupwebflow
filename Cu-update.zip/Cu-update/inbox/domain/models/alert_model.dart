import 'package:flutter/material.dart';

/// Model representing an alert notification
class AlertModel {
  /// Unique identifier for the alert
  final String id;

  /// Title of the alert
  final String title;

  /// Message content of the alert
  final String message;

  /// Time when the alert was created
  final DateTime time;

  /// Type of alert (e.g., 'like', 'comment', 'mention', 'follow')
  final String type;

  /// Whether the alert has been read
  final bool isRead;

  /// URL to the sender's profile image
  final String senderImageUrl;

  /// Target screen to navigate to when alert is tapped
  final String targetScreen;

  /// Additional data needed for navigation (e.g., post ID, user ID)
  final Map<String, dynamic>? navigationData;

  /// Icon to display based on the alert type
  IconData get typeIcon {
    switch (type) {
      case 'like':
        return Icons.favorite;
      case 'comment':
        return Icons.comment;
      case 'mention':
        return Icons.alternate_email;
      case 'follow':
        return Icons.person_add;
      case 'event':
        return Icons.event;
      case 'game':
        return Icons.sports_basketball;
      // High Priority Alert Types
      case 'event_reminder':
        return Icons.schedule;
      case 'booking_confirmed':
        return Icons.check_circle;
      case 'booking_cancelled':
        return Icons.cancel;
      case 'booking_reminder':
        return Icons.access_time;
      case 'team_invite':
        return Icons.group_add;
      case 'payment_received':
        return Icons.payment;
      case 'payment_failed':
        return Icons.error;
      case 'payment_due':
        return Icons.account_balance_wallet;
      // Medium Priority Alert Types - Social Interactions
      case 'post_shared':
        return Icons.share;
      case 'video_featured':
        return Icons.star;
      case 'achievement_unlocked':
        return Icons.emoji_events;
      case 'profile_viewed':
        return Icons.visibility;
      case 'content_trending':
        return Icons.trending_up;
      // Medium Priority Alert Types - Score Updates
      case 'game_score_updated':
        return Icons.scoreboard;
      case 'game_finished':
        return Icons.sports_score;
      case 'personal_stats_updated':
        return Icons.analytics;
      case 'leaderboard_position':
        return Icons.leaderboard;
      case 'season_stats_summary':
        return Icons.assessment;
      case 'bracket_advancement':
        return Icons.emoji_events;
      // Medium Priority Alert Types - Nearby Activities
      case 'nearby_activity':
        return Icons.location_on;
      case 'weather_alert':
        return Icons.cloud;
      case 'court_status_change':
        return Icons.info;
      // Low Priority Alert Types - System Announcements
      case 'system_announcement':
        return Icons.campaign;
      case 'maintenance_notice':
        return Icons.build;
      case 'app_update_available':
        return Icons.system_update;
      case 'terms_updated':
        return Icons.description;
      case 'privacy_policy_updated':
        return Icons.privacy_tip;
      case 'server_maintenance':
        return Icons.settings;
      // Low Priority Alert Types - Feature Updates
      case 'new_feature_available':
        return Icons.new_releases;
      case 'feature_improvement':
        return Icons.upgrade;
      case 'beta_feature_invite':
        return Icons.science;
      case 'tutorial_available':
        return Icons.school;
      case 'tips_and_tricks':
        return Icons.lightbulb;
      case 'community_guidelines':
        return Icons.rule;
      default:
        return Icons.notifications;
    }
  }

  /// Color to display based on the alert type
  Color get typeColor {
    switch (type) {
      case 'like':
        return Colors.red;
      case 'comment':
        return Colors.blue;
      case 'mention':
        return Colors.purple;
      case 'follow':
        return Colors.green;
      case 'event':
        return Colors.amber;
      case 'game':
        return Colors.orange;
      // High Priority Alert Types
      case 'event_reminder':
        return Colors.deepOrange;
      case 'booking_confirmed':
        return Colors.green;
      case 'booking_cancelled':
        return Colors.red;
      case 'booking_reminder':
        return Colors.orange;
      case 'team_invite':
        return Colors.blue;
      case 'payment_received':
        return Colors.green;
      case 'payment_failed':
        return Colors.red;
      case 'payment_due':
        return Colors.amber;
      // Medium Priority Alert Types - Social Interactions
      case 'post_shared':
        return Colors.cyan;
      case 'video_featured':
        return Colors.yellow;
      case 'achievement_unlocked':
        return Colors.purple;
      case 'profile_viewed':
        return Colors.teal;
      case 'content_trending':
        return Colors.pink;
      // Medium Priority Alert Types - Score Updates
      case 'game_score_updated':
        return Colors.indigo;
      case 'game_finished':
        return Colors.deepPurple;
      case 'personal_stats_updated':
        return Colors.lightBlue;
      case 'leaderboard_position':
        return Colors.lime;
      case 'season_stats_summary':
        return Colors.brown;
      case 'bracket_advancement':
        return Colors.purple;
      // Medium Priority Alert Types - Nearby Activities
      case 'nearby_activity':
        return Colors.green;
      case 'weather_alert':
        return Colors.blueGrey;
      case 'court_status_change':
        return Colors.orange;
      // Low Priority Alert Types - System Announcements
      case 'system_announcement':
        return Colors.grey;
      case 'maintenance_notice':
        return Colors.blueGrey;
      case 'app_update_available':
        return Colors.blue;
      case 'terms_updated':
        return Colors.grey;
      case 'privacy_policy_updated':
        return Colors.grey;
      case 'server_maintenance':
        return Colors.blueGrey;
      // Low Priority Alert Types - Feature Updates
      case 'new_feature_available':
        return Colors.green;
      case 'feature_improvement':
        return Colors.lightGreen;
      case 'beta_feature_invite':
        return Colors.deepPurple;
      case 'tutorial_available':
        return Colors.blue;
      case 'tips_and_tricks':
        return Colors.amber;
      case 'community_guidelines':
        return Colors.grey;
      default:
        return Colors.grey;
    }
  }

  /// Constructor
  const AlertModel({
    required this.id,
    required this.title,
    required this.message,
    required this.time,
    required this.type,
    required this.senderImageUrl,
    this.isRead = false,
    this.targetScreen = '',
    this.navigationData,
  });
}
