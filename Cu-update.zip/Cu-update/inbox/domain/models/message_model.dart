import 'package:flutter/material.dart';

/// Model representing a message in the inbox
class MessageModel {
  /// Unique identifier for the message
  final String id;
  
  /// Sender's name
  final String senderName;
  
  /// Sender's profile image URL
  final String senderImageUrl;
  
  /// Message content
  final String content;
  
  /// Time when the message was sent
  final DateTime time;
  
  /// Whether the message has been read
  final bool isRead;
  
  /// Type of message: 'direct', 'group', or 'team'
  final String type;
  
  /// Group or team name (if applicable)
  final String? groupName;
  
  /// Group or team image URL (if applicable)
  final String? groupImageUrl;
  
  /// Number of unread messages in this conversation
  final int unreadCount;
  
  /// Constructor
  const MessageModel({
    required this.id,
    required this.senderName,
    required this.senderImageUrl,
    required this.content,
    required this.time,
    required this.type,
    this.isRead = false,
    this.groupName,
    this.groupImageUrl,
    this.unreadCount = 0,
  });
  
  /// Icon to display based on the message type
  IconData get typeIcon {
    switch (type) {
      case 'direct':
        return Icons.person;
      case 'group':
        return Icons.group;
      case 'team':
        return Icons.sports_basketball;
      default:
        return Icons.message;
    }
  }
}
